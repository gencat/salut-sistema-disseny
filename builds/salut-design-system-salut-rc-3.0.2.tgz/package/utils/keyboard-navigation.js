import { getCustomElementSuffix as l } from "../api/custom-element-scope.js";
function u(e) {
  e && e.focus();
}
function b(e, o, n) {
  let s = 0;
  const t = e.querySelectorAll(n), c = t.length - 1;
  o === t[0] ? u(t[c]) : (t.forEach((i, a) => {
    i === o && (s = a);
  }), u(t[s - 1]));
}
function f(e, o, n) {
  let s = 0;
  const t = e.querySelectorAll(n), c = t.length - 1;
  o === t[c] ? u(t[0]) : (t.forEach((i, a) => {
    i === o && (s = a);
  }), u(t[s + 1]));
}
function d(e, o, n) {
  e.querySelector(`${n}[tabindex="0"]`)?.setAttribute("tabindex", "-1"), o.setAttribute("tabindex", "0"), o.click();
}
function x(e) {
  if (!e) return null;
  const o = [
    "button",
    "[href]",
    "input",
    "select",
    "textarea",
    '[tabindex]:not([tabindex="-1"])',
    `dss-button${l()}`,
    `dss-icon-button${l()}`,
    `dss-badge-button${l()}`,
    `dss-split-button${l()}`
  ];
  return Array.from(e.querySelectorAll(o.join(", ")))[0];
}
export {
  x as getNextFocusable,
  f as moveFocusToNextTarget,
  b as moveFocusToPreviousTarget,
  u as moveFocusToTarget,
  d as onKeyboardEnter
};
//# sourceMappingURL=keyboard-navigation.js.map
