import { autoUpdate as s, computePosition as h, offset as m, flip as w, shift as x, size as y } from "@floating-ui/dom";
function b(e) {
  e.clearHideTimeout(), e.clearShowTimeout();
  const t = window.setTimeout(() => {
    e.onExecuteShow();
  }, e.delay);
  e.setShowTimeout(t);
}
function p(e) {
  e.initialParent || e.setInitialParent(e.floatingEl.parentElement), e.portalManager && e.floatingEl.parentElement !== e.portalManager && e.portalManager.appendChild(e.floatingEl), setTimeout(() => {
    e.floatingEl.classList.add(e.visibleClass ?? "visible");
  }, 0), e.parentEl && e.onUpdateFloating();
}
function P(e) {
  e.clearShowTimeout(), e.floatingEl.classList.remove(e.visibleClass ?? "visible");
  const t = window.setTimeout(() => {
    e.cleanupAutoUpdate?.(), e.setCleanupAutoUpdate(void 0), e.initialParent && e.floatingEl.parentElement !== e.initialParent && (e.initialParent.appendChild(e.floatingEl), e.resetPosition && (e.floatingEl.style.left = "0", e.floatingEl.style.top = "0"));
  }, e.hideDelay ?? 240);
  e.setHideTimeout(t);
}
function T(e) {
  if (!e.referenceEl) return;
  const t = s(e.referenceEl, e.floatingEl, () => e.onUpdatePosition());
  e.setCleanupAutoUpdate(t);
}
async function v(e, t, r = {}) {
  const { placement: d = "bottom", strategy: l = "fixed", offsetPx: f = 8, paddingPx: i = 16, matchWidth: u = !0 } = r, { x: c, y: g } = await h(e, t, {
    placement: d,
    strategy: l,
    middleware: [
      m(f),
      w({
        padding: i,
        boundary: "clippingAncestors",
        rootBoundary: "viewport"
      }),
      x({
        padding: i,
        rootBoundary: "viewport",
        crossAxis: !0
      }),
      y({
        padding: i,
        apply({ rects: o, elements: a, availableWidth: n }) {
          a.floating.style.width = "", a.floating.style.maxWidth = "", Object.assign(a.floating.style, {
            maxWidth: `${n}px`,
            boxSizing: "border-box"
          }), u ? a.floating.style.width = `${Math.min(o.reference.width, n)}px` : a.floating.style.width = "max-content";
        }
      })
    ]
  });
  Object.assign(t.style, {
    left: `${c}px`,
    top: `${g}px`,
    position: l
  });
}
export {
  p as executeShow,
  P as hideFloating,
  b as scheduleShow,
  T as updateFloatingCombobox,
  v as updateFloatingPosition
};
//# sourceMappingURL=floating-combobox.js.map
