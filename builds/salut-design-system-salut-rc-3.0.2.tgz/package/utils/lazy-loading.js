function s(n, e, r) {
  if (typeof window.IntersectionObserver != "function") {
    e();
    return;
  }
  new IntersectionObserver(
    (o, t) => {
      o[0].isIntersecting && (t.disconnect(), e());
    },
    {
      rootMargin: "80px",
      // pre-carga antes de verse
      ...r
    }
  ).observe(n);
}
export {
  s as lazyLoading
};
//# sourceMappingURL=lazy-loading.js.map
