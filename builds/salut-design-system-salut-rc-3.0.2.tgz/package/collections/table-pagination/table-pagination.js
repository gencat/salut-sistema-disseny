import { LitElement as d, unsafeCSS as o } from "lit";
import { property as i } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import { booleanType as g } from "../../utils/property-types.js";
import l from "./table-pagination.style.css.js";
import { template as x } from "./table-pagination.template.js";
var S = Object.defineProperty, c = Object.getOwnPropertyDescriptor, n = (h, e, t, p) => {
  for (var s = c(e, t), a = h.length - 1, _; a >= 0; a--)
    (_ = h[a]) && (s = _(e, t, s) || s);
  return s && S(e, t, s), s;
};
class r extends d {
  constructor() {
    super(...arguments), this._length = 0, this._pageSizeOptions = [], this._pageSize = 10, this._totalPages = 0, this._currentIndex = 1, this._startIndex = 1, this._endIndex = this._pageSize, this._rowsPerPageText = "Files per pàgina", this._resultsText = "Resultats", this._pageSizeOptionsDisabled = !1, this._hidePaginationResults = !1;
  }
  static get styles() {
    return [o(u), o(l)];
  }
  set length(e) {
    const t = this._length;
    this._length = e, this.requestUpdate("length", t);
  }
  get length() {
    return this._length;
  }
  set pageSize(e) {
    const t = this._pageSize;
    this._pageSize = e, this.requestUpdate("pageSize", t);
  }
  get pageSize() {
    return this._pageSize;
  }
  set pageSizeOptions(e) {
    const t = this._pageSizeOptions;
    this._pageSizeOptions = e, this.requestUpdate("pageSizeOptions", t);
  }
  get pageSizeOptions() {
    return this._pageSizeOptions;
  }
  set pageSizeOptionsDisabled(e) {
    const t = this._pageSizeOptionsDisabled;
    this._pageSizeOptionsDisabled = e, this.requestUpdate("pageSizeOptionsDisabled", t);
  }
  get pageSizeOptionsDisabled() {
    return this._pageSizeOptionsDisabled;
  }
  set currentIndex(e) {
    const t = this._currentIndex;
    this._currentIndex = e, this.requestUpdate("currentIndex", t);
  }
  get currentIndex() {
    return this._currentIndex;
  }
  set rowsPerPageText(e) {
    const t = this._rowsPerPageText;
    this._rowsPerPageText = e, this.requestUpdate("rowsPerPageText", t);
  }
  get rowsPerPageText() {
    return this._rowsPerPageText;
  }
  set resultsText(e) {
    const t = this._resultsText;
    this._resultsText = e, this.requestUpdate("resultsText", t);
  }
  get resultsText() {
    return this._resultsText;
  }
  set hidePaginationResults(e) {
    const t = this._hidePaginationResults;
    this._hidePaginationResults = e, this.requestUpdate("hidePaginationResults", t);
  }
  get hidePaginationResults() {
    return this._hidePaginationResults;
  }
  _next() {
    this._currentIndex++, this._startIndex += this._pageSize, this._endIndex += this._pageSize, this._currentIndex === this._totalPages && (this._endIndex = this._length), this._emitCurrentPage(), this.requestUpdate();
  }
  _prev() {
    const e = Math.abs(this._startIndex - this._endIndex) + 1;
    this._startIndex -= this._pageSize, this._endIndex -= this._currentIndex === this._totalPages ? e : this._pageSize, this._currentIndex--, this._emitCurrentPage(), this.requestUpdate();
  }
  _handleChange() {
    const e = this.shadowRoot?.querySelector("#pagination-select");
    this._pageSize = Number(e.value), this._reload(this._startIndex), this._emitCurrentPage(), this.requestUpdate();
  }
  _emitCurrentPage() {
    this.dispatchEvent(
      new CustomEvent("page-changed", {
        detail: {
          currentIndex: this._currentIndex,
          startIndex: this._startIndex,
          endIndex: this._endIndex,
          pageSize: this._pageSize
        },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _reload(e) {
    this._currentIndex = Math.ceil(e / this._pageSize), this._reset(!0);
  }
  _reset(e) {
    this._totalPages = Math.ceil(this._length / this._pageSize), e || (this._currentIndex < 1 ? this._currentIndex = 1 : this._currentIndex > this._totalPages && (this._currentIndex = this._totalPages)), this._startIndex = (this._currentIndex - 1) * this._pageSize + 1, this._endIndex = this._startIndex - 1 + this._pageSize, this._endIndex > this._length && (this._endIndex = this._length);
  }
  _getDefaultPageSize() {
    const e = this._pageSizeOptions.includes(this._pageSize);
    return this._pageSizeOptions?.length ? e ? this._pageSize : this._pageSizeOptions[0] : this._pageSize;
  }
  _printStartIndex() {
    return this._startIndex <= 0 || this._length <= 0 ? "0" : this._startIndex.toString();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._pageSize = this._getDefaultPageSize(), this._reset(), this._emitCurrentPage(), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(e) {
    const t = e.has("length"), p = e.has("pageSize"), s = e.has("pageSizeOptions"), a = e.has("currentIndex");
    (t || p || s || a) && (this._pageSize = this._getDefaultPageSize(), this._reset(), a && this._emitCurrentPage(), this.requestUpdate());
  }
  render() {
    return x(this);
  }
}
n([
  i({ type: Number })
], r.prototype, "length");
n([
  i({ type: Number })
], r.prototype, "pageSize");
n([
  i({ type: Array })
], r.prototype, "pageSizeOptions");
n([
  i(g)
], r.prototype, "pageSizeOptionsDisabled");
n([
  i({ type: Number })
], r.prototype, "currentIndex");
n([
  i({ type: String })
], r.prototype, "rowsPerPageText");
n([
  i({ type: String })
], r.prototype, "resultsText");
n([
  i(g)
], r.prototype, "hidePaginationResults");
export {
  r as TablePagination
};
//# sourceMappingURL=table-pagination.js.map
