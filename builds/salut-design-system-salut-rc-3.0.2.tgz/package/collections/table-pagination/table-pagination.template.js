import { html as t } from "lit/static-html.js";
const e = (a) => t`
    <div class="pagination__container">
      ${a._hidePaginationResults ? null : t`
            <span class="pagination__results"
              >${a._length} ${a._resultsText}</span
            >
            <div class="pagination__divider"></div>
          `}
      ${a._pageSizeOptions?.length ? t`
            <div class="pagination__row-page">
              <span class="pagination__text">${a._rowsPerPageText}</span>
              <div class="pagination__select">
                <select
                  id="pagination-select"
                  class="pagination-select-options"
                  @change=${a._handleChange}
                  aria-label="Seleccionar la mida de la pàgina"
                  ?disabled=${a._pageSizeOptionsDisabled}
                >
                  ${a._pageSizeOptions.map(
  (i) => t`
                        <option
                          value="${i}"
                          .selected=${a._pageSize === i}
                        >
                          ${i}
                        </option>
                      `
)}
                </select>
                <span class="material-symbols-rounded pagination__arrow-down">
                  keyboard_arrow_down
                </span>
              </div>
            </div>
            <span class="pagination__text">
              ${a._printStartIndex()}-${a._endIndex.toString()} de
              ${a._length}
            </span>
            <div class="pagination__buttons">
              <button
                type="button"
                class="pagination__button ${a._currentIndex}"
                @click=${a._prev}
                ?disabled=${+a._currentIndex == 1 || +a._length <= 0}
              >
                <span>keyboard_arrow_left</span>
              </button>
              <button
                type="button"
                class="pagination__button"
                @click=${a._next}
                ?disabled=${+a._currentIndex == +a._totalPages || +a._length <= 0}
              >
                <span>keyboard_arrow_right</span>
              </button>
            </div>
          ` : t`
            <button
              type="button"
              class="pagination__button"
              @click=${a._prev}
              ?disabled=${+a._currentIndex == 1 || +a._length <= 0}
            >
              <span>keyboard_arrow_left</span>
            </button>
            <span class="pagination__text">
              ${a._printStartIndex()} - ${a._endIndex.toString()} de
              ${a._length.toString()}
            </span>
            <button
              type="button"
              class="pagination__button"
              @click=${a._next}
              ?disabled=${+a._currentIndex === a._totalPages || +a._length <= 0}
            >
              <span>keyboard_arrow_right</span>
            </button>
          `}
    </div>
  `;
export {
  e as template
};
//# sourceMappingURL=table-pagination.template.js.map
