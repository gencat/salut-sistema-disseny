import { html as s } from "lit/static-html.js";
import t from "../../assets/img/gencat-logotip-default.svg.js";
const l = (o) => s`
  <footer class='dss-footer-wrapper'>
    <div class='dss-footer-content'>
      <img class='dss-footer-logo' src="${o.logo ? o.logo : t}" alt="Gencat Logo"/>
      <p class="dss-footer-description">${o.description}</p>
    </div>
    <slot></slot>
  </footer>
`;
export {
  l as template
};
//# sourceMappingURL=footer.template.js.map
