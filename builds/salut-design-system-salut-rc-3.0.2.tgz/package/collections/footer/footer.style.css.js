const e = ':host{display:block;min-width:-moz-fit-content;min-width:fit-content}.dss-footer-wrapper{display:flex;align-items:center;height:40px;box-sizing:border-box;padding:var(--dss-spacing-xs) var(--dss-spacing-lg);box-shadow:var(--dss-elevation-sm)}.dss-footer-wrapper ::slotted(*){max-height:100%}.dss-footer-content{flex:1;display:flex;align-items:center;gap:var(--dss-spacing-md)}.dss-footer-logo{height:24px;margin:0}.dss-footer-description{display:none;font-weight:var(--font-regular);font-size:var(--dss-font-size-xs);line-height:var(--line-16)}@media(min-width:768px){.dss-footer-description{display:block;position:relative;padding-left:var(--dss-spacing-md)}.dss-footer-description:before{content:"";width:1px;height:24px;background-color:var(--color-neutral-100);position:absolute;left:0;top:-4px;margin:auto}}@media only screen and (max-height:808px){.dss-footer-wrapper{display:none}}';
export {
  e as default
};
//# sourceMappingURL=footer.style.css.js.map
