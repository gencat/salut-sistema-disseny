import { LitElement as c, unsafeCSS as p } from "lit";
import { property as s } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import m from "./header.style.css.js";
import { headerTemplate as y } from "./header.template.js";
var v = Object.defineProperty, r = (l, e, i, h) => {
  for (var t = void 0, n = l.length - 1, d; n >= 0; n--)
    (d = l[n]) && (t = d(e, i, t) || t);
  return t && v(e, i, t), t;
};
class o extends c {
  constructor() {
    super(), this.title = "", this.titleText = "", this.titleFullWidth = !1, this.area = void 0, this.logoSrc = void 0, this.jcef = !1, this.showEndVisit = !1, this.hideEndVisitDivider = !1, this.endVisitLabel = "Finalitzar visita", this._isBreakpointSm = !1, this._resizeTimer = null, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [p(f), p(u), p(m)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound);
  }
  _propagateProperties() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((i) => {
      i.assignedElements().forEach((t) => {
        this.jcef ? t.setAttribute("jcef", "true") : t.removeAttribute("jcef");
      });
    });
  }
  _updateSlotsDivider() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((i) => {
      const t = i.assignedNodes({ flatten: !0 }).filter((d) => !(d.nodeType === Node.TEXT_NODE && d?.textContent?.trim() === "")).length > 0, n = i.previousElementSibling;
      n && n.classList.contains("dss-header-divider") && (n.style.display = t ? "block" : "none");
    });
  }
  _handleEndVisit() {
    this.dispatchEvent(new CustomEvent("end-visit", { bubbles: !0, composed: !0 }));
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      const e = window.innerWidth, i = this.jcef ? 1418 : 1439;
      this._isBreakpointSm = e <= i, this.requestUpdate();
    }, 250);
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties(), this._updateSlotsDivider();
  }
  updated(e) {
    super.updated(e), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return y(this);
  }
}
r([
  s({ type: String })
], o.prototype, "title");
r([
  s({ type: String })
], o.prototype, "titleText");
r([
  s(a)
], o.prototype, "titleFullWidth");
r([
  s({ type: String })
], o.prototype, "area");
r([
  s({ type: String })
], o.prototype, "logoSrc");
r([
  s(a)
], o.prototype, "jcef");
r([
  s(a)
], o.prototype, "showEndVisit");
r([
  s(a)
], o.prototype, "hideEndVisitDivider");
r([
  s({ type: String })
], o.prototype, "endVisitLabel");
export {
  o as Header
};
//# sourceMappingURL=header.js.map
