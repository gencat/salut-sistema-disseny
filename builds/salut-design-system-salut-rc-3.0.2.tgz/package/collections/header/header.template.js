import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as l, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
import r from "../../assets/img/salut-logotip-default.svg.js";
const i = l`dss-button${a(t())}`, n = (s) => d`
  <header
    class=${e({
  "dss-header": !0
})}
  >
    <div class="dss-header-left">
      <div class="dss-header-brand">
        <img
          class="dss-header-logo"
          src="${s.logoSrc ? s.logoSrc : r}"
          alt="Salut logotip"
        />
        ${s.titleText ? d`
              <div  class=${e({
  "dss-header-title": !0,
  "dss-header-title--full-width": s.titleFullWidth
})}
              >
                ${s.area ? d`
                      <span class="dss-header-title__area"
                        >${s.area}</span
                      >
                    ` : null}
                <span class="dss-header-title__name">${s.titleText}</span>
              </div>
            ` : null}
      </div>
      <div class="dss-header-divider"></div>
      <slot name="patient-menu"></slot>
      <div class="dss-header-divider"></div>
      <slot name="allergies"></slot>
      <div class="dss-header-divider"></div>
      <slot name="situation-marks"></slot>
    </div>
    <div class="dss-header-right">
        
      ${s.showEndVisit ? d`
        <${i} 
          class="dss-header-end-visit"
          ?onlyIcon="${s._isBreakpointSm}"
          size="md"
          variant="secondary"
          icon="check"
          label=${s.endVisitLabel} 
          @click=${s._handleEndVisit}
        >
        </${i}>
        ${s.hideEndVisitDivider ? null : d`<div class="dss-header-divider" style="display: block;"></div>`}
      ` : null}
      <div class="dss-header-actions">
        <slot name="notifications"></slot>
        <slot name="links"></slot>
      </div>
      <div class="dss-header-divider"></div>
      <slot name="professional-menu"></slot>
    </div>
  </header>
`;
export {
  n as headerTemplate
};
//# sourceMappingURL=header.template.js.map
