import { LitElement as d, unsafeCSS as m, html as c } from "lit";
import { property as h } from "lit/decorators.js";
import { classMap as f } from "lit/directives/class-map.js";
import b from "./pagination.style.css.js";
import { template as P } from "./pagination.template.js";
var x = Object.defineProperty, u = (l, t, i, o) => {
  for (var e = void 0, n = l.length - 1, s; n >= 0; n--)
    (s = l[n]) && (e = s(t, i, e) || e);
  return e && x(t, i, e), e;
};
class g extends d {
  constructor() {
    super(...arguments), this.length = 0, this.pageSize = 0, this.currentIndex = 1, this.size = "md", this._totalPages = 0, this._buttons = [];
  }
  static get styles() {
    return m(b);
  }
  _next() {
    this.currentIndex++, this._updateButtons(), this._emitCurrentPage();
  }
  _prev() {
    this.currentIndex--, this._updateButtons(), this._emitCurrentPage();
  }
  _emitCurrentPage() {
    this.dispatchEvent(
      new CustomEvent("page-changed", {
        detail: this.currentIndex,
        bubbles: !0,
        composed: !0
      })
    );
  }
  _updateButtons() {
    this._buttons = [];
    const t = 1, i = Math.max(this.currentIndex - 1, 1), o = Math.min(this.currentIndex + 1, this._totalPages), e = i > 2, n = o < this._totalPages - 2, s = this._getButtons(t, t), a = this._getButtons(this._totalPages, this._totalPages), r = c`
      <button class="pagination__item pagination__item--dot" tabindex="-1">
        ...
      </button>
    `;
    if (this._totalPages <= 6) {
      this._buttons = this._getButtons(t, this._totalPages), this.requestUpdate();
      return;
    }
    if (!e && n) {
      const _ = this._getButtons(t, 4);
      this._buttons = [..._, r, a];
    }
    if (e && !n) {
      const _ = this._getButtons(this._totalPages - 3, this._totalPages);
      this._buttons = [s, r, ..._];
    }
    if (e && n) {
      const p = this._getButtons(i + 1, o);
      this._buttons = [s, r, ...p, r, a];
    }
    this.requestUpdate();
  }
  _getButtons(t, i) {
    const o = i - t + 1;
    return Array(o).fill(0).map((e, n) => {
      const s = n + t, a = {
        "pagination__item--selected": this.currentIndex === s,
        "pagination__item--large": s >= 10
      };
      return c`
          <button
            class="pagination__item ${f(a)}"
            @click=${() => this._selectItem(s)}
          >
            ${s}
          </button>
        `;
    });
  }
  _selectItem(t) {
    this.currentIndex = t, this._updateButtons();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._totalPages = Math.ceil(this.length / this.pageSize), this._updateButtons();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(t) {
    const i = t.has("length"), o = t.has("pageSize");
    (i || o) && (this._totalPages = Math.ceil(this.length / this.pageSize), this._updateButtons());
  }
  render() {
    return P(this);
  }
}
u([
  h({ type: Number })
], g.prototype, "length");
u([
  h({ type: Number })
], g.prototype, "pageSize");
u([
  h({ type: Number })
], g.prototype, "currentIndex");
u([
  h({ type: String })
], g.prototype, "size");
export {
  g as Pagination
};
//# sourceMappingURL=pagination.js.map
