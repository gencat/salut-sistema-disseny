import { html as e } from "lit";
import { classMap as s } from "lit/directives/class-map.js";
const i = (l) => {
  const a = {
    selected: l.selected,
    "is-hidden": !l.selected,
    "has-scroll": l.hasScroll
  };
  return e`
    <div
      id="${l.panelId}"
      role="tabpanel"
      aria-label="${l.label}"
      linkedTo="${l.linkedTo}"
      class="${s(a)}"
    >
      <slot></slot>
    </div>
  `;
};
export {
  i as tabsPanelTemplate
};
//# sourceMappingURL=tabs-panel.template.js.map
