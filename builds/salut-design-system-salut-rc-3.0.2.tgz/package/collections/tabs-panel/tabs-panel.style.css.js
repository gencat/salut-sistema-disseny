const e = ":host{width:100%;height:-moz-fit-content;height:fit-content}:host(.visible-full-height){display:flex;flex-direction:column;height:100%}:host(.visible-full-height) [role=tabpanel].selected{display:flex;flex-direction:column;height:100%}:not(:defined){display:none}[role=tabpanel]{width:100%;display:none}[role=tabpanel].has-scroll{overflow:auto}[role=tabpanel].selected{display:block}";
export {
  e as default
};
//# sourceMappingURL=tabs-panel.style.css.js.map
