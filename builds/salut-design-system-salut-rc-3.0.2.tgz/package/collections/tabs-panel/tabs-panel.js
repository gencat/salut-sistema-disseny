import { LitElement as h, unsafeCSS as f } from "lit";
import { property as t } from "lit/decorators.js";
import { booleanType as p } from "../../utils/property-types.js";
import d from "./tabs-panel.style.css.js";
import { tabsPanelTemplate as m } from "./tabs-panel.template.js";
var u = Object.defineProperty, l = (r, i, a, y) => {
  for (var e = void 0, o = r.length - 1, n; o >= 0; o--)
    (n = r[o]) && (e = n(i, a, e) || e);
  return e && u(i, a, e), e;
};
class s extends h {
  constructor() {
    super(...arguments), this.panelId = void 0, this.label = void 0, this.linkedTo = void 0, this.selected = !1, this.hasScroll = !1, this.fullHeight = !1;
  }
  static get styles() {
    return f(d);
  }
  updated(i) {
    i.has("selected") && this.fullHeight && (this.selected ? this.classList.add("visible-full-height") : this.classList.remove("visible-full-height"));
  }
  render() {
    return m(this);
  }
}
l([
  t({ type: String })
], s.prototype, "panelId");
l([
  t({ type: String })
], s.prototype, "label");
l([
  t({ type: String })
], s.prototype, "linkedTo");
l([
  t(p)
], s.prototype, "selected");
l([
  t(p)
], s.prototype, "hasScroll");
l([
  t(p)
], s.prototype, "fullHeight");
export {
  s as TabsPanel
};
//# sourceMappingURL=tabs-panel.js.map
