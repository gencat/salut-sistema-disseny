import { classMap as i } from "lit/directives/class-map.js";
import { unsafeStatic as u, literal as b, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const t = b`dss-icon${u(e())}`, d = b`dss-tooltip${u(e())}`, c = (s) => {
  const $ = {
    [`dss-split-button--${s.variant}`]: !!s.variant,
    "dss-split-button--open": s.isOpen,
    "dss-split-button--disabled": s.disabled,
    [`dss-split-button--${s.size}`]: !!s.size
  }, l = {
    [`dss-button--${s.variant}`]: !!s.variant
  };
  return a`
    <div class="dss-split-button ${i($)}" @mouseenter=${s.checkTextTruncate}>
      <button
        type="button"
        class="dss-button ${i(l)} dss-split-button-main"
        ?disabled=${s.disabled}
        @click="${s._dispatchMainClick}"
      >
        ${s.icon ? a`
              <${t}
                size=${s._iconSize}
                icon=${s.icon}
                ?fill=${s.iconFill}
                >${s.icon}</${t}>
            ` : null}
        <span class="dss-button-text">
          ${s.label}
				</span>
      </button>
      <div class="dss-split-button-action" data-expanded="${s.isOpen}">
        <button
          aria-label="${s.isOpen ? s.secondaryLabelClose : s.secondaryLabelOpen}"
          type="button" 
          class="dss-button ${i(l)} dss-button--only-icon dss-split-button-icon"
          ?disabled=${s.disabled}
          @click="${s._dispatchIconClick}"
        >
          <${t} 
            icon="${s.isOpen ? s.iconOpen : s.iconClose}"
            size="md">
          </${t}>
        </button>
        <slot name="menu"></slot>
      </div>
      <${d} class="dss-split-button__tooltip" aria-hidden="true">
        ${s.label}
      </${d}>
    </div>
  `;
};
export {
  c as splitButtonTemplate
};
//# sourceMappingURL=split-button.template.js.map
