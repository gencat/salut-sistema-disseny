import { LitElement as h, unsafeCSS as u } from "lit";
import { property as s } from "lit/decorators.js";
import { booleanType as a } from "../../utils/property-types.js";
import m from "../../components/button/button.style.css.js";
import y from "./split-button.style.css.js";
import { splitButtonTemplate as f } from "./split-button.template.js";
var _ = Object.defineProperty, b = Object.getOwnPropertyDescriptor, i = (d, t, n, r) => {
  for (var o = r > 1 ? void 0 : r ? b(t, n) : t, c = d.length - 1, l; c >= 0; c--)
    (l = d[c]) && (o = (r ? l(t, n, o) : l(o)) || o);
  return r && o && _(t, n, o), o;
};
const p = class p extends h {
  constructor() {
    super(), this.variant = "primary", this.size = "lg", this.label = "", this.iconOpen = "expand_less", this.iconClose = "expand_more", this.disabled = !1, this.isOpen = !1, this.hasMenu = !1, this.dropdownPosition = "bottom-right", this.secondaryLabelOpen = "Obrir", this.secondaryLabelClose = "Tamcar", this.icon = void 0, this.iconFill = !1, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleActionMenuClosedBound = this._handleActionMenuClosed.bind(this);
  }
  static get styles() {
    return [u(m), u(y)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound), this._actionMenu && this._actionMenu.removeEventListener("close", this._handleActionMenuClosedBound);
  }
  get _actionMenu() {
    const t = this.shadowRoot?.querySelector('slot[name="menu"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set text(t) {
    this.label = t;
  }
  get text() {
    return this.label;
  }
  get _iconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  _dispatchMainClick() {
    const t = {
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("main-click", t));
  }
  _dispatchIconClick() {
    this.hasMenu && this._toggleMenu();
    const t = {
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("icon-click", t));
  }
  _toggleMenu() {
    this.isOpen = !this.isOpen, this.requestUpdate();
  }
  _handleActionMenuClosed() {
    this.isOpen = !1, this._actionMenu && !this.isOpen && this._actionMenu._closeMenu();
  }
  _handleDocumentClick(t) {
    this._clickedOutsideItem(this, t);
  }
  checkTextTruncate(t) {
    if (!t) return;
    const n = t.target, r = n.querySelector(".dss-button-text"), o = r.scrollWidth > r.offsetWidth;
    n.setAttribute("data-truncated", o.toString());
  }
  _clickedOutsideItem(t, n) {
    n.composedPath().includes(t) || this.isOpen && (this.isOpen = !1, this.requestUpdate());
  }
  async firstUpdated() {
    await this.updateComplete, this._actionMenu && this._actionMenu.addEventListener("close", this._handleActionMenuClosedBound);
  }
  render() {
    return f(this);
  }
};
p.shadowRootOptions = {
  ...h.shadowRootOptions,
  delegatesFocus: !0
};
let e = p;
i([
  s({ type: String })
], e.prototype, "variant", 2);
i([
  s({ type: String })
], e.prototype, "size", 2);
i([
  s({ type: String })
], e.prototype, "label", 2);
i([
  s({ type: String })
], e.prototype, "iconOpen", 2);
i([
  s({ type: String })
], e.prototype, "iconClose", 2);
i([
  s({ type: String })
], e.prototype, "text", 1);
i([
  s(a)
], e.prototype, "disabled", 2);
i([
  s(a)
], e.prototype, "isOpen", 2);
i([
  s(a)
], e.prototype, "hasMenu", 2);
i([
  s({ type: String })
], e.prototype, "dropdownPosition", 2);
i([
  s({ type: String })
], e.prototype, "secondaryLabelOpen", 2);
i([
  s({ type: String })
], e.prototype, "secondaryLabelClose", 2);
i([
  s({ type: String })
], e.prototype, "icon", 2);
i([
  s(a)
], e.prototype, "iconFill", 2);
export {
  e as SplitButton
};
//# sourceMappingURL=split-button.js.map
