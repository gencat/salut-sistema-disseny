const o = ":host{display:block;width:100%;max-width:100%;box-sizing:border-box;flex:1;min-height:0;overflow-y:auto}:host(.scrollable){overflow-x:auto}";
export {
  o as default
};
//# sourceMappingURL=table-grid.style.css.js.map
