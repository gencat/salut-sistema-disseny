import { LitElement as a, unsafeCSS as n } from "lit";
import { property as f } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import d from "../../shared/scrollbar.style.css.js";
import y from "./table-grid.style.css.js";
import { template as S } from "./table-grid.template.js";
var g = Object.defineProperty, m = (c, t, i, s) => {
  for (var e = void 0, l = c.length - 1, o; l >= 0; l--)
    (o = c[l]) && (e = o(t, i, e) || e);
  return e && g(t, i, e), e;
};
class u extends a {
  constructor() {
    super(...arguments), this.config = {}, this._handleScrollXBound = this._handleScrollX.bind(this), this._onSlotChange = () => {
      requestAnimationFrame(() => {
        this._applyStickyConfig(), this._initScrollX(this);
      });
    };
  }
  static get styles() {
    return [n(h), n(d), n(y)];
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "treegrid"), (this.config.leftStickyColumns || this.config.rightStickyColumns) && this.shadowRoot?.querySelector("slot")?.addEventListener("slotchange", this._onSlotChange);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), (this.config.leftStickyColumns || this.config.rightStickyColumns) && (this.shadowRoot?.querySelector("slot")?.removeEventListener("slotchange", this._onSlotChange), this.removeEventListener("scroll", this._handleScrollXBound));
  }
  _applyRowConfig() {
    this.config?.gridTemplateColumns && this.style.setProperty("--dss-table-grid-template-columns", this.config.gridTemplateColumns);
  }
  _applyStickyConfig() {
    const t = this.shadowRoot?.querySelector("slot");
    if (!t) return;
    t.assignedElements().forEach((s) => {
      const e = s.querySelectorAll("dss-row");
      for (const l of e) {
        const o = l.querySelectorAll("dss-cell");
        if (this.config.leftStickyColumns && this.config.leftStickyColumns > 0) {
          const r = Array.from(o || []).slice(0, this.config.leftStickyColumns);
          this._cellsToSticky(r, "left");
        }
        if (this.config.rightStickyColumns && this.config.rightStickyColumns > 0) {
          const r = Array.from(o || []).slice(-this.config.rightStickyColumns).reverse();
          this._cellsToSticky(r, "right");
        }
      }
    });
  }
  _cellsToSticky(t, i) {
    for (const [s, e] of Array.from(t || []).entries()) {
      const l = e;
      l.classList.add("sticky");
      let o = 0;
      s > 0 && (o = o + t[s - 1].offsetWidth), i === "left" ? l.style.left = `${o}px` : l.style.right = `${o}px`, l.classList.add("sticky-column"), s === 0 && (i === "left" && l.classList.add("sticky-column--left-first"), i === "right" && l.classList.add("sticky-column--right-last")), s === t.length - 1 && (i === "left" ? l.classList.add("sticky-column--left-last") : l.classList.add("sticky-column--right-first"));
    }
  }
  _setStickyScrollState(t) {
    this.querySelectorAll("dss-cell.sticky-column").forEach((s) => {
      s.classList.toggle("scroll-init", t === "init"), s.classList.toggle("scroll-middle", t === "middle"), s.classList.toggle("scroll-end", t === "end");
    });
  }
  _initScrollX(t) {
    if (t?.clientWidth < t?.scrollWidth) {
      this._setStickyScrollState("init");
      return;
    }
    this._setStickyScrollState("none");
  }
  _handleScrollX(t) {
    const i = t.target, s = i?.scrollWidth - i?.clientWidth;
    if (s <= 0) {
      this._setStickyScrollState("none");
      return;
    }
    if (i?.scrollLeft === 0) {
      this._setStickyScrollState("init");
      return;
    }
    if (i?.scrollLeft > 0 && Math.round(i?.scrollLeft) < s) {
      this._setStickyScrollState("middle");
      return;
    }
    Math.round(i?.scrollLeft) === s && this._setStickyScrollState("end");
  }
  async firstUpdated() {
    await this.updateComplete, this.config.gridTemplateColumns && this._applyRowConfig(), this.config.scrollable && this.classList.add("scrollable"), (this.config.leftStickyColumns || this.config.rightStickyColumns) && requestAnimationFrame(() => {
      this._applyStickyConfig(), this._initScrollX(this), this.addEventListener("scroll", this._handleScrollXBound);
    });
  }
  updated(t) {
    t.has("config") && this.config?.gridTemplateColumns && this._applyRowConfig(), t.has("config") && (this.config.leftStickyColumns || this.config.rightStickyColumns) && requestAnimationFrame(() => {
      this._applyStickyConfig(), this._initScrollX(this);
    });
  }
  render() {
    return S();
  }
}
m([
  f({ type: Array })
], u.prototype, "config");
export {
  u as TableGrid
};
//# sourceMappingURL=table-grid.js.map
