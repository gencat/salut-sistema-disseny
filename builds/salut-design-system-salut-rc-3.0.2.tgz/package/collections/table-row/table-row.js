import { LitElement as c, unsafeCSS as p } from "lit";
import { property as t } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import m from "./table-row.style.css.js";
import { template as g } from "./table-row.template.js";
var u = Object.defineProperty, s = (o, e, h, n) => {
  for (var r = void 0, a = o.length - 1, d; a >= 0; a--)
    (d = o[a]) && (r = d(e, h, r) || r);
  return r && u(e, h, r), r;
};
class i extends c {
  constructor() {
    super(...arguments), this.hover = !1, this.clickable = !1, this.selected = !1, this.disabled = !1, this.deleted = !1, this.highlight = !1, this.isCurrentFocused = !1, this.gridTemplateColumns = void 0;
  }
  static get styles() {
    return [p(f), p(m)];
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "row"), this.setAttribute("tabindex", "-1");
  }
  updated(e) {
    if (e.has("hover") && this.classList.toggle("hover", this.hover), e.has("clickable") && this.classList.toggle("clickable", this.clickable), e.has("selected") && this.classList.toggle("selected", this.selected), e.has("highlight") && this.classList.toggle("highlight", this.highlight), e.has("disabled") && this.classList.toggle("disabled", this.disabled), e.has("deleted") && this.classList.toggle("deleted", this.deleted), e.has("gridTemplateColumns")) {
      if (!this.gridTemplateColumns) return;
      this.style.gridTemplateColumns = this.gridTemplateColumns;
    }
  }
  async firstUpdated() {
    await this.updateComplete;
  }
  render() {
    return g();
  }
}
s([
  t(l)
], i.prototype, "hover");
s([
  t(l)
], i.prototype, "clickable");
s([
  t(l)
], i.prototype, "selected");
s([
  t(l)
], i.prototype, "disabled");
s([
  t(l)
], i.prototype, "deleted");
s([
  t(l)
], i.prototype, "highlight");
s([
  t(l)
], i.prototype, "isCurrentFocused");
s([
  t({ type: String })
], i.prototype, "gridTemplateColumns");
export {
  i as TableRow
};
//# sourceMappingURL=table-row.js.map
