import { LitElement as f, unsafeCSS as m } from "lit";
import { property as a } from "lit/decorators.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
import u from "../../shared/reset.style.css.js";
import p from "./toast-manager.style.css.js";
import { template as c } from "./toast-manager.template.js";
var b = Object.defineProperty, l = (i, t, e, o) => {
  for (var s = void 0, r = i.length - 1, h; r >= 0; r--)
    (h = i[r]) && (s = h(t, e, s) || s);
  return s && b(t, e, s), s;
};
class n extends f {
  constructor() {
    super(), this._toastSelector_ = `dss-toast${d()}`, this.maxVisibleToasts = 3, this.handleToastClose = this.handleToastClose.bind(this), this.handleSlotMutations = this.handleSlotMutations.bind(this);
  }
  static get styles() {
    return [m(u), m(p)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("close", this.handleToastClose);
  }
  firstUpdated() {
    this.initSlotObserver(), this.evaluateToasts();
  }
  updated(t) {
    t.has("maxVisibleToasts") && this.evaluateToasts(), t.has("leftPosition") && this.applyHostCssVar("--dss-toast-manager-left", this.leftPosition), t.has("bottomPosition") && this.applyHostCssVar("--dss-toast-manager-bottom", this.bottomPosition), super.updated(t);
  }
  applyHostCssVar(t, e) {
    e && e.trim().length > 0 ? this.style.setProperty(t, e.trim()) : this.style.removeProperty(t);
  }
  initSlotObserver() {
    this._slotObserver_ && this._slotObserver_.disconnect(), this._slotObserver_ = new MutationObserver(this.handleSlotMutations), this._slotObserver_.observe(this, { childList: !0 });
  }
  handleSlotMutations() {
    this.evaluateToasts();
  }
  handleToastClose(t) {
    this.isToastElement(t.target) && this.evaluateToasts();
  }
  isToastElement(t) {
    return !t || !(t instanceof HTMLElement) ? !1 : t.matches(this._toastSelector_);
  }
  getToastElements() {
    return Array.from(this.querySelectorAll(this._toastSelector_));
  }
  evaluateToasts() {
    const t = this.getToastElements();
    if (t.length === 0)
      return;
    const e = Math.max(0, this.maxVisibleToasts);
    let o = 0;
    if (t.forEach((s) => {
      s.managed = !0, s.isShow && o < e ? o += 1 : s.isShow && o >= e && (s.isShow = !1);
    }), !(o >= e))
      for (const s of t)
        !s.isShow && o < e && (s.isShow = !0, o += 1);
  }
  render() {
    return c();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("close", this.handleToastClose), this._slotObserver_?.disconnect(), this._slotObserver_ = void 0;
  }
}
l([
  a({ type: Number })
], n.prototype, "maxVisibleToasts");
l([
  a({ type: String })
], n.prototype, "leftPosition");
l([
  a({ type: String })
], n.prototype, "bottomPosition");
export {
  n as ToastManager
};
//# sourceMappingURL=toast-manager.js.map
