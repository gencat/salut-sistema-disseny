import { classMap as t } from "lit/directives/class-map.js";
import { html as s } from "lit/static-html.js";
const a = () => s`
    <div class="${t({
  "dss-toast-manager": !0
})}"
  	>
      <slot></slot>
    </div>
  </div>`;
export {
  a as template
};
//# sourceMappingURL=toast-manager.template.js.map
