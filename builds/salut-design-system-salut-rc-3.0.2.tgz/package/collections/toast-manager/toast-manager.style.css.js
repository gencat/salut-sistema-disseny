const t = ":host{position:fixed;z-index:999;bottom:var(--dss-toast-manager-bottom, calc(40px + var(--dss-spacing-lg)));left:var(--dss-toast-manager-left, calc(72px + var(--dss-spacing-lg)));height:-moz-fit-content;height:fit-content;width:-moz-fit-content;width:fit-content;display:flex;justify-content:flex-start;align-items:flex-end}.dss-toast-manager{display:flex;flex-direction:column;gap:var(--dss-spacing-md)}@media only screen and (max-height:808px){:host{bottom:var(--dss-toast-manager-bottom, var(--dss-spacing-lg))}}";
export {
  t as default
};
//# sourceMappingURL=toast-manager.style.css.js.map
