import { unsafeStatic as l, literal as d, html as t } from "lit/static-html.js";
const i = (s) => {
  const e = d`${l(s.tag)}`;
  return t`
    <div class='dss-module-header'>
      <${e} class='dss-headline--sm'>${s.titleText}</${e}>
      <div class='dss-module-header__child-container'>
        <p class='dss-legend--sm'>${s.legend}</p>
        <slot></slot>
      </div>
    </div>
`;
};
export {
  i as template
};
//# sourceMappingURL=module-header.template.js.map
