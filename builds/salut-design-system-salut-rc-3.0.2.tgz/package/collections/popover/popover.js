import { autoUpdate as f, offset as m, flip as b, shift as g, arrow as w, computePosition as y } from "@floating-ui/dom";
import { LitElement as H, unsafeCSS as p } from "lit";
import { property as r, state as c } from "lit/decorators.js";
import C from "../../foundations/icon/icon.style.css.js";
import k from "../../shared/reset.style.css.js";
import P from "../../shared/scrollbar.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import S from "./popover.style.css.js";
import { popoverTemplate as x } from "./popover.template.js";
var E = Object.defineProperty, i = (d, e, t, o) => {
  for (var l = void 0, a = d.length - 1, h; a >= 0; a--)
    (h = d[a]) && (l = h(e, t, l) || l);
  return l && E(e, t, l), l;
};
class s extends H {
  constructor() {
    super(), this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        if (t.type === "attributes" && t.attributeName === "data-popper-placement") {
          const o = this.getAttribute("data-popper-placement");
          o && this._propagatePlacement(o);
        }
    }, this.mutationObserver = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || this._closePopover();
      },
      {
        root: null,
        threshold: 0
      }
    ), this.maxHeightObserverTimeout = null, this.maxHeightObserver = new ResizeObserver(([e]) => {
      this.maxHeightObserverTimeout && clearTimeout(this.maxHeightObserverTimeout), this.maxHeightObserverTimeout = window.setTimeout(() => {
        const t = e.contentRect.height;
        this._onHeightChange(t);
      }, 100);
    }), this._parentMousedownHandler = null, this._parentKeydownHandler = null, this.open = !1, this.variant = "default", this.hideCloseIcon = !1, this.disableParentClick = !1, this.title = "", this.titleText = "", this.actionIcon = void 0, this.actionLabel = void 0, this.position = "top", this.popoverFixed = !1, this.removeMaxHeight = !1, this.fullWidth = !1, this.hideHeader = !1, this._referenceEl = null, this._floatingEl = null, this.hideTooltip = !1, this.forceViewport = !1, this.tooltipPosition = "top", this._arrowEl = null, this._cleanupAutoUpdate = null, this._parent = null, this._disableClickOutside = !0, this._isFirstUpdate = !0, this._hasFooterSlot = !1, this.availableHeight = void 0, this.hasMaxHeight = !1, this.hasWidget = !1, this._resizeObserver = null, this._scrollHandler = null, this._scrollContent = null, this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [p(k), p(P), p(C), p(S)];
  }
  connectedCallback() {
    super.connectedCallback(), this._handleConnectedCallback();
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.mutationObserver.disconnect(), this.visibleObserver.disconnect(), this.maxHeightObserver.disconnect(), this._cleanupAutoUpdate && (this._cleanupAutoUpdate(), this._cleanupAutoUpdate = null), this._parent && (this._parentMousedownHandler && (this._parent.removeEventListener("mousedown", this._parentMousedownHandler), this._parentMousedownHandler = null), this._parentKeydownHandler && (this._parent.removeEventListener("keydown", this._parentKeydownHandler), this._parentKeydownHandler = null));
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  _handleOutsideClick(e) {
    this._checkClickOutside(e);
  }
  _handleConnectedCallback() {
    if (requestAnimationFrame(() => {
      this.hasWidget = !!this.querySelector("dss-widget");
    }), this._isFirstUpdate) return;
    const e = this.style.position;
    e !== "absolute" && e !== "fixed" && e !== "relative" && (this._referenceEl ? this._updateFloatingPosition() : this._initPopover());
  }
  _handleAction() {
    this.dispatchEvent(new CustomEvent("action", { bubbles: !0, composed: !0 }));
  }
  _handleClose() {
    this._closePopover();
  }
  _checkClickOutside(e) {
    if (this.disableParentClick && this._disableClickOutside)
      return;
    const t = e.composedPath(), o = t.includes(this._parent);
    !t.includes(this) && !o && this._closePopover();
  }
  _closePopover() {
    setTimeout(() => {
      this.classList.contains("visible") && (this.classList.remove("visible"), this.open = !1, this._removeScrollListener(), this._removeDropdownListener(), this.dispatchEvent(new CustomEvent("close", { bubbles: !1, composed: !1 })));
    }, 0);
  }
  _createFloatingInstance(e) {
    this._parent = e, this._referenceEl = e, this._floatingEl = this.shadowRoot?.querySelector(".dss-popover"), this._arrowEl = this.shadowRoot?.querySelector(".dss-popover-arrow"), this._floatingEl && (this._cleanupAutoUpdate = f(this._referenceEl, this._floatingEl, () => this._updateFloatingPosition()), this.visibleObserver.observe(e), this._parentMousedownHandler = () => this._popoverParentListener(), this._parentKeydownHandler = (t) => {
      t.stopPropagation(), t.key === "Enter" || t.key === " " ? this._popoverParentListener() : t.key === "Escape" && this._closePopover();
    }, this._parent.addEventListener("mousedown", this._parentMousedownHandler), this._parent.addEventListener("keydown", this._parentKeydownHandler));
  }
  async _updateFloatingPosition() {
    if (!this._referenceEl || !this._floatingEl) return;
    const e = [
      m(16),
      this.variant !== "filter" ? b() : void 0,
      g({
        padding: { top: 8, bottom: 8, left: 16, right: 16 }
      }),
      this._arrowEl ? w({ element: this._arrowEl, padding: 8 }) : void 0
    ].filter(Boolean), { x: t, y: o, placement: l, strategy: a, middlewareData: h } = await y(this._referenceEl, this._floatingEl, {
      placement: this.variant !== "filter" ? this.position : "bottom",
      strategy: this.popoverFixed ? "fixed" : "absolute",
      middleware: e
    });
    if (Object.assign(this._floatingEl.style, {
      position: a,
      left: `${t}px`,
      top: `${o}px`
    }), this._arrowEl && h.arrow) {
      const { x: u, y: _ } = h.arrow;
      Object.assign(this._arrowEl.style, {
        left: u != null ? `${u}px` : "",
        top: _ != null ? `${_}px` : ""
      });
      const v = l.split("-")[0];
      this._arrowEl.setAttribute("data-placement", v);
    }
    this._propagatePlacement(l);
  }
  _popoverParentListener() {
    !this.open && !this.disableParentClick && (this.open = !0, this.classList.add("visible"), this._disableClickOutside = !1, this._referenceEl && (this._updateFloatingPosition(), this._checkMaxHeight(), this._handleScroll()), this._addDropdownListener());
  }
  _propagatePlacement(e) {
    const t = this.renderRoot.querySelector(".dss-popover");
    t && t.setAttribute("data-popper-placement", e);
  }
  _checkMaxHeight() {
    if (this.variant !== "filter") return;
    const e = this.shadowRoot?.querySelector(".dss-popover");
    if (!e) return;
    const t = e.getBoundingClientRect();
    let o = window.innerHeight - t.top;
    o = o - 24, o < 180 && (o = 180);
    const l = this.shadowRoot?.querySelector(".dss-popover-box");
    l && (l.style.maxHeight = `${o}px`, this.availableHeight = o);
  }
  _handleScroll() {
    const e = this.shadowRoot?.querySelector(".dss-popover-content");
    e && (this._scrollContent = e, this._scrollHandler = () => this._checkPopoverScroll(e), e.addEventListener("scroll", this._scrollHandler), this._resizeObserver = new ResizeObserver(() => this._checkPopoverScroll(e)), this._resizeObserver.observe(e), e.scrollHeight > e.clientHeight && e.scrollTop === 0 && this.shadowRoot?.querySelector(".dss-popover-footer-wrapper")?.classList.add("dss-popover-footer-wrapper--scrolled"));
  }
  _removeScrollListener() {
    this._scrollContent && this._scrollHandler && this._scrollContent.removeEventListener("scroll", this._scrollHandler), this._scrollHandler = null, this._scrollContent = null, this._resizeObserver?.disconnect(), this._resizeObserver = null;
  }
  _checkPopoverScroll(e) {
    const t = this.shadowRoot?.querySelector(".dss-popover-header"), o = this.shadowRoot?.querySelector(".dss-popover-footer-wrapper");
    e.scrollTop > 0 ? t?.classList.add("dss-popover-header--scrolled") : t?.classList.remove("dss-popover-header--scrolled"), e.scrollHeight - e.scrollTop !== e.clientHeight ? o?.classList.add("dss-popover-footer-wrapper--scrolled") : o?.classList.remove("dss-popover-footer-wrapper--scrolled");
  }
  _initPopover() {
    const e = this.assignedSlot;
    this._parent = e ? e.parentElement : this.parentElement, this._parent && this._createFloatingInstance(this._parent), this.mutationObserver.observe(this, this.observerConfig), this.maxHeightObserver.observe(this), setTimeout(() => {
      this.open && (this.classList.add("visible"), this._updateFloatingPosition(), this._checkMaxHeight(), this._handleScroll(), this.requestUpdate(), this._addDropdownListener());
    }, 0);
  }
  async firstUpdated() {
    await this.updateComplete, this.classList.add("animation-enabled");
    const e = this.shadowRoot?.querySelector('slot[name="footer"]');
    if (e) {
      const t = e.assignedElements({ flatten: !0 });
      this._hasFooterSlot = t.length > 0;
    }
    this._initPopover(), this._isFirstUpdate = !1;
  }
  updated(e) {
    super.updated(e), e.has("position") && this._referenceEl && this._updateFloatingPosition(), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    }), e.has("open") && (this.open ? (this.classList.add("visible"), this._updateFloatingPosition(), this._addDropdownListener(), this.disableParentClick && (this._checkMaxHeight(), this._handleScroll(), setTimeout(() => {
      this._disableClickOutside = !1;
    }, 100))) : (this.classList.remove("visible"), this._removeDropdownListener(), this.disableParentClick && (this._disableClickOutside = !0)));
  }
  // Función que puedes definir si quieres manejar cambios de altura
  _onHeightChange(e) {
    this.availableHeight && (this.hasMaxHeight = e >= this.availableHeight);
  }
  render() {
    return x(this);
  }
}
i([
  r(n)
], s.prototype, "open");
i([
  r({ type: String })
], s.prototype, "variant");
i([
  r(n)
], s.prototype, "hideCloseIcon");
i([
  r(n)
], s.prototype, "disableParentClick");
i([
  r({ type: String })
], s.prototype, "title");
i([
  r({ type: String })
], s.prototype, "titleText");
i([
  r({ type: String })
], s.prototype, "actionIcon");
i([
  r({ type: String })
], s.prototype, "actionLabel");
i([
  r({ type: String })
], s.prototype, "position");
i([
  r(n)
], s.prototype, "popoverFixed");
i([
  r(n)
], s.prototype, "removeMaxHeight");
i([
  r(n)
], s.prototype, "fullWidth");
i([
  r(n)
], s.prototype, "hideHeader");
i([
  r(n)
], s.prototype, "hideTooltip");
i([
  r(n)
], s.prototype, "forceViewport");
i([
  r({ type: String })
], s.prototype, "tooltipPosition");
i([
  c()
], s.prototype, "availableHeight");
i([
  c()
], s.prototype, "hasMaxHeight");
i([
  c()
], s.prototype, "hasWidget");
export {
  s as Popover
};
//# sourceMappingURL=popover.js.map
