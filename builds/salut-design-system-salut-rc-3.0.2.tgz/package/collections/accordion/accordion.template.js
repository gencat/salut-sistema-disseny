import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as l, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
import { checkTextTruncate as v } from "../../utils/helpers.js";
const d = l`dss-icon-button${a(e())}`, $ = l`dss-decorative-icon${a(e())}`, t = l`dss-badge${a(e())}`, c = l`dss-icon-badge${a(e())}`, r = l`dss-tooltip${a(e())}`, o = l`dss-notification-badge${a(e())}`, h = l`dss-typography${a(e())}`, _ = (i) => {
  const u = {
    "dss-accordion--open": i.isOpen,
    [`dss-accordion--${i.accordionStyle}`]: !!i.accordionStyle,
    // 'dss-accordion--box': component._accordionStyle === 'box',
    // 'dss-accordion--inner': component._accordionStyle === 'inner',
    "dss-accordion--widget": i.widget,
    "dss-accordion--show-header-divider": i.showHeaderDivider,
    "dss-accordion--hide-footer-divider": i.hideFooterDivider
  };
  return s`
    <div class="dss-accordion ${g(u)}">
      <div class="dss-accordion-header">
        <div class="dss-accordion-header__info">
          <div class="dss-accordion-title">
            ${i.icon ? s`
                  <${$} icon=${i.icon} state=${i.iconStatus} size="sm"></${$}>
                ` : null}
            ${i.hasCheckbox ? s`
                  <div class="dss-accordion-title__checkbox dss-form-field">
                    <slot
                      name="checkbox"
                      @click=${i._dispatchCheckboxChange}
                    ></slot>
                    <slot name="checkboxLabel"></slot>
                  </div>
                ` : s`
                  <div
                    class="dss-accordion-title__text" @mouseenter=${v}
                    @click="${i._toggleAccordion}"
                  >
                    ${i.titleText ? s` ${i.titleText} ` : s` ${i.type} ${i.index} `}
                    <${r} class="title-tooltip" aria-hidden="true">
                      ${i.titleText ? s` ${i.titleText} ` : s` ${i.type} ${i.index} `}
                    </${r}>


                  </div>
                `}
          </div>
        </div>

        <div class="dss-accordion-header__config">

            <div class="dss-accordion-header__config-info">
              ${i.helpText ? s`<${h} variant="body-3">${i.helpText}</${h}>` : null}
              ${i.widgetBadgeLabel ? s`
                    <${t}
                      size="md"
                      state="${i.widgetBadgeStatus}"
                      outlined
                      hideIcon
                      text="${i.widgetBadgeLabel}"
                    ></${t}>
                  ` : null}

              ${i.results ? s`
                  <${t}
                    size="md"
                    state="${i.resultsStatus}"
                    outlined
                    hideIcon
                    text="${i.results} ${i.resultsLabel}"
                  ></${t}>
                ` : null}

              ${i.info ? s`
                  <${c}  size="md" state="${i.infoBadgeStatus}" icon="${i.infoBadgeIcon}" ?outlined="${i.infoBadgeOutlined}">
                    <${r} slot="tooltip">
                      <span>${i.info}</span>
                    </${r} >
                  </${c} >
                ` : null}

              ${i.notifications ? s`
                  <${o}
                    state="${i.notificationsStatus}"
                    value="${i.notifications}"
                  >
                  </${o}>
                ` : null}

            </div>

            ${i.helpText || i.results || i.notifications || i.info || i.widgetBadgeLabel ? s`
                <span class="dss-accordion-widget__divider"></span>
              ` : null}

           

            <div class="dss-accordion-header__config-actions">
              ${i.hasPrimaryAction ? s`
                  <${d}
                    size="md"
                    label="${i.primaryActionLabel}"
                    icon="${i.primaryActionIcon}"
                    variant="${i.primaryActionStatus}"
                    ?fill=${i.primaryActionFill}
                    ?disabled=${i.primaryActionDisabled}
                    ?hideTooltip="${i.hideTooltip}"
                    @onClick=${i._dispatchPrimaryAction}
                  ></${d}>
                ` : null}

              ${i.hasSecondaryAction ? s`
                  <${d}
                    size="md"
                    label="${i.secondaryActionLabel}"
                    icon="${i.secondaryActionIcon}"
                    variant="${i.secondaryActionStatus}"
                    ?fill=${i.secondaryActionFill}
                    ?disabled=${i.secondaryActionDisabled}
                    ?hideTooltip="${i.hideTooltip}"
                    @onClick=${i._dispatchSecondaryAction}
                  ></${d}>
                ` : null}

              ${i.widgetShowNext ? s`
                    <${d}
                      size="md"
                      variant="primary"
                      label="Següent"
                      icon="arrow_forward"
                      hideTooltip
                      @onClick="${i._dispatchWidgetNext}"
                    >
                    </${d}>
                  ` : null}
              ${i.widgetShowClose ? s`
                    <${d}
                      size="md"
                      variant="default"
                      icon="close"
                      label="Tancar"
                      hideTooltip
                      @onClick="${i._dispatchWidgetClose}"
                    >
                    </${d}>
                  ` : null}
              <${d}
                label="${i.isOpen ? `Obrir ${i.titleText} acordió` : `Tancar ${i.titleText} acordió`}"
                hideTooltip
                ariaExpanded="${i.isOpen}"
                size="md"
                icon="${i.isOpen ? "expand_less" : "expand_more"}"
                variant="primary"
                @onClick=${i._toggleAccordion}
              ></${d}>
            </div>
        </div>
      </div>

      <div class="dss-accordion-panel-wrapper">
        <div class="dss-accordion-panel">
          <slot></slot>
        </div>
      </div>
    </div>
  `;
};
export {
  _ as template
};
//# sourceMappingURL=accordion.template.js.map
