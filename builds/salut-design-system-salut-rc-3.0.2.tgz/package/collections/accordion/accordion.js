import { LitElement as y, unsafeCSS as h } from "lit";
import { property as t } from "lit/decorators.js";
import { booleanType as s } from "../../utils/property-types.js";
import l from "./accordion.style.css.js";
import { template as g } from "./accordion.template.js";
var u = Object.defineProperty, S = Object.getOwnPropertyDescriptor, e = (p, o, a, n) => {
  for (var r = n > 1 ? void 0 : n ? S(o, a) : o, c = p.length - 1, d; c >= 0; c--)
    (d = p[c]) && (r = (n ? d(o, a, r) : d(r)) || r);
  return n && r && u(o, a, r), r;
};
class i extends y {
  constructor() {
    super(...arguments), this.showHeaderDivider = !1, this.hideFooterDivider = !1, this.hideTooltip = !1, this.info = void 0, this.infoBadgeStatus = "critic", this.infoBadgeIcon = "", this.infoBadgeOutlined = !0, this.secondaryActionLabel = "", this.secondaryActionFill = !1, this.hasPrimaryAction = !1, this.primaryActionLabel = "", this.primaryActionIcon = "", this.primaryActionStatus = "neutral", this.primaryActionDisabled = !1, this.primaryActionFill = !1, this.helpText = null, this.icon = "", this.iconStatus = "default", this.titleText = "", this.type = "", this.index = void 0, this.isOpen = !1, this.accordionStyle = "box", this.results = void 0, this.resultsLabel = "Resultats", this.resultsStatus = "neutral", this.hasCheckbox = !1, this.hasSecondaryAction = !1, this.secondaryActionIcon = "add_box", this.secondaryActionStatus = "primary", this.secondaryActionDisabled = !1, this.notifications = void 0, this.notificationsStatus = "neutral", this.widget = !1, this.widgetBadgeStatus = "neutral", this.widgetBadgeLabel = void 0, this.widgetShowNext = !1, this.widgetShowClose = !1;
  }
  static get styles() {
    return [h(l)];
  }
  set infoBadgeState(o) {
    this.infoBadgeStatus = o;
  }
  get infoBadgeState() {
    return this.infoBadgeStatus;
  }
  get _checkbox() {
    const o = this.shadowRoot?.querySelector('slot[name="checkbox"]') || void 0;
    return this.requestUpdate(), o?.assignedElements()[0];
  }
  set resultsText(o) {
    this.resultsLabel = o;
  }
  get resultsText() {
    return this.resultsLabel;
  }
  set resultsState(o) {
    this.resultsStatus = o;
  }
  get resultsState() {
    return this.resultsStatus;
  }
  set notificationsState(o) {
    this.notificationsStatus = o;
  }
  get notificationsState() {
    return this.notificationsStatus;
  }
  set widgetBadgeState(o) {
    this.widgetBadgeStatus = o;
  }
  get widgetBadgeState() {
    return this.widgetBadgeStatus;
  }
  set widgetBadgeText(o) {
    this.widgetBadgeLabel = o;
  }
  get widgetBadgeText() {
    return this.widgetBadgeLabel || "";
  }
  _toggleAccordion() {
    this.isOpen = !this.isOpen, this._dispatchToggleAccordion(), this.requestUpdate();
  }
  _dispatchCheckboxChange() {
    const o = {
      detail: this._checkbox.checked,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("checkbox-changed", o));
  }
  _dispatchSecondaryAction() {
    const o = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("secondary-action", o));
  }
  _dispatchPrimaryAction() {
    this.dispatchEvent(new Event("primary-action"));
  }
  _dispatchToggleAccordion() {
    const o = {
      detail: this.isOpen,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("toggle", o));
  }
  _dispatchWidgetNext() {
    const o = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("next", o));
  }
  _dispatchWidgetClose() {
    const o = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("close", o));
  }
  render() {
    return g(this);
  }
}
e([
  t(s)
], i.prototype, "showHeaderDivider", 2);
e([
  t(s)
], i.prototype, "hideFooterDivider", 2);
e([
  t(s)
], i.prototype, "hideTooltip", 2);
e([
  t({ type: String })
], i.prototype, "info", 2);
e([
  t({ type: String })
], i.prototype, "infoBadgeStatus", 2);
e([
  t({ type: String })
], i.prototype, "infoBadgeState", 1);
e([
  t({ type: String })
], i.prototype, "infoBadgeIcon", 2);
e([
  t(s)
], i.prototype, "infoBadgeOutlined", 2);
e([
  t({ type: String })
], i.prototype, "secondaryActionLabel", 2);
e([
  t(s)
], i.prototype, "secondaryActionFill", 2);
e([
  t(s)
], i.prototype, "hasPrimaryAction", 2);
e([
  t({ type: String })
], i.prototype, "primaryActionLabel", 2);
e([
  t({ type: String })
], i.prototype, "primaryActionIcon", 2);
e([
  t({ type: String })
], i.prototype, "primaryActionStatus", 2);
e([
  t(s)
], i.prototype, "primaryActionDisabled", 2);
e([
  t(s)
], i.prototype, "primaryActionFill", 2);
e([
  t({ type: String })
], i.prototype, "helpText", 2);
e([
  t({ type: String })
], i.prototype, "icon", 2);
e([
  t({ type: String })
], i.prototype, "iconStatus", 2);
e([
  t({ type: String })
], i.prototype, "titleText", 2);
e([
  t({ type: String })
], i.prototype, "type", 2);
e([
  t({ type: String })
], i.prototype, "index", 2);
e([
  t(s)
], i.prototype, "isOpen", 2);
e([
  t({ type: String })
], i.prototype, "accordionStyle", 2);
e([
  t({ type: String })
], i.prototype, "results", 2);
e([
  t({ type: String })
], i.prototype, "resultsLabel", 2);
e([
  t({ type: String })
], i.prototype, "resultsText", 1);
e([
  t({ type: String })
], i.prototype, "resultsStatus", 2);
e([
  t(s)
], i.prototype, "hasCheckbox", 2);
e([
  t(s)
], i.prototype, "hasSecondaryAction", 2);
e([
  t({ type: String })
], i.prototype, "secondaryActionIcon", 2);
e([
  t({ type: String })
], i.prototype, "secondaryActionStatus", 2);
e([
  t(s)
], i.prototype, "secondaryActionDisabled", 2);
e([
  t({ type: String })
], i.prototype, "resultsState", 1);
e([
  t({ type: String })
], i.prototype, "notifications", 2);
e([
  t({ type: String })
], i.prototype, "notificationsStatus", 2);
e([
  t({ type: String })
], i.prototype, "notificationsState", 1);
e([
  t(s)
], i.prototype, "widget", 2);
e([
  t({ type: String })
], i.prototype, "widgetBadgeStatus", 2);
e([
  t({ type: String })
], i.prototype, "widgetBadgeState", 1);
e([
  t({ type: String })
], i.prototype, "widgetBadgeLabel", 2);
e([
  t({ type: String })
], i.prototype, "widgetBadgeText", 1);
e([
  t(s)
], i.prototype, "widgetShowNext", 2);
e([
  t(s)
], i.prototype, "widgetShowClose", 2);
export {
  i as Accordion
};
//# sourceMappingURL=accordion.js.map
