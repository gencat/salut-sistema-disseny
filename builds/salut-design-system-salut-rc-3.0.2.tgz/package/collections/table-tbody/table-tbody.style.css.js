const s = ":host{display:block;width:100%}";
export {
  s as default
};
//# sourceMappingURL=table-tbody.style.css.js.map
