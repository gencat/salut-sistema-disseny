import { LitElement as d, unsafeCSS as m } from "lit";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import g from "../../shared/reset.style.css.js";
import f from "./table-tbody.style.css.js";
import { template as w } from "./table-tbody.template.js";
class T extends d {
  constructor() {
    super(...arguments), this._assignedElements = [], this._currentFocusableElement = null, this._handleSlotChange = () => {
      const s = this.shadowRoot?.querySelector("slot")?.assignedElements({ flatten: !0 }) || [];
      this._assignedElements = s, this._assignedElements.length > 0 && this._setKeyboardNavigation();
    }, this._handleKeydown = (e) => {
      switch (e.key) {
        case "PageDown":
          this._moveToRowEdge(e, "last");
          break;
        case "PageUp":
          this._moveToRowEdge(e, "first");
          break;
        case "Home":
          this._moveToRowEdgeCell(e, "first");
          break;
        case "End":
          this._moveToRowEdgeCell(e, "last");
          break;
        case "ArrowDown":
          this._moveRowFocus(e, 1);
          break;
        case "ArrowUp":
          this._moveRowFocus(e, -1);
          break;
        case "ArrowRight":
          this._moveCellFocus(e, 1);
          break;
        case "ArrowLeft":
          this._moveCellFocus(e, -1);
          break;
        case "Tab":
          this._handleTab(e);
          break;
      }
    };
  }
  static get styles() {
    return [m(g), m(f)];
  }
  _setCurrentFocusableElement(e) {
    this._currentFocusableElement && this._currentFocusableElement !== e && this._currentFocusableElement.setAttribute("tabindex", "-1"), e.setAttribute("tabindex", "0"), this._currentFocusableElement = e;
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "rowgroup"), this.addEventListener("keydown", this._handleKeydown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.shadowRoot?.querySelector("slot")?.removeEventListener("slotchange", this._handleSlotChange), this.removeEventListener("keydown", this._handleKeydown);
  }
  firstUpdated() {
    this.shadowRoot?.querySelector("slot")?.addEventListener("slotchange", this._handleSlotChange), this._handleSlotChange();
  }
  _handleTab(e) {
    const s = this._getRowFromEvent(e);
    !s || !this._getCellFromEvent(e) || this._setCurrentFocusableElement(s);
  }
  _moveRowFocus(e, s) {
    const t = this._getRows();
    if (t.length === 0) return;
    const r = this._getRowFromEvent(e) ?? t[0], c = t.indexOf(r) + s, n = t[c];
    if (!n) return;
    e.preventDefault();
    const i = `dss-cell${l()}`;
    if (this._currentFocusableElement?.localName === i && r.contains(this._currentFocusableElement)) {
      const a = this._getCellsFromRow(r).indexOf(this._currentFocusableElement), u = this._getCellsFromRow(n)[a];
      if (u) {
        this._setCurrentFocusableElement(u), u.focus();
        return;
      }
    }
    this._setCurrentFocusableElement(n), n.focus();
  }
  _moveCellFocus(e, s) {
    const t = this._getRowFromEvent(e);
    if (!t) return;
    const r = this._getCellsFromRow(t);
    if (r.length === 0) return;
    const o = this._getCellFromEvent(e);
    if (!o) {
      if (s < 0) return;
      e.preventDefault(), this._setCurrentFocusableElement(r[0]), r[0].focus();
      return;
    }
    const c = r.indexOf(o);
    if (c < 0) return;
    const n = c + s;
    if (n < 0) {
      e.preventDefault(), this._setCurrentFocusableElement(t), t.focus();
      return;
    }
    const i = r[n];
    i && (e.preventDefault(), this._setCurrentFocusableElement(i), i.focus());
  }
  _moveToRowEdge(e, s) {
    const t = this._getRows();
    if (t.length === 0) return;
    const r = s === "first" ? t[0] : t[t.length - 1], o = this._getRowFromEvent(e) ?? this._getRowFromFocusable(), c = `dss-cell${l()}`, n = this._currentFocusableElement?.localName === c && o && o.contains(this._currentFocusableElement);
    if (e.preventDefault(), n && o) {
      const h = this._getCellsFromRow(o).indexOf(this._currentFocusableElement), a = this._getCellsFromRow(r)[h];
      if (a) {
        this._setCurrentFocusableElement(a), a.focus();
        return;
      }
    }
    this._setCurrentFocusableElement(r), r.focus();
  }
  _moveToRowEdgeCell(e, s) {
    const t = this._getRowFromEvent(e) ?? this._getRowFromFocusable();
    if (!t) return;
    const r = this._getCellsFromRow(t);
    if (r.length === 0) return;
    const o = s === "first" ? r[0] : r[r.length - 1];
    e.preventDefault(), this._setCurrentFocusableElement(o), o.focus();
  }
  _getRows() {
    const e = `dss-row${l()}`;
    return this._assignedElements.filter((s) => s.localName === e);
  }
  _getRowFromEvent(e) {
    const s = `dss-row${l()}`;
    for (const t of e.composedPath())
      if (t instanceof HTMLElement && t.localName === s) return t;
    return null;
  }
  _getRowFromFocusable() {
    const e = `dss-row${l()}`, s = `dss-cell${l()}`, t = this._currentFocusableElement;
    return t ? t.localName === e ? t : t.localName === s ? t.closest(e) : null : null;
  }
  _getCellsFromRow(e) {
    const s = `dss-cell${l()}`;
    return Array.from(e.querySelectorAll(s));
  }
  _getCellFromEvent(e) {
    const s = `dss-cell${l()}`;
    for (const t of e.composedPath())
      if (t instanceof HTMLElement && t.localName === s) return t;
    return null;
  }
  async _setKeyboardNavigation() {
    const e = this._assignedElements[0];
    e && this._setCurrentFocusableElement(e);
  }
  render() {
    return w();
  }
}
export {
  T as TableTbody
};
//# sourceMappingURL=table-tbody.js.map
