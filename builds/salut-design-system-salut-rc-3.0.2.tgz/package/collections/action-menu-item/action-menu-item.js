import { LitElement as u, unsafeCSS as h } from "lit";
import { property as t } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import { booleanType as s } from "../../utils/property-types.js";
import y from "./action-menu-item.style.css.js";
import { actionMenuItemTemplate as f } from "./action-menu-item.template.js";
var m = Object.defineProperty, S = Object.getOwnPropertyDescriptor, e = (p, i, n, a) => {
  for (var r = a > 1 ? void 0 : a ? S(i, n) : i, c = p.length - 1, l; c >= 0; c--)
    (l = p[c]) && (r = (a ? l(i, n, r) : l(r)) || r);
  return a && r && m(i, n, r), r;
};
class o extends u {
  constructor() {
    super(), this.status = "primary", this.label = "Label", this.leftIconFill = !1, this.leftIcon = void 0, this.rightIconFill = !1, this.rightIcon = void 0, this.actionLabel = "", this.actionIcon = void 0, this.actionStatus = "primary", this.notifications = 0, this.notificationsStatus = "error", this.selected = !1, this.disabled = !1, this.hasNestedMenu = !1, this.nestedMenuPosition = "top", this.first = !1, this.last = !1, this.tooltipPosition = "top", this.hideTooltip = !1, this._handleDocumentMouseDown = this._onDocumentMouseDown.bind(this);
  }
  static get styles() {
    return [h(d), h(y)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentMouseDown);
  }
  set state(i) {
    this.status = i;
  }
  get state() {
    return this.status;
  }
  set actionState(i) {
    this.actionStatus = i;
  }
  get actionState() {
    return this.actionStatus;
  }
  set notificationsState(i) {
    this.notificationsStatus = i;
  }
  get notificationsState() {
    return this.notificationsStatus;
  }
  _handleItemClick() {
    this.hasNestedMenu ? (this.selected = !0, this.requestUpdate()) : (this.dispatchEvent(new CustomEvent("item-click", { bubbles: !1, composed: !1 })), this.dispatchEvent(new CustomEvent("item-close", { bubbles: !0, composed: !0 })));
  }
  _handleKeydown(i) {
    const n = i.key;
    n === "Enter" || n === "Space" ? this._handleItemClick() : n === "Escape" && this.selected && this._unselectItem();
  }
  _handleAction(i) {
    i.stopPropagation(), this.dispatchEvent(new CustomEvent("item-action", { detail: this.label }));
  }
  _clickOutside() {
    document.addEventListener("mousedown", this._handleDocumentMouseDown);
  }
  _onDocumentMouseDown(i) {
    i.composedPath().includes(this) || this.selected && this._unselectItem();
  }
  _unselectItem() {
    this.selected = !1, this.requestUpdate();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._clickOutside();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return f(this);
  }
}
e([
  t({ type: String })
], o.prototype, "status", 2);
e([
  t({ type: String })
], o.prototype, "state", 1);
e([
  t({ type: String })
], o.prototype, "label", 2);
e([
  t(s)
], o.prototype, "leftIconFill", 2);
e([
  t({ type: String })
], o.prototype, "leftIcon", 2);
e([
  t(s)
], o.prototype, "rightIconFill", 2);
e([
  t({ type: String })
], o.prototype, "rightIcon", 2);
e([
  t({ type: String })
], o.prototype, "actionLabel", 2);
e([
  t({ type: String })
], o.prototype, "actionIcon", 2);
e([
  t({ type: String })
], o.prototype, "actionStatus", 2);
e([
  t({ type: String })
], o.prototype, "actionState", 1);
e([
  t({ type: Number })
], o.prototype, "notifications", 2);
e([
  t({ type: String })
], o.prototype, "notificationsStatus", 2);
e([
  t({ type: String })
], o.prototype, "notificationsState", 1);
e([
  t(s)
], o.prototype, "selected", 2);
e([
  t(s)
], o.prototype, "disabled", 2);
e([
  t(s)
], o.prototype, "hasNestedMenu", 2);
e([
  t({ type: String })
], o.prototype, "nestedMenuPosition", 2);
e([
  t(s)
], o.prototype, "first", 2);
e([
  t(s)
], o.prototype, "last", 2);
e([
  t({ type: String })
], o.prototype, "tooltipPosition", 2);
e([
  t(s)
], o.prototype, "hideTooltip", 2);
export {
  o as ActionMenuItem
};
//# sourceMappingURL=action-menu-item.js.map
