import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as a, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const s = a`dss-icon${t(e())}`, d = a`dss-icon-button${t(e())}`, $ = a`dss-notification-badge${t(e())}`, n = (i) => l`
  <li
    class=${o({
  "dss-action-menu-item": !0,
  "dss-action-menu-item--selected": !!i.selected,
  "dss-action-menu-item--disabled": !!i.disabled,
  "dss-action-menu-item--first": !!i.first,
  "dss-action-menu-item--last": !!i.last,
  [`dss-action-menu-item--${i.status}`]: !!i.status
})}
    tabindex="${i.disabled ? -1 : 0}"
    role="menuitem"
    aria-disabled=${i.disabled ? "true" : "false"}
    @click=${i._handleItemClick}
    @keydown=${i._handleKeydown}
  >
    ${i.leftIcon ? l`<${s} role="none" size="md" icon="${i.leftIcon}" ?fill="${i.leftIconFill}"></${s}>` : null}
    <p role="none" class="dss-action-menu-item-label">${i.label}</p>
    ${!i.selected && i.notifications > 0 ? l`
          <${$}
            state="${i.notificationsState}"
            value="${i.notifications}"
            hideBorder
          ></${$}>
        ` : null}
    ${i.rightIcon ? l`<${s} size="md" icon="${i.rightIcon}" ?fill="${i.rightIconFill}"></${s}>` : null}
    ${i.actionIcon ? l`
          <${d}
            icon="${i.actionIcon}"
            label="${i.actionLabel}"
            variant="${i.actionState}"
            @click="${i._handleAction}"
            ?disabled=${i.disabled}
            tooltipPosition="${i.tooltipPosition}"
            ?hideTooltip=${i.hideTooltip}
          ></${d}>
        ` : null}
    ${i.hasNestedMenu ? l`
          <${s} size="md" icon="chevron_right"></${s}>
          <slot></slot>
        ` : null}
  </li>
`;
export {
  n as actionMenuItemTemplate
};
//# sourceMappingURL=action-menu-item.template.js.map
