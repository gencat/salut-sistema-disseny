import { nothing as b } from "lit";
import { repeat as v } from "lit/directives/repeat.js";
import { unsafeHTML as g } from "lit/directives/unsafe-html.js";
import { unsafeStatic as t, literal as d, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { highlightText as u } from "../../api/marker/marker.js";
import _ from "../../assets/img/feedback-empty.svg.js";
import T from "../../assets/img/feedback-not_found.svg.js";
const f = d`dss-modal${t(l())}`, o = d`dss-content-switcher${t(l())}`, h = d`dss-tile${t(l())}`, a = d`dss-button${t(l())}`, n = d`dss-searchbar${t(l())}`, $ = d`dss-user-feedback${t(l())}`, z = (e) => {
  const r = e._filterItems(), x = r.findIndex((i) => i.text === e._selectedText);
  return s`
    <${f} 
      modalTitle="${e.titleText}" 
      ?open=${e.open}
      hideCloseIcon
      hasScroll
      fullHeight
      fullWidth
      flexBody
      removeBodyPadding
      @close=${e._onClose}>
      
      <div slot="body" class="dss-predefined-texts-wrapper">

        <div class="dss-predefined-texts-header">
          <${o}
          size="lg"
          .tabs="${e._categories}"
          @change=${e._handleTabChange}
          ></${o}>

          <${n}
            class="dss-predefined-texts-searchbar"
            label="Cercador"
            hideLabel
            size="md"
            innerFocus
            @input=${e._handleSearch}
            @change=${e._clearFilter}
            >
          </${n}>

        </div>

        <div class="dss-predefined-texts-content">

          ${r.length > 0 ? s`
            <div class="dss-predefined-texts-options">
              ${v(
    r,
    (i, c) => s`
                  <${h} 
                    type="selector" 
                    tiletitle="${i.title}" 
                    description="${i.text}"
                    selected=${e._selectedIndex ? c === e._selectedIndex : c === x}
                    marker="${e._filter}"
                    @onTileClick=${() => e._onSelectText(c, i.text)}
                  >
                  </${h} >
              `
  )}
          
            </div>

            <div class="dss-predefined-texts-value">
              ${e._selectedText !== "" ? s`
                  <div class="preset-text">
                    ${g(u(e._selectedText, e._filter))}
                  </div>
                  <div class="description">${e.descriptionLabel}</div>
                ` : b}
            </div>
            ` : s`
            <div class="dss-predefined-texts-no-results">

              ${e._filter.length > 0 ? s`
                  <${$} 
                    size="md" 
                    imagesrc="${T}"  
                    title="${e.noResultsTitle}" 
                    description="${e.noResultsLabel}"">
                  </${$}>
                ` : s`
                  <${$} 
                    size="md" 
                    imagesrc="${_}" 
                    title="${e.noDataTitle}" 
                    description="${e.noDataLabel}"">
                  </${$}>
                `}
              
            </div>
            `}
        </div>
      </div>
      <div class="dss-modal-footer" slot="footer">
        <${a} 
          variant="secondary" 
          size="lg" 
          label="${e.buttonLabelCancel}"
          @onClick=${e._handleCancel}
        ></${a}>
        <${a} 
          size="lg" 
          label="${e.buttonLabelSelect}"
          @onClick=${e._handleSelect}
          ?disabled=${r.length === 0}
        ></${a}>
      </div>
    </${f}>
  `;
};
export {
  z as template
};
//# sourceMappingURL=preset-texts.template.js.map
