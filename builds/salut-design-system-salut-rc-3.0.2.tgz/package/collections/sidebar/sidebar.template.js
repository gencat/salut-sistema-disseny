import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as e, literal as d, html as o } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const t = d`dss-icon-button${e(i())}`, l = d`dss-typography${e(i())}`, r = d`dss-tooltip${e(i())}`, b = (s) => o`
	<div class=${a({
  "dss-sidebar": !0,
  "dss-sidebar--expanded": s.expanded,
  [`dss-sidebar--${s.placement}`]: !!s.placement
})}>
		<div class="dss-sidebar-header">
			<div class="dss-sidebar-header__toggle">
				<${t}
					icon=${s.expanded ? s._iconToggleExpanded : s._iconToggleCollapsed}
					size="lg"
					label="${s.expanded ? "col·lapsar sidebar" : "expandir sidebar"}"
					hideTooltip
					@click=${s._toggle}
				></${t}>
			</div>
			<div class="dss-sidebar-header__title" @mouseenter=${s._checkTitleTruncated}>
				<${l} variant="headline-4">
					${s.titleText}
					<${r} 
						class="${a({
  "dss-sidebar-tooltip": !0,
  "dss-sidebar-tooltip--visible": s._isTruncated
})}"
						?tooltipFixed=${s.tooltipFixed}
						?forceViewport=${s.forceViewport}
						aria-hidden="true"
					>
						${s.titleText}
					</${r}>
				</${l}>
				
			</div>
		</div>
		<div class="dss-sidebar-content">
			<slot></slot>
		</div>
	</div>
`;
export {
  b as template
};
//# sourceMappingURL=sidebar.template.js.map
