import { LitElement as h, unsafeCSS as c } from "lit";
import { property as r, state as p } from "lit/decorators.js";
import T from "../../shared/reset.style.css.js";
import { booleanConverter as f, booleanType as d } from "../../utils/property-types.js";
import u from "./sidebar.style.css.js";
import { template as m } from "./sidebar.template.js";
var y = Object.defineProperty, t = (l, i, o, g) => {
  for (var s = void 0, n = l.length - 1, a; n >= 0; n--)
    (a = l[n]) && (s = a(i, o, s) || s);
  return s && y(i, o, s), s;
};
class e extends h {
  constructor() {
    super(...arguments), this.titleText = void 0, this.expanded = !1, this.placement = "left", this.iconToggleRight = "keyboard_arrow_right", this.iconToggleLeft = "keyboard_arrow_left", this.tooltipFixed = !1, this.forceViewport = !1, this._iconToggleExpanded = this.iconToggleLeft, this._iconToggleCollapsed = this.iconToggleRight, this._isTruncated = !1;
  }
  static get styles() {
    return [c(T), c(u)];
  }
  _toggle() {
    this.expanded = !this.expanded, this.dispatchEvent(
      new CustomEvent("toggle", {
        detail: { expanded: this.expanded },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _checkTitleTruncated(i) {
    if (!i || this.prevTitleText === this.titleText) return;
    const o = i.currentTarget;
    if (!o) return;
    const g = o.scrollHeight > o.clientHeight || o.scrollWidth > o.clientWidth;
    this._isTruncated = g, this.prevTitleText = this.titleText;
  }
  updated(i) {
    i.has("placement") && queueMicrotask(() => {
      this.placement === "right" ? (this._iconToggleExpanded = this.iconToggleRight, this._iconToggleCollapsed = this.iconToggleLeft) : (this._iconToggleExpanded = this.iconToggleLeft, this._iconToggleCollapsed = this.iconToggleRight);
    });
  }
  render() {
    return m(this);
  }
}
t([
  r({ type: String })
], e.prototype, "titleText");
t([
  r({ converter: f, reflect: !0 })
], e.prototype, "expanded");
t([
  r({ type: String })
], e.prototype, "placement");
t([
  r({ type: String })
], e.prototype, "iconToggleRight");
t([
  r({ type: String })
], e.prototype, "iconToggleLeft");
t([
  r(d)
], e.prototype, "tooltipFixed");
t([
  r(d)
], e.prototype, "forceViewport");
t([
  p()
], e.prototype, "_iconToggleExpanded");
t([
  p()
], e.prototype, "_iconToggleCollapsed");
t([
  p()
], e.prototype, "_isTruncated");
export {
  e as Sidebar
};
//# sourceMappingURL=sidebar.js.map
