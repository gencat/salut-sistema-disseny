import { LitElement as u, unsafeCSS as d } from "lit";
import { property as n, state as m, query as c, queryAll as f } from "lit/decorators.js";
import { getPortalContainer as _ } from "../../api/portal-manager/portal-manager.js";
import g from "../../shared/reset.style.css.js";
import { scheduleShow as y, executeShow as E, hideFloating as b, updateFloatingCombobox as w, updateFloatingPosition as x } from "../../utils/floating-combobox.js";
import { booleanType as I } from "../../utils/property-types.js";
import T from "./context-menu-options.style.css.js";
import { template as P } from "./context-menu-options.template.js";
var U = Object.defineProperty, r = (h, t, e, s) => {
  for (var i = void 0, a = h.length - 1, p; a >= 0; a--)
    (p = h[a]) && (i = p(t, e, i) || i);
  return i && U(t, e, i), i;
};
const l = class l extends u {
  constructor() {
    super(...arguments), this.isOpen = !1, this.items = [], this.placement = "right-start", this._isFirstUpdated = !0, this.delay = 0, this._initialParent = null, this._portalManager = null, this._toggle = () => {
      this.isOpen ? this.show() : this.hide();
    };
  }
  static get styles() {
    return [d(g), d(T)];
  }
  show() {
    y({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    });
  }
  _executeShow() {
    E({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCombobox()
    });
  }
  hide() {
    b({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCombobox() {
    w({
      referenceEl: this.referenceEl ?? this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    const t = this.referenceEl ?? this._parent;
    t && await x(t, this, {
      placement: this.placement,
      matchWidth: !1
    });
  }
  _handleClick(t) {
    this.dispatchEvent(new CustomEvent("option-click", { detail: { id: t }, bubbles: !0, composed: !0 }));
  }
  _getFirstEnabledIndex() {
    return this.items.findIndex((t) => !t.disabled);
  }
  _getNextEnabledIndex(t, e) {
    if (!this.items.length) return -1;
    let s = t + e;
    for (; s >= 0 && s < this.items.length; ) {
      if (!this.items[s].disabled) return s;
      s += e;
    }
    return -1;
  }
  _focusItemByIndex(t) {
    const e = Array.from(this._itemEls ?? []);
    !e.length || t < 0 || t >= e.length || (e.forEach((s, i) => {
      s.tabIndex = i === t ? 0 : -1;
    }), e[t].focus());
  }
  _resetRovingTabIndex() {
    const t = Array.from(this._itemEls ?? []);
    if (!t.length) return;
    const e = this._getFirstEnabledIndex();
    t.forEach((s, i) => {
      s.tabIndex = e !== -1 && i === e ? 0 : -1;
    });
  }
  _getInitialTabIndex(t) {
    const e = this._getFirstEnabledIndex();
    return e === -1 ? -1 : t === e ? 0 : -1;
  }
  _onItemKeydown(t, e) {
    if (t.key === "Escape") {
      this._focusSentinel();
      return;
    }
    if (t.key === "Enter" || t.key === " ") {
      t.target.click();
      return;
    }
    if (t.key !== "ArrowDown" && t.key !== "ArrowUp") return;
    t.preventDefault();
    const s = t.key === "ArrowDown" ? 1 : -1, i = this._getNextEnabledIndex(e, s);
    i !== -1 && this._focusItemByIndex(i);
  }
  _focusSentinel() {
    this.dispatchEvent(
      new CustomEvent("options-focusout", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  updated(t) {
    t.has("isOpen") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : (this._toggle(), this.isOpen && this.updateComplete.then(() => this._resetRovingTabIndex()));
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = _(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return P(this);
  }
};
l.shadowRootOptions = {
  ...u.shadowRootOptions,
  delegatesFocus: !0
};
let o = l;
r([
  n(I)
], o.prototype, "isOpen");
r([
  n({ type: Array })
], o.prototype, "items");
r([
  n({ type: String })
], o.prototype, "placement");
r([
  n({ attribute: !1 })
], o.prototype, "referenceEl");
r([
  m()
], o.prototype, "_isFirstUpdated");
r([
  c(".dss-context-menu-options")
], o.prototype, "_floatingCombobox");
r([
  f(".dss-context-menu-item")
], o.prototype, "_itemEls");
r([
  n({ type: Number })
], o.prototype, "delay");
export {
  o as ContextMenuOptions
};
//# sourceMappingURL=context-menu-options.js.map
