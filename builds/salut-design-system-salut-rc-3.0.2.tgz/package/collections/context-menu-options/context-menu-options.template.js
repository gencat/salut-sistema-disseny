import { nothing as a } from "lit";
import { classMap as i } from "lit/directives/class-map.js";
import { ifDefined as d } from "lit/directives/if-defined.js";
import { unsafeStatic as u, literal as c, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as m } from "../../api/custom-element-scope.js";
const o = c`dss-icon${u(m())}`, x = (s) => e`
  <div
    class=${i({
  "dss-context-menu-options": !0,
  "dss-context-menu-options--open": s.isOpen
})}>
		<ul class="dss-context-menu-list" role="menu">
			${s.items.map(
  (t, n) => e`
				<li
					role="menuitem"
					class=${i({
    "dss-context-menu-item": !0,
    "dss-context-menu-item--disabled": !!t.disabled
  })}
					tabindex=${d(t.disabled ? -1 : s._getInitialTabIndex(n))}
					@keydown=${(l) => s._onItemKeydown(l, n)}
					@click=${() => s._handleClick(t.id)}
				>
					${t.icon ? e`<${o} icon=${t.icon}></${o}>` : a}
					<span class="dss-context-menu-item__label">
						${t.label}
					</span>
				</li>
			`
)}
		</ul>
		<button
			class="dss-context-menu-options__sentinel"
			type="button"
			aria-hidden="true"
			@focus=${s._focusSentinel}
		>
			Focus Sentinel
		</button>
	</div>
`;
export {
  x as template
};
//# sourceMappingURL=context-menu-options.template.js.map
