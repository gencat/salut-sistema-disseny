import { autoUpdate as f, computePosition as m, offset as b, flip as g, shift as v } from "@floating-ui/dom";
import { LitElement as C, unsafeCSS as u } from "lit";
import { property as n } from "lit/decorators.js";
import w from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import L from "./action-menu.style.css.js";
import { actionMenuTemplate as k } from "./action-menu.template.js";
var y = Object.defineProperty, o = (d, t, e, s) => {
  for (var i = void 0, a = d.length - 1, c; a >= 0; a--)
    (c = d[a]) && (i = c(t, e, i) || i);
  return i && y(t, e, i), i;
};
class l extends C {
  constructor() {
    super(), this._parentMouseDownHandler = null, this._parentKeyDownHandler = null, this._slotChangeHandler = null, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || (this.classList.remove("visible"), this._isVisible = !1, this._removeDropdownListener());
      },
      {
        root: null,
        threshold: 0
      }
    ), this.fullWidth = !1, this.position = "right-start", this.disablePopper = !1, this.disableParentClick = !1, this.open = !1, this.dropdownFixed = !1, this._cleanupFloating = null, this._referenceEl = null, this._floatingEl = null, this._parent = null, this._trigger = null, this._isVisible = !1, this._disableClickOutside = !0, this._isFirstUpdate = !0, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [u(w), u(L)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("item-close", this._handleCloseAllMenus), this._handleConnectedCallback();
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.removeEventListener("item-close", this._handleCloseAllMenus), this.visibleObserver.disconnect(), this._cleanupFloating?.(), this._cleanupFloating = null;
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _handleConnectedCallback() {
    if (this._isFirstUpdate) return;
    const t = this.style.position;
    t !== "absolute" && t !== "fixed" && t !== "relative" && (this._referenceEl ? this._updateFloatingPosition() : this._initActionMenu());
  }
  _createFloatingInstance(t) {
    this._referenceEl = t, this._floatingEl = this, this._cleanupFloating?.(), this._cleanupFloating = f(this._referenceEl, this._floatingEl, () => this._updateFloatingPosition()), this.visibleObserver.observe(t), this._parentMouseDownHandler = () => this._openByParent(), this._parentKeyDownHandler = (e) => {
      const s = e.key;
      (s === "Enter" || s === " ") && this._openByParent();
    }, t.addEventListener("mousedown", this._parentMouseDownHandler), t.addEventListener("keydown", this._parentKeyDownHandler);
  }
  async _updateFloatingPosition() {
    if (!this._referenceEl || !this._floatingEl) return;
    const { x: t, y: e, strategy: s } = await m(this._referenceEl, this._floatingEl, {
      placement: this.position,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        b(8),
        g(),
        v({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        })
      ]
    });
    Object.assign(this._floatingEl.style, {
      position: s,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _openByParent() {
    !this._isVisible && !this.disableParentClick && setTimeout(() => {
      this._updateFloatingPosition(), this.classList.add("visible"), this._disableClickOutside = !1, this._isVisible = !0, this._addDropdownListener();
    }, 100);
  }
  _handleCloseAllMenus() {
    this._closeMenu();
  }
  _handleSlotChange() {
    const t = this.shadowRoot?.querySelector("slot");
    if (t) {
      const e = t.assignedElements({ flatten: !0 }).filter((s) => s.tagName.toLowerCase() === "dss-action-menu-item");
      e.forEach((s, i) => {
        i === 0 ? s.setAttribute("first", "") : s.removeAttribute("first"), i === e.length - 1 ? s.setAttribute("last", "") : s.removeAttribute("last");
      });
    }
  }
  _checkClickOutside(t) {
    if (this.disableParentClick && this._disableClickOutside)
      return;
    const e = t.composedPath(), s = this.closest("dss-action-menu-item"), i = s && e.includes(s);
    if (s && !i)
      return this._closeMenu();
    const a = e.includes(this._parent);
    if (!e.some(
      (h) => h instanceof HTMLElement && (h.tagName.toLowerCase() === "dss-action-menu" || h.tagName.toLowerCase() === "ul" && h.classList.contains("dss-action-menu"))
    ) && !a && !this.disablePopper)
      return this._closeMenu();
    const p = this._parent.classList.contains("dss-split-button-action"), _ = this._parent?.getAttribute("data-expanded");
    if (p && _ === "false")
      return this._closeMenu();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e.tagName.toLowerCase() !== "dss-action-menu-item" && this._closeMenu();
  }
  _closeMenu() {
    setTimeout(() => {
      this.classList.contains("visible") && (this.classList.remove("visible"), this._isVisible = !1, this.dispatchEvent(new CustomEvent("close")), this._removeDropdownListener());
    }, 0);
  }
  _initActionMenu() {
    const t = this.assignedSlot;
    this._parent = t ? t.parentElement : this.parentElement, this._parent && !this.disablePopper && this._createFloatingInstance(this._parent), this.disablePopper && (this.classList.add("visible"), this._addDropdownListener());
    const e = this.shadowRoot?.querySelector("slot");
    e && (this._slotChangeHandler = () => this._handleSlotChange(), e.addEventListener("slotchange", this._slotChangeHandler)), this._handleSlotChange();
  }
  async firstUpdated() {
    await this.updateComplete, this._initActionMenu(), this._isFirstUpdate = !1;
  }
  updated(t) {
    super.updated(t), t.has("position") && this._updateFloatingPosition(), t.has("open") && (this.open ? (this.classList.add("visible"), this._isVisible = !0, this._updateFloatingPosition(), setTimeout(() => {
      this._addDropdownListener(), this._disableClickOutside = !1;
    }, 100)) : (this.classList.remove("visible"), this._isVisible = !1, this._disableClickOutside = !0, this._removeDropdownListener()));
  }
  render() {
    return k(this);
  }
}
o([
  n(r)
], l.prototype, "fullWidth");
o([
  n({ type: String })
], l.prototype, "position");
o([
  n(r)
], l.prototype, "disablePopper");
o([
  n(r)
], l.prototype, "disableParentClick");
o([
  n(r)
], l.prototype, "open");
o([
  n(r)
], l.prototype, "dropdownFixed");
export {
  l as ActionMenu
};
//# sourceMappingURL=action-menu.js.map
