import { LitElement as p, unsafeCSS as l } from "lit";
import { property as r } from "lit/decorators.js";
import w from "../../components/icon-button/icon-button.style.css.js";
import _ from "../../foundations/icon/icon.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import u from "./drawer.style.css.js";
import { template as m } from "./drawer.template.js";
var y = Object.defineProperty, i = (d, e, t, a) => {
  for (var s = void 0, n = d.length - 1, h; n >= 0; n--)
    (h = d[n]) && (s = h(e, t, s) || s);
  return s && y(e, t, s), s;
};
const v = 250;
class o extends p {
  /* METHODS */
  constructor() {
    super(), this.variant = "default", this.jcef = !1, this.open = !1, this.title = "", this.titleText = "", this._drawerHeader = null, this._drawerFooter = null, this._scrollHandler = null, this._scrollContainer = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this), this._scrollHandler = this._handleScroll.bind(this);
  }
  static get styles() {
    return [l(f), l(_), l(w), l(u)];
  }
  _showDrawer() {
    this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), document.body.style.overflow = "hidden";
  }
  _hideDrawer() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      this.classList.remove("hide"), this.style.visibility = "hidden";
    }, v), document.body.style.overflow = "";
  }
  _handleClose() {
    this.open = !1, this._hideDrawer(), this.requestUpdate();
    const e = new Event("close");
    this.dispatchEvent(e);
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._handleClose();
  }
  _handleOutsideClick(e) {
    if (this.open) {
      const t = this.shadowRoot?.querySelector(".drawer"), a = e.composedPath();
      t && a.includes(this) && !a.includes(t) && this._handleClose();
    }
  }
  _handleScroll(e) {
    const t = e.target;
    t && (t.scrollTop > 0 ? this._drawerHeader?.classList.add("drawer-header--scrolled") : this._drawerHeader?.classList.remove("drawer-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? this._drawerFooter?.classList.add("drawer-footer--scrolled") : this._drawerFooter?.classList.remove("drawer-footer--scrolled"));
  }
  /* LIT LIFECYCLE */
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick), this._scrollContainer && this._scrollHandler && this._scrollContainer.removeEventListener("scroll", this._scrollHandler), this._scrollContainer = null;
  }
  updated(e) {
    e.has("open") && (this.open ? this._showDrawer() : this._hideDrawer()), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  firstUpdated() {
    const e = this.shadowRoot?.querySelector(".drawer");
    e && (this._scrollContainer = e, this._scrollHandler && this._scrollContainer.addEventListener("scroll", this._scrollHandler), this._drawerHeader = this.shadowRoot?.querySelector(".drawer-header"), this._drawerFooter = this.shadowRoot?.querySelector(".drawer-footer"), e.scrollHeight > e.clientHeight && this._drawerFooter.classList.add("drawer-footer--scrolled"));
  }
  render() {
    return m(this);
  }
}
i([
  r({ type: String })
], o.prototype, "variant");
i([
  r(c)
], o.prototype, "jcef");
i([
  r(c)
], o.prototype, "open");
i([
  r({ type: String })
], o.prototype, "title");
i([
  r({ type: String })
], o.prototype, "titleText");
export {
  o as Drawer
};
//# sourceMappingURL=drawer.js.map
