import { unsafeStatic as a, literal as d, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const e = d`dss-button${a(t())}`, r = (l) => i`
  <ul class="dss-header-links" role="menu">
    ${l.items.map(
  (s) => i`
        <li class="dss-header-links__item" role="menuitem">
          <${e}
            variant="subtle"
            size="lg"
            icon="${s.icon ? s.icon : void 0}"
            label="${s.label}"
            ?disabled=${s.disabled}
            @click=${() => l._dispatchItemAction(s)}
            onlyIcon
          >  
          </${e}>
        </li>
      `
)}
    ${l.hideHelp ? null : i`
          <li class="dss-header-links__item" role="menuitem">
            <${e}
              class="dss-header-links__button-default"
              variant="subtle"
              size="lg"
              icon="help_outline"
              label="${l.helpLabel}"
              ?disabled=${l.disableHelp}
              @click=${l._handleHelp}
              onlyIcon
            >  
            </${e}>
          </li>
        `}
     ${l.hideConfig ? null : i`
          <li class="dss-header-links__item" role="menuitem">
            <${e}
              class="dss-header-links__button-default"
              variant="subtle"
              size="lg"
              icon="settings"
              label="${l.configLabel}"
              ?disabled=${l.disableConfig}
              @click=${l._handleConfig}
              onlyIcon
            >  
            </${e}>
          </li>
        `}
  </ul>
`;
export {
  r as headerLinksTemplate
};
//# sourceMappingURL=header-links.template.js.map
