import { LitElement as f, unsafeCSS as d } from "lit";
import { property as e } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./header-links.style.css.js";
import { headerLinksTemplate as c } from "./header-links.template.js";
var u = Object.defineProperty, t = (n, s, p, b) => {
  for (var o = void 0, l = n.length - 1, a; l >= 0; l--)
    (a = n[l]) && (o = a(s, p, o) || o);
  return o && u(s, p, o), o;
};
class i extends f {
  constructor() {
    super(...arguments), this.jcef = !1, this.hideHelp = !1, this.disableHelp = !1, this.helpLabel = "Ajuda", this.configLabel = "Centre de configuració", this.hideConfig = !1, this.disableConfig = !1, this.items = [];
  }
  static get styles() {
    return [d(h), d(m)];
  }
  /* METHODS */
  _dispatchItemAction(s) {
    const p = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("link-click", p));
  }
  _handleHelp() {
    this.dispatchEvent(new CustomEvent("help", { bubbles: !0, composed: !0 }));
  }
  _handleConfig() {
    this.dispatchEvent(new CustomEvent("config", { bubbles: !0, composed: !0 }));
  }
  render() {
    return c(this);
  }
}
t([
  e(r)
], i.prototype, "jcef");
t([
  e(r)
], i.prototype, "hideHelp");
t([
  e(r)
], i.prototype, "disableHelp");
t([
  e({ type: String })
], i.prototype, "helpLabel");
t([
  e({ type: String })
], i.prototype, "configLabel");
t([
  e(r)
], i.prototype, "hideConfig");
t([
  e(r)
], i.prototype, "disableConfig");
t([
  e({ type: Array })
], i.prototype, "items");
export {
  i as HeaderLinks
};
//# sourceMappingURL=header-links.js.map
