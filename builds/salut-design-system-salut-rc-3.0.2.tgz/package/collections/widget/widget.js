import { LitElement as c, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import f from "../../shared/scrollbar.style.css.js";
import { booleanType as o } from "../../utils/property-types.js";
import u from "./widget.style.css.js";
import { template as S } from "./widget.template.js";
var g = Object.defineProperty, e = (n, s, r, h) => {
  for (var p = void 0, a = n.length - 1, y; a >= 0; a--)
    (y = n[a]) && (p = y(s, r, p) || p);
  return p && g(s, r, p), p;
};
class i extends c {
  constructor() {
    super(...arguments), this.variant = "box", this.icon = void 0, this.iconStatus = void 0, this.title = "Title", this.titleText = "Title", this.results = void 0, this.resultsState = "info", this.resultsLabel = "", this.info = void 0, this.infoBadgeState = "critic", this.infoBadgeIcon = "", this.infoBadgeOutlined = !0, this.notifications = void 0, this.notificationsState = "info", this.helpText = null, this.hasAction = !1, this.hasNext = !1, this.hasClose = !1, this.actionLabel = void 0, this.actionIcon = void 0, this.actionVariant = "primary", this.actionFill = !1, this.actionDisabled = !1, this.tooltipFixed = !1, this.tooltipPosition = "top", this.hideTooltip = !1, this.hasScroll = !1, this.folded = !1, this._eventOptions = {
      bubbles: !1,
      composed: !1
    };
  }
  static get styles() {
    return [l(d), l(f), l(u)];
  }
  checkTextTruncate(s) {
    if (!s) return;
    const r = s.target, h = r.scrollWidth > r.offsetWidth;
    r.setAttribute("data-truncated", h.toString());
  }
  handleAction() {
    this.dispatchEvent(new CustomEvent("action", this._eventOptions));
  }
  handleNext() {
    this.dispatchEvent(new CustomEvent("next", this._eventOptions));
  }
  handleClose() {
    this.dispatchEvent(new CustomEvent("close", this._eventOptions));
  }
  firstUpdated() {
    this.hasScroll && this.classList.add("scrollable");
  }
  updated(s) {
    super.updated(s), s.has("title") && queueMicrotask(() => {
      this.title !== "Title" && (this.titleText = this.title);
    });
  }
  render() {
    return S(this);
  }
}
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "icon");
e([
  t({ type: String })
], i.prototype, "iconStatus");
e([
  t({ type: String })
], i.prototype, "title");
e([
  t({ type: String })
], i.prototype, "titleText");
e([
  t({ type: String })
], i.prototype, "results");
e([
  t({ type: String })
], i.prototype, "resultsState");
e([
  t({ type: String })
], i.prototype, "resultsLabel");
e([
  t({ type: String })
], i.prototype, "info");
e([
  t({ type: String })
], i.prototype, "infoBadgeState");
e([
  t({ type: String })
], i.prototype, "infoBadgeIcon");
e([
  t(o)
], i.prototype, "infoBadgeOutlined");
e([
  t({ type: Number })
], i.prototype, "notifications");
e([
  t({ type: String })
], i.prototype, "notificationsState");
e([
  t({ type: String })
], i.prototype, "helpText");
e([
  t(o)
], i.prototype, "hasAction");
e([
  t(o)
], i.prototype, "hasNext");
e([
  t(o)
], i.prototype, "hasClose");
e([
  t({ type: String })
], i.prototype, "actionLabel");
e([
  t({ type: String })
], i.prototype, "actionIcon");
e([
  t({ type: String })
], i.prototype, "actionVariant");
e([
  t(o)
], i.prototype, "actionFill");
e([
  t(o)
], i.prototype, "actionDisabled");
e([
  t(o)
], i.prototype, "tooltipFixed");
e([
  t({ type: String })
], i.prototype, "tooltipPosition");
e([
  t(o)
], i.prototype, "hideTooltip");
e([
  t(o)
], i.prototype, "hasScroll");
e([
  t(o)
], i.prototype, "folded");
export {
  i as Widget
};
//# sourceMappingURL=widget.js.map
