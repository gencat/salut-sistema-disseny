import { LitElement as h, unsafeCSS as i } from "lit";
import { getCustomElementSuffix as n } from "../../api/custom-element-scope.js";
import d from "../../shared/reset.style.css.js";
import m from "./table-thead.style.css.js";
import { template as g } from "./table-thead.template.js";
class p extends h {
  constructor() {
    super(...arguments), this._assignedElements = [], this._currentFocusableElement = null, this._handleSlotChange = () => {
      const t = this.shadowRoot?.querySelector("slot")?.assignedElements({ flatten: !0 }) || [];
      this._assignedElements = t, this._setInitialFocus();
    }, this._handleKeydown = (e) => {
      switch (e.key) {
        case "Home":
        case "PageUp":
          this._moveToEdgeCell(e, "first");
          break;
        case "End":
        case "PageDown":
          this._moveToEdgeCell(e, "last");
          break;
        case "ArrowRight":
          this._moveCellFocus(e, 1);
          break;
        case "ArrowLeft":
          this._moveCellFocus(e, -1);
          break;
      }
    };
  }
  static get styles() {
    return [i(d), i(m)];
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "rowgroup"), this.addEventListener("keydown", this._handleKeydown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.shadowRoot?.querySelector("slot")?.removeEventListener("slotchange", this._handleSlotChange), this.removeEventListener("keydown", this._handleKeydown);
  }
  firstUpdated() {
    this.shadowRoot?.querySelector("slot")?.addEventListener("slotchange", this._handleSlotChange), this._handleSlotChange();
  }
  _setCurrentFocusableElement(e) {
    this._currentFocusableElement && this._currentFocusableElement !== e && this._currentFocusableElement.setAttribute("tabindex", "-1"), e.setAttribute("tabindex", "0"), this._currentFocusableElement = e;
  }
  _setInitialFocus() {
    const e = this._getHeaderRow();
    if (!e) return;
    e.removeAttribute("tabindex");
    const t = this._getCellsFromRow(e);
    t.length !== 0 && this._setCurrentFocusableElement(t[0]);
  }
  _moveCellFocus(e, t) {
    const s = `dss-row${n()}`, l = `dss-cell${n()}`, o = this._getCellFromEvent(e) ?? (this._currentFocusableElement?.localName === l ? this._currentFocusableElement : null), a = o?.closest(s) ?? this._getHeaderRow();
    if (!a) return;
    const r = this._getCellsFromRow(a);
    if (r.length === 0) return;
    const u = (o ? r.indexOf(o) : -1) + t, c = r[u];
    c && (e.preventDefault(), this._setCurrentFocusableElement(c), c.focus());
  }
  _moveToEdgeCell(e, t) {
    const s = this._getHeaderRow();
    if (!s) return;
    const l = this._getCellsFromRow(s);
    if (l.length === 0) return;
    const o = t === "first" ? l[0] : l[l.length - 1];
    e.preventDefault(), this._setCurrentFocusableElement(o), o.focus();
  }
  _getHeaderRow() {
    const e = `dss-row${n()}`;
    return this._assignedElements.find((t) => t.localName === e) ?? null;
  }
  _getCellsFromRow(e) {
    const t = `dss-cell${n()}`;
    return Array.from(e.querySelectorAll(t));
  }
  _getCellFromEvent(e) {
    const t = `dss-cell${n()}`;
    for (const s of e.composedPath())
      if (s instanceof HTMLElement && s.localName === t) return s;
    return null;
  }
  render() {
    return g();
  }
}
export {
  p as TableThead
};
//# sourceMappingURL=table-thead.js.map
