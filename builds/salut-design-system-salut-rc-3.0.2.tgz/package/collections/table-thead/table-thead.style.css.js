const o = ":host{display:block;width:100%;position:sticky;top:0;background-color:var(--color-white);z-index:200;box-shadow:var(--dss-border-width-md) var(--dss-border-width-md) -1px var(--color-neutral-700)}";
export {
  o as default
};
//# sourceMappingURL=table-thead.style.css.js.map
