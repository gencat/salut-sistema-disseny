import { html as t } from "lit/static-html.js";
const r = () => t`
    <slot></slot>
  `;
export {
  r as template
};
//# sourceMappingURL=table-thead.template.js.map
