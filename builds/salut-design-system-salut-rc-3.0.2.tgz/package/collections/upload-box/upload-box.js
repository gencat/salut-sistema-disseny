import { LitElement as p, unsafeCSS as d } from "lit";
import { property as r } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import _ from "./upload-box.style.css.js";
import { booleanType as f } from "../../utils/property-types.js";
import { template as m } from "./upload-box.template.js";
var c = Object.defineProperty, a = (o, e, t, i) => {
  for (var s = void 0, n = o.length - 1, h; n >= 0; n--)
    (h = o[n]) && (s = h(e, t, s) || s);
  return s && c(e, t, s), s;
};
class l extends p {
  constructor() {
    super(...arguments), this._inputChangeHandler = null, this.fileExplorerMessage = "Clica ", this.dragAndDropMessage = "o arrossega arxius aquí", this.dragAndDropIcon = "file_upload", this.filesFormatMessage = "PDF, JPEG o PNG de menys de 5MB", this.buttonLabel = "Buscar arxius", this.filesFormat = ["pdf", "jpeg", "png"], this.maxFileSize = 5242880, this.disableOpenFile = !1, this.helpText = void 0, this.maxUploadFiles = void 0, this.maxUploadFilesMessage = "", this._dragOver = !1, this._files = [], this._disabled = !1, this._hasMaxUploadFilesError = !1, this._fileFormatErrorMessage = "Format d’arxiu incorrecte", this._fileSizeErrorMessage = "Mida d’arxiu incorrecte", this._fileFormatAndSizeErrorMessage = "Format i mida d’arxiu incorrecte", this._fileErrors = {}, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._input && this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [d(u), d(_)];
  }
  get _input() {
    const e = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), e?.assignedElements()[0];
  }
  disconnectedCallback() {
    this.observer.disconnect(), this._input && this._inputChangeHandler && this._input.removeEventListener("change", this._inputChangeHandler);
  }
  _checkInputAttributes() {
    const e = this._input?.getAttribute("disabled");
    this._disabled = e !== null, this.requestUpdate();
  }
  /* METHODS */
  _onDragOver(e) {
    e.preventDefault(), !this._dragOver && !this._disabled && (this._dragOver = !0, this.requestUpdate());
  }
  _onDragLeave(e) {
    e.preventDefault(), this._dragOver && !this._disabled && (this._dragOver = !1, this.requestUpdate());
  }
  _onDrop(e) {
    if (e.preventDefault(), !this._disabled) {
      this._dragOver && (this._dragOver = !1, this.requestUpdate());
      const t = e.dataTransfer?.files;
      if (!t) return;
      this._handleUploadedFiles(t);
    }
  }
  _onClick() {
    this._input && !this._disabled && this._input.click();
  }
  _onSlotInputChange() {
    this._input && (this._inputChangeHandler || (this._inputChangeHandler = this._handleInputFileChange.bind(this)), this._input.addEventListener("change", this._inputChangeHandler));
  }
  _checkMaxUploadFiles(e) {
    if (!this.maxUploadFiles)
      return this._hasMaxUploadFilesError = !1, !0;
    const t = this._files.length + e;
    this._hasMaxUploadFilesError = t > this.maxUploadFiles, this.requestUpdate();
  }
  _isValidFileFormat(e) {
    const t = e.name.split(".").pop()?.toLowerCase();
    return this.filesFormat.includes(t || "");
  }
  _isValidFileSize(e) {
    return e.size <= this.maxFileSize;
  }
  _validateFile(e) {
    let t = !0, i = "";
    return !this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (t = !1, i = this._fileFormatAndSizeErrorMessage) : this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (t = !1, i = this._fileFormatErrorMessage) : !this._isValidFileSize(e) && this._isValidFileFormat(e) && (t = !1, i = this._fileSizeErrorMessage), t || (this._fileErrors[e.name] = i), t;
  }
  _isAlreadyUploaded(e) {
    return this._files.some((t) => t.name === e.name);
  }
  _handleInputFileChange(e) {
    const t = e.target;
    t.files && this._handleUploadedFiles(t.files);
  }
  _handleUploadedFiles(e) {
    if (e && e.length > 0) {
      if (this._checkMaxUploadFiles(e.length), this._hasMaxUploadFilesError) return;
      for (const t of Array.from(e))
        if (!this._isAlreadyUploaded(t)) {
          const i = this._validateFile(t), s = t;
          s.status = i ? "loading" : "invalid", this._files.push(s), this.requestUpdate(), this._readFile(t, i);
        }
    }
  }
  _readFile(e, t) {
    const i = new FileReader();
    i.onload = () => {
      this._files.find((s) => s.name === e.name).status = t ? "ready" : "invalid", this.requestUpdate(), this._dispatchUploadFiles();
    }, i.onerror = () => {
      this._files.find((s) => s.name === e.name).status = "error", i.error && (this._fileErrors[e.name] = i.error.message), this.requestUpdate();
    }, i.readAsDataURL(e);
  }
  _removeFile(e) {
    this._files.splice(e, 1), this._dispatchUploadFiles(), this._input && (this._input.value = ""), this._checkMaxUploadFiles(0), this.requestUpdate();
  }
  _reloadFile(e) {
    this._files.find((t) => t.name === e.name).status = "loading", this._fileErrors[e.name] = "", this.requestUpdate(), this._readFile(e);
  }
  /* PUBLIC METHODS */
  resetFiles() {
    this._files = [], this.requestUpdate();
  }
  /* EVENTS */
  _dispatchUploadFiles() {
    const e = {
      detail: this._files,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("upload-files", e));
  }
  _dispatchOpenFile(e) {
    const t = {
      detail: { file: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("open-file", t));
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    try {
      await this.updateComplete, this.maxUploadFiles && this.maxUploadFilesMessage === "" && (this.maxUploadFilesMessage = `S'ha superat el límit d'arxius. S'hi admet un màxim de ${this.maxUploadFiles} arxius`), this._input && (this.observer.observe(this._input, this.observerConfig), this._checkInputAttributes(), this._onSlotInputChange());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return m(this);
  }
}
a([
  r({ type: String })
], l.prototype, "fileExplorerMessage");
a([
  r({ type: String })
], l.prototype, "dragAndDropMessage");
a([
  r({ type: String })
], l.prototype, "dragAndDropIcon");
a([
  r({ type: String })
], l.prototype, "filesFormatMessage");
a([
  r({ type: String })
], l.prototype, "buttonLabel");
a([
  r({ type: Array })
], l.prototype, "filesFormat");
a([
  r({ type: Number })
], l.prototype, "maxFileSize");
a([
  r(f)
], l.prototype, "disableOpenFile");
a([
  r({ type: String })
], l.prototype, "helpText");
a([
  r({ type: Number })
], l.prototype, "maxUploadFiles");
a([
  r({ type: String })
], l.prototype, "maxUploadFilesMessage");
export {
  l as UploadBox
};
//# sourceMappingURL=upload-box.js.map
