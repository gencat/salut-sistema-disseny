import { LitElement as m, unsafeCSS as u } from "lit";
import { property as n, state as b } from "lit/decorators.js";
import _ from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import v from "../../shared/scrollbar.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import E from "./tabs-list.style.css.js";
import { tabsListTemplate as T } from "./tabs-list.template.js";
var w = Object.defineProperty, a = (f, t, e, s) => {
  for (var i = void 0, r = f.length - 1, d; r >= 0; r--)
    (d = f[r]) && (i = d(t, e, i) || i);
  return i && w(t, e, i), i;
};
class o extends m {
  constructor() {
    super(), this.dssTabsId = "", this.label = "", this.tabs = [], this.addTabText = "Afegir Tab", this.addTabEnabled = !1, this.canOrder = !1, this.canEdit = !1, this.canDelete = !1, this.fullHeight = !1, this._isEditing = !1, this._focusedIndex = null, this._tabsElements = window.document.querySelectorAll("[role='tab']"), this._firstTab = document.createElement("div"), this._lastTab = document.createElement("div"), this._addTabEnabled = !1, this._addTabText = "", this._ignoreInputFocusout = !1, this.draggedIndex = null, this._lastOverEl = null, this._handleUpdateArrowsBound = this._updateArrows.bind(this), this._tabKeydownHandler = (t) => {
      this._handleKeydown(t);
    }, this._tabMouseDownHandler = (t) => {
      this.setSelectedTab(t.currentTarget);
    };
  }
  static get styles() {
    return [u(g), u(v), u(_), u(E)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleUpdateArrowsBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._menu?.removeEventListener("scroll", this._handleUpdateArrowsBound), window.removeEventListener("resize", this._handleUpdateArrowsBound), this._removeTabListeners();
  }
  // menuContainer
  get _wrapper() {
    return this.shadowRoot?.querySelector(".dss-tabs") || void 0;
  }
  get _header() {
    return this.shadowRoot?.querySelector(".dss-tabs-header") || void 0;
  }
  // menu
  get _menu() {
    return this.shadowRoot?.querySelector(".dss-tabs-menu") || void 0;
  }
  // leftArrow
  get _prevScroll() {
    return this.shadowRoot?.querySelector(".dss-tabs-scroll-button--prev") || void 0;
  }
  // rightArrow
  get _nextScroll() {
    return this.shadowRoot?.querySelector(".dss-tabs-scroll-button--next") || void 0;
  }
  updated(t) {
    t.has("tabs") && this.changeTabWatch(), t.has("fullHeight") && (this.fullHeight ? (this.classList.add("full-height"), this._wrapper?.classList.add("dss-tabs--full-height")) : (this.classList.remove("full-height"), this._wrapper?.classList.remove("dss-tabs--full-height")));
  }
  async changeTabWatch() {
    this._removeTabListeners(), this._tabsElements = this.renderRoot.querySelectorAll("[role='tab']"), this._tabsElements.forEach((t) => {
      t.addEventListener("keydown", this._tabKeydownHandler), t.addEventListener("mousedown", this._tabMouseDownHandler);
    }), this.setFirstAndLastTabs();
  }
  _removeTabListeners() {
    this._tabsElements.forEach((t) => {
      t.removeEventListener("keydown", this._tabKeydownHandler), t.removeEventListener("mousedown", this._tabMouseDownHandler);
    });
  }
  setFirstAndLastTabs() {
    let t = !1;
    this._tabsElements.forEach((e) => {
      t || (this._firstTab = e, t = !0), this._lastTab = e;
    });
  }
  changeTab(t) {
    const e = {
      detail: { selectedPanel: t.panel },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("change", e)), this.updateTabs(t.id), this.updatePanels(t.panel);
  }
  updateTabs(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t ? { ...e, selected: !0 } : { ...e, selected: !1 }
    );
  }
  updatePanels(t) {
    window.document.querySelectorAll("dss-tabs-panel").forEach((s) => {
      const i = s.getAttribute("panelId");
      s.getAttribute("linkedTo") === this.dssTabsId && (i === t ? s.setAttribute("selected", "true") : s.removeAttribute("selected"));
    });
  }
  _handleKeydown(t) {
    const e = t, s = t.currentTarget;
    let i = !1;
    switch (e.key) {
      case "ArrowLeft":
        this.moveFocusToPreviousTab(s), i = !0;
        break;
      case "ArrowRight":
        this.moveFocusToNextTab(s), i = !0;
        break;
      case "Home":
        this.moveFocusToTab(this._firstTab), i = !0;
        break;
      case "End":
        this.moveFocusToTab(this._lastTab), i = !0;
        break;
    }
    i && (t.stopPropagation(), t.preventDefault());
  }
  moveFocusToTab(t) {
    t && t.focus();
  }
  moveFocusToPreviousTab(t) {
    let e = 0;
    t === this._firstTab ? this.moveFocusToTab(this._lastTab) : (this._tabsElements.forEach((s, i) => {
      s === t && (e = i);
    }), this.moveFocusToTab(this._tabsElements[e - 1]));
  }
  moveFocusToNextTab(t) {
    let e = 0;
    t === this._lastTab ? this.moveFocusToTab(this._firstTab) : (this._tabsElements.forEach((s, i) => {
      s === t && (e = i);
    }), this.moveFocusToTab(this._tabsElements[e + 1]));
  }
  setSelectedTab(t) {
    for (let e = 0; e < this._tabsElements.length; e += 1) {
      const s = this._tabsElements[e];
      t === s ? (s.setAttribute("aria-selected", "true"), s.removeAttribute("tabindex"), s.classList.add("dss-tabs-item--selected"), this._centerTabIntoScroll(s)) : (s.setAttribute("aria-selected", "false"), s.setAttribute("tabindex", "-1"), s.classList.remove("dss-tabs-item--selected"));
    }
  }
  selectTab(t) {
    const e = this.renderRoot.querySelector(`[role='tab'][id='${t}']`);
    e && this.setSelectedTab(e);
  }
  _centerTabIntoScroll(t) {
    if (!t || !this._menu) return;
    const e = t.getBoundingClientRect(), s = this._menu.getBoundingClientRect(), i = e.left + e.width / 2, r = s.left + s.width / 2, d = i - r;
    this._menu.scrollBy({ left: d, behavior: "smooth" });
  }
  addNewTab() {
    const t = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("add-tab", t));
  }
  // Scroll behavior
  _updateArrows() {
    if (this._menu && this._prevScroll && this._nextScroll) {
      const t = Math.ceil(this._menu.scrollLeft), e = Math.ceil(this._menu.scrollWidth - this._menu.clientWidth);
      this._prevScroll.style.display = t > 0 ? "block" : "none", this._nextScroll.style.display = t < e ? "block" : "none";
    }
  }
  _scrollMenu(t) {
    this._menu && this._menu.scrollBy({
      left: t * 160,
      behavior: "smooth"
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._menu && this._menu.addEventListener("scroll", this._handleUpdateArrowsBound), this._updateArrows();
  }
  render() {
    return T(this);
  }
  /* Edit and Delete handlers */
  _handleEdit(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t.id ? { ...e, isEditing: !0 } : { ...e, isEditing: !1 }
    ), setTimeout(() => {
      this._ignoreInputFocusout = !1;
      const e = this.shadowRoot?.querySelector(`#${t.id}-edit`);
      e.focus();
      const s = e.value.length;
      e.setSelectionRange(s, s);
    }, 50);
  }
  _handleDelete(t) {
    const e = {
      detail: { tab: t },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("delete", e));
  }
  _closeInputEdit(t) {
    this.tabs = this.tabs.map((e) => e.id === t.id ? { ...e, isEditing: !1 } : e);
  }
  _handleEditSave(t) {
    this._ignoreInputFocusout = !0;
    const e = (this.shadowRoot?.querySelector(`#${t.id}-edit`)).value;
    this._closeInputEdit(t), e && e.trim() !== "" && e !== t.text && (this.tabs = this.tabs.map((s) => s.id === t.id ? { ...s, text: e } : s), this._dispatchEditTabs());
  }
  _handleEditCancel(t, e) {
    t.preventDefault(), t.stopPropagation(), this._ignoreInputFocusout = !0, this._closeInputEdit(e);
  }
  _handleInputFocusout(t, e) {
    if (this._ignoreInputFocusout) {
      this._ignoreInputFocusout = !1;
      return;
    }
    const s = t.relatedTarget;
    s?.classList.contains("save-edit") || s?.classList.contains("cancel-edit") || this._handleEditSave(e);
  }
  _handleEditCancelFocusout(t, e) {
    const s = t.relatedTarget;
    if (s?.classList.contains("save-edit") || s?.classList.contains("cancel-edit")) return;
    const i = t.currentTarget?.closest(".dss-tabs-item");
    (!s || !i?.contains(s)) && this._handleEditSave(e);
  }
  _handleEditCancelKeydown(t, e) {
    t.key === "Enter" && this._handleEditCancel(t, e);
  }
  _handleEditKeydown(t, e) {
    (t.key === "Enter" || t.key === "Escape") && this._handleEditSave(e);
  }
  _dispatchEditTabs() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("edit", t));
  }
  onDragStart(t, e) {
    this.draggedIndex = e, t.currentTarget.classList.add("dragging");
    try {
      t.dataTransfer?.setData("text/plain", "");
    } catch {
    }
    t.dataTransfer && (t.dataTransfer.effectAllowed = "move", t.dataTransfer.dropEffect = "move");
  }
  onDragEnd(t) {
    t.currentTarget.classList.remove("dragging"), this._lastOverEl && (this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = null), this.draggedIndex = null;
  }
  onDragOver(t) {
    t.preventDefault();
    const e = t.currentTarget;
    this._lastOverEl && this._lastOverEl !== e && this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = e;
    const s = e.getBoundingClientRect(), i = s.left + s.width / 2, r = (t.clientX ?? 0) < i;
    e.classList.toggle("over-left", r), e.classList.toggle("over-right", !r), t.dataTransfer && (t.dataTransfer.dropEffect = "move");
  }
  onDragLeave(t) {
    const e = t.currentTarget;
    e.classList.remove("over-left", "over-right"), this._lastOverEl === e && (this._lastOverEl = null);
  }
  onDrop(t, e) {
    t.preventDefault();
    const s = t.currentTarget;
    if (s.classList.remove("over-left", "over-right"), this._lastOverEl === s && (this._lastOverEl = null), this.draggedIndex === null) return;
    const i = s.getBoundingClientRect(), r = i.left + i.width / 2, d = (t.clientX ?? 0) >= r;
    let l = e + (d ? 1 : 0);
    const h = [...this.tabs], [p] = h.splice(this.draggedIndex, 1);
    this.draggedIndex < l && l--, l < 0 && (l = 0), l > h.length && (l = h.length), h.splice(l, 0, p), this.tabs = h, this.draggedIndex = null, this.dispatchOrder();
  }
  dispatchOrder() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("order", t));
  }
  onItemFocus(t) {
    this.shadowRoot?.activeElement?.matches(":focus-visible") && (this._focusedIndex = t);
  }
  onItemBlur(t) {
    this._focusedIndex === t && (this._focusedIndex = null);
  }
}
a([
  n({ type: String })
], o.prototype, "dssTabsId");
a([
  n({ type: String })
], o.prototype, "label");
a([
  n({ type: Array })
], o.prototype, "tabs");
a([
  n({ type: String })
], o.prototype, "addTabText");
a([
  n(c)
], o.prototype, "addTabEnabled");
a([
  n(c)
], o.prototype, "canOrder");
a([
  n(c)
], o.prototype, "canEdit");
a([
  n(c)
], o.prototype, "canDelete");
a([
  n(c)
], o.prototype, "fullHeight");
a([
  b()
], o.prototype, "_isEditing");
a([
  b()
], o.prototype, "_focusedIndex");
a([
  b()
], o.prototype, "draggedIndex");
export {
  o as TabsList
};
//# sourceMappingURL=tabs-list.js.map
