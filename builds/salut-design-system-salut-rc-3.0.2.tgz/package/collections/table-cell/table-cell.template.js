import { nothing as i } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { when as d } from "lit/directives/when.js";
import { unsafeStatic as t, literal as $, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
const e = $`dss-icon${t(c())}`, a = $`dss-tooltip${t(c())}`, x = (s) => {
  const u = !!s.querySelector("*");
  return l`
    <div class="${r({
    "dss-cell": !0,
    "dss-cell--max-lines": s.maxLines > 1,
    "dss-cell--reverse": s.reverse,
    "dss-cell--value-max-width": s.valueMaxWidth,
    "dss-cell--slot-max-width": s.slotMaxWidth,
    [`dss-cell--font-${s.fontWeight}`]: !!s.fontWeight,
    [`dss-cell--align-${s.align}`]: !!s.align,
    [`dss-cell--${s.size}`]: !!s.size,
    [`dss-cell--divider-${s.divider}`]: s.divider !== "default",
    "dss-cell--hide-divider": s.hideDivider,
    "dss-cell--nested": s.nested,
    "dss-cell--has-indicator": s.hasIndicator,
    "dss-cell--expanded": s.variant === "expanded"
  })}">
       ${d(
    s.icon,
    () => l`
          <div class="dss-cell__icon-container">
            <${e} class="dss-cell__icon" icon="${s.icon}" size="md"></${e}>
            ${s.iconTooltip ? l`<${a}>${s.iconTooltip}</${a}>` : i} 
          </div>
          `,
    () => i
  )}

      ${d(
    s.value,
    () => l`
					<div class="dss-cell__value-container" data-truncated="${s.isValueTruncaded}">
						<div class="dss-cell__value ${s.srOnly ? "sr-only" : ""}" @mouseover=${s._checkValueTruncated}>${s.value}</div>
		      	<${a} ?hidden=${!1} aria-hidden="true">${s.value}</${a}>
					</div>
				`,
    () => i
  )}
      
      ${d(
    u,
    () => l` <div class="dss-cell__slot"><slot></slot></div>`,
    () => i
  )}

      ${d(
    s.sort,
    () => l`
					<button 
						class="${r({
      "dss-cell__sort-button": !0,
      "dss-cell__sort-button--active": s.currentSortedColumn === s.id
    })}"
						aria-label="Sort" 
						@click=${s._nextSortState} 
					>
						<${e} class="dss-cell__sort" icon="${s._getSortIcon()}" size="sm"></${e}>
					</button>
					`,
    () => i
  )}
    </div>
  `;
};
export {
  x as template
};
//# sourceMappingURL=table-cell.template.js.map
