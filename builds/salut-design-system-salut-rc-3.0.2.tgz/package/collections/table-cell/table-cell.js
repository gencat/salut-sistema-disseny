import { LitElement as c, unsafeCSS as n } from "lit";
import { property as i, state as h } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import f from "./table-cell.style.css.js";
import { template as y } from "./table-cell.template.js";
var g = Object.defineProperty, t = (l, s, o, v) => {
  for (var a = void 0, p = l.length - 1, d; p >= 0; p--)
    (d = l[p]) && (a = d(s, o, a) || a);
  return a && g(s, o, a), a;
};
class e extends c {
  constructor() {
    super(...arguments), this.size = "sm", this.fontWeight = "regular", this.align = "left", this.colSpan = 1, this.maxLines = 1, this.variant = "default", this.hover = !1, this.highlight = !1, this.sort = !1, this.sortState = "none", this.currentSortedColumn = void 0, this.borderRight = !1, this.borderLeft = !1, this.borderTop = !1, this.reverse = !1, this.valueMaxWidth = !1, this.slotMaxWidth = !1, this.width = void 0, this.icon = void 0, this.iconTooltip = void 0, this.value = void 0, this.divider = "default", this.hideDivider = !1, this.nested = !1, this.hasIndicator = !1, this.srOnly = !1, this.isCurrentFocused = !1, this.isFirstUpdate = !0, this.fontWeightBackup = "regular", this.isValueTruncaded = !1, this.lastValue = void 0;
  }
  static get styles() {
    return [n(u), n(f)];
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "gridcell"), this.setAttribute("tabindex", "-1");
  }
  updated(s) {
    if (s.has("hover") && this.classList.toggle("hover", this.hover), s.has("highlight") && this.classList.toggle("highlight", this.highlight), s.has("borderRight") && this.classList.toggle("has-border-right", this.borderRight), s.has("borderLeft") && this.classList.toggle("has-border-left", this.borderLeft), s.has("borderTop") && this.variant === "header" && this.classList.toggle("has-border-top", this.borderTop), s.has("width") && this.width !== "") {
      if (!this.width) return;
      this.style.width = this.width, this.style.maxWidth = this.width;
    }
    s.has("fontWeight") && this.isFirstUpdate && (this.fontWeightBackup = this.fontWeight, this.isFirstUpdate = !1), s.has("variant") && (this.variant === "header" ? (this.setAttribute("role", "columnheader"), this.classList.add("sticky"), this.classList.add("column-header"), this.fontWeight = "semibold") : (this.setAttribute("role", "gridcell"), this.classList.remove("sticky"), this.classList.remove("column-header"), this.fontWeight = this.fontWeightBackup)), this.colSpan && this.colSpan > 1 && (this.style.gridColumn = `span ${this.colSpan}`);
  }
  _checkValueTruncated(s) {
    if (this.value === this.lastValue) return;
    this.lastValue = this.value;
    const o = s.currentTarget;
    if (this.maxLines > 1) {
      this.isValueTruncaded = o.scrollHeight > o.clientHeight;
      return;
    }
    this.isValueTruncaded = o.scrollWidth > o.offsetWidth;
  }
  _getSortIcon() {
    let s = "swap_vert";
    switch (this.sortState) {
      case "asc":
        s = "arrow_upward";
        break;
      case "desc":
        s = "arrow_downward";
        break;
      default:
        s = "swap_vert";
        break;
    }
    return s;
  }
  _nextSortState() {
    let s = "none";
    switch (this.sortState) {
      case "none":
        s = "asc";
        break;
      case "asc":
        s = "desc";
        break;
      case "desc":
        s = "none";
        break;
    }
    this.sortState = s, this._dispatchSort();
  }
  _dispatchSort() {
    const s = new CustomEvent("sort", {
      detail: {
        id: this.id,
        value: this.value,
        sortState: this.sortState
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(s);
  }
  async firstUpdated() {
    await this.updateComplete;
  }
  render() {
    return y(this);
  }
}
t([
  i()
], e.prototype, "size");
t([
  i({ type: String })
], e.prototype, "fontWeight");
t([
  i()
], e.prototype, "align");
t([
  i({ type: Number })
], e.prototype, "colSpan");
t([
  i({ type: Number })
], e.prototype, "maxLines");
t([
  i()
], e.prototype, "variant");
t([
  i(r)
], e.prototype, "hover");
t([
  i(r)
], e.prototype, "highlight");
t([
  i(r)
], e.prototype, "sort");
t([
  i()
], e.prototype, "sortState");
t([
  i({ type: String })
], e.prototype, "currentSortedColumn");
t([
  i(r)
], e.prototype, "borderRight");
t([
  i(r)
], e.prototype, "borderLeft");
t([
  i(r)
], e.prototype, "borderTop");
t([
  i(r)
], e.prototype, "reverse");
t([
  i(r)
], e.prototype, "valueMaxWidth");
t([
  i(r)
], e.prototype, "slotMaxWidth");
t([
  i({ type: String })
], e.prototype, "width");
t([
  i({ type: String })
], e.prototype, "icon");
t([
  i({ type: String })
], e.prototype, "iconTooltip");
t([
  i({ type: String })
], e.prototype, "value");
t([
  i()
], e.prototype, "divider");
t([
  i(r)
], e.prototype, "hideDivider");
t([
  i(r)
], e.prototype, "nested");
t([
  i(r)
], e.prototype, "hasIndicator");
t([
  i(r)
], e.prototype, "srOnly");
t([
  i(r)
], e.prototype, "isCurrentFocused");
t([
  h()
], e.prototype, "isFirstUpdate");
t([
  h()
], e.prototype, "fontWeightBackup");
t([
  h()
], e.prototype, "isValueTruncaded");
t([
  h()
], e.prototype, "lastValue");
export {
  e as TableCell
};
//# sourceMappingURL=table-cell.js.map
