import { unsafeStatic as s, literal as o, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const l = o`dss-context-menu-options${s(u())}`, r = (t) => i`
  <div>
		<${l} 
			class='dss-context-menu-options'
			.isOpen=${t.open}
			.items=${t.items}
			.referenceEl=${t.referenceEl}
			@option-click=${(e) => t._handleClick(e)}
			@options-focusout=${t._handleOptionsFocusout}
	    @focusout=${t._handleFocusout}
		/>
	</div>
`;
export {
  r as template
};
//# sourceMappingURL=context-menu.template.js.map
