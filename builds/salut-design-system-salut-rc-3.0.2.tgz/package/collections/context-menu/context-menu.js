import { LitElement as p, unsafeCSS as c } from "lit";
import { property as a, query as u } from "lit/decorators.js";
import { getPortalContainer as _ } from "../../api/portal-manager/portal-manager.js";
import m from "../../shared/reset.style.css.js";
import { getNextFocusable as b } from "../../utils/keyboard-navigation.js";
import { booleanType as h } from "../../utils/property-types.js";
import f from "./context-menu.style.css.js";
import { template as C } from "./context-menu.template.js";
var k = Object.defineProperty, s = (r, e, t, i) => {
  for (var n = void 0, l = r.length - 1, d; l >= 0; l--)
    (d = r[l]) && (n = d(e, t, n) || n);
  return n && k(e, t, n), n;
};
class o extends p {
  constructor() {
    super(), this.open = !1, this.disableParentClick = !1, this.items = [], this._parent = null, this._referenceEl = null, this._parentClickHandler = null, this._parentKeydownHandler = null, this._portalManager = null, this._visibleObserver = new IntersectionObserver(
      ([e]) => {
        !e.isIntersecting && this.open && this._closeMenu();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._handleClickOutside = this._handleClickOutside.bind(this);
  }
  static get styles() {
    return [c(m), c(f)];
  }
  connectedCallback() {
    super.connectedCallback(), !this.disableParentClick && (this._parent = this.parentElement, this._referenceEl = this.previousElementSibling ?? this._parent, this._parent && (this._referenceEl && this._visibleObserver.observe(this._referenceEl), this._parentClickHandler = () => {
      this._toggleMenu();
    }, this._parent.addEventListener("click", this._parentClickHandler), this._parentKeydownHandler = (e) => {
      this._handleParentKeydown(e);
    }, this._parent.addEventListener("keydown", this._parentKeydownHandler)));
  }
  get referenceEl() {
    return this._referenceEl;
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.open && this._closeMenu(), this._removeListenerClickOutside(), this._visibleObserver.disconnect(), this._parent && this._parentClickHandler && (this._parent.removeEventListener("click", this._parentClickHandler), this._parentClickHandler = null), this._parent && this._parentKeydownHandler && (this._parent.removeEventListener("keydown", this._parentKeydownHandler), this._parentKeydownHandler = null);
  }
  _getPortalCombobox() {
    return this._portalManager?.querySelector(".dss-context-menu-options");
  }
  _toggleMenu() {
    this.open = !this.open, this.open ? (this._addListenerClickOutside(), setTimeout(() => {
      this._disableAnimations();
    }, 240)) : this._removeListenerClickOutside();
  }
  _closeMenu() {
    this.open = !1, this._removeListenerClickOutside(), setTimeout(() => {
      this._enableAnimations();
    }, 400);
  }
  _handleClick(e) {
    const t = e.detail.id;
    this.dispatchEvent(new CustomEvent("menu-click", { detail: { id: t }, bubbles: !0, composed: !0 })), this._closeMenu();
  }
  _handleParentKeydown(e) {
    this.open && (e.key === "Tab" ? (e.preventDefault(), this._getPortalCombobox().focus()) : e.key === "Escape" && this._closeMenu());
  }
  _handleFocusout(e) {
    const t = e.relatedTarget, i = this._getPortalCombobox();
    t instanceof HTMLElement && t.contains(this) || t !== null && t !== this._combobox && t !== i && this._handleOptionsFocusout();
  }
  _handleOptionsFocusout() {
    if (!this.open) return;
    this._closeMenu();
    const e = b(this._parent);
    e && e.focus();
  }
  _addListenerClickOutside() {
    document.addEventListener("mousedown", this._handleClickOutside);
  }
  _removeListenerClickOutside() {
    document.removeEventListener("mousedown", this._handleClickOutside);
  }
  _handleClickOutside(e) {
    if (!this.open) return;
    const t = e.composedPath(), i = this._portalManager?.querySelector(".dss-context-menu-options");
    !t.includes(this) && !t.includes(i) && this._closeMenu();
  }
  _enableAnimations() {
    this._combobox.classList.add("animation-enabled");
  }
  _disableAnimations() {
    this._getPortalCombobox()?.classList.remove("animation-enabled");
  }
  async firstUpdated() {
    await this.updateComplete;
    try {
      this._portalManager = _(), this._enableAnimations();
    } catch (e) {
      console.error("Error in firstUpdated:", e);
    }
  }
  render() {
    return C(this);
  }
}
s([
  a(h)
], o.prototype, "open");
s([
  a(h)
], o.prototype, "disableParentClick");
s([
  a({ type: Array })
], o.prototype, "items");
s([
  u(".dss-context-menu-options")
], o.prototype, "_combobox");
export {
  o as ContextMenu
};
//# sourceMappingURL=context-menu.js.map
