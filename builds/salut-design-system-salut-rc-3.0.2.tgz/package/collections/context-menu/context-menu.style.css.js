const s = "";
export {
  s as default
};
//# sourceMappingURL=context-menu.style.css.js.map
