import { LitElement as f, unsafeCSS as u } from "lit";
import { property as l, state as p } from "lit/decorators.js";
import { getCustomElementSuffix as _ } from "../../api/custom-element-scope.js";
import g from "../../foundations/icon/icon.style.css.js";
import w from "../../shared/reset.style.css.js";
import y from "../../shared/scrollbar.style.css.js";
import { booleanType as h } from "../../utils/property-types.js";
import b from "./sidemenu.style.css.js";
import { sidemenuTemplate as C } from "./sidemenu.template.js";
var M = Object.defineProperty, n = (m, e, t, d) => {
  for (var s = void 0, i = m.length - 1, a; i >= 0; i--)
    (a = m[i]) && (s = a(e, t, s) || s);
  return s && M(e, t, s), s;
};
class r extends f {
  // private _handleContainerScrollBound: (event: Event) => void;
  constructor() {
    super(), this.topMenuItems = [], this.createMenuItems = [], this.roleMenuItems = [], this.globalMenuItems = [], this.axiaHidden = !1, this.axiaDisabled = !1, this.axiaLabel = "Axia", this.expanded = !1, this.disabled = !1, this.toggleLabel = "Tancar menú", this.createLabel = "Crear", this.createMenuPosition = "top", this.createNotifications = 0, this.createDisabled = !1, this.hideCreateMenu = !1, this._hasManualSelected = !1, this._toggleDisabled = !1, this._showCreateDropdown = !1, this._resizeTimer = null, this._othersTopItem = null, this._dropdown = null, this._isFirstUpdated = !0, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [u(w), u(y), u(g), u(b)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), document.addEventListener("mousedown", this._handleDocumentClickBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  get _createNotification() {
    return this.shadowRoot?.querySelector("dss-notification-badge") || void 0;
  }
  get _createSection() {
    return this.shadowRoot?.querySelector(".dss-sidemenu-create");
  }
  _propagateProperties() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((t) => {
      t.assignedElements().forEach((s) => {
        this.expanded ? s.setAttribute("expanded", "true") : s.removeAttribute("expanded");
      });
    });
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._checkWindowInnerwidth(), this._updateTopMenu(), this._getHiddenRoleNotifications();
    }, 250);
  }
  _getHiddenRoleNotifications() {
    if (!this._othersTopItem) return;
    const e = this._othersTopItem.querySelectorAll("dss-action-menu-item"), t = Array.from(e).filter(
      (s) => s.parentElement?.parentElement === this._othersTopItem && s.classList.contains("hidden") === !1
    );
    let d = 0;
    for (const s of t) {
      const i = s.getAttribute("notifications");
      i && (d += Number(i));
    }
    this._othersTopItem.setAttribute("notifications", d.toString());
  }
  _getTopMenuItems(e) {
    const t = e.querySelectorAll("dss-sidemenu-list-item"), d = Array.from(t).filter(
      (c) => c.classList.contains("dss-sidemenu-top-menu__other-items") === !1
    ), i = e.querySelector(".dss-sidemenu-top-menu__other-items").querySelectorAll("dss-action-menu");
    if (!i) return;
    const a = i[0], o = Array.from(a.querySelectorAll("dss-action-menu-item")).filter(
      (c) => c.parentElement === a
    );
    return { defaultItems: d, hiddenItems: o };
  }
  async _updateTopMenu() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu");
    if (!e) return;
    const t = this._getTopMenuItems(e);
    if (!t) return;
    const d = 40;
    let s = 0, i = 0;
    for (const [a, o] of t.defaultItems.entries()) {
      if (s += d, a === 0) {
        o.classList.remove("hidden");
        continue;
      }
      s <= e.clientHeight ? o.classList.remove("hidden") : (o.classList.add("hidden"), i += 1), s += 4;
    }
    if (this._othersTopItem = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu__other-items"), i > 0) {
      if (this._othersTopItem?.classList.remove("hidden"), e.scrollHeight > e.clientHeight) {
        const a = t.defaultItems.filter((c) => !c.classList.contains("hidden")), o = a[a.length - 1];
        o !== t.defaultItems[0] && (o.classList.add("hidden"), i += 1);
      }
      t.hiddenItems && (t.hiddenItems.forEach((o) => o.classList.add("hidden")), t.hiddenItems.slice(-i).forEach((o) => o.classList.remove("hidden")));
    } else
      this._othersTopItem?.classList.add("hidden");
  }
  _checkWindowInnerwidth() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-toggle");
    window.innerWidth < 1024 ? (this.removeAttribute("expanded"), this._toggleDisabled = !0, e.disabled = !0, e.classList.add("dss-sidemenu-toggle--hidden")) : (this._toggleDisabled = !1, e.disabled = !1, e.classList.remove("dss-sidemenu-toggle--hidden"));
  }
  _clickedOutsideCreateMenu(e, t) {
    t.composedPath().includes(e) || this._closeCreateDropdown();
  }
  _closeCreateDropdown() {
    this._showCreateDropdown && (this._showCreateDropdown = !1, this._toggleCreateMenuTooltip());
  }
  _handleKeydownEscape(e) {
    const d = e.detail.shadowRoot?.querySelector("slot");
    if (!d) return;
    const i = `dss-action-menu${_()}`, o = d.assignedElements({ flatten: !0 }).find((c) => c.tagName.toLowerCase() === i);
    o && o.classList.contains("visible") && o._closeMenu();
  }
  _handleDocumentClick(e) {
    this._createSection && this._clickedOutsideCreateMenu(this._createSection, e);
  }
  _openCreateMenu() {
    this._showCreateDropdown = !0, this._toggleCreateMenuTooltip();
  }
  _toggleCreateMenuTooltip() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create__tooltip");
    this._showCreateDropdown ? e?.classList.add("force-hidden") : e?.classList.remove("force-hidden");
  }
  _toggleSidemenu() {
    this.expanded ? this.removeAttribute("expanded") : this.setAttribute("expanded", "true");
  }
  _handleCreateMouseEnter() {
    this._createNotification && this._createNotification.setAttribute("isHover", "true");
  }
  _handleCreateMouseLeave() {
    this._createNotification && this._createNotification.removeAttribute("isHover");
  }
  _handleCreateMouseDown() {
    this._createNotification && this._createNotification.setAttribute("isActive", "true");
  }
  _handleCreateFocusout(e) {
    if (this._showCreateDropdown) {
      const t = e.relatedTarget;
      t === null && this._closeCreateDropdown(), t && !this._createSection.contains(t) && t.tagName !== "DSS-ACTION-MENU-ITEM" && this._closeCreateDropdown();
    }
  }
  _handleCreateMouseUp() {
    this._createNotification && this._createNotification.removeAttribute("isActive");
  }
  _handleMenuClick(e, t) {
    if (t.nestedMenu || t.disabled) return;
    t.external || this._selectSidenenuItem(e);
    const d = e.composedPath(), s = d.some((c) => c instanceof HTMLElement && c.classList.contains("dss-sidemenu-top-menu")), i = d.some(
      (c) => c instanceof HTMLElement && c.classList.contains("dss-sidemenu-bottom-menu")
    );
    let a = "";
    s ? a = "role" : i ? a = "global" : a = "create";
    const o = {
      detail: {
        menu: a,
        label: t.label,
        item: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("menu-click", o));
  }
  _selectSidenenuItem(e) {
    this.shadowRoot?.querySelectorAll('dss-sidemenu-list-item[selected="true"]')?.forEach((i) => {
      i.removeAttribute("selected");
    });
    const s = e.currentTarget.closest("dss-sidemenu-list-item");
    s && s.setAttribute("selected", "true"), this._hasManualSelected = !0;
  }
  // private get _scrollContainer(): HTMLElement | null {
  // 	return document.querySelector(`.${this.scrollContainerClass}`);
  // }
  _getCreateDropdownFixedPosition() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create");
    if (!e) return;
    const t = e.getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-create__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _handleContainerScroll() {
    this._getCreateDropdownFixedPosition();
  }
  _handleAxia() {
    const e = {
      detail: !0,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("toggle-axia", e));
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties();
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create__dropdown");
    e && (this._dropdown = e, this._getCreateDropdownFixedPosition()), this._othersTopItem = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu__other-items"), this.expanded && this.requestUpdate(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), (e.has("expanded") || e.has("disabled")) && queueMicrotask(() => {
      this._propagateProperties(), this._getCreateDropdownFixedPosition();
    }), this._isFirstUpdated || requestAnimationFrame(() => this._updateTopMenu());
  }
  render() {
    return C(this);
  }
}
n([
  l({ type: Array })
], r.prototype, "topMenuItems");
n([
  l({ type: Array })
], r.prototype, "createMenuItems");
n([
  l({ type: Array })
], r.prototype, "roleMenuItems");
n([
  l({ type: Array })
], r.prototype, "globalMenuItems");
n([
  l(h)
], r.prototype, "axiaHidden");
n([
  l(h)
], r.prototype, "axiaDisabled");
n([
  l({ type: String })
], r.prototype, "axiaLabel");
n([
  l(h)
], r.prototype, "expanded");
n([
  l(h)
], r.prototype, "disabled");
n([
  l({ type: String })
], r.prototype, "toggleLabel");
n([
  l({ type: String })
], r.prototype, "createLabel");
n([
  l({ type: String })
], r.prototype, "createMenuPosition");
n([
  l({ type: Number })
], r.prototype, "createNotifications");
n([
  l(h)
], r.prototype, "createDisabled");
n([
  l(h)
], r.prototype, "hideCreateMenu");
n([
  p()
], r.prototype, "_hasManualSelected");
n([
  p()
], r.prototype, "_toggleDisabled");
n([
  p()
], r.prototype, "_showCreateDropdown");
export {
  r as Sidemenu
};
//# sourceMappingURL=sidemenu.js.map
