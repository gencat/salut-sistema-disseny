import { nothing as l } from "lit";
import { classMap as _ } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as $, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
import g from "../../assets/img/logo_axia.svg.js";
const c = $`dss-icon${t(u())}`, h = $`dss-tooltip${t(u())}`, v = $`dss-notification-badge${t(u())}`, o = $`dss-sidemenu-list${t(u())}`, n = $`dss-sidemenu-list-item${t(u())}`, M = $`dss-action-menu${t(u())}`, f = $`dss-action-menu-item${t(u())}`, b = (e, s, d) => a`
    <${M} class="dss-sidemenu-nested-menu">
      ${e.map(
  (i) => a`
        <${f}
          class=${_({
    hidden: !!s
  })}
          lefticon=${i.icon}
          label=${i.label}
          notifications=${i.notifications}
          ?disabled=${i.disabled}
          ?hasNestedMenu=${!!i.nestedMenu}
          @click=${(r) => d._handleMenuClick(r, i)}
        >
          ${i.nestedMenu ? b(i.nestedMenu, !1, d) : l}
        </${f}>
      `
)}
    </${M}>
  `, k = (e) => {
  if (!e._othersTopItem) return 0;
  const s = e._othersTopItem.querySelectorAll("dss-action-menu-item"), d = Array.from(s).filter(
    (r) => r.parentElement?.parentElement === e._othersTopItem && r.classList.contains("hidden") === !1
  );
  let i = 0;
  for (const r of d) {
    const x = r.getAttribute("notifications");
    x && (i += Number(x));
  }
  return i;
}, E = (e) => a`
  <aside
    class=${_({
  "dss-sidemenu": !0,
  "dss-sidemenu--expanded": !!e.expanded
})}
  >
    
    ${e.topMenuItems.length > 0 ? a`
        <div class="dss-sidemenu-extra-menu">
        <${o} ?expanded=${e.expanded}>
          ${e.topMenuItems.map(
  (s) => a`
            <${n}
              icon=${s.icon}
              label=${s.label}
              notifications=${s.notifications}
              ?selected=${s.selected && !e._hasManualSelected}
              ?disabled=${s.disabled}
              ?hasNestedMenu=${!!s.nestedMenu}
              ?expanded=${e.expanded}
              @click=${(d) => e._handleMenuClick(d, s)}
              @keydownEscape=${e._handleKeydownEscape}
              >
              ${s.nestedMenu ? b(s.nestedMenu, !1, e) : l}
            </${n}>
          `
)}
        </${o}>
      </div>
      <div class="dss-sidemenu-divider"></div>
      ` : l}

    ${e.roleMenuItems.length > 0 ? a`
        <div class="dss-sidemenu-top-menu">
          <${o} ?expanded=${e.expanded}>
            ${e.roleMenuItems.map(
  (s) => a`
              <${n}
                icon=${s.icon}
                label=${s.label}
                notifications=${s.notifications}
                ?selected=${s.selected && !e._hasManualSelected}
                ?disabled=${s.disabled}
                ?hasNestedMenu=${!!s.nestedMenu}
                ?expanded=${e.expanded}
                @click=${(d) => e._handleMenuClick(d, s)}
                @keydownEscape=${e._handleKeydownEscape}
                >
                ${s.nestedMenu ? b(s.nestedMenu, !1, e) : l}
              </${n}>
            `
)}
            <${n} 
              class="dss-sidemenu-top-menu__other-items hidden"
              expanded=${e.expanded}
              icon="more_horiz"
              label="Altres"
              notifications=${k(e)}
              @keydownEscape=${e._handleKeydownEscape}
              hasNestedMenu>
               ${b(e.roleMenuItems, !0, e)}
            </${n}>
          </${o}>
        </div>
    ` : l}

    ${e.hideCreateMenu ? l : a`
          <div
            class="dss-sidemenu-create"
            @focusout="${e._handleCreateFocusout}"
          >
            <button
              class="dss-sidemenu-create__button"
              ?disabled=${e.createDisabled}
              @click="${e._openCreateMenu}"
              @mouseenter="${e._handleCreateMouseEnter}"
              @mouseleave="${e._handleCreateMouseLeave}"
              @mousedown="${e._handleCreateMouseDown}"
              @mouseup="${e._handleCreateMouseUp}"
              aria-label="${e.createLabel}"
            >
              <span class="dss-sidemenu-create__button__content">
                <${c} class="dss-sidemenu-create__icon" size="md" icon="add"></${c}>
                ${e.createNotifications && !e._showCreateDropdown && !e.createDisabled ? a`
                      <${v}
                        class=${_({
  "dss-sidemenu-create__notification": !0,
  "dss-sidemenu-create__notification--expanded": !0
})}
                        value="${e.createNotifications}"
                        variant="sidemenu"
                        inverted
                      />
                    ` : null}
              </span>
              <span class= class=${_({
  "dss-sidemenu-label-animation": !0,
  "dss-sidemenu-label-animation--expanded": e.expanded
})}>
                  ${e.createLabel}
              </span>
            </button>

            <${h} position="right" class="dss-sidemenu-create__tooltip" delay="800" ?hidden=${e.expanded}>
              ${e.createLabel}
            </${h}>

            <${M}>
              ${e.createMenuItems.map(
  (s) => a`
                <${f}
                  label=${s.label}
                  notifications=${s.notifications}
                  @click=${(d) => e._handleMenuClick(d, s)}
                  >
                </${f}>
              `
)}
            </${M}>
          </div>
        `}

    <div class="dss-sidemenu-bottom">
      <div class="dss-sidemenu-bottom-menu">
        <div class="dss-sidemenu-divider"></div>
          ${e.globalMenuItems.length > 0 ? a`
            <${o} ?expanded=${e.expanded}>
              ${e.globalMenuItems.map(
  (s) => a`
                <${n}
                  icon=${s.icon}
                  label=${s.label}
                  notifications=${s.notifications}
                  ?selected=${s.selected && !e._hasManualSelected}
                  ?disabled=${s.disabled}
                  ?hasNestedMenu=${!!s.nestedMenu}
                  ?expanded=${e.expanded}
                  @click=${(d) => e._handleMenuClick(d, s)}
                  @keydownEscape=${e._handleKeydownEscape}
                  >
                  ${s.nestedMenu ? b(s.nestedMenu, !1, e) : l}
                </${n}>
              `
)}
            </${o}>
           ` : l}
          ${e.axiaHidden ? l : a`
            <div class="dss-sidemenu-toggle-axia">
              <button
                class="dss-sidemenu-axia"
                ?disabled=${e.axiaDisabled}
                @click="${e._handleAxia}"
              >
                <span class="dss-sidemenu-axia__content">
                  <img src="${g}" alt="Logo Axia" class="dss-sidemenu-axia__logo" />
                  <span class="dss-sidemenu-axia__label">${e.axiaLabel}</span>
                </span>
              </button>
              <${h} position="right" class="dss-sidemenu-axia__tooltip" delay="800" ?hidden=${e.expanded}>
                ${e.axiaLabel}
              </${h}>
            </div>
          `}
        </div>
     
      
      <button
        class="dss-sidemenu-toggle"
        ?disabled=${e._toggleDisabled}
        @click="${e._toggleSidemenu}"
        aria-label="${e.expanded ? "col·lapsar menú" : "expandir menú"}"
      >
        ${e.expanded ? a`
              <${c} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_left"></${c}>
            ` : a`
              <${c} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_right"></${c}>
            `}
        <span class= class=${_({
  "dss-sidemenu-label-animation": !0,
  "dss-sidemenu-label-animation--expanded": e.expanded
})}>
            ${e.toggleLabel}
        </span>
      </button>
    </div>
  </aside>
`;
export {
  E as sidemenuTemplate
};
//# sourceMappingURL=sidemenu.template.js.map
