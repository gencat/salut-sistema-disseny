import { LitElement as t, unsafeCSS as e } from "lit";
import r from "../../shared/reset.style.css.js";
import s from "./table.style.css.js";
import { template as m } from "./table.template.js";
class a extends t {
  static get styles() {
    return [e(r), e(s)];
  }
  render() {
    return m();
  }
}
export {
  a as Table
};
//# sourceMappingURL=table.js.map
