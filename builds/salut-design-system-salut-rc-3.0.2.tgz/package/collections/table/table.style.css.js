const t = ":host{display:flex;flex-direction:column;height:100%;width:100%;max-width:100%;box-sizing:border-box}";
export {
  t as default
};
//# sourceMappingURL=table.style.css.js.map
