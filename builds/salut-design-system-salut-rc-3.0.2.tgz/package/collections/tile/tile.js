import { LitElement as y, unsafeCSS as a } from "lit";
import { property as t } from "lit/decorators.js";
import d from "../../api/marker/marker.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./tile.style.css.js";
import { template as f } from "./tile.template.js";
var c = Object.defineProperty, e = (p, s, n, g) => {
  for (var i = void 0, l = p.length - 1, h; l >= 0; l--)
    (h = p[l]) && (i = h(s, n, i) || i);
  return i && c(s, n, i), i;
};
class o extends y {
  constructor() {
    super(...arguments), this.type = "default", this.icon = "", this.tileTitle = "", this.description = "", this.selected = !1, this.disabled = !1, this.hasLogo = !1, this.logoURL = "", this.heightAuto = !1, this.widget = !1, this.marker = void 0;
  }
  static get styles() {
    return [a(d), a(m)];
  }
  _onClick() {
    this.type === "selector" && (this.selected = !this.selected, this.requestUpdate());
    const s = {
      detail: { title: this.tileTitle },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onTileClick", s));
  }
  render() {
    return f(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "tileTitle");
e([
  t({ type: String })
], o.prototype, "description");
e([
  t(r)
], o.prototype, "selected");
e([
  t(r)
], o.prototype, "disabled");
e([
  t(r)
], o.prototype, "hasLogo");
e([
  t({ type: String })
], o.prototype, "logoURL");
e([
  t(r)
], o.prototype, "heightAuto");
e([
  t(r)
], o.prototype, "widget");
e([
  t({ type: String })
], o.prototype, "marker");
export {
  o as Tile
};
//# sourceMappingURL=tile.js.map
