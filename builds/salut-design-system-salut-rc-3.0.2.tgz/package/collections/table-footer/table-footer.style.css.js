const t = ".table-footer{display:flex;justify-content:space-between;align-items:center;gap:var(--dss-spacing-xs);opacity:1;visibility:visible;transition:opacity var(--animation-delay) ease-out}.table-footer:not(.table-footer--hide){height:auto;border-top:var(--dss-border-width-sm) solid var(--color-neutral-100);padding:var(--dss-spacing-md)}.table-footer--hide{opacity:0;visibility:hidden;height:0;padding:0;margin:0;transition:none}.table-footer-description{color:var(--color-neutral-900);font-size:16px;font-weight:var(--font-bold)}.table-footer-actions{display:flex;justify-content:flex-end;align-items:center;gap:var(--dss-spacing-xs)}";
export {
  t as default
};
//# sourceMappingURL=table-footer.style.css.js.map
