import { classMap as t } from "lit/directives/class-map.js";
import { html as l } from "lit/static-html.js";
const d = (e) => l`
    <div class="${t({
  "table-footer": !0,
  "table-footer--hide": !e.selectedLength || e.selectedLength === 0
})}">
      <div class="table-footer-description">
        ${e.selectedLength} de ${e.dataLength} ${e.selectedLabel}
      </div>
      <div class="table-footer-actions">
        <slot></slot>
      </div>
    </div>
  `;
export {
  d as template
};
//# sourceMappingURL=table-footer.template.js.map
