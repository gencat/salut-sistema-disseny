import { LitElement as m, unsafeCSS as a } from "lit";
import { property as s } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import f from "./table-footer.style.css.js";
import { template as c } from "./table-footer.template.js";
var u = Object.defineProperty, o = (t, i, l, y) => {
  for (var e = void 0, r = t.length - 1, n; r >= 0; r--)
    (n = t[r]) && (e = n(i, l, e) || e);
  return e && u(i, l, e), e;
};
class p extends m {
  constructor() {
    super(...arguments), this.dataLength = void 0, this.selectedLength = void 0, this.selectedLabel = "files seleccionades";
  }
  static get styles() {
    return [a(d), a(f)];
  }
  render() {
    return c(this);
  }
}
o([
  s({ type: Number })
], p.prototype, "dataLength");
o([
  s({ type: Number })
], p.prototype, "selectedLength");
o([
  s({ type: String })
], p.prototype, "selectedLabel");
export {
  p as TableFooter
};
//# sourceMappingURL=table-footer.js.map
