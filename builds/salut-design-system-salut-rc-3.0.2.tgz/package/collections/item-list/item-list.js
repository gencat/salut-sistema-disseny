import { LitElement as d, unsafeCSS as f } from "lit";
import { property as s } from "lit/decorators.js";
import { itemListTemplate as u } from "./item-list.template.js";
import { booleanType as a } from "../../utils/property-types.js";
import c from "./item-list.style.css.js";
import { getCustomElementSuffix as h } from "../../api/custom-element-scope.js";
var y = Object.defineProperty, r = (l, t, e, p) => {
  for (var o = void 0, i = l.length - 1, m; i >= 0; i--)
    (m = l[i]) && (o = m(t, e, o) || o);
  return o && y(t, e, o), o;
};
class n extends d {
  constructor() {
    super(...arguments), this.items = void 0, this.widget = !1, this.hideTooltip = !1, this.tooltipFixed = !1, this.forceViewport = !1, this.tooltipPosition = "top", this.variant = "default";
  }
  static get styles() {
    return [f(c)];
  }
  // 'checkbox' | 'radio' | 'default'
  /* METHODS */
  _dispatchItemAction(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItem", e));
  }
  _dispatchItemChip(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItemChip", e));
  }
  _dispatchWidgetAction(t, e) {
    const p = {
      detail: { item: t, action: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickWidgetAction", p));
  }
  _applyDivider() {
    if (this.items?.length) return;
    const t = this.shadowRoot?.querySelectorAll("slot");
    if (!t || t.length === 0) return;
    let e = !0;
    t.forEach((p) => {
      p.assignedElements({ flatten: !0 }).forEach((i) => {
        i instanceof HTMLElement && i.tagName.toLowerCase() === `dss-item-list-base${h()}` && (e ? (i.setAttribute("first", ""), e = !1) : i.removeAttribute("first"));
      });
    });
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    await this.updateComplete, this._applyDivider();
  }
  render() {
    return u(this);
  }
}
r([
  s({ type: Array })
], n.prototype, "items");
r([
  s(a)
], n.prototype, "widget");
r([
  s(a)
], n.prototype, "hideTooltip");
r([
  s(a)
], n.prototype, "tooltipFixed");
r([
  s(a)
], n.prototype, "forceViewport");
r([
  s({ type: String })
], n.prototype, "tooltipPosition");
r([
  s({ type: String })
], n.prototype, "variant");
export {
  n as ItemList
};
//# sourceMappingURL=item-list.js.map
