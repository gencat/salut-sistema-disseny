import { LitElement as E, unsafeCSS as f, render as q } from "lit";
import { unsafeStatic as S, literal as y, html as d } from "lit/static-html.js";
import { property as o, state as D } from "lit/decorators.js";
import { classMap as g } from "lit/directives/class-map.js";
import { ifDefined as P } from "lit/directives/if-defined.js";
import { getCustomElementSuffix as m } from "../../api/custom-element-scope.js";
import { booleanType as h } from "../../utils/property-types.js";
import { moveFocusToNextTarget as L, moveFocusToPreviousTarget as v, onKeyboardEnter as U } from "../../utils/keyboard-navigation.js";
import { sort as x } from "../../utils/sorting.js";
import z from "../../angular/ng-checkbox/ng-checkbox.style.css.js";
import I from "../../foundations/icon/icon.style.css.js";
import V from "../../shared/scrollbar.style.css.js";
import B from "./custom-table.style.css.js";
var N = Object.defineProperty, M = Object.getOwnPropertyDescriptor, a = (w, t, e, s) => {
  for (var r = s > 1 ? void 0 : s ? M(t, e) : t, n = w.length - 1, i; n >= 0; n--)
    (i = w[n]) && (r = (s ? i(t, e, r) : i(r)) || r);
  return s && r && N(t, e, r), r;
};
const R = y`dss-icon${S(m())}`, K = y`dss-checkbox${S(m())}`, k = y`dss-custom-table-header${S(m())}`, $ = y`dss-table-pagination${S(m())}`;
class l extends E {
  constructor() {
    super(), this._scrollBody = null, this.internalSelectedCounter = 0, this.showConfig = !1, this.configTableLabel = "Configurar taula", this.customActions = !1, this.enableCombinedFilters = !1, this._hideHeader = !1, this._hidePaginator = !1, this._columnsHeader = [], this._data = void 0, this._paginatedData = void 0, this._currentSortColumn = "", this._currentSortType = "string", this._currentSortOrder = "none", this._multiselect = !1, this._radioselect = !1, this._allRowsSelected = !1, this._selectedRowsLabel = "files seleccionades", this._isFirstUpdate = !0, this._shouldUpdate = !1, this._table = void 0, this._currentRowsChecked = 0, this._selectedRowsCounter = void 0, this._tableTitle = "", this._filters = void 0, this._innerFilters = !1, this._expandTable = !1, this._expandLabel = "Ampliar", this._collapseLabel = "Reduir", this._filtersLabel = "Selecció", this._cleanFiltersLabel = "Netejar filtres", this._isTableHeaderCreated = !1, this._hideHeaderTitleAndExpand = !1, this._disableSorting = !1, this.hideActionExpand = !1, this.showActionFilters = !1, this._isPaginationStarted = !1, this._totalResults = void 0, this._currentIndex = 1, this._pageSize = 10, this._pageSizeOptions = [5, 10, 20], this._resultstext = "Resultats", this._rowsperpagetext = "Files per pàgina", this._paginationState = void 0, this._pageSizeOptionsDisabled = !1, this._hidePaginationResults = !1, this._hideFooter = !1, this.fixedColumnsBefore = void 0, this.fixedColumnsAfter = void 0, this.tableInfo = void 0, this.jcef = !1, this._currentSortedData = void 0, this._tbody = void 0, this._tbodyObserver = void 0, this._tbodyKeydownHandler = this._handleTableKeydown.bind(this), this._changeHandler = (t) => {
      this._rowsCheckedListener(t.target), this._checkAllRowsSelected();
    }, this._scrollXHandler = this._handleScrollX.bind(this);
  }
  static get styles() {
    return [f(I), f(V), f(z), f(B)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._tbody?.removeEventListener("keydown", this._tbodyKeydownHandler), this.removeEventListener("change", this._changeHandler), this._scrollBody && (this._scrollBody.removeEventListener("scroll", this._scrollXHandler), this._scrollBody = null), this._tbodyObserver?.disconnect(), this._tbodyObserver = void 0;
  }
  set hideHeader(t) {
    const e = this._hideHeader;
    this._hideHeader = t, this.requestUpdate("hideHeader", e);
  }
  get hideHeader() {
    return this._hideHeader;
  }
  set hidePaginator(t) {
    const e = this._hidePaginator;
    this._hidePaginator = t, this.requestUpdate("hidePaginator", e);
  }
  get hidePaginator() {
    return this._hidePaginator;
  }
  set columnsHeader(t) {
    const e = this._columnsHeader;
    this._columnsHeader = t, this.requestUpdate("columnsHeader", e);
  }
  get columnsHeader() {
    return this._columnsHeader;
  }
  set data(t) {
    const e = this._data;
    this._data = t, this.requestUpdate("data", e);
  }
  get data() {
    return this._data || [];
  }
  set multiselect(t) {
    const e = this._multiselect;
    this._multiselect = t, this.requestUpdate("multiselect", e);
  }
  get multiselect() {
    return this._multiselect;
  }
  set radioselect(t) {
    const e = this._radioselect;
    this._radioselect = t, this.requestUpdate("radioselect", e);
  }
  get radioselect() {
    return this._radioselect;
  }
  set selectedRowsLabel(t) {
    const e = this._selectedRowsLabel;
    this._selectedRowsLabel = t, this.requestUpdate("selectedRowsLabel", e);
  }
  get selectedRowsLabel() {
    return this._selectedRowsLabel;
  }
  set selectedRowsCounter(t) {
    const e = this._selectedRowsCounter;
    this._selectedRowsCounter = t, this.requestUpdate("selectedRowsCounter", e);
  }
  get selectedRowsCounter() {
    return this._selectedRowsCounter || 0;
  }
  set tableTitle(t) {
    const e = this._tableTitle;
    this._tableTitle = t, this.requestUpdate("tableTitle", e);
  }
  get tableTitle() {
    return this._tableTitle;
  }
  set filters(t) {
    const e = this._filters;
    this._filters = t, this.requestUpdate("filters", e);
  }
  get filters() {
    return this._filters ?? [];
  }
  set innerFilters(t) {
    const e = this._innerFilters;
    this._innerFilters = t, this.requestUpdate("innerFilters", e);
  }
  get innerFilters() {
    return this._innerFilters;
  }
  set expandTable(t) {
    const e = this._expandTable;
    this._expandTable = t, this.requestUpdate("expandTable", e);
  }
  get expandTable() {
    return this._expandTable;
  }
  set expandLabel(t) {
    const e = this._expandLabel;
    this._expandLabel = t, this.requestUpdate("expandLabel", e);
  }
  get expandLabel() {
    return this._expandLabel;
  }
  set collapseLabel(t) {
    const e = this._collapseLabel;
    this._collapseLabel = t, this.requestUpdate("collapseLabel", e);
  }
  get collapseLabel() {
    return this._collapseLabel;
  }
  set filtersLabel(t) {
    const e = this._filtersLabel;
    this._filtersLabel = t, this.requestUpdate("filtersLabel", e);
  }
  get filtersLabel() {
    return this._filtersLabel;
  }
  set cleanFiltersLabel(t) {
    const e = this._cleanFiltersLabel;
    this._cleanFiltersLabel = t, this.requestUpdate("cleanFiltersLabel", e);
  }
  get cleanFiltersLabel() {
    return this._cleanFiltersLabel;
  }
  set hideHeaderTitleAndExpand(t) {
    const e = this._hideHeaderTitleAndExpand;
    this._hideHeaderTitleAndExpand = t, this.requestUpdate("hideHeaderTitleAndExpand", e);
  }
  get hideHeaderTitleAndExpand() {
    return this._hideHeaderTitleAndExpand;
  }
  set disableSorting(t) {
    const e = this._disableSorting;
    this._disableSorting = t, this.requestUpdate("disableSorting", e);
  }
  get disableSorting() {
    return this._disableSorting;
  }
  set totalResults(t) {
    const e = this._totalResults;
    this._totalResults = t, this.requestUpdate("totalResults", e);
  }
  get totalResults() {
    return this._totalResults || 0;
  }
  set currentIndex(t) {
    const e = this._currentIndex;
    this._currentIndex = t, this.requestUpdate("currentIndex", e);
  }
  get currentIndex() {
    return this._currentIndex;
  }
  set pageSize(t) {
    const e = this._pageSize;
    this._pageSize = t, this.requestUpdate("pageSize", e);
  }
  get pageSize() {
    return this._pageSize;
  }
  set pageSizeOptions(t) {
    const e = this._pageSizeOptions;
    this._pageSizeOptions = t, this.requestUpdate("pageSizeOptions", e);
  }
  get pageSizeOptions() {
    return this._pageSizeOptions;
  }
  set resultsLabel(t) {
    const e = this._resultstext;
    this._resultstext = t, this.requestUpdate("resultsLabel", e);
  }
  get resultsLabel() {
    return this._resultstext;
  }
  set rowsPerPageLabel(t) {
    const e = this._rowsperpagetext;
    this._rowsperpagetext = t, this.requestUpdate("rowsperpageLabel", e);
  }
  get rowsPerPageLabel() {
    return this._rowsperpagetext;
  }
  set hidePaginationResults(t) {
    const e = this._hidePaginationResults;
    this._hidePaginationResults = t, this.requestUpdate("hidePaginationResults", e);
  }
  get hidePaginationResults() {
    return this._hidePaginationResults;
  }
  set pageSizeOptionsDisabled(t) {
    const e = this._pageSizeOptionsDisabled;
    this._pageSizeOptionsDisabled = t, this.requestUpdate("pageSizeOptionsDisabled", e);
  }
  get pageSizeOptionsDisabled() {
    return this._pageSizeOptionsDisabled;
  }
  set hideFooter(t) {
    const e = this._hideFooter;
    this._hideFooter = t, this.requestUpdate("hideFooter", e);
  }
  get hideFooter() {
    return this._hideFooter;
  }
  // @state() _currentSortedData: any[] | undefined = undefined;
  /* METHODS */
  _getDataLength() {
    let t = 0;
    return this._totalResults && this._totalResults >= 0 ? t = this._totalResults : this._data && (t = this._currentSortedData ? this._currentSortedData.length : this._data.length), t;
  }
  _sortBy(t, e, s) {
    this._currentSortColumn = t, this._currentSortType = e, s ? s === "none" ? this._currentSortOrder = "asc" : s === "asc" ? this._currentSortOrder = "desc" : s === "desc" && (this._currentSortOrder = "none") : this._currentSortOrder = "asc", this._updateColumnSortState(), this._currentSortOrder === "none" ? this._currentSortedData = this._data : this._currentSortedData = x(this._data, this._currentSortColumn, this._currentSortOrder, e);
    const r = this._hidePaginator || this._hideFooter ? this._currentSortedData : this._resetPagination(this._currentSortedData || []);
    return this._dispatchSort(r || []), r;
  }
  _resetPagination(t) {
    this._currentIndex = 1;
    const e = this._currentIndex - 1, s = this._pageSize;
    if (t) {
      const r = s <= t.length ? s : t.length;
      this._paginatedData = [...t.slice(e, r)];
    }
    return this._paginatedData;
  }
  _updateColumnSortState() {
    this._columnsHeader.forEach((t) => {
      t.column === this._currentSortColumn ? t.sortOrder = this._currentSortOrder : t.sortOrder && (t.sortOrder = "none");
    });
  }
  _onSelectAll() {
    if (this._table) {
      this._allRowsSelected = !this._allRowsSelected;
      let t = 0, e = 0;
      const s = this._table.querySelectorAll(".dss-checkbox--multiselect");
      s.forEach((r) => {
        r.disabled ? e += 1 : (r.checked || (t += 1), r.checked = this._allRowsSelected);
      }), this._allRowsSelected ? this._currentRowsChecked += t : this._currentRowsChecked -= s.length - e, this._updateTableFooterRowsChecked(), this._dispatchMultiselect();
    }
  }
  _rowsCheckedListener(t) {
    if (!this._table || t.classList.contains("dss-checkbox--thead")) return;
    let s = !1;
    if (t.tagName === "INPUT" && t.type === "checkbox" && t.classList.contains("dss-checkbox") && !t.classList.contains("dss-checkbox--thead"))
      s = t.checked;
    else if (t.tagName === "DSS-CHECKBOX") {
      const r = t;
      s = r.checked ?? r.getAttribute("checked") !== null;
    }
    s ? this._currentRowsChecked += 1 : this._currentRowsChecked -= 1, this._updateTableFooterRowsChecked();
  }
  _updateTableFooterRowsChecked() {
    this._selectedRowsCounter === void 0 && (this.internalSelectedCounter = this._currentRowsChecked);
  }
  _updateTableHeader() {
    if (this._table) {
      const t = this._table.querySelector(".dss-custom-table");
      let e = t.querySelector("thead");
      e || (e = document.createElement("thead"), e.classList.add("dss-thead"), t.insertBefore(e, t.firstChild)), q(this._generateTableHeaderHTML(), e);
    }
  }
  _generateTableHeaderHTML() {
    let t = !0, e = d``, s = d``;
    this._multiselect && (e = d`
        <th class="dss-th dss-th--select">
          <div class="dss-th-content dss-th-content--select">
						<span class="sr-only">Seleccionar totes les files</span>
						<${K}
							class="dss-checkbox dss-checkbox--thead"
							label="Seleccionar totes les files"
							hideLabel
							.checked=${this._allRowsSelected}
              @change="${this._onSelectAll.bind(this)}"
						/>
          </div>
        </th>
      `), this._radioselect && (s = d`
        <th class="dss-th dss-th--select">
          <div class="dss-th-content dss-th-content--select">
						<span class="sr-only">Seleccionar fila</span>
					</div>
        </th>
      `);
    const r = this._columnsHeader.map((i) => {
      const c = () => {
        i.sortType && !this._disableSorting && (this._sortBy(i.column, i.sortType, i?.sortOrder), this._updateTableHeaderIcons());
      }, u = (p) => {
        const T = p.currentTarget, O = p;
        let b = !1;
        switch (O.key) {
          case "ArrowLeft":
            this._table && v(this._table, T, ".dss-th-content--clickable"), b = !0;
            break;
          case "ArrowRight":
            this._table && L(this._table, T, ".dss-th-content--clickable"), b = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const H = p.target;
            this._table && U(this._table, H, ".dss-th-content--clickable"), b = !0;
            break;
          }
        }
        b && (p.stopPropagation(), p.preventDefault());
      }, _ = {
        "dss-th--align-center": i.align === "center",
        "dss-th--align-right": i.align === "right",
        "dss-th--highlight": !!i.highlight
      };
      let C = !1;
      i.sortType && !this._disableSorting && (C = !0);
      const A = {
        "dss-th-content--clickable": C
        // 'table-th--review': columnType === 'review',
      }, F = d`
        <th
          class="dss-th ${g(_)}"
          style="${P(i.style)}"
        >
          <div
            class="dss-th-content ${g(A)}"
            tabindex="${t ? 0 : -1}"
            @click=${c}
            @keydown=${u}
          >
						${i.renderTemplate ? d`
									<span class="sr-only">${i.label}</span>
									${i.renderTemplate()}
								` : d`
								${i.srOnly ? d`<span class="sr-only">${i.label}</span>` : d`<span class="dss-th-content__label">${i.label}</span>`}
							`}

            ${i.sortType && !this._disableSorting ? d`${this._getTableHeaderSortIconHTML(i.column)}` : null}
          </div>
        </th>
      `;
      return t = !1, F;
    });
    return d` <tr class="dss-thead-row ${g({})}">
      ${e} ${s} ${r}
    </tr>`;
  }
  _getTableHeaderSortIconHTML(t) {
    let e = "swap_vert";
    if (this._currentSortColumn === t)
      switch (this._currentSortOrder) {
        case "asc":
          e = "arrow_upward";
          break;
        case "desc":
          e = "arrow_downward";
          break;
        default:
          e = "swap_vert";
          break;
      }
    return d`
			<${R} 
				class="dss-th-content__icon dss-icon--column-sort"
				column="${t}" 
				icon="${e}" 
				size="sm">
			</${R}>
    `;
  }
  _updateTableHeaderIcons() {
    this._table && this._table.querySelectorAll(
      ".dss-th-content--clickable > .dss-icon--column-sort"
    ).forEach((e) => {
      const s = e.getAttribute("column");
      let r = "swap_vert";
      if (this._currentSortColumn === s)
        switch (this._currentSortOrder) {
          case "asc":
            r = "arrow_upward";
            break;
          case "desc":
            r = "arrow_downward";
            break;
          default:
            r = "swap_vert";
            break;
        }
      e.setAttribute("icon", r);
    });
  }
  _paginate(t) {
    const e = t.startIndex, s = t.endIndex;
    if (this._currentSortedData) {
      const r = s <= this._currentSortedData.length ? s : this._currentSortedData.length;
      this._paginatedData = [...this._currentSortedData.slice(e - 1, r)];
    }
    return t.pageSize && (this._pageSize = t.pageSize), this._paginatedData;
  }
  /* OUTPUT EVENTS */
  _dispatchChangeFilters(t) {
    this._filters = t.detail;
    const e = {
      detail: this._filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onUpdateFilters", e));
  }
  _dispatchExpandTable(t) {
    this._expandTable = t.detail;
    const e = {
      detail: this._expandTable,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onExpandTable", e));
  }
  _dispatchOpenFilters() {
    const t = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenDrawer", t));
  }
  handleChangePage(t) {
    this._dispatchPagination(t);
  }
  _dispatchPagination(t) {
    if (!this._totalResults || this._isPaginationStarted) {
      const e = {
        detail: t.detail,
        bubbles: !0,
        composed: !0
      };
      if (this._paginationState = e.detail, this._data && !this._totalResults && (e.detail.data = this._paginate(this._paginationState)), this._totalResults && (this._shouldUpdate = !0), this._allRowsSelected) {
        this._allRowsSelected = !1;
        const s = this._table?.querySelector(".dss-checkbox--thead");
        s && (s.checked = !1);
      }
      setTimeout(() => {
        this.dispatchEvent(new CustomEvent("onPaginate", e));
      }, 0);
    }
    this._isPaginationStarted = !0;
  }
  _dispatchSort(t) {
    const e = {
      detail: {
        currentSortColumn: this._currentSortColumn,
        currentSortOrder: this._currentSortOrder,
        currentSortType: this._currentSortType,
        columnsHeader: this._columnsHeader,
        data: t
      },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onSort", e));
  }
  _dispatchMultiselect() {
    const t = {
      detail: this._allRowsSelected,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onMultiselect", t));
  }
  _handleTableKeydown(t) {
    if (!this._table) return;
    const e = t.target;
    let s = !1;
    const r = e.closest("tr");
    switch (t.key) {
      case "ArrowUp":
        v(this._table, r, ".dss-tbody-row"), s = !0;
        break;
      case "ArrowDown":
        L(this._table, r, ".dss-tbody-row"), s = !0;
        break;
      case "Enter":
        if (this._multiselect) {
          const n = r?.querySelector(".dss-checkbox--multiselect");
          n && (n.checked = !n?.checked, this.requestUpdate()), s = !0;
        }
        if (this._radioselect) {
          const n = r?.querySelector(".dss-radio");
          n && (n.checked = !n?.checked, this.requestUpdate()), s = !0;
        }
        break;
    }
    s && (t.stopPropagation(), t.preventDefault());
  }
  _initTable() {
    const t = this.shadowRoot?.querySelector('slot[name="table"]') || void 0;
    this._table = t?.assignedElements()[0], this._table && (this._columnsHeader.length && !this._isTableHeaderCreated && (this._updateTableHeader(), this._isTableHeaderCreated = !0), this._setFirstRowTabindex(), this._checkAllRowsSelected(), this._tbody = this._table.querySelector("tbody"), this._tbody?.addEventListener("keydown", this._tbodyKeydownHandler), this._detectNewRows());
  }
  _detectNewRows() {
    this._tbody && (this._tbodyObserver = new MutationObserver((t) => {
      let e = !1;
      for (const s of t)
        if (s.type === "childList" && (s.addedNodes.length > 0 || s.removedNodes.length > 0)) {
          e = !0;
          break;
        }
      e && (this._setFirstRowTabindex(), this._checkAllRowsSelected());
    }), this._tbodyObserver.observe(this._tbody, { childList: !0 }));
  }
  _setFirstRowTabindex() {
    if (!this._table) return;
    const t = this._table.querySelectorAll(".dss-tbody-row");
    let e = !0;
    t.forEach((s) => {
      e ? s.setAttribute("tabindex", "0") : s.setAttribute("tabindex", "-1"), e = !1;
    });
  }
  _checkAllRowsSelected() {
    if (this._table) {
      const t = this._table.querySelectorAll(".dss-checkbox--multiselect");
      let e = !0;
      if (t.length === 0 && (e = !1), t.forEach((s) => {
        !s.checked && !s.disabled && (e = !1);
      }), this._allRowsSelected !== e) {
        this._allRowsSelected = e;
        const s = this._table?.querySelector(".dss-checkbox--thead");
        s.checked = this._allRowsSelected;
      }
    }
  }
  _fixColumns() {
    if (this._table && (this.fixedColumnsBefore || this.fixedColumnsAfter)) {
      const t = this._table.querySelector("table"), e = t?.querySelector("thead"), s = t?.querySelector("tbody"), r = e?.querySelectorAll("th"), n = s?.querySelectorAll("tr");
      if (t?.classList.add("dss-custom-table--max-content-width"), t?.classList.add("dss-custom-table--sticky-columns-lit"), this.fixedColumnsBefore) {
        const i = Array.from(r || []).slice(0, this.fixedColumnsBefore);
        this._cellsToSticky(i, "left");
        for (const c of Array.from(n || [])) {
          const u = c.querySelectorAll("td"), _ = Array.from(u).slice(0, this.fixedColumnsBefore);
          this._cellsToSticky(_, "left");
        }
      }
      if (this.fixedColumnsAfter) {
        const i = Array.from(r || []).slice(-this.fixedColumnsAfter).reverse();
        this._cellsToSticky(i, "right");
        for (const c of Array.from(n || [])) {
          const u = c.querySelectorAll("td"), _ = Array.from(u).slice(-this.fixedColumnsAfter).reverse();
          this._cellsToSticky(_, "right");
        }
      }
    }
  }
  _cellsToSticky(t, e) {
    for (const [s, r] of Array.from(t || []).entries()) {
      const n = r;
      n.classList.add("dss-sticky-column");
      let i = 0;
      s > 0 && (i = i + t[s - 1].offsetWidth), e === "left" ? n.style.left = `${i}px` : n.style.right = `${i}px`, s === t.length - 1 && (e === "left" ? n.classList.add("dss-sticky-column--before-last") : n.classList.add("dss-sticky-column--after-first"));
    }
  }
  _initScrollX(t) {
    t?.clientWidth < t?.scrollWidth && this._table?.classList.add("scroll-init");
  }
  _handleScrollX(t) {
    const e = t.target, s = e?.scrollWidth - e?.clientWidth;
    s <= 0 || (e?.scrollLeft === 0 && (this._table?.classList.add("scroll-init"), this._table?.classList.remove("scroll-middle")), e?.scrollLeft > 0 && Math.round(e?.scrollLeft) < s && (this._table?.classList.add("scroll-middle"), this._table?.classList.remove("scroll-init"), this._table?.classList.remove("scroll-end")), Math.round(e?.scrollLeft) === s && (this._table?.classList.add("scroll-end"), this._table?.classList.remove("scroll-middle")));
  }
  _setDataState() {
    this._currentSortOrder === "none" ? this._currentSortedData = this._data : this._currentSortedData = x(
      this._data,
      this._currentSortColumn,
      this._currentSortOrder,
      this._currentSortType
    );
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    if (await this.updateComplete, this._setDataState(), this._isFirstUpdate && !this._table && (this._initTable(), this.addEventListener("change", this._changeHandler), this._fixColumns()), this.fixedColumnsBefore || this.fixedColumnsAfter) {
      const t = this.shadowRoot?.querySelector(".dss-custom-table-body");
      this._scrollBody = t || null, this._initScrollX(t), t?.addEventListener("scroll", this._scrollXHandler);
    }
    this._isFirstUpdate = !1;
  }
  willUpdate(t) {
    const e = t.has("columnsHeader"), s = t.has("disableSorting"), r = t.has("data"), n = t.has("currentIndex");
    if (s && this._updateTableHeader(), e && (this._columnsHeader.forEach((i) => {
      i.sortOrder && (this._currentSortColumn = i.column, this._currentSortOrder = i.sortOrder, i.sortType && (this._currentSortType = i.sortType));
    }), !this._isTableHeaderCreated && this._table && (this._updateTableHeader(), this._isTableHeaderCreated = !0), this._fixColumns()), r && !this._isFirstUpdate) {
      if (this._setDataState(), this._totalResults) {
        if (this.internalSelectedCounter > this._totalResults && (this.internalSelectedCounter = this._totalResults), this._shouldUpdate) {
          if (this._currentSortColumn && this._currentSortType && this._currentSortOrder && this._currentSortOrder !== "none") {
            const i = x(
              this._data,
              this._currentSortColumn,
              this._currentSortOrder,
              this._currentSortType
            );
            this._dispatchSort(i);
          }
          this._shouldUpdate = !1;
        }
      } else {
        const i = this._getDataLength();
        if (this.internalSelectedCounter > i && (this.internalSelectedCounter = i, this._currentRowsChecked = i), this._paginationState) {
          this._paginationState.endIndex < this._pageSize && (this._paginationState.endIndex = this._pageSize);
          const c = {
            detail: this._paginationState,
            bubbles: !0,
            composed: !0
          };
          this._dispatchPagination(c);
        }
      }
      this._fixColumns();
    }
    n && !this._isFirstUpdate && (this._fixColumns(), this.requestUpdate());
  }
  filtersPopoverClose() {
    const t = this.shadowRoot?.querySelector("dss-custom-table-header");
    t && t.filtersPopoverClose();
  }
  _areRowsSelected() {
    return this._selectedRowsCounter !== void 0 ? this._selectedRowsCounter > 0 : this.internalSelectedCounter > 0;
  }
  render() {
    return d`
      <div class="dss-custom-table">
        <div class="dss-custom-table-header">
          ${this._hideHeader ? null : d`
                <${k}
									?customActions=${this.customActions}
									?showConfig=${this.showConfig}
									?hideActionExpand=${this.hideActionExpand}
									?showActionFilters=${this.showActionFilters}
									?jcef=${this.jcef}
									.tableInfo=${this.tableInfo}
									.configTableLabel=${this.configTableLabel}
                  .tableTitle=${this._tableTitle}
                  .filters=${this._filters}
                  .innerFilters=${this._innerFilters}
									.enableCombinedFilters=${this.enableCombinedFilters}
                  .expandTable=${this._expandTable}
                  .expandLabel=${this._expandLabel}
                  .collapseLabel=${this._collapseLabel}
                  .filtersLabel=${this._filtersLabel}
                  .cleanFiltersLabel=${this._cleanFiltersLabel}
                  .hideHeaderTitleAndExpand=${this._hideHeaderTitleAndExpand}
                  @onChangeFilters=${this._dispatchChangeFilters}
                  @onExpand=${this._dispatchExpandTable}
                  @onOpenFilters=${this._dispatchOpenFilters}
                >
									${this.customActions ? d`
	                  <slot name="header-custom-actions" slot="header-custom-actions"></slot>
									` : null}
                  <slot name="filters-popover-body" slot="filters-popover-body"></slot>
                  <slot name="filters-popover-footer" slot="filters-popover-footer"></slot>
                  <slot name="filters" slot="filters"></slot>
                </${k}>
              `}
        </div>

        <div class="dss-custom-table-body">
          <slot name="table"></slot>
        </div>

        ${this._hideFooter ? null : d`
              <div class="dss-custom-table-footer">
                
                ${this._multiselect ? d`
                      <div class="${g({
      "table-footer": !0,
      "table-footer--hide": !this._areRowsSelected()
    })}">
                        <div class="table-footer-description">
                          <span class="table-footer-description__counter">
                            ${this._selectedRowsCounter !== void 0 ? this._selectedRowsCounter : this.internalSelectedCounter}
                          </span>
                          de ${this._getDataLength()} ${this._selectedRowsLabel}
                        </div>
                        <slot name="footer-actions"></slot>
                      </div>
                    ` : null}

								${this._hidePaginator ? null : d`
                      <${$}
                        .length=${this._getDataLength()}
                        pagesize=${this._pageSize}
                        .pageSizeOptions=${this._pageSizeOptions}
                        currentindex=${this._currentIndex}
                        .resultsText=${this._resultstext}
                        .rowsPerPageText=${this._rowsperpagetext}
                        ?pageSizeOptionsDisabled=${this._pageSizeOptionsDisabled}
                        ?hidePaginationResults=${this._hidePaginationResults}
                        @page-changed=${this.handleChangePage}
                      ></${$}>
                    `}
              </div>
            `}
      </div>
    `;
  }
}
a([
  o({ type: Number })
], l.prototype, "internalSelectedCounter", 2);
a([
  o(h)
], l.prototype, "hideHeader", 1);
a([
  o(h)
], l.prototype, "hidePaginator", 1);
a([
  o({ type: Array })
], l.prototype, "columnsHeader", 1);
a([
  o({ type: Array })
], l.prototype, "data", 1);
a([
  o(h)
], l.prototype, "multiselect", 1);
a([
  o(h)
], l.prototype, "radioselect", 1);
a([
  o({ type: String })
], l.prototype, "selectedRowsLabel", 1);
a([
  o({ type: Number })
], l.prototype, "selectedRowsCounter", 1);
a([
  o(h)
], l.prototype, "showConfig", 2);
a([
  o({ type: String })
], l.prototype, "configTableLabel", 2);
a([
  o(h)
], l.prototype, "customActions", 2);
a([
  o(h)
], l.prototype, "enableCombinedFilters", 2);
a([
  o({ type: String })
], l.prototype, "tableTitle", 1);
a([
  o({ type: Array })
], l.prototype, "filters", 1);
a([
  o(h)
], l.prototype, "innerFilters", 1);
a([
  o(h)
], l.prototype, "expandTable", 1);
a([
  o({ type: String })
], l.prototype, "expandLabel", 1);
a([
  o({ type: String })
], l.prototype, "collapseLabel", 1);
a([
  o({ type: String })
], l.prototype, "filtersLabel", 1);
a([
  o({ type: String })
], l.prototype, "cleanFiltersLabel", 1);
a([
  o(h)
], l.prototype, "hideHeaderTitleAndExpand", 1);
a([
  o(h)
], l.prototype, "disableSorting", 1);
a([
  o({ type: Number })
], l.prototype, "totalResults", 1);
a([
  o({ type: Number })
], l.prototype, "currentIndex", 1);
a([
  o({ type: Number })
], l.prototype, "pageSize", 1);
a([
  o({ type: Array })
], l.prototype, "pageSizeOptions", 1);
a([
  o({ type: String })
], l.prototype, "resultsLabel", 1);
a([
  o({ type: String })
], l.prototype, "rowsPerPageLabel", 1);
a([
  o(h)
], l.prototype, "hidePaginationResults", 1);
a([
  o(h)
], l.prototype, "pageSizeOptionsDisabled", 1);
a([
  o(h)
], l.prototype, "hideFooter", 1);
a([
  o(h)
], l.prototype, "hideActionExpand", 2);
a([
  o(h)
], l.prototype, "showActionFilters", 2);
a([
  o({ type: Number })
], l.prototype, "fixedColumnsBefore", 2);
a([
  o({ type: Number })
], l.prototype, "fixedColumnsAfter", 2);
a([
  o({ type: String })
], l.prototype, "tableInfo", 2);
a([
  o(h)
], l.prototype, "jcef", 2);
a([
  D()
], l.prototype, "_currentSortedData", 2);
export {
  l as CustomTable
};
//# sourceMappingURL=custom-table.js.map
