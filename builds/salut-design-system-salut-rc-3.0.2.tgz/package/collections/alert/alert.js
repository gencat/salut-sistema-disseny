import { LitElement as d, unsafeCSS as h } from "lit";
import { property as o, state as c } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import f from "./alert.style.css.js";
import { alertTemplate as m } from "./alert.template.js";
var g = Object.defineProperty, b = Object.getOwnPropertyDescriptor, t = (p, s, a, i) => {
  for (var r = i > 1 ? void 0 : i ? b(s, a) : s, l = p.length - 1, u; l >= 0; l--)
    (u = p[l]) && (r = (i ? u(s, a, r) : u(r)) || r);
  return i && r && g(s, a, r), r;
};
class e extends d {
  constructor() {
    super(...arguments), this.status = "info", this.size = "md", this.message = void 0, this.titleText = void 0, this.description = void 0, this.buttonLabel = "Label", this.showMoreLabel = "Mostrar més", this.showLessLabel = "Mostrar menys", this.hasCloseIcon = !1, this.hasButton = !1, this.fullWidth = !1, this.buttonBottom = !1, this.expanded = !1, this.isOverflowing = !1, this._statusIcon = "info";
  }
  static get styles() {
    return [h(y), h(f)];
  }
  set state(s) {
    this.status = s;
  }
  get state() {
    return this.status;
  }
  _handleButtonClick() {
    this.dispatchEvent(new CustomEvent("button-click", { bubbles: !0, composed: !0 }));
  }
  _handleClose() {
    this.dispatchEvent(new CustomEvent("close", { bubbles: !0, composed: !0 }));
  }
  updated(s) {
    s.has("state") && queueMicrotask(() => {
      this.setStatusIcon();
    }), s.has("message") && queueMicrotask(() => {
      this.titleText = this.message;
    });
  }
  async firstUpdated() {
    await this.updateComplete, setTimeout(() => {
      const s = this.renderRoot.querySelector(".dss-alert__text"), a = this._isTextTruncated(s), i = this.renderRoot.querySelector(".dss-alert__description"), r = this._isTextTruncated(i);
      this.isOverflowing = a || r;
    }, 0);
  }
  _isTextTruncated(s) {
    if (!s) return !1;
    const { scrollHeight: a, clientHeight: i } = s;
    return a > i;
  }
  setStatusIcon() {
    switch (this.state) {
      case "error":
        this._statusIcon = "cancel";
        break;
      case "warning":
        this._statusIcon = "report";
        break;
      case "success":
        this._statusIcon = "check_circle";
        break;
      default:
        this._statusIcon = "info";
    }
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  toggleExpand() {
    this.expanded = !this.expanded;
  }
  render() {
    return m(this);
  }
}
t([
  o({ type: String })
], e.prototype, "status", 2);
t([
  o({ type: String })
], e.prototype, "state", 1);
t([
  o({ type: String })
], e.prototype, "size", 2);
t([
  o({ type: String })
], e.prototype, "message", 2);
t([
  o({ type: String })
], e.prototype, "titleText", 2);
t([
  o({ type: String })
], e.prototype, "description", 2);
t([
  o({ type: String })
], e.prototype, "buttonLabel", 2);
t([
  o({ type: String })
], e.prototype, "showMoreLabel", 2);
t([
  o({ type: String })
], e.prototype, "showLessLabel", 2);
t([
  o(n)
], e.prototype, "hasCloseIcon", 2);
t([
  o(n)
], e.prototype, "hasButton", 2);
t([
  o(n)
], e.prototype, "fullWidth", 2);
t([
  o(n)
], e.prototype, "buttonBottom", 2);
t([
  c(n)
], e.prototype, "expanded", 2);
t([
  c(n)
], e.prototype, "isOverflowing", 2);
t([
  c()
], e.prototype, "_statusIcon", 2);
export {
  e as Alert
};
//# sourceMappingURL=alert.js.map
