import { nothing as _ } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
import { unsafeHTML as r } from "lit/directives/unsafe-html.js";
import { unsafeStatic as i, literal as d, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const $ = d`dss-icon${i(e())}`, u = d`dss-icon-button${i(e())}`, t = d`dss-button${i(e())}`, h = (s) => a`
  <div
    class=${l({
  "dss-alert": !0,
  [`dss-alert--${s.size}`]: !!s.size,
  [`dss-alert--${s.status}`]: !!s.status,
  "dss-alert--full-width": s.fullWidth,
  "dss-alert--button-bottom": s.buttonBottom
})}
  >
    <div class="dss-alert-body">
      ${s.size !== "sm" ? a`
            <div class="dss-alert__icon">
              <${$} size="${s._getIconSize()}" icon="${s._statusIcon}"></${$}>
            </div>
          ` : null}
      <div class="dss-alert-content">
        <div
          class=${l({
  "dss-alert__text": !0,
  "dss-alert__text--expanded": s.expanded
})}>
          ${r(s.titleText)}
        </div>
        ${s.description ? a`
          <div
            class=${l({
  "dss-alert__description": !0,
  "dss-alert__description--expanded": s.expanded
})}>
            ${r(s.description)}
          </div>
          ` : _}
        ${s.isOverflowing ? a`
          <${t}
            class="dss-alert__show-more"
            size="sm"
            variant="secondary"
            icon="${s.expanded ? "expand_less" : "expand_more"}"
            iconPosition="right"
            status="${s.status === "error" ? "danger" : s.status}"
            label="${s.expanded ? s.showLessLabel : s.showMoreLabel}"
            @onClick="${s.toggleExpand}"
          ></${t}>
          ` : null}
      </div>
    </div>
    ${s.hasCloseIcon ? a`
          <div class="dss-alert-action">
            <${u}
              hideTooltip
              class="dss-alert__icon-button"
              icon="close"
              label="Tancar"
              size="${s._getIconSize()}"
              variant="${s.status}"
              @onClick="${s._handleClose}"
            ></${u}>
          </div>
        ` : null}
    ${s.size === "lg" && s.hasButton ? a`
          <div class="dss-alert-action">
            <${t}
              size="sm"
              variant="${s.status}"
              label="${s.buttonLabel}"
              @onClick="${s._handleButtonClick}"
            ></${t}>
          </div>
        ` : null}
  </div>
`;
export {
  h as alertTemplate
};
//# sourceMappingURL=alert.template.js.map
