import { nothing as a } from "lit";
import { classMap as h } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as n, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import { checkTextTruncate as r, checkWebkitTruncate as _ } from "../../utils/helpers.js";
const i = n`dss-icon-button${l($())}`, p = n`dss-link${l($())}`, t = n`dss-icon${l($())}`, u = n`dss-badge${l($())}`, d = n`dss-tooltip${l($())}`, m = (e) => s`
  <div
    class=${h({
  "dss-header-menu-patient": !0,
  "dss-header-menu-patient--jcef": e.jcef,
  [`dss-header-menu-patient--${e.variant}`]: !!e.variant
})}
  >
    <div class="dss-header-menu-patient-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-patient-details">
      <div class="dss-header-menu-patient-details__name">
        ${e.name}
      </div>
      <div class="dss-header-menu-patient-details__info">
        ${e.cip ? s`
            <span class="dss-header-menu-patient-details__info-label dss-header-menu-patient-details__info-label--cip">
              ${e.cip}
            </span>
            <span class="divider-v divider-v--cip"></span>
          ` : null}
        ${e.age ? s`
            <span class="dss-header-menu-patient-details__info-label">
              ${e.age}
              ${e.ageLabel ? s`${e.ageLabel.trim().charAt(0)}.` : a}
            </span>
            <span class="divider-v"></span>
          ` : null}
        ${e.gender ? s`
            <span class="dss-header-menu-patient-details__info-label">
              ${e.gender}
            </span>
          ` : null}
      </div>
    </div>
    <${i}
      class="dss-header-menu-patient__toggle-action"
      icon="${e._toggleIcon}"
      label="${e._toggleLabel}"
      variant="primary"
      @onClick="${e._toggleDropdown}"
      ?disabled=${e.disabled}
      ariaLabel="${e._toggleLabel} menú pacient"
      ariaExpanded="${e._showDropdown ? "true" : "false"}"
      hideTooltip
    ></${i}>
    ${e._showDropdown ? s`
          <div
            id="menu-patient"
            class=${h({
  "dss-header-menu-patient-dropdown": !0,
  "dss-header-menu-patient-dropdown--expanded": !!e._showDropdown
})}
          >
            <div class="dss-header-menu-patient-dropdown__info">
              <div class="dss-header-menu-patient-dropdown__title">
                ${e.infoLabel}
              </div>

              <div class="dss-header-menu-patient-dropdown__content">
                <div class="dss-header-menu-patient-dropdown__subtitle">
                  ${e.name}
                </div>

                ${e.cip ? s`
                  <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--cip">
                    <span class="dss-header-menu-patient-dropdown__description__cip">
                      ${e.cip}
                    </span>
                    ${e.hideCopyCip ? a : s`
                        <${i}
                          icon="content_copy"
                          size="sm"
                          label="Copiar CIP"
                          variant="primary"
                          @onClick="${e._handleCIPClick}"
                          ?disabled=${e.disabled}
                        ></${i}>
                      `}
                   
                  </div>
                  ` : a}

                ${e.age ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${t} icon="person" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.age}
                        ${e.ageLabel ? s`${e.ageLabel}` : a}
                      </div>
                    </div>
                  ` : a}

                ${e.gender ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${t} icon="${e._getGenderIcon()}" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.gender}
                      </div>
                    </div>
                  ` : a}

                ${e.phoneMain ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${t} icon="phone" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.phoneMain}
                      </div>
                      ${e.hasPhoneMainCall ? s`
                        <${i}
                          size='sm'
                          icon='phone_forwarded'
                          label="Trucar al telèfon principal"
                          hideTooltip
                          @click=${() => e._handlePhoneCall(e.phoneMain)}
                        ></${i}>
                        ` : a}
                      ${e.hasPhoneMainChat ? s`
                        <${i}
                          size='sm'
                          icon='sms'
                          label="Enviar missatge al telèfon principal"
                          hideTooltip
                          @click=${() => e._handlePhoneChat(e.phoneMain)}
                        ></${i}>
                        ` : a}
                    </div>
                  ` : a}

                ${e.phoneAlt ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${t} icon="phone" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.phoneAlt}
                      </div>
                       ${e.hasPhoneAltCall ? s`
                        <${i}
                          size='sm'
                          icon='phone_forwarded'
                          label="Trucar al telèfon alternatiu"
                          hideTooltip
                          @click=${() => e._handlePhoneCall(e.phoneAlt)}
                        ></${i}>
                        ` : a}
                      ${e.hasPhoneAltChat ? s`
                        <${i}
                          size='sm'
                          icon='sms'
                          label="Enviar missatge al telèfon alternatiu"
                          hideTooltip
                          @click=${() => e._handlePhoneChat(e.phoneAlt)}
                        ></${i}>
                        ` : a}
                    </div>
                  ` : a}

                ${e.mail ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${t} icon="mail" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                        ${e.mailHref ? s`
                          <a class="dss-header-menu-patient-dropdown__link" href="${e.mailHref}" target="_blank" rel="noopener">
                            ${e.mail}
                          </a>
                          ` : s`
                            ${e.mail}
                          `}
                        <${d} 
                          class="description-tooltip" 
                          aria-hidden="true" 
                          interactive
                        >
                          ${e.mail}
                        </${d}>
                      </div>
                    </div>
                  ` : a}

                

                ${e.address ? s`
                    <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--address">
                      <${t} class="address-icon" icon="home_work" size="sm"></${t}>
                      <div class="dss-header-menu-patient-dropdown__description dss-header-menu-patient-dropdown__description--address" @mouseenter=${_}>
                        <a class="dss-header-menu-patient-dropdown__link" href="${e.addressURL}" target="_blank" rel="noopener">
                          ${e.address}
                        </a>
                        <${d} 
                          class="description-tooltip header-menu-patient-tooltip" 
                          aria-hidden="true" 
                          interactive
                        >
                          ${e.address}
                        </${d}>
                      </div>
                    </div>
                  ` : a}

                ${e.assignments ? s`
                  <div class="dss-header-menu-patient-dropdown__assignments">
                    <div class="dss-header-menu-patient-dropdown__title dss-header-menu-patient-dropdown__title--assigned">
                      ${e.assignedLabel}
                    </div>

                    ${e.assignments.uab ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAB</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${e.assignments.uab}
                          <${d} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.uab}
                          </${d}>
                        </div>
                      </div>
                      ` : a} 

                    ${e.assignments.ui ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UI</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${e.assignments.ui}
                          <${d} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.ui}
                          </${d}>
                        </div>
                      </div>
                      ` : a} 

                    ${e.assignments.uas ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAS</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${e.assignments.uas}
                          <${d} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.uas}
                          </${d}>
                        </div>
                      </div>
                      ` : a} 

                    ${e.assignments.center ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${e.assignments.center}
                          <${d} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.center}
                          </${d}>
                        </div>
                        ${e.assignments.up ? s`
                          <${u} size="sm" status="alert" label="${e.upLabel}">
                            <${d}
                              class="header-menu-patient-tooltip"
                              slot="tooltip"
                             > 
                              ${e.upMessage} 
                            </${d}>
                          </${u}>
                        ` : a}
                      </div>
                      ` : a} 
                  </div>
                ` : a}
              </div>
            </div>

            ${!e.hideViewDetails || e.edit ? s`
                <div class="dss-header-menu-patient-dropdown__actions">
                  ${e.hideViewDetails ? a : s`
                      <${p}
                        variant="default"
                        size="md"
                        label="${e.detailsLabel}"
                        href='${e.detailsHref}'
                        target='${e.detailsTarget}'
                        fullWidth
                      >
                      </${p}>
                    `}
                  ${e.edit ? s`
                      <${p}
                        variant="default"
                        size="md"
                        label="${e.editLabel}"
                        href='${e.editHref}'
                        target='${e.editTarget}'
                        icon="open_in_new" 
                        iconPosition="right"
                        fullWidth
                      >
                      </${p}>
                    ` : a}
                </div>` : a}

          </div>
        ` : null}
  </div>
`;
export {
  m as headerMenuPatientTemplate
};
//# sourceMappingURL=header-menu-patient.template.js.map
