import { LitElement as c, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import y from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import { booleanType as s } from "../../utils/property-types.js";
import u from "./header-menu-patient.style.css.js";
import { headerMenuPatientTemplate as m } from "./header-menu-patient.template.js";
var f = Object.defineProperty, e = (p, o, r, h) => {
  for (var a = void 0, n = p.length - 1, d; n >= 0; n--)
    (d = p[n]) && (a = d(o, r, a) || a);
  return a && f(o, r, a), a;
};
class i extends c {
  constructor() {
    super(), this.disabled = !1, this.variant = "default", this.name = void 0, this.cip = void 0, this.age = void 0, this.ageLabel = void 0, this.gender = void 0, this.phoneMain = void 0, this.phoneAlt = void 0, this.hasPhoneMainCall = !1, this.hasPhoneMainChat = !1, this.hasPhoneAltCall = !1, this.hasPhoneAltChat = !1, this.mail = void 0, this.mailHref = void 0, this.address = void 0, this.addressURL = "#", this.infoLabel = "Dades del pacient", this.assignedLabel = "Professionals assignats", this.detailsLabel = "Veure més detalls", this.detailsHref = "#", this.detailsTarget = "_self", this.editLabel = "Editar usuari", this.editHref = "#", this.editTarget = "_self", this.hideViewDetails = !1, this.jcef = !1, this.edit = !1, this.assignments = void 0, this.hideCopyCip = !1, this.upLabel = "UP", this.upMessage = "Usuari desplaçat: no pertany a l’equip d’atenció primària", this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Obrir", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [l(g), l(y), l(u)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Tancar" : "Obrir", this.requestUpdate();
  }
  _handleCIPClick(o) {
    this._handleCopyCIP(o), this._toggleDropdown();
  }
  _handleCopyCIP(o) {
    o.stopPropagation(), this.cip && (navigator.clipboard.writeText(this.cip), this.dispatchEvent(
      new CustomEvent("copy-cip", {
        detail: { text: this.cip },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _handlePhoneCall(o) {
    this.dispatchEvent(
      new CustomEvent("phone-call", {
        detail: { phoneNumber: o },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _handlePhoneChat(o) {
    this.dispatchEvent(
      new CustomEvent("phone-chat", {
        detail: { phoneNumber: o },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _getGenderIcon() {
    return this.gender?.toLowerCase() === "femení" ? "female" : "male";
  }
  _handleDocumentClick(o) {
    this._clickedOutside(this, o);
  }
  _clickedOutside(o, r) {
    if (r.composedPath().includes(o))
      return;
    const n = r.target?.closest?.("dss-tooltip");
    n && n.classList.contains("header-menu-patient-tooltip") || this._showDropdown && this._toggleDropdown();
  }
  render() {
    return m(this);
  }
}
e([
  t(s)
], i.prototype, "disabled");
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "name");
e([
  t({ type: String })
], i.prototype, "cip");
e([
  t({ type: String })
], i.prototype, "age");
e([
  t({ type: String })
], i.prototype, "ageLabel");
e([
  t({ type: String })
], i.prototype, "gender");
e([
  t({ type: String })
], i.prototype, "phoneMain");
e([
  t({ type: String })
], i.prototype, "phoneAlt");
e([
  t(s)
], i.prototype, "hasPhoneMainCall");
e([
  t(s)
], i.prototype, "hasPhoneMainChat");
e([
  t(s)
], i.prototype, "hasPhoneAltCall");
e([
  t(s)
], i.prototype, "hasPhoneAltChat");
e([
  t({ type: String })
], i.prototype, "mail");
e([
  t({ type: String })
], i.prototype, "mailHref");
e([
  t({ type: String })
], i.prototype, "address");
e([
  t({ type: String })
], i.prototype, "addressURL");
e([
  t({ type: String })
], i.prototype, "infoLabel");
e([
  t({ type: String })
], i.prototype, "assignedLabel");
e([
  t({ type: String })
], i.prototype, "detailsLabel");
e([
  t({ type: String })
], i.prototype, "detailsHref");
e([
  t({ type: String })
], i.prototype, "detailsTarget");
e([
  t({ type: String })
], i.prototype, "editLabel");
e([
  t({ type: String })
], i.prototype, "editHref");
e([
  t({ type: String })
], i.prototype, "editTarget");
e([
  t(s)
], i.prototype, "hideViewDetails");
e([
  t(s)
], i.prototype, "jcef");
e([
  t(s)
], i.prototype, "edit");
e([
  t({ type: Array })
], i.prototype, "assignments");
e([
  t(s)
], i.prototype, "hideCopyCip");
e([
  t({ type: String })
], i.prototype, "upLabel");
e([
  t({ type: String })
], i.prototype, "upMessage");
export {
  i as HeaderMenuPatient
};
//# sourceMappingURL=header-menu-patient.js.map
