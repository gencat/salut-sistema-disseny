import { LitElement as u, unsafeCSS as c } from "lit";
import { property as s, state as a } from "lit/decorators.js";
import { getCustomElementSuffix as f } from "../../api/custom-element-scope.js";
import m from "../../foundations/icon/icon.style.css.js";
import _ from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import w from "./sidemenu-list-item.style.css.js";
import { sidemenuListItemTemplate as g } from "./sidemenu-list-item.template.js";
var y = Object.defineProperty, b = Object.getOwnPropertyDescriptor, o = (l, t, e, r) => {
  for (var n = r > 1 ? void 0 : r ? b(t, e) : t, p = l.length - 1, h; p >= 0; p--)
    (h = l[p]) && (n = (r ? h(t, e, n) : h(n)) || n);
  return r && n && y(t, e, n), n;
};
class i extends u {
  constructor() {
    super(), this.label = "Menu", this.icon = "add_box", this.selected = !1, this.disabled = !1, this.expanded = !1, this.hasNestedMenu = !1, this.notifications = 0, this.notificationsStatus = "error", this.nestedMenuPosition = "top", this.focusEnabled = !1, this._isHover = !1, this._isActive = !1, this._showItemDropdown = !1, this._isFocused = !1, this._tooltip = null, this._dropdown = null, this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [c(_), c(m), c(w)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  set notificationsState(t) {
    this.notificationsStatus = t;
  }
  get notificationsState() {
    return this.notificationsStatus;
  }
  // @property({ type: String }) scrollContainerClass = 'dss-layout-sidebar';
  get _notificationBadge() {
    return this.shadowRoot?.querySelector("dss-notification-badge") || void 0;
  }
  _clickedOutsideItem(t, e) {
    e.composedPath().includes(t) || this._showItemDropdown && (this._showItemDropdown = !1, this.requestUpdate());
  }
  _handleDocumentClick(t) {
    this._clickedOutsideItem(this, t);
  }
  _handleClick() {
    this.disabled || (this.hasNestedMenu ? (this._showItemDropdown = !0, this._toggleTooltip(), this.requestUpdate()) : this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 })), this.dispatchEvent(
      new CustomEvent("updateItemFocus", {
        detail: !0,
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _handleMouseEnter() {
    this._notificationBadge && !this.disabled && this._notificationBadge.setAttribute("isHover", "true");
  }
  _handleMouseLeave() {
    this._notificationBadge && !this.disabled && this._notificationBadge.removeAttribute("isHover");
  }
  _handleMouseDown() {
    this._notificationBadge && !this.disabled && this._notificationBadge.setAttribute("isActive", "true");
  }
  _handleMouseUp() {
    this._notificationBadge && !this.disabled && this._notificationBadge.removeAttribute("isActive");
  }
  _handleKeyDown(t) {
    if (t.key === "ArrowDown" || t.key === "ArrowUp") {
      const e = t.target, n = `dss-action-menu-item${f()}`;
      if (e.tagName.toLowerCase() === n) return;
      t.preventDefault(), this.dispatchEvent(
        new CustomEvent("navigate", {
          detail: {
            direction: t.key === "ArrowDown" ? "next" : "previous"
          },
          bubbles: !0,
          composed: !0
        })
      );
    }
    if (t.key === "Enter" && t.target.click(), t.key === "Escape") {
      this._closeItemDropdown();
      const e = {
        detail: this,
        bubbles: !1,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("keydownEscape", e));
    }
  }
  _handleFocusout(t) {
    const e = t.relatedTarget;
    e === null && this._closeItemDropdown(), e && !this.contains(e) && this._closeItemDropdown();
  }
  _toggleTooltip() {
    this._showItemDropdown ? this._tooltip?.classList.add("force-hidden") : this._tooltip?.classList.remove("force-hidden");
  }
  _closeItemDropdown() {
    this._showItemDropdown && setTimeout(() => {
      this._showItemDropdown = !1, this._toggleTooltip(), this.requestUpdate();
    }, 0);
  }
  focusItem() {
    this._isFocused = !0, this.shadowRoot?.querySelector("li")?.focus();
  }
  blurItem() {
    this._isFocused = !1, this.shadowRoot?.querySelector("li")?.blur();
  }
  _getDropdownFixedPosition() {
    const t = this.getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-list-item__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _getTooltipFixedPosition() {
    if (this._tooltip) {
      const t = this.getBoundingClientRect();
      this._tooltip.style.top = `${t.top + t.height / 2}px`, this._tooltip.style.left = `${t.right - 4}px`;
    }
  }
  async firstUpdated() {
    await this.updateComplete;
    const t = this.shadowRoot?.querySelector(".dss-sidemenu-list-item__tooltip");
    if (t && (this._tooltip = t), this.hasNestedMenu) {
      const e = this.shadowRoot?.querySelector(".dss-sidemenu-list-item__dropdown");
      e && (this._dropdown = e);
    }
  }
  render() {
    return g(this);
  }
}
o([
  s({ type: String })
], i.prototype, "label", 2);
o([
  s({ type: String })
], i.prototype, "icon", 2);
o([
  s(d)
], i.prototype, "selected", 2);
o([
  s(d)
], i.prototype, "disabled", 2);
o([
  s(d)
], i.prototype, "expanded", 2);
o([
  s(d)
], i.prototype, "hasNestedMenu", 2);
o([
  s({ type: String })
], i.prototype, "notifications", 2);
o([
  s({ type: String })
], i.prototype, "notificationsStatus", 2);
o([
  s({ type: String })
], i.prototype, "notificationsState", 1);
o([
  s({ type: String })
], i.prototype, "nestedMenuPosition", 2);
o([
  s(d)
], i.prototype, "focusEnabled", 2);
o([
  a()
], i.prototype, "_isHover", 2);
o([
  a()
], i.prototype, "_isActive", 2);
o([
  a()
], i.prototype, "_showItemDropdown", 2);
o([
  a()
], i.prototype, "_isFocused", 2);
export {
  i as SidemenuListItem
};
//# sourceMappingURL=sidemenu-list-item.js.map
