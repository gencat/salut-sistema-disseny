import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as l, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as a } from "../../api/custom-element-scope.js";
const i = l`dss-icon${d(a())}`, u = l`dss-tooltip${d(a())}`, n = l`dss-notification-badge${d(a())}`, o = (s) => t`
  <li
    role="menuitem"
    aria-label="${s.label}"
    class=${e({
  "dss-sidemenu-list-item": !0,
  "dss-sidemenu-list-item--expanded": !!s.expanded,
  "dss-sidemenu-list-item--collapsed": !s.expanded,
  "dss-sidemenu-list-item--selected": !!s.selected,
  "dss-sidemenu-list-item--disabled": !!s.disabled
})}
    tabindex="${s.focusEnabled ? "0" : "-1"}"
    ?disabled=${s.disabled}
    @click="${s._handleClick}"
    @mouseenter="${s._handleMouseEnter}"
    @mouseleave="${s._handleMouseLeave}"
    @mousedown="${s._handleMouseDown}"
    @mouseup="${s._handleMouseUp}"
    @keydown="${s._handleKeyDown}"
    @focusout="${s._handleFocusout}"
  >
    <span class="dss-sidemenu-list-item__icon">
      <${i} icon="${s.icon}" size="md"></${i}>
      ${s.notifications > 0 && !s._showItemDropdown && !s.selected ? t`
            <${n}
              class=${e({
  "dss-sidemenu-list-item__notification": !0,
  "dss-sidemenu-list-item__notification--expanded": !0
})}
              value="${s.notifications}"
              variant="sidemenu"
              type="default"
            >
            </${n}>
          ` : null}
    </span>

    <span class=${e({
  "dss-sidemenu-list-item__label": !0,
  "dss-sidemenu-list-item__label--expanded": s.expanded
})}>
      ${s.label}
    </span>

    <${i} class=${e({
  "dss-sidemenu-list-item__nested-icon": !0,
  "dss-sidemenu-list-item__nested-icon--expanded": s.expanded && s.hasNestedMenu
})}
      icon="chevron_right" 
      size="md">
    </${i}>

    <${u} position="right" class="dss-sidemenu-list-item__tooltip" delay="800" ?hidden=${s.expanded}>
      <span>${s.label}</span>
    </${u}>

    <slot></slot>
  </li>
`;
export {
  o as sidemenuListItemTemplate
};
//# sourceMappingURL=sidemenu-list-item.template.js.map
