import { LitElement as L, unsafeCSS as h, nothing as v } from "lit";
import { property as i } from "lit/decorators.js";
import { unsafeStatic as T, literal as C, html as x } from "lit/static-html.js";
import { getCustomElementSuffix as w } from "../../api/custom-element-scope.js";
import { booleanType as a } from "../../utils/property-types.js";
import g from "../../angular/ng-checkbox/ng-checkbox.style.css.js";
import S from "../../angular/ng-radio-button/ng-radio-button.style.css.js";
import q from "../../components/badge/badge.states.css.js";
import E from "../../components/button/button.style.css.js";
import U from "../../components/chip/chip.style.css.js";
import A from "../../components/icon-button/icon-button.style.css.js";
import O from "../../foundations/icon/icon.style.css.js";
import R from "./custom-table-header.style.css.js";
import { template as z } from "./custom-table-header.template.js";
var M = Object.defineProperty, B = Object.getOwnPropertyDescriptor, l = (f, e, t, s) => {
  for (var o = s > 1 ? void 0 : s ? B(e, t) : e, n = f.length - 1, d; n >= 0; n--)
    (d = f[n]) && (o = (s ? d(e, t, o) : d(o)) || o);
  return s && o && M(e, t, o), o;
};
const F = C`dss-chip${T(w())}`;
class r extends L {
  constructor() {
    super(), this._resizeTimer = null, this.enableCombinedFilters = !1, this.tableInfo = void 0, this.showConfig = !1, this.configTableLabel = "Configurar taula", this.hideActionExpand = !1, this.showActionFilters = !1, this.jcef = !1, this.customActions = !1, this._filters = void 0, this._visibleFilters = [], this._hiddenFilters = [], this._filtersExpanded = !1, this._filtersShowMore = !1, this._tableTitle = "", this._innerFilters = !1, this._expandTable = !1, this._expandLabel = "Ampliar", this._collapseLabel = "Reduir", this._rowsOnCollapsed = 5, this._filtersLabel = "Selecció", this._cleanFiltersLabel = "Netejar filtres", this._openFiltersLabel = "Filtres", this._hidetableTitleAndExpand = !1, this._isFirstUpdated = !0, this._isSideMenuLoaded = !1, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [
      h(O),
      h(E),
      h(A),
      h(U),
      h(g),
      h(S),
      h(R),
      h(q)
    ];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), this._sideMenuResizeObserver = new ResizeObserver(() => {
      this._isSideMenuLoaded && this._handleResize(), this._isSideMenuLoaded = !0;
    }), setTimeout(() => {
      const e = document.querySelector(`dss-side-menu${w()}`);
      e && this._sideMenuResizeObserver?.observe(e);
    }, 0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), this._sideMenuResizeObserver?.disconnect();
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._filters && (!this._innerFilters || this.enableCombinedFilters) && (this._visibleFilters = this._filters, this._hiddenFilters = [], this.shadowRoot?.querySelector("#filtersWrapper")?.querySelector(".filters-list")?.classList.add("hide"), this.requestUpdate(), setTimeout(() => {
        this._splitFiltersByLine();
      }, 0)), this._innerFilters && (this.shadowRoot?.querySelector(".dss-custom-table-header")?.classList.remove("dss-custom-table-header--innerfilters-overflow"), setTimeout(() => {
        this._checkInnerFiltersOverflow();
      }, 0));
    }, 250);
  }
  set filters(e) {
    const t = this._filters;
    this._filters = e, this._visibleFilters = e, this._hiddenFilters = [], this.requestUpdate("filters", t);
  }
  get filters() {
    return this._filters ?? [];
  }
  set tableTitle(e) {
    const t = this._tableTitle;
    this._tableTitle = e, this.requestUpdate("tableTitle", t);
  }
  get tableTitle() {
    return this._tableTitle;
  }
  set hidetableTitleAndExpand(e) {
    const t = this._hidetableTitleAndExpand;
    this._hidetableTitleAndExpand = e, this.requestUpdate("hidetableTitleAndExpand", t);
  }
  get hidetableTitleAndExpand() {
    return this._hidetableTitleAndExpand;
  }
  set innerFilters(e) {
    const t = this._innerFilters;
    this._innerFilters = e, this.requestUpdate("innerFilters", t);
  }
  get innerFilters() {
    return this._innerFilters;
  }
  set expandTable(e) {
    const t = this._expandTable;
    this._expandTable = e, this.requestUpdate("expandTable", t);
  }
  get expandTable() {
    return this._expandTable;
  }
  set expandLabel(e) {
    const t = this._expandLabel;
    this._expandLabel = e, this.requestUpdate("expandLabel", t);
  }
  get expandLabel() {
    return this._expandLabel;
  }
  set collapseLabel(e) {
    const t = this._collapseLabel;
    this._collapseLabel = e, this.requestUpdate("collapseLabel", t);
  }
  get collapseLabel() {
    return this._collapseLabel;
  }
  set rowsOnCollapsed(e) {
    const t = this._rowsOnCollapsed;
    this._rowsOnCollapsed = e, this.requestUpdate("rowsOnCollapsed", t);
  }
  get rowsOnCollapsed() {
    return this._rowsOnCollapsed;
  }
  set filtersLabel(e) {
    const t = this._filtersLabel;
    this._filtersLabel = e, this.requestUpdate("filtersLabel", t);
  }
  get filtersLabel() {
    return this._filtersLabel;
  }
  set cleanFiltersLabel(e) {
    const t = this._cleanFiltersLabel;
    this._cleanFiltersLabel = e, this.requestUpdate("cleanFiltersLabel", t);
  }
  get cleanFiltersLabel() {
    return this._cleanFiltersLabel;
  }
  _generateFilterChips(e) {
    let t;
    return e && (t = e.map((s, o) => {
      if (!s) return v;
      const n = (u) => {
        const c = u.detail.text;
        typeof s == "string" ? this._filters = this._filters.filter((p) => p !== c) : this._filters = this._filters.filter((p) => p.value.trim() !== c?.trim()), this._emitChangeFilters(), this.requestUpdate();
      };
      return x`
					<${F} 
						class="filter-chip"
						data-index="${o}"
						label="${typeof s === "string" ? s : s.value}" 
						size="sm" 
						disableSelect
						hasDelete
						@delete="${n}">
					</${F}>
        `;
    })), t;
  }
  _clearFilters() {
    this._filters = [], this._visibleFilters = [], this._hiddenFilters = [], this._emitChangeFilters(), this.requestUpdate();
  }
  // Output events
  _emitExpandAction() {
    this._expandTable = !this._expandTable;
    const e = {
      detail: this._expandTable,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onExpand", e)), this.requestUpdate();
  }
  _emitOpenFilters() {
    const e = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenFilters", e)), this.requestUpdate();
  }
  _emitConfigTable() {
    const e = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onConfigTable", e)), this.requestUpdate();
  }
  _emitChangeFilters() {
    const e = {
      detail: this._filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onChangeFilters", e)), this.requestUpdate();
  }
  async _splitFiltersByLine() {
    const e = this.shadowRoot?.querySelector("#filtersWrapper"), t = this.shadowRoot?.querySelector("#filtersClean"), s = e?.querySelector(".filters-list"), o = this.shadowRoot?.querySelector(".filters-show-more"), n = o ? o.clientWidth : 72;
    if (!e || !t || !s) return;
    s.classList.remove("hide"), await this.updateComplete, await new Promise(requestAnimationFrame);
    const d = Array.from(s.querySelectorAll(".filter-chip"));
    if (d.length === 0) {
      this._visibleFilters = [], this._hiddenFilters = [], this._filtersShowMore = !1, this.requestUpdate();
      return;
    }
    let b = e.clientWidth - t.clientWidth - n - 8 - 8;
    const u = [], c = [];
    for (const p of d) {
      const y = Math.ceil(p.getBoundingClientRect().width), _ = p.dataset.index ? Number(p.dataset.index) : -1, m = _ >= 0 && this._filters?.[_] ? this._filters[_] : null;
      m && (y > b ? c.push(m) : (u.push(m), b -= y + 8));
    }
    this._visibleFilters = [...u], this._hiddenFilters = [...c], this._filtersShowMore = c.length > 0, this.requestUpdate();
  }
  _filtersToggleMore() {
    this._filtersExpanded = !this._filtersExpanded, this.requestUpdate();
  }
  _checkInnerFiltersOverflow() {
    const e = window.innerWidth, t = this.jcef ? 1419 : 1440;
    e >= t && setTimeout(() => {
      const s = this.shadowRoot?.querySelector(".dss-custom-table-header"), o = this.shadowRoot?.querySelector(".dss-custom-table-header__filters"), n = this.shadowRoot?.querySelector(".dss-custom-table-header__main-actions");
      !s || !o || !n || (o.scrollWidth + n.scrollWidth > s.clientWidth ? s.classList.add("dss-custom-table-header--innerfilters-overflow") : s.classList.remove("dss-custom-table-header--innerfilters-overflow"));
    }, 0);
  }
  filtersPopoverClose() {
    const e = this.shadowRoot?.querySelector("dss-popover");
    e && e._closePopover();
  }
  async firstUpdated() {
    await this.updateComplete, (!this._innerFilters || this.enableCombinedFilters) && this._splitFiltersByLine(), this._innerFilters && this._checkInnerFiltersOverflow(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), e.has("filters") && !this._isFirstUpdated && this._splitFiltersByLine();
  }
  render() {
    return z(this);
  }
}
l([
  i(a)
], r.prototype, "enableCombinedFilters", 2);
l([
  i({ type: String })
], r.prototype, "tableInfo", 2);
l([
  i(a)
], r.prototype, "showConfig", 2);
l([
  i({ type: String })
], r.prototype, "configTableLabel", 2);
l([
  i({ type: Array })
], r.prototype, "filters", 1);
l([
  i({ type: String })
], r.prototype, "tableTitle", 1);
l([
  i(a)
], r.prototype, "hidetableTitleAndExpand", 1);
l([
  i(a)
], r.prototype, "innerFilters", 1);
l([
  i(a)
], r.prototype, "expandTable", 1);
l([
  i({ type: String })
], r.prototype, "expandLabel", 1);
l([
  i({ type: String })
], r.prototype, "collapseLabel", 1);
l([
  i({ type: Number })
], r.prototype, "rowsOnCollapsed", 1);
l([
  i({ type: String })
], r.prototype, "filtersLabel", 1);
l([
  i({ type: String })
], r.prototype, "cleanFiltersLabel", 1);
l([
  i(a)
], r.prototype, "hideActionExpand", 2);
l([
  i(a)
], r.prototype, "showActionFilters", 2);
l([
  i(a)
], r.prototype, "jcef", 2);
l([
  i(a)
], r.prototype, "customActions", 2);
export {
  r as CustomTableHeader
};
//# sourceMappingURL=custom-table-header.js.map
