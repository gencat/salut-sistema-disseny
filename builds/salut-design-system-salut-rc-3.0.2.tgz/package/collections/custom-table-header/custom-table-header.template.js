import { nothing as l } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as _, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as b } from "../../api/custom-element-scope.js";
const i = _`dss-button${d(b())}`, v = (e) => {
  const a = e._innerFilters, r = !e._innerFilters || e.enableCombinedFilters;
  return s`
    <div
      class=${t({
    "dss-custom-table-header": !0,
    "dss-custom-table-header--hide-title": !e.tableTitle || e.tableTitle === "",
    "dss-custom-table-header--jcef": e.jcef,
    "dss-custom-table-header--inner-filters": e._innerFilters,
    "dss-custom-table-header--combined-filters": e.enableCombinedFilters,
    "dss-custom-table-header--hide-expand-divider": e.tableTitle !== "" && !e.showConfig && !e.showActionFilters && !e.tableInfo && !e.customActions,
    "dss-custom-table-header--only-inner-expand": e.tableTitle === "" && !e.showConfig && !e.showActionFilters && !e.tableInfo,
    "dss-custom-table-header--empty-filters": !e._filters && !e._innerFilters,
    "dss-custom-table-header--deleted-filters": !e._innerFilters && (!e._filters || e._filters?.length === 0)
  })}
    >
      <div class="dss-custom-table-header__main">
          
        ${e.tableTitle ? s`
            <div class="dss-custom-table-header__main-title">
              ${e.tableTitle}
            </div>
          ` : l}

        <div class=${t({
    "dss-custom-table-header__main-actions": !0,
    "dss-custom-table-header__main-actions--combined-filters": e.enableCombinedFilters,
    "dss-custom-table-header__main-actions--empty-title": !e.tableTitle || e.tableTitle === ""
  })}>
        
          <div class="dss-custom-table-header__main-actions__config">

            ${e.tableInfo ? s`
              <div class="main-actions__config-info">
                ${e.tableInfo}
              </div>
              ` : l}

            ${e.customActions ? s`
                <div class="dss-custom-table-header__main-actions__custom">
                  <slot name="header-custom-actions"></slot>
                </div>
              ` : l}

            

            ${e.showConfig ? s`
              <${i}
                variant="subtle"
                size="md"
                icon="settings"
                label="${e.configTableLabel}"
                @onClick=${e._emitConfigTable}
              ></${i}>
              ` : l}

            ${e.showActionFilters ? s`
              <div style="position: relative;">
                <${i}
                variant="secondary"
                size="md"
                icon="filter_list"
                label="${e._openFiltersLabel}"
                @onClick=${e._emitOpenFilters}
                ></${i}>
              </div>
              ` : l}

          </div>

          ${e.hideActionExpand ? l : s`
            <div class="dss-custom-table-header__main-actions__expand">
              <${i}
                variant="subtle"
                label="${e._expandTable ? e._collapseLabel : e._expandLabel}"
                icon="${e._expandTable ? "close_fullscreen" : "open_in_full"}"
                size="md"
                @click="${e._emitExpandAction}"
              ></${i}>
            </div>`}
    
        </div>
      </div>

      <div class=${t({
    "dss-custom-table-header__filters": !0,
    "dss-custom-table-header__filters--combined": e.enableCombinedFilters,
    "dss-custom-table-header__filters--inner": a,
    "dss-custom-table-header__filters--chips": r,
    "dss-custom-table-header__filters--has-content": !!e._filters && e._filters.length > 0,
    "dss-custom-table-header__filters--empty-filters": !e._filters || e._filters.length === 0,
    "dss-custom-table-header__filters--expanded": e._filtersExpanded,
    "dss-custom-table-header__filters--empty-title": !e.tableTitle || e.tableTitle === ""
  })}>
      ${a ? s` 
            <slot name="filters"></slot>
          ` : l}
      ${r ? s`
           
              <div class="filters-label">${e._filtersLabel}:</div>
        
              <div class="filters-wrapper" id="filtersWrapper">
                <div class="filters-list hide" id="filtersList">
                  ${e._generateFilterChips(e._visibleFilters)}
                  ${e._hiddenFilters.length > 0 && e._filtersShowMore && !e._filtersExpanded ? s`
                      <${i}
                        class="filters-show-more"
                        variant="info"
                        size="sm"
                        label="Més (${e._hiddenFilters.length})"
                        @onClick=${e._filtersToggleMore}
                      ></${i}>
                    ` : l}

                  ${e._filtersExpanded ? s`
                    ${e._generateFilterChips(e._hiddenFilters)}
                  ` : l}

                  ${e._filtersShowMore && e._filtersExpanded ? s`
                      <${i}
                        variant="info"
                        size="sm"
                        label="Menys"
                        @onClick=${e._filtersToggleMore}
                      ></${i}>
                    ` : l}

                  <${i}
                    id="filtersClean"
                    class="filters-clean"
                    variant="subtle"
                    size="sm"
                    icon="filter_list_off"
                    label="${e._cleanFiltersLabel}"
                    @onClick=${e._clearFilters}
                  ></${i}>
                  
                </div>
              </div>
           
          ` : l}
      </div>
    </div>
  `;
};
export {
  v as template
};
//# sourceMappingURL=custom-table-header.template.js.map
