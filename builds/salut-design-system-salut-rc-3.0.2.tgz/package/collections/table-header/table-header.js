import { LitElement as v, unsafeCSS as F } from "lit";
import { property as s, state as a } from "lit/decorators.js";
import { getCustomElementSuffix as w } from "../../api/custom-element-scope.js";
import S from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import L from "./table-header.style.css.js";
import { template as g } from "./table-header.template.js";
var E = Object.defineProperty, t = (p, e, l, o) => {
  for (var r = void 0, n = p.length - 1, h; n >= 0; n--)
    (h = p[n]) && (r = h(e, l, r) || r);
  return r && E(e, l, r), r;
};
class i extends v {
  constructor() {
    super(), this.jcef = !1, this.titleText = void 0, this.tableInfo = void 0, this.hasCustomActions = !1, this.hideConfigAction = !1, this.hideFilterAction = !1, this.hideExpandAction = !1, this.isExpanded = !1, this.configLabel = "Configurar taula", this.filterLabel = "Filtres", this.expandLabel = "Ampliar", this.collapseLabel = "Reduir", this.filtersVariant = "none", this.filters = void 0, this.selectLabel = "Selecció", this.clearLabel = "Netejar filtres", this._visibleFilters = [], this._hiddenFilters = [], this._areFiltersExpanded = !1, this._showMoreFilters = !1, this._isSideMenuLoaded = !1, this._isFirstUpdated = !0, this._resizeTimer = null, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [F(S), F(L)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), this._sideMenuResizeObserver = new ResizeObserver(() => {
      this._isSideMenuLoaded && this._handleResize(), this._isSideMenuLoaded = !0;
    }), setTimeout(() => {
      const e = document.querySelector(`dss-side-menu${w()}`);
      e && this._sideMenuResizeObserver?.observe(e);
    }, 0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), this._sideMenuResizeObserver?.disconnect();
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this.filters && (this.filtersVariant === "chips" || this.filtersVariant === "combined") && (this._visibleFilters = this.filters, this._hiddenFilters = [], this.shadowRoot?.querySelector("#filtersWrapper")?.querySelector(".filters-list")?.classList.add("hide"), this.requestUpdate(), setTimeout(() => {
        this._splitFiltersByLine();
      }, 0)), this.filtersVariant === "slot" && (this.shadowRoot?.querySelector(".dss-table-header")?.classList.remove("dss-table-header--slot-filters-overflow"), setTimeout(() => {
        this._checkSlotsFiltersOverflow();
      }, 0));
    }, 240);
  }
  _dispatchConfig() {
    const e = {
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("config", e));
  }
  _dispatchOpenFilters() {
    const e = {
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("filters-open", e));
  }
  _dispatchExpand() {
    this.isExpanded = !this.isExpanded;
    const e = {
      detail: { isExpanded: this.isExpanded },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("expand", e));
  }
  _dispatchFiltersChange() {
    const e = {
      detail: this.filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("filters-changed", e));
  }
  _toggleFilters() {
    this._areFiltersExpanded = !this._areFiltersExpanded;
  }
  _clearFilters() {
    this.filters = [], this._visibleFilters = [], this._hiddenFilters = [], this._dispatchFiltersChange();
  }
  async _splitFiltersByLine() {
    const e = this.shadowRoot?.querySelector("#filtersWrapper"), l = this.shadowRoot?.querySelector("#filtersClean"), o = e?.querySelector(".filters-list"), r = this.shadowRoot?.querySelector(".filters-show-more"), n = r ? r.clientWidth : 72;
    if (!e || !l || !o) return;
    o.classList.remove("hide"), await this.updateComplete, await new Promise(requestAnimationFrame);
    const h = Array.from(o.querySelectorAll(".filter-chip"));
    if (h.length === 0) {
      this._visibleFilters = [], this._hiddenFilters = [], this._showMoreFilters = !1, this._areFiltersExpanded = !1, this.requestUpdate();
      return;
    }
    let b = e.clientWidth - l.clientWidth - n - 8 - 8;
    const m = [], c = [];
    for (const f of h) {
      const y = Math.ceil(f.getBoundingClientRect().width), u = f.dataset.index ? Number(f.dataset.index) : -1, _ = u >= 0 && this.filters?.[u] ? this.filters[u] : null;
      _ && (y > b ? c.push(_) : (m.push(_), b -= y + 8));
    }
    this._visibleFilters = [...m], this._hiddenFilters = [...c], this._showMoreFilters = c.length > 0, this.requestUpdate();
  }
  _checkSlotsFiltersOverflow() {
    const e = window.innerWidth, l = this.jcef ? 1419 : 1440;
    e >= l && setTimeout(() => {
      const o = this.shadowRoot?.querySelector(".dss-table-header"), r = this.shadowRoot?.querySelector(".dss-table-header__filters"), n = this.shadowRoot?.querySelector(".dss-table-header__main-actions");
      !o || !r || !n || (r.scrollWidth + n.scrollWidth > o.clientWidth ? o.classList.add("dss-table-header--slot-filters-overflow") : o.classList.remove("dss-table-header--slot-filters-overflow"));
    }, 0);
  }
  _initFilters() {
    this.filters && (this._visibleFilters = this.filters, this._hiddenFilters = []);
  }
  async firstUpdated() {
    await this.updateComplete, (this.filtersVariant === "chips" || this.filtersVariant === "combined") && (this._initFilters(), this._splitFiltersByLine()), (this.filtersVariant === "slot" || this.filtersVariant === "combined") && this._checkSlotsFiltersOverflow(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), e.has("filters") && !this._isFirstUpdated && queueMicrotask(() => {
      this._initFilters(), this._splitFiltersByLine();
    });
  }
  render() {
    return g(this);
  }
}
t([
  s(d)
], i.prototype, "jcef");
t([
  s({ type: String })
], i.prototype, "titleText");
t([
  s({ type: String })
], i.prototype, "tableInfo");
t([
  s(d)
], i.prototype, "hasCustomActions");
t([
  s(d)
], i.prototype, "hideConfigAction");
t([
  s(d)
], i.prototype, "hideFilterAction");
t([
  s(d)
], i.prototype, "hideExpandAction");
t([
  s(d)
], i.prototype, "isExpanded");
t([
  s({ type: String })
], i.prototype, "configLabel");
t([
  s({ type: String })
], i.prototype, "filterLabel");
t([
  s({ type: String })
], i.prototype, "expandLabel");
t([
  s({ type: String })
], i.prototype, "collapseLabel");
t([
  s({ type: String })
], i.prototype, "filtersVariant");
t([
  s({ type: Array })
], i.prototype, "filters");
t([
  s({ type: String })
], i.prototype, "selectLabel");
t([
  s({ type: String })
], i.prototype, "clearLabel");
t([
  a()
], i.prototype, "_visibleFilters");
t([
  a()
], i.prototype, "_hiddenFilters");
t([
  a()
], i.prototype, "_areFiltersExpanded");
t([
  a()
], i.prototype, "_showMoreFilters");
t([
  a()
], i.prototype, "_isSideMenuLoaded");
t([
  a()
], i.prototype, "_isFirstUpdated");
export {
  i as TableHeader
};
//# sourceMappingURL=table-header.js.map
