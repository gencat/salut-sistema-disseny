import { nothing as s } from "lit";
import { classMap as f } from "lit/directives/class-map.js";
import { unsafeStatic as h, literal as _, html as i } from "lit/static-html.js";
import { checkTextTruncate as F } from "../../utils/helpers.js";
import { getCustomElementSuffix as b } from "../../api/custom-element-scope.js";
const l = _`dss-button${h(b())}`, v = _`dss-chip${h(b())}`, x = _`dss-tooltip${h(b())}`, L = (e) => {
  const t = e.filtersVariant === "slot" || e.filtersVariant === "combined", r = e.filtersVariant === "chips" || e.filtersVariant === "combined";
  return i`
    <div
      class=${f({
    "dss-table-header": !0,
    "dss-table-header--hide-title": !e.titleText || e.titleText === "",
    "dss-table-header--jcef": e.jcef,
    "dss-table-header--slot-filters": e.filtersVariant === "slot" || e.filtersVariant === "combined",
    "dss-table-header--combined-filters": e.filtersVariant === "combined",
    "dss-table-header--hide-expand-divider": e.titleText !== "" && e.hideConfigAction && e.hideFilterAction && !e.tableInfo && !e.hasCustomActions,
    "dss-table-header--only-slot-expand": e.titleText === "" && e.hideConfigAction && e.hideFilterAction && !e.tableInfo,
    "dss-table-header--empty-filters": !e.filters && e.filtersVariant !== "slot",
    "dss-table-header--deleted-filters": e.filtersVariant !== "slot" && (!e.filters || e.filters?.length === 0)
  })}
    >
      <div class="dss-table-header__main">
     
        ${e.titleText ? i`
            <div class="dss-table-header__main-title">
              <span class="title-text" @mouseenter=${F} >${e.titleText}
               <${x} 
                class="title-tooltip" 
                slot="tooltip" 
                aria-hidden="true"
                >${e.titleText}</${x}>
              </span>
            </div>
          ` : s}

        <div class=${f({
    "dss-table-header__main-actions": !0,
    "dss-table-header__main-actions--combined-filters": e.filtersVariant === "combined",
    "dss-table-header__main-actions--empty-title": !e.titleText || e.titleText === ""
  })}>
          <div class="dss-table-header__main-actions__config">
            ${e.tableInfo ? i`
              <div class="main-actions__config-info">
                ${e.tableInfo}
              </div>
              ` : s}

            ${e.hasCustomActions ? i`
                <div class="dss-table-header__main-actions__custom">
                  <slot name="custom-actions"></slot>
                </div>
              ` : s}

            ${e.hideConfigAction ? s : i`
                <${l}
                  variant="subtle"
                  size="md"
                  icon="settings"
                  label="${e.configLabel}"
                  @onClick=${e._dispatchConfig}
                ></${l}>
              `}

            ${e.hideFilterAction ? s : i`
                <${l}
                  variant="secondary"
                  size="md"
                  icon="filter_list"
                  label="${e.filterLabel}"
                  @onClick=${e._dispatchOpenFilters}
                ></${l}>
              `}
          </div>

          ${e.hideExpandAction ? s : i`
              <div class="dss-table-header__main-actions__expand">
                <${l}
                  variant="subtle"
                  label="${e.isExpanded ? e.collapseLabel : e.expandLabel}"
                  icon="${e.isExpanded ? "close_fullscreen" : "open_in_full"}"
                  size="md"
                  @click="${e._dispatchExpand}"
                ></${l}>
              </div>
              `}
        </div>
      </div>

      <div class=${f({
    "dss-table-header__filters": !0,
    "dss-table-header__filters--combined": e.filtersVariant === "combined",
    "dss-table-header__filters--slot": t,
    "dss-table-header__filters--chips": r,
    "dss-table-header__filters--has-content": !!e.filters && e.filters.length > 0,
    "dss-table-header__filters--empty-filters": !e.filters || e.filters.length === 0,
    "dss-table-header__filters--expanded": e._areFiltersExpanded,
    "dss-table-header__filters--empty-title": !e.titleText || e.titleText === ""
  })}>

        ${t ? i` 
            <slot name="filters"></slot>
          ` : s}

        ${r ? i`
            <div class="filters-label">${e.selectLabel}:</div>
                    
            <div class="filters-wrapper" id="filtersWrapper">
              <div class="filters-list hide" id="filtersList">
                ${c(e._visibleFilters, e)}
                ${e._hiddenFilters.length > 0 && e._showMoreFilters && !e._areFiltersExpanded ? i`
                    <${l}
                      class="filters-show-more"
                      variant="info"
                      size="sm"
                      label="Més (${e._hiddenFilters.length})"
                      @onClick=${e._toggleFilters}
                    ></${l}>
                  ` : s}

                ${e._areFiltersExpanded ? i`
                  ${c(e._hiddenFilters, e)}
                ` : s}

                ${e._showMoreFilters && e._areFiltersExpanded ? i`
                    <${l}
                      variant="info"
                      size="sm"
                      label="Menys"
                      @onClick=${e._toggleFilters}
                    ></${l}>
                  ` : s}

                <${l}
                  id="filtersClean"
                  class="filters-clean"
                  variant="subtle"
                  size="sm"
                  icon="filter_list_off"
                  label="${e.clearLabel}"
                  @onClick=${e._clearFilters}
                ></${l}>
                
              </div>
            </div>
          ` : s}

      </div>
    </div>
  `;
}, c = (e, t) => !e || e.length === 0 ? s : e.map((a, u) => {
  if (!a) return s;
  const g = (C) => {
    const $ = C.detail.text;
    typeof a == "string" ? t.filters = t.filters.filter((d) => d !== $) : t.filters = t.filters.filter(
      (d) => d.value.trim() !== $?.trim()
    ), t._dispatchFiltersChange();
  };
  return i`
      <${v} 
        class="filter-chip"
        data-index="${u}"
        label="${typeof a === "string" ? a : a.value}" 
        size="sm" 
        disableSelect
        hasDelete
        @delete="${g}">
      </${v}>
    `;
});
export {
  L as template
};
//# sourceMappingURL=table-header.template.js.map
