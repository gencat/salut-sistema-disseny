import { nothing as o } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as l, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
import { checkTextTruncate as n } from "../../utils/helpers.js";
const u = l`dss-icon-button${i(r())}`, d = l`dss-button${i(r())}`, f = l`dss-link${i(r())}`, a = l`dss-tooltip${i(r())}`, v = (s) => e`
  <div
    class=${t({
  "dss-header-menu-professional": !0,
  "dss-header-menu-professional--jcef": s.jcef
})}
  >
    <div class="dss-header-menu-professional-avatar">
      <slot name="avatar"></slot>
    </div>

    <div class="dss-header-menu-professional-details">
      <div class="dss-header-menu-professional-details__name">
        ${s.name}
      </div>
      <div class="dss-header-menu-professional-details__info">
        ${s.center ? e`
              <span
                class="dss-header-menu-professional-details__info-label dss-header-menu-professional-details__info-label--center"
                >${s.center}</span
              >
            ` : null}
      </div>
    </div>

    <${u} 
      icon="${s._toggleIcon}"
      label="${s._toggleLabel}"
      variant="primary"
      @onClick="${s._toggleDropdown}"
      ?disabled=${s.disabled}
      ariaLabel="${s._toggleLabel} menú professional"
      ariaExpanded="${s._showDropdown ? "true" : "false"}"
      hideTooltip
      >
    </${u}>
   
    <div
      class=${t({
  "dss-header-menu-professional-dropdown": !0,
  "dss-header-menu-professional-dropdown--expanded": !!s._showDropdown,
  "dss-header-menu-professional-dropdown--hide-details": !!s.hideDropdownDetails
})}
    >
      <div class="dss-header-menu-professional-dropdown__info">
        <div class="dss-header-menu-professional-dropdown__details">
          <div class="dss-header-menu-professional-dropdown__details-title">
            ${s.infoLabel}
          </div>

          <div class="dss-header-menu-professional-dropdown__details-content">
            <div class="dss-header-menu-professional-dropdown__details-subtitle">
              ${s.name}
            </div>

            ${s.center ? e`
                  <div class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${n}>
                    ${s.center}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${s.center}
                    </${a}>
                  </div>
                ` : null}
            ${s.collegiate ? e`
                  <p class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${n}>
                    ${s.collegiateLabel} ${s.collegiate}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${s.collegiate}
                    </${a}>
                  </p>
                ` : null}
          </div>

          
        </div>

        ${s.hideViewDetails ? o : e`
            <${f}
              class="dss-header-menu-professional-dropdown__view-details-button"
              variant="default"
              size="md"
              label="${s.detailsLabel}"
              fullWidth
              href='${s.detailsHref}'
              target='${s.detailsTarget}'
            >
            </${f}>
					`}

        <div class="dss-header-menu-professional__divider"></div>

        ${s.hideDropdownPreferences ? null : e`
              <div class="dss-header-menu-professional-dropdown__preferences">
                <div class="dss-header-menu-professional-dropdown__details-title">
                  ${s.preferencesLabel}
                </div>
                <div class="dss-header-menu-professional-dropdown__preferences__options">
                  <slot></slot>
                </div>
              </div>
            `}
      </div>

      <div class="dss-header-menu-professional-dropdown__actions">
        ${s.showSecondaryAction ? e`
          <${d}
            variant="secondary"
            label="${s.secondaryActionLabel}"
            status="${s.secondaryActionStatus}"
            ?disabled=${s.secondaryActionDisabled}
            fullWidth
            @onClick="${s._handleSecondaryAction}"
          ></${d}>
          ` : o}
        
        <${d}
          label="${s.primaryActionLabel}"
          status="${s.primaryActionStatus}"
          ?disabled=${s.primaryActionDisabled}
          fullWidth
          @onClick="${s._handlePrimaryAction}"
        ></${d}>
      </div>

      
    </div>
    
  </div>
`;
export {
  v as headerMenuProfessionalTemplate
};
//# sourceMappingURL=header-menu-professional.template.js.map
