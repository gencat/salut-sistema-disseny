import { LitElement as y, unsafeCSS as h } from "lit";
import { property as e } from "lit/decorators.js";
import { getCustomElementSuffix as m } from "../../api/custom-element-scope.js";
import { getPortalContainer as u } from "../../api/portal-manager/portal-manager.js";
import g from "../../foundations/icon/icon.style.css.js";
import w from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import b from "./header-menu-professional.style.css.js";
import { headerMenuProfessionalTemplate as _ } from "./header-menu-professional.template.js";
var S = Object.defineProperty, t = (c, n, i, p) => {
  for (var r = void 0, s = c.length - 1, l; s >= 0; s--)
    (l = c[s]) && (r = l(n, i, r) || r);
  return r && S(n, i, r), r;
};
class o extends y {
  constructor() {
    super(), this.disabled = !1, this.name = void 0, this.center = void 0, this.collegiate = void 0, this.infoLabel = "Les meves dades", this.collegiateLabel = "Col·legiat nº", this.preferencesLabel = "Preferences de treball", this.detailsLabel = "Veure més detalls", this.detailsHref = "#", this.detailsTarget = "_self", this.detailsIcon = "info", this.detailsIconPosition = "left", this.primaryActionLabel = "Sortir", this.primaryActionStatus = "default", this.primaryActionDisabled = !1, this.showSecondaryAction = !1, this.secondaryActionLabel = "Tancar sessió", this.secondaryActionStatus = "default", this.secondaryActionDisabled = !1, this.hideViewDetails = !1, this.hideDropdownDetails = !1, this.hideDropdownPreferences = !1, this.jcef = !1, this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Obrir", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [h(w), h(g), h(b)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Tancar" : "Obrir", this._showDropdown && setTimeout(() => {
      this._updatePreferencesDropdownPosition();
    }, 100), this.requestUpdate();
  }
  _handlePrimaryAction() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("primary-action", { bubbles: !1, composed: !1 }));
  }
  _handleSecondaryAction() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("secondary-action", { bubbles: !1, composed: !1 }));
  }
  _handleDocumentClick(n) {
    this._clickedOutside(this, n);
  }
  _clickedOutside(n, i) {
    const p = i.composedPath(), s = u().querySelector(`dss-select-options${m()}`);
    if (s && p.includes(s) || p.includes(n)) return;
    const d = i.target?.closest?.("dss-tooltip");
    d && d.classList.contains("header-menu-professional-tooltip") || this._showDropdown && this._toggleDropdown();
  }
  _updatePreferencesDropdownPosition() {
    const n = this.shadowRoot?.querySelector(".dss-header-menu-professional-dropdown"), i = this.shadowRoot?.querySelector(
      ".dss-header-menu-professional-dropdown__preferences__options"
    ), p = i?.querySelector("slot");
    if (i && p) {
      const r = p.assignedElements({ flatten: !0 });
      for (const s of r) {
        const l = i.offsetLeft, d = n.offsetTop, f = s.offsetTop - d + 44;
        s.setAttribute("dropdownOffsetX", l.toString()), s.setAttribute("dropdownOffsetY", f.toString());
      }
    }
  }
  render() {
    return _(this);
  }
}
t([
  e(a)
], o.prototype, "disabled");
t([
  e({ type: String })
], o.prototype, "name");
t([
  e({ type: String })
], o.prototype, "center");
t([
  e({ type: String })
], o.prototype, "collegiate");
t([
  e({ type: String })
], o.prototype, "infoLabel");
t([
  e({ type: String })
], o.prototype, "collegiateLabel");
t([
  e({ type: String })
], o.prototype, "preferencesLabel");
t([
  e({ type: String })
], o.prototype, "detailsLabel");
t([
  e({ type: String })
], o.prototype, "detailsHref");
t([
  e({ type: String })
], o.prototype, "detailsTarget");
t([
  e({ type: String })
], o.prototype, "detailsIcon");
t([
  e({ type: String })
], o.prototype, "detailsIconPosition");
t([
  e({ type: String })
], o.prototype, "primaryActionLabel");
t([
  e({ type: String })
], o.prototype, "primaryActionStatus");
t([
  e(a)
], o.prototype, "primaryActionDisabled");
t([
  e(a)
], o.prototype, "showSecondaryAction");
t([
  e({ type: String })
], o.prototype, "secondaryActionLabel");
t([
  e({ type: String })
], o.prototype, "secondaryActionStatus");
t([
  e(a)
], o.prototype, "secondaryActionDisabled");
t([
  e(a)
], o.prototype, "hideViewDetails");
t([
  e(a)
], o.prototype, "hideDropdownDetails");
t([
  e(a)
], o.prototype, "hideDropdownPreferences");
t([
  e(a)
], o.prototype, "jcef");
export {
  o as HeaderMenuProfessional
};
//# sourceMappingURL=header-menu-professional.js.map
