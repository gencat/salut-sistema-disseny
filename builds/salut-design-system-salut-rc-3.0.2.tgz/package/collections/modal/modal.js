import { LitElement as p, unsafeCSS as c } from "lit";
import { property as s } from "lit/decorators.js";
import u from "../../shared/scrollbar.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import m from "./modal.style.css.js";
import { modalTemplate as f } from "./modal.template.js";
var y = Object.defineProperty, _ = Object.getOwnPropertyDescriptor, o = (h, e, t, l) => {
  for (var r = l > 1 ? void 0 : l ? _(e, t) : e, d = h.length - 1, n; d >= 0; d--)
    (n = h[d]) && (r = (l ? n(e, t, r) : n(r)) || r);
  return l && r && y(e, t, r), r;
};
const g = 250;
class i extends p {
  constructor() {
    super(), this.open = !1, this.modalTitle = "", this.status = "", this.hideCloseIcon = !1, this.hasScroll = !1, this.modalStyle = void 0, this.fullHeight = !1, this.fullWidth = !1, this.flexBody = !1, this.removeBodyPadding = !1, this.jcef = !1, this._scrollHandler = null, this._scrollContainer = null, this._modalHeader = null, this._modalFooter = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this), this._scrollHandler = this._handleScroll.bind(this);
  }
  static get styles() {
    return [c(u), c(m)];
  }
  set state(e) {
    this.status = e;
  }
  get state() {
    return this.status;
  }
  get _headerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="header"]') || void 0)?.assignedElements()[0];
  }
  get _footerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="footer"]') || void 0)?.assignedElements()[0];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick), this._scrollContainer && this._scrollHandler && this._scrollContainer.removeEventListener("scroll", this._scrollHandler), this._scrollContainer = null;
  }
  updated(e) {
    e.has("open") && (this.open ? this._showDialog() : this._hideDialog());
  }
  _showDialog() {
    this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), document.addEventListener("keydown", this._handleKeydown), document.body.style.overflow = "hidden";
  }
  _hideDialog() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      this.classList.remove("hide"), this.style.visibility = "hidden", document.removeEventListener("keydown", this._handleKeydown);
    }, g), document.body.style.overflow = "";
  }
  _close() {
    this.open = !1, this._hideDialog(), this.requestUpdate();
    const e = new Event("close");
    this.dispatchEvent(e);
  }
  _isStatusValid() {
    return this.status === "danger" || this.status === "error" || this.status === "warning" || this.status === "alert";
  }
  _getStatusIcon() {
    let e = "";
    switch (this.status) {
      case "danger":
        e = "warning";
        break;
      case "error":
        e = "warning";
        break;
      case "warning":
        e = "error";
        break;
      case "alert":
        e = "error";
        break;
      default:
        e = "";
    }
    return e;
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._close();
  }
  _handleOutsideClick(e) {
    if (this.open) {
      const t = this.shadowRoot?.querySelector(".dss-dialog"), l = e.composedPath();
      t && l.includes(this) && !l.includes(t) && this._close();
    }
  }
  fixEmptyFooter() {
    this.shadowRoot?.querySelector(".dss-dialog")?.classList.contains("dss-dialog--footer-empty") && this.requestUpdate();
  }
  _handleScroll(e) {
    const t = e.target;
    t && (t.scrollTop > 0 ? this._modalHeader?.classList.add("dss-dialog-header--scrolled") : this._modalHeader?.classList.remove("dss-dialog-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? this._modalFooter?.classList.add("dss-dialog-footer--scrolled") : this._modalFooter?.classList.remove("dss-dialog-footer--scrolled"));
  }
  async firstUpdated() {
    await this.updateComplete, this._footerSlot && this.fixEmptyFooter();
    const e = this.shadowRoot?.querySelector(".dss-dialog-body");
    if (this.hasScroll && e) {
      this._scrollContainer = e, this._scrollHandler && this._scrollContainer.addEventListener("scroll", this._scrollHandler), this._modalHeader = this.shadowRoot?.querySelector(".dss-dialog-header"), this._modalFooter = this.shadowRoot?.querySelector(".dss-dialog-footer");
      const t = this._modalHeader ? this._modalHeader.clientHeight : 0, l = this._modalFooter ? this._modalFooter.clientHeight : 0, d = (this.shadowRoot?.querySelector(".dss-dialog")?.clientHeight || 0) - t - l;
      e.scrollHeight > d && this._modalFooter.classList.add("dss-dialog-footer--scrolled");
    }
  }
  render() {
    return f(this);
  }
}
o([
  s(a)
], i.prototype, "open", 2);
o([
  s({ type: String })
], i.prototype, "modalTitle", 2);
o([
  s({ type: String })
], i.prototype, "status", 2);
o([
  s({ type: String })
], i.prototype, "state", 1);
o([
  s(a)
], i.prototype, "hideCloseIcon", 2);
o([
  s(a)
], i.prototype, "hasScroll", 2);
o([
  s({ type: String })
], i.prototype, "modalStyle", 2);
o([
  s(a)
], i.prototype, "fullHeight", 2);
o([
  s(a)
], i.prototype, "fullWidth", 2);
o([
  s(a)
], i.prototype, "flexBody", 2);
o([
  s(a)
], i.prototype, "removeBodyPadding", 2);
o([
  s(a)
], i.prototype, "jcef", 2);
export {
  i as Modal
};
//# sourceMappingURL=modal.js.map
