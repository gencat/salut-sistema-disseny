import { LitElement as p, unsafeCSS as o } from "lit";
import { property as a } from "lit/decorators.js";
import l from "../../foundations/icon/icon.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import _ from "./ng-checkbox.style.css.js";
import { template as f } from "./ng-checkbox.template.js";
var b = Object.defineProperty, m = Object.getOwnPropertyDescriptor, c = (n, e, t, i) => {
  for (var s = i > 1 ? void 0 : i ? m(e, t) : e, h = n.length - 1, r; h >= 0; h--)
    (r = n[h]) && (s = (i ? r(e, t, s) : r(s)) || s);
  return i && s && b(e, t, s), s;
};
class d extends p {
  constructor() {
    super(...arguments), this.variant = "default", this.indeterminate = !1, this._checked = !1, this._isCheckedPropDefined = !1, this._isFirstUpdate = !0, this._disabled = !1, this._readonly = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this._handleChangeBound = this._handleChange.bind(this);
  }
  static get styles() {
    return [o(l), o(_)];
  }
  get _input() {
    const e = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), e?.assignedElements()[0];
  }
  get _label() {
    const e = this.shadowRoot?.querySelector('slot[name="label"]') || void 0;
    return this.requestUpdate(), e?.assignedElements()[0];
  }
  set checked(e) {
    const t = this._checked;
    this._checked = e, this._isCheckedPropDefined = !0, this._isFirstUpdate || this._dispatchChange(), this.requestUpdate("checked", t);
  }
  get checked() {
    return this._checked;
  }
  disconnectedCallback() {
    this.observer.disconnect(), this._input?.removeEventListener("change", this._handleChangeBound);
  }
  /* END Input Observer */
  _checkInputAttributes() {
    if (!this._isCheckedPropDefined) {
      const i = this._input?.getAttribute("checked");
      this._checked = i !== null;
    }
    const e = this._input?.getAttribute("disabled");
    this._disabled = e !== null;
    const t = this._input?.getAttribute("readonly");
    this._readonly = t !== null;
  }
  _handleChange() {
    this._checked = this._input?.checked, this._dispatchChange();
  }
  _dispatchChange() {
    this.dispatchEvent(
      new CustomEvent("onChange", {
        detail: this._checked,
        bubbles: !0,
        composed: !0
      })
    );
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._checked && (this._input.checked = !0), this.indeterminate && (this._input.indeterminate = !0), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this._input.addEventListener("change", this._handleChangeBound)), this._isFirstUpdate = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(e) {
    const t = e.has("indeterminate"), i = e.has("checked");
    this._input && t && (this._input.indeterminate = this.indeterminate), this._input && i && (this._input.checked = this.checked);
  }
  render() {
    return f(this);
  }
}
c([
  a({ type: String })
], d.prototype, "variant", 2);
c([
  a(u)
], d.prototype, "indeterminate", 2);
c([
  a(u)
], d.prototype, "checked", 1);
export {
  d as NgCheckbox
};
//# sourceMappingURL=ng-checkbox.js.map
