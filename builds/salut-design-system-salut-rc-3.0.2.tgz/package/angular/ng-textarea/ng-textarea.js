import { LitElement as l, unsafeCSS as _ } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as d } from "../../utils/property-types.js";
import c from "./ng-textarea.style.css.js";
import { template as p } from "./ng-textarea.template.js";
var v = Object.defineProperty, b = Object.getOwnPropertyDescriptor, r = (o, e, t, h) => {
  for (var s = h > 1 ? void 0 : h ? b(e, t) : e, n = o.length - 1, u; n >= 0; n--)
    (u = o[n]) && (s = (h ? u(e, t, s) : u(s)) || s);
  return h && s && v(e, t, s), s;
};
class a extends l {
  constructor() {
    super(...arguments), this.autoHeight = !1, this.size = "lg", this.icon = void 0, this._maxLength = 0, this._isTextareaFocused = !1, this._isGroupFocusedVisible = !1, this._showError = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && this._checkAttributes();
      this.requestUpdate();
    }, this.observer = new MutationObserver(this.callback), this._handleInputBound = this._handleInput.bind(this), this._handleFocusBound = this._handleFocus.bind(this), this._handleFocusOutBound = this._handleFocusOut.bind(this), this._handleBlurBound = this._handleBlur.bind(this), this._handelLabelClickBound = this._handelLabelClick.bind(this), this._handleKeyupBound = this._handleKeyup.bind(this);
  }
  static get styles() {
    return _(c);
  }
  set value(e) {
    e !== void 0 && this.requestUpdate();
  }
  get value() {
    return this._textarea ? this._textarea.value : "";
  }
  set showError(e) {
    const t = this._showError;
    this._showError = e, this.requestUpdate("showError", t);
  }
  get showError() {
    return this._showError;
  }
  get _label() {
    return (this.shadowRoot?.querySelector('slot[name="label"]') || void 0)?.assignedElements()[0];
  }
  get _textarea() {
    return (this.shadowRoot?.querySelector('slot[name="textarea"]') || void 0)?.assignedElements()[0];
  }
  get _description() {
    return (this.shadowRoot?.querySelector('slot[name="description"]') || void 0)?.assignedElements()[0];
  }
  disconnectedCallback() {
    this._textarea?.removeEventListener("input", this._handleInputBound), this._textarea?.removeEventListener("focus", this._handleFocusBound), this._textarea?.removeEventListener("focusout", this._handleFocusOutBound), this._textarea?.removeEventListener("blur", this._handleBlurBound), this._textarea?.removeEventListener("keyup", this._handleKeyupBound), this._label?.removeEventListener("click", this._handelLabelClickBound), this.observer.disconnect();
  }
  _checkAttributes() {
    if (this._textarea) {
      const { maxLength: e } = this._textarea;
      this._maxLength = e > 0 ? e : 0;
    }
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._checkAttributes(), this._addEventListeners(), this.autoHeight && this._updateHeight(), this.requestUpdate(), this.observer.observe(this._textarea, this.observerConfig);
    } catch (e) {
      console.error("ERROR OCURRED", e);
    }
  }
  _addEventListeners() {
    this._textarea.addEventListener("input", this._handleInputBound), this._textarea.addEventListener("focus", this._handleFocusBound), this._textarea.addEventListener("focusout", this._handleFocusOutBound), this._textarea.addEventListener("blur", this._handleBlurBound), this._label?.addEventListener("click", this._handelLabelClickBound), this._textarea.addEventListener("keyup", this._handleKeyupBound);
  }
  _updateHeight() {
    this._textarea.style.height = "auto", this._textarea.style.height = `${this._textarea.scrollHeight}px`;
  }
  _handleInput() {
    this.autoHeight && this._updateHeight(), this._showError = !this._textarea.checkValidity(), this.requestUpdate();
  }
  _handleKeyup(e) {
    (e.keyCode ? e.keyCode : e.which) === 9 && this._handleFocus();
  }
  _handleFocus() {
    this._isGroupFocusedVisible = !0, this._isTextareaFocused = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._handleBlur(), this._isGroupFocusedVisible = !1, this._isTextareaFocused = !1, this.requestUpdate();
  }
  _handleBlur() {
    this._isTextareaFocused = !1, this.requestUpdate();
  }
  _handelLabelClick() {
    this._textarea.focus(), this.requestUpdate();
  }
  _handleSlotChange() {
    this.requestUpdate();
  }
  render() {
    return p(this);
  }
}
r([
  i({ type: String })
], a.prototype, "value", 1);
r([
  i(d)
], a.prototype, "showError", 1);
r([
  i(d)
], a.prototype, "autoHeight", 2);
r([
  i({ type: String })
], a.prototype, "size", 2);
r([
  i({ type: String })
], a.prototype, "icon", 2);
export {
  a as NgTextarea
};
//# sourceMappingURL=ng-textarea.js.map
