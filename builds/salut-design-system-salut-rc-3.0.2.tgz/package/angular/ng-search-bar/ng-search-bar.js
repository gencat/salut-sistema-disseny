import { LitElement as E, unsafeCSS as T } from "lit";
import { state as O, property as l } from "lit/decorators.js";
import { classMap as b } from "lit/directives/class-map.js";
import { unsafeHTML as x } from "lit/directives/unsafe-html.js";
import { unsafeStatic as q, literal as U, html as w } from "lit/static-html.js";
import { getCustomElementSuffix as F } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as L, highlightText as k } from "../../api/marker/marker.js";
import V from "../../api/marker/marker.style.css.js";
import { normalizeText as m } from "../../utils/helpers.js";
import { booleanType as d } from "../../utils/property-types.js";
import A from "./ng-search-bar.style.css.js";
import { template as I } from "./ng-search-bar.template.js";
var z = Object.defineProperty, B = Object.getOwnPropertyDescriptor, r = (f, t, e, s) => {
  for (var a = s > 1 ? void 0 : s ? B(t, e) : t, c = f.length - 1, p; c >= 0; c--)
    (p = f[c]) && (a = (s ? p(t, e, a) : p(a)) || a);
  return s && a && z(t, e, a), a;
};
const C = U`dss-icon${q(F())}`, D = U`dss-chip${q(F())}`;
class o extends E {
  constructor() {
    super(...arguments), this._filter = "", this.innerFocus = !1, this.advancedFilter = !1, this._multiple = !1, this._icon = "search", this._placeholder = "Escriu per cercar", this._inputSize = "lg", this._invalid = !1, this._helpText = "", this._isFocused = !1, this._showClearButton = !1, this._threshold = 3, this._searchTerms = [], this._catalog = [], this._filteredCatalog = [], this._showDropdown = !1, this._isCatalogLoading = !1, this._emptyDropdownText = "Sense resultats per", this._recentSearches = !1, this._recentSearchesText = "Últimes cerques", this._dropdownStyle = "", this._searchboxStyle = "", this._showAllChips = !1, this._handleDocumentMouseDown = (t) => {
      t.target !== this && t.target !== this._input && (this._showDropdown = !1, this.requestUpdate());
    }, this._handleDocumentFocusOut = (t) => {
      const e = t.relatedTarget;
      e !== null && e !== this && e !== this._input && (this._showDropdown = !1, this.requestUpdate());
    }, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && this.requestUpdate();
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [T(V), T(A)];
  }
  get _input() {
    const t = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set multiple(t) {
    const e = this._multiple;
    this._multiple = t, this.requestUpdate("multiple", e);
  }
  get multiple() {
    return this._multiple;
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set inputSize(t) {
    const e = this._inputSize;
    t === "md" ? this._inputSize = t : this._inputSize = "lg", this.requestUpdate("inputSize", e);
  }
  get inputSize() {
    return this._inputSize;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set invalid(t) {
    const e = this._invalid;
    t ? this._invalid = t : this._invalid = this._inputValidity ? t : !0, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set threshold(t) {
    const e = this._threshold;
    this._threshold = t, this.requestUpdate("threshold", e);
  }
  get threshold() {
    return this._threshold;
  }
  set searchTerms(t) {
    const e = this._searchTerms;
    this._searchTerms = t, this.requestUpdate("searchTerms", e);
  }
  get searchTerms() {
    return this._searchTerms;
  }
  set catalog(t) {
    const e = this._catalog;
    this._catalog = t, this.requestUpdate("catalog", e);
  }
  get catalog() {
    return this._catalog;
  }
  set emptyDropdownText(t) {
    const e = this._emptyDropdownText;
    this._emptyDropdownText = t, this.requestUpdate("emptyDropdownText", e);
  }
  get emptyDropdownText() {
    return this._emptyDropdownText;
  }
  set recentSearchesText(t) {
    const e = this._recentSearchesText;
    this._recentSearchesText = t, this.requestUpdate("recentSearchesText", e);
  }
  get recentSearchesText() {
    return this._recentSearchesText;
  }
  set recentSearches(t) {
    const e = this._recentSearches;
    this._recentSearches = t, this.requestUpdate("recentSearches", e);
  }
  get recentSearches() {
    return this._recentSearches;
  }
  set isCatalogLoading(t) {
    const e = this._isCatalogLoading;
    this._isCatalogLoading = t, this.requestUpdate("isCatalogLoading", e);
  }
  get isCatalogLoading() {
    return this._isCatalogLoading;
  }
  set dropdownStyle(t) {
    const e = this._dropdownStyle;
    this._dropdownStyle = t, this.requestUpdate("dropdownStyle", e);
  }
  get dropdownStyle() {
    return this._dropdownStyle;
  }
  _getSearchStyle() {
    return `top: ${this.renderRoot.querySelectorAll(".dss-search-bar")[0].offsetHeight + 4}px; ${this._dropdownStyle}`;
  }
  get _inputValidity() {
    return this._input && this._input.value !== "" ? this._input?.checkValidity() : !0;
  }
  _handleClick() {
    this.requestUpdate();
  }
  _handleInput() {
    this._filter = this._input.value;
    let t = this._input.value;
    t.length >= this._threshold ? (this._showDropdown = !0, this._filteredCatalog = this._getFilterCatalog(t), this._multiple && t.endsWith(",") && (t = t.slice(0, -1), this._searchTerms.push(t), this._input.value = "", this._searchTerms.length && this._dispatchSearchChange()), this._searchboxStyle = this._getSearchStyle(), this.requestUpdate()) : this._hideDropdown(), this._dispatchOnInput(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._isFocused = !1, this._showClearButton = !1, this.requestUpdate();
  }
  _handleKeyDown(t) {
    t?.key === "Enter" ? (this._showDropdown = !0, !this._multiple && this._input.value !== "" && (this._searchTerms = [], this._searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1), this._searchboxStyle = this._getSearchStyle()) : t?.key === "Escape" && (this._showDropdown = !1), this.requestUpdate();
  }
  _focusInput() {
    this._input?.focus();
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus()), this._searchTerms = [], this._dispatchSearchChange(), this._hideDropdown(), this.requestUpdate();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedFilter(t) : this._applyDefaultFilter(t);
  }
  _applyDefaultFilter(t) {
    const e = m(t);
    return this._catalog.filter((s) => m(s.value).includes(e));
  }
  _applyAdvancedFilter(t) {
    if (!m(t.trim())) return this.catalog;
    const s = m(t).split(/\s+/).filter((a) => a.length >= this._threshold);
    return s.length === 0 ? this.catalog : this.catalog.filter((a) => {
      const c = m(a.value);
      return s.every((p) => c.includes(p));
    });
  }
  _generateSearchChips() {
    let t = 0;
    return this._searchTerms.map((s) => {
      const a = (y) => {
        const S = y.detail.text;
        this._searchTerms = this._searchTerms.filter((v) => v !== S), this._dispatchSearchChange(), this.requestUpdate();
      };
      t += 1;
      const c = {
        disabled: this._input?.disabled || this._input?.readOnly,
        "dss-chip--selected": !this._input?.disabled && !this._input?.readOnly,
        "dss-chip--hide": t > 5
      };
      return w`
				<${D}
 					class="${b(c)}"
					size="sm" 
					label="${s}" 
					selected 
					disableSelect
					hasdelete 
					?disabled=${this._input?.disabled}
					@delete="${a}">
				</${D}>
      `;
    });
  }
  _generateFilterCatalog() {
    let t = !0;
    return this._filteredCatalog.map((s) => {
      const a = (i) => {
        const h = i.target.getAttribute("value");
        h && (this._multiple ? this._searchTerms.includes(h) ? this._searchTerms = this._searchTerms.filter((u) => u !== h) : this._searchTerms.push(h) : (this._input.value = h, this._showDropdown = !1, this._searchTerms = [], this._searchTerms.push(h)), this.requestUpdate(), this._dispatchSearchChange());
      }, c = (i) => {
        i && i.focus();
      }, p = (i) => {
        let h = 0;
        const n = this.renderRoot.querySelectorAll(".dss-catalog-item"), u = n.length - 1;
        i === n[0] ? c(n[u]) : (n.forEach((_, g) => {
          _ === i && (h = g);
        }), c(n[h - 1]));
      }, y = (i) => {
        let h = 0;
        const n = this.renderRoot.querySelectorAll(".dss-catalog-item"), u = n.length - 1;
        i === n[u] ? c(n[0]) : (n.forEach((_, g) => {
          _ === i && (h = g);
        }), c(n[h + 1]));
      }, S = (i) => {
        const h = i.currentTarget, n = i;
        let u = !1;
        switch (n.key) {
          case "ArrowUp":
            p(h), u = !0;
            break;
          case "ArrowDown":
            y(h), u = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const _ = i.target;
            this.renderRoot.querySelector('.dss-catalog-item[tabindex="0"]')?.setAttribute("tabindex", "-1"), i.target.setAttribute("tabindex", "0"), _.click(), u = !0;
            break;
          }
        }
        u && (i.stopPropagation(), i.preventDefault());
      }, v = {
        "dss-catalog-item--selected": this._searchTerms.includes(s.value)
        // 'disabled': this._input?.disabled,
        // 'dss-chip--selected': !this._input?.disabled,
      }, $ = w`
        <div
          class="dss-catalog-item ${b(v)}"
          value="${s.value}"
          tabindex="${t ? 0 : -1}"
          @click="${a}"
          @keydown=${S}
        >
          ${s.icon ? w`
								<${C}
									class="dss-catalog-item__icon"
									icon="${s.icon}"
									size="md"
									value="${s.value}"
								></${C}>
              ` : null}
          <div class="dss-catalog-item__text" value="${s.value}">
            ${this.advancedFilter ? x(L(s.value, this._filter, this._threshold)) : x(k(s.value, this._filter))}
					</div>
        </div>
      `;
      return t = !1, $;
    });
  }
  _dispatchSearchChange() {
    const t = {
      detail: this._searchTerms,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onSearchChange", t));
  }
  _dispatchOnInput() {
    if (!this._input || this._multiple) return;
    const t = {
      detail: this._input.value,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onInput", t));
  }
  _closeDropdown() {
    document.addEventListener("mousedown", this._handleDocumentMouseDown), document.addEventListener("focusout", this._handleDocumentFocusOut);
  }
  disconnectedCallback() {
    document.removeEventListener("mousedown", this._handleDocumentMouseDown), document.removeEventListener("focusout", this._handleDocumentFocusOut), this.observer.disconnect();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this.observer.observe(this._input, this.observerConfig), this._input?.getAttribute("placeholder") || this._input?.setAttribute("placeholder", this._placeholder), this._closeDropdown(), this._searchboxStyle = this._getSearchStyle(), this.requestUpdate());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return I(this);
  }
}
r([
  O()
], o.prototype, "_filter", 2);
r([
  l(d)
], o.prototype, "innerFocus", 2);
r([
  l(d)
], o.prototype, "multiple", 1);
r([
  l({ type: String })
], o.prototype, "icon", 1);
r([
  l({ type: String })
], o.prototype, "inputSize", 1);
r([
  l({ type: String })
], o.prototype, "helpText", 1);
r([
  l(d)
], o.prototype, "invalid", 1);
r([
  l({ type: Number })
], o.prototype, "threshold", 1);
r([
  l({ type: Array })
], o.prototype, "searchTerms", 1);
r([
  l({ type: Array })
], o.prototype, "catalog", 1);
r([
  l({ type: String })
], o.prototype, "emptyDropdownText", 1);
r([
  l({ type: String })
], o.prototype, "recentSearchesText", 1);
r([
  l(d)
], o.prototype, "recentSearches", 1);
r([
  l(d)
], o.prototype, "isCatalogLoading", 1);
r([
  l({ type: String })
], o.prototype, "dropdownStyle", 1);
r([
  l(d)
], o.prototype, "advancedFilter", 2);
export {
  o as NgSearchBar
};
//# sourceMappingURL=ng-search-bar.js.map
