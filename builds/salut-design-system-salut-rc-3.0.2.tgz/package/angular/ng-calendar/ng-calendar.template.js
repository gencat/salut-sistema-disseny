import { classMap as x } from "lit/directives/class-map.js";
import { unsafeStatic as _, literal as o, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
import { MONTH as g, WEEK as D } from "./ng-calendar.js";
const b = o`dss-ng-timepicker${_(u())}`, n = o`dss-icon${_(u())}`, i = o`dss-icon-button${_(u())}`, c = o`dss-button${_(u())}`, A = (e) => d`
  <div
        class="calendar__container"
        @keydown="${e._handleCalendarKeydown}"
      >
        <div class="calendar__content">
          <div class="calendar__header">
            <div class="calendar__header-item calendar__header-selector">
              <div
                id="firstCalendarElement"
                class="calendar__header-item calendar__header-item--click calendar__header-month"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderMonthKeyDown}"
                @click="${e._toggleMonthSelector}"
                aria-label="selecciona el mes, actualment ${g[e._currMonth]}"
              >
                ${g[e._currMonth]}
                <${n} icon="expand_more" size="sm"></${n}>
              </div>
              <div
                class="calendar__header-item calendar__header-item--click calendar__header-year"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderYearKeyDown}"
                @click=${e._toggleYearSelector}
                aria-label="selecciona l'any, actualment ${e._currYear}"
              >
                ${e._currYear}
                <${n} icon="expand_more" size="sm"></${n}>
              </div>
            </div>
            <div class="calendar__header-item calendar__header-buttons">
              <${i} hideTooltip variant="primary" icon="chevron_left" label="Anterior" @click=${e._prev}
                ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
              </${i}>
              <${i} hideTooltip variant="primary" icon="chevron_right" label="Següent" @click=${e._next}
                ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
              </${i}>
            </div>
          </div>

          <div class="calendar__days-content">
            <ul class="calendar__week-names">
              ${D.map((l) => d`<li>${l}</li>`)}
            </ul>
            <div
              class="calendar__days"
              @mouseleave=${e._removeRangeOverDate}
            >
              ${e._days.map((l) => {
  const f = {
    "calendar__day-item--active": e._isToday(l),
    "calendar__day-item--weekend": e._isWeekend(l),
    "calendar__day-item--selected": e._isSelected(l),
    [`calendar__day-item--${e._getCustomType(l)}`]: !!e._getCustomType(l),
    "calendar__day-item--range": e._isBetweenRange(l) || e._isBetweenRangeOnMouseOver(l),
    "calendar__day-item--selected-range-start": e._isSelectedRangeStart(l),
    "calendar__day-item--selected-range-end": e._isSelectedRangeEnd(l) || e._isOverRangeDate(l),
    "calendar__day-item--range-enabled": e._range
  }, m = (r) => {
    const a = r.target;
    if (r.key === "ArrowUp") {
      r.preventDefault();
      const t = h(a, -7);
      t ? t.focus() : v();
    }
    if (r.key === "ArrowDown") {
      r.preventDefault();
      const t = h(a, 7);
      t ? t.focus() : y();
    }
    if (r.key === "ArrowRight") {
      r.preventDefault();
      const t = a.nextElementSibling;
      t ? t.focus() : y();
    }
    if (r.key === "ArrowLeft") {
      r.preventDefault();
      const t = k(a);
      t ? t.focus() : v();
    }
  }, v = () => {
    e._prev(), setTimeout(() => {
      const r = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), a = Array.from(r).filter((s) => !s.disabled), t = a[a.length - 1];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, y = () => {
    e._next(), setTimeout(() => {
      const r = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), t = Array.from(r).filter((s) => !s.disabled)[0];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, k = (r) => {
    let a = r?.previousElementSibling;
    for (; a; ) {
      if (!a.classList.contains("calendar__day-item") || a.classList.contains("calendar__day-item--empty")) {
        a = a.previousElementSibling;
        continue;
      }
      if (!a.disabled)
        return a;
      a = a.previousElementSibling;
    }
    return null;
  }, h = (r, a) => {
    const s = Array.from(
      r.closest(".calendar__days")?.querySelectorAll(".calendar__day-item:not(.calendar__day-item--empty)") || []
    ).filter((w) => !w.disabled), $ = s.indexOf(r) + a;
    return $ < 0 || $ >= s.length ? null : s[$];
  };
  return d`
                  <button
                    tabindex="${e._isFocusable(l) ? 0 : -1}"
                    class="calendar__day-item ${x(f)}"
                    @click=${() => e._selectDate(l)}
                    @mouseover=${() => e._selectRangeOverDate(l)}
                    @focus=${() => e._selectRangeOverDate(l)}
                    ?disabled=${e._isInactive(l)}
                    @keydown="${m}"
                  >
                    ${l || null}
                  </button>
                `;
})}
            </div>
          </div>
        </div>
        ${e._showMonthSelector ? d`
              <div class="calendar-selector calendar-selector--month">
                <div class="calendar-selector-title">Selecciona un mes</div>
                <div class="calendar-selector-options">
                  ${e._generateMonthsOptions()}
                </div>
              </div>
            ` : null}
        ${e._showYearSelector ? d`
              <div class="calendar-selector calendar-selector--year">
                <div
                  class="calendar-selector-title calendar-selector-title--years"
                >
                  <div class="calendar-selector-title__years">
                    ${e._yearsRangeStart} - ${e._yearsRangeEnd}
                  </div>
                  <div class="calendar-selector-title__actions">
                    <${i}
                      hideTooltip
                      variant="primary" 
                      label="Anys anteriors"
                      icon="chevron_left"
                      @click=${e._onYearRangeStepDown}
                    ></${i}>
                    <${i}
                      hideTooltip
                      variant="primary" 
                      label="Anys posteriors"
                      icon="chevron_right"
                      @click=${e._onYearRangeStepUp}
                    ></${i}>
                  </div>
                </div>
                <div
                  class="calendar-selector-options calendar-selector-options--4col"
                >
                  ${e._generateYearsRangeOptions()}
                </div>
              </div>
            ` : null}
        ${e._showTime ? d`
              <div class="dss-datepicker__timepicker">
                <${b}
                  .dropdown="${e._timepicker}"
                  .customTimeListOptions=${e._customTimeListOptions}
                  .minutesRange=${e._minutesRange}
                  .minHour=${e._minHour}
                  .maxHour=${e._maxHour}
                  @onTimepickerChange=${e._onSelectTime}
                  .value="${e._timepickerValue}"
                >
                  <label slot="label" for="innerTimepicker"
                    >${e._timepickerLabel}</label
                  >
                  <input
                    slot="input"
                    id="innerTimepicker"
                    type="text"
                    maxlength="5"
                    .value="${e._timepickerValue}"
                  />
                </${b}>
              </div>
            ` : null}
        ${e._showButtons || e._showTime ? d`
              <div class="calendar__content calendar__content--buttons">
                <div class="calendar__buttons">
                  <${c}
                    variant="secondary"
                    label=${e._leftLabel}
                    @click=${e._onCancel}
                  >
                  </${c}>
                  <${c}
                    variant="primary"
                    label=${e._rightLabel}

                    @click=${e._onAccept}
                    ?disabled=${e._validateSelectedDate()}
                  >
                  </${c}>
                </div>
              </div>
            ` : null}
      </div>

`;
export {
  A as template
};
//# sourceMappingURL=ng-calendar.template.js.map
