import { nothing as l } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as r, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const t = r`dss-icon${a(e())}`, d = r`dss-icon-button${a(e())}`, p = r`dss-tooltip${a(e())}`, g = (i) => {
  const _ = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": i._input?.required,
    "dss-input-wrapper--disabled": i._input?.disabled,
    [`dss-input-wrapper--${i.inputSize}`]: !!i.inputSize,
    "dss-input-wrapper--no-label": !i._labelSlot
  }, $ = {
    "dss-input-group": !0,
    [`dss-input-group--${i.inputSize}`]: !!i.inputSize,
    "dss-input-group--invalid": i._invalid || !i._inputValidity,
    "dss-input-group--required": i._input?.required,
    "dss-input-group--disabled": i._input?.disabled,
    "dss-input-group--focused": i._input?.value || i._placeholder || i._isFocused,
    "dss-input-group--read-only": i._input?.readOnly,
    "dss-input-group--no-label": !i._labelSlot,
    "dss-input-group--numeric": i._isTypeNumeric,
    "dss-input-group--no-min-width": i._removeMinWidth,
    "dss-input-group--read-only-empty": i._input?.readOnly && i._placeholder === "" && !i._input?.value
  }, n = {
    "dss-input-help": !0,
    "dss-input-help--invalid": i._invalid,
    "dss-input-help--disabled": i._input?.disabled
  };
  return s`
      <div class="${u(_)}">
    
        ${i.inputSize === "sm" ? s`
          <div class="${u({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": i._invalid
  })}"
          >
            <slot name="label" @click=${i._focusInput}></slot>
          </div>
          ` : l}
  
        <div class="${u($)}">
  
          ${i.icon && i.icon !== "" ? s`
            <${t} icon="${i.icon}" class="dss-input-icon"></${t}>
            ` : l}
  
          <div class="dss-input-field">
            ${i.inputSize !== "sm" ? s`
              <slot name="label" @click=${i._focusInput}></slot>
              ` : l}

            ${i.inputPrefix ? s`
            <span class="dss-input-inputPrefix">${i.inputPrefix}</span>
          ` : l}
          
            <slot name="input"
              @click=${i._handleClick}
              @input=${i._handleInput}
              @focusin=${i._handleFocusIn}
              @focusout=${i._handleFocusOut}
            ></slot>
          </div>

          ${i.unit ? s`
            <div class="dss-input-unit">${i.unit}</div>
            ` : l}
  
          ${i._isTypeNumeric ? s`
                <div class="dss-input-numeric-buttons">
                  <${d}
                    label="Augmentar"
                    hideTooltip
                    size="sm"
                    icon="keyboard_arrow_up"
                    variant="primary"
                    ?disabled=${i._input.disabled || i._input.readOnly}
                    disableTabindex
                    @onClick=${i._stepUp}
                    @mousedown=${() => i._onHold("up")}
                    @mouseup=${i._stopHold}
                    @mouseleave=${i._stopHold}
                  ></${d}>
                  <${d}
                    label="Disminuir"
                    hideTooltip
                    size="sm"
                    icon="keyboard_arrow_down"
                    variant="primary"
                    ?disabled=${i._input.disabled || i._input.readOnly}
                    disableTabindex
                    @onClick=${i._stepDown}
                    @mousedown=${() => i._onHold("down")}
                    @mouseup=${i._stopHold}
                    @mouseleave=${i._stopHold}
                  ></${d}>
                </div>
              ` : null}

          <div class="dss-input-actions">
            <slot name="action"></slot>
            <slot name="secondaryAction"></slot>
          </div>
  
          ${i._isTruncated ? s`
              <${p}>${i._input?.value}</${p}>
            ` : null}
        </div>
  
        ${i._helpText ? s`
              <div class="${u(n)}">
                <span>${i._helpText}</span>
                ${i._maxLength ? s`<span>
                      ${i._input?.value?.length}/${i._maxLength}
                    </span>` : null}
              </div>
            ` : null}
      </div>
    `;
};
export {
  g as inputActionTemplate
};
//# sourceMappingURL=ng-input-action.template.js.map
