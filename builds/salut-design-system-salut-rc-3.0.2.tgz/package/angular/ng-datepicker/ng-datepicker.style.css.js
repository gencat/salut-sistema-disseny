const e = ".dss-datepicker-help{font-family:var(--font-family)}.dss-datepicker-help{font-family:inherit;font-size:12px;color:var(--color-neutral-700);padding:var(--dss-spacing-xxs) var(--dss-spacing-sm)}.dss-datepicker-help--disabled{color:var(--color-neutral-500)}.dss-datepicker-help--invalid{color:var(--color-red-500)}.dss-calendar{z-index:999;width:-moz-fit-content;width:fit-content;opacity:0;visibility:hidden;transition:opacity var(--animation-delay) ease-out}.dss-calendar--visible{opacity:1;visibility:visible}.dss-datepicker-stepper-divider{height:20px;width:1px;background-color:var(--color-neutral-500)}.dss-datepicker-stepper-divider.dss-datepicker-stepper-divider--lg{height:24px}.dss-datepicker-stepper-arrows{display:flex;align-items:center;gap:var(--dss-spacing-xs)}";
export {
  e as default
};
//# sourceMappingURL=ng-datepicker.style.css.js.map
