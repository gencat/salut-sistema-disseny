import { nothing as d } from "lit";
import { classMap as a } from "lit/directives/class-map.js";
import { ifDefined as g } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as r, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const t = r`dss-ng-calendar${e(u())}`, $ = r`dss-icon${e(u())}`, l = r`dss-icon-button${e(u())}`, _ = r`dss-tooltip${e(u())}`, S = (i) => {
  const p = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": i._required,
    "dss-input-wrapper--disabled": i._disabled,
    [`dss-input-wrapper--${i.inputSize}`]: !!i.inputSize,
    "dss-input-wrapper--no-label": !i._labelSlot
  }, b = {
    "dss-input-group": !0,
    [`dss-input-group--${i.inputSize}`]: !!i.inputSize,
    "dss-input-group--invalid": i._invalid || !i._inputValidity,
    "dss-input-group--required": i._required,
    "dss-input-group--disabled": i._disabled,
    "dss-input-group--focused": i._input?.value || i._placeholder || i._isFocused,
    "dss-input-group--read-only": i._readonly,
    "dss-input-group--no-label": !i._labelSlot
  }, h = {
    "dss-input-help": !0,
    "dss-input-help--invalid": i._invalid,
    "dss-input-help--disabled": i._disabled
  }, v = {
    "dss-calendar": !0,
    "dss-calendar--visible": i._showCalendar && !i._readonly,
    "dss-calendar--disabled": i._disabled,
    "dss-calendar--md": i.inputSize !== "lg"
  };
  return s`
  
      <div class="${a(p)}">
  
        ${i.inputSize === "sm" ? s`
          <div class="${a({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": i._invalid
  })}"
          >
            <slot name="label" @click=${i._focusInput}></slot>
          </div>
          ` : d}
  
        <div 
          class="dss-input-dropdown-wrapper"
          role="combobox"
          aria-controls="datepicker-calendar"
          aria-expanded=${g(i._showCalendar)}>
          <div class="${a(b)}">
            ${i.icon && i.icon !== "" ? s`
              <${$} icon="${i.icon}" class="dss-input-icon"></${$}>
              ` : d}
            <div class="dss-input-field">
              ${i.inputSize !== "sm" ? s`
                <slot name="label" @click=${i._focusInput}></slot>
                ` : d}
              <slot name="input"
                @click=${i._handleClick}
                @input=${i._handleInput}
                @focusin=${i._handleFocus}
                @focusout=${i._handleBlur}
                @keydown=${i._handleKeyUp}
              ></slot>
              ${!i._showCalendar && i._isTruncated ? s`
                  <${_}>${i._input?.value}</${_}>
                ` : null}
            </div>
            
            ${!i.hasStepper && i._input?.value ? s`
              <${l}
                size="md"
                icon="close"
                hideTooltip
                label="Netejar data"
                @onClick=${i._clearDate}
                ?hidden=${i._readonly || i._disabled}
              ></${l}>
              ` : d}

            ${i.hasStepper && i._input?.value && i.isValidDate() ? s`
              <div class="${a({
    "dss-datepicker-stepper-divider": !0,
    [`dss-datepicker-stepper-divider--${i.inputSize}`]: !!i.inputSize
  })}"
              >
              </div>
              <div class="dss-datepicker-stepper-arrows">
                <${l}
                  size="md"
                  icon="chevron_left"
                  hideTooltip
                  label="Data anterior"
                  @onClick=${i._prevDate}
                  ?disabled=${i._isPrevDateDisabled()}
                  ?hidden=${i._readonly || i._disabled}
                ></${l}>

                <${l}
                  size="md"
                  icon="chevron_right"
                  hideTooltip
                  label="Següent data"
                  @onClick=${i._nextDate}
                  ?disabled=${i._isNextDateDisabled()}
                  ?hidden=${i._readonly || i._disabled}
                ></${l}>
              
              </div>
              ` : d}

          </div>
  
          <${t}
            role="listbox"
            aria-label="Datepicker Calendar"
            id="datepicker-calendar"
            class="${a(v)}"
            .selectedDate=${i._input?.value}
            .showTime=${i._showTime}
            .showButtons=${i._showButtons}
            .leftLabel=${i._leftLabel}
            .rightLabel=${i._rightLabel}
            .minDate=${i._minDate}
            .maxDate=${i._maxDate}
            timepickerLabel=${i._timepickerLabel}
            .timepicker=${i._timepicker}
            .customCalendar=${i.customCalendar}
            .customTimeListOptions=${i._customTimeListOptions}
            .minutesRange=${i._minutesRange}
            .minHour=${i._minHour}
            .maxHour=${i._maxHour}
            @onDateChange=${i._onDateChange}
            @onCancel=${i._onCancel}
          ></${t}>
        </div>
  
        ${i._helpText ? s`
              <div class="${a(h)}">
                <span>${i._helpText}</span>
              </div>
            ` : null}
      </div>
    `;
};
export {
  S as template
};
//# sourceMappingURL=ng-datepicker.template.js.map
