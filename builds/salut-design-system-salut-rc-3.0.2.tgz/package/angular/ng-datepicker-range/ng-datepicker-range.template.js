import { nothing as e } from "lit";
import { classMap as i } from "lit/directives/class-map.js";
import { ifDefined as b } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as t, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const n = t`dss-ng-calendar${l(u())}`, s = t`dss-icon${l(u())}`, r = t`dss-icon-button${l(u())}`, f = (a) => {
  const g = {
    "dss-datepicker-range--sm": a.inputSize !== "lg"
  }, p = {
    "dss-datepicker-range-help--invalid": a._invalid || !a._inputRangeStart?.validity.valid && a._inputRangeStart?.value !== "" || !a._inputRangeEnd?.validity.valid && a._inputRangeEnd?.value !== "",
    "dss-datepicker-range-help--disabled": a._inputRangeStart?.disabled && a._inputRangeEnd?.disabled
  }, _ = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": a._inputRangeStart?.required,
    "dss-input-wrapper--disabled": a._inputRangeStart?.disabled,
    [`dss-input-wrapper--${a.inputSize}`]: !!a.inputSize
  }, $ = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": a._inputRangeEnd?.required,
    "dss-input-wrapper--disabled": a._inputRangeEnd?.disabled,
    [`dss-input-wrapper--${a.inputSize}`]: !!a.inputSize
  }, R = {
    "dss-input-group": !0,
    [`dss-input-group--${a.inputSize}`]: !!a.inputSize,
    "dss-input-group--invalid": a._invalid || !a._inputRangeStart?.validity.valid && a._inputRangeStart?.value !== "",
    "dss-input-group--required": a._inputRangeStart?.required,
    "dss-input-group--disabled": a._inputRangeStart?.disabled,
    "dss-input-group--focused": a._inputRangeStart?.value || a._isStartFocused || a._copyInputRangeStartPlaceholder,
    "dss-input-group--read-only": a._inputRangeStart?.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, v = {
    "dss-input-group": !0,
    [`dss-input-group--${a.inputSize}`]: !!a.inputSize,
    "dss-input-group--invalid": a._invalid || !a._inputRangeEnd?.validity.valid && a._inputRangeEnd?.value !== "",
    "dss-input-group--required": a._inputRangeEnd?.required,
    "dss-input-group--disabled": a._inputRangeEnd?.disabled,
    "dss-input-group--focused": a._inputRangeEnd?.value || a._isEndFocused || a._copyInputRangeEndPlaceholder,
    "dss-input-group--read-only": a._inputRangeEnd?.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, S = {
    "dss-calendar": !0,
    "dss-calendar--visible": a._showCalendar && !a._inputRangeStart?.readOnly && !a._inputRangeEnd?.readOnly,
    "dss-calendar--disabled": a._inputRangeStart?.disabled && a._inputRangeEnd?.disabled,
    "dss-calendar--sm": a.inputSize !== "lg"
  };
  return d`
      <div class="dss-datepicker-range ${i(g)}">
        <div 
          class="dss-datepicker-range-inputs" 
          role="combobox"
          aria-controls="datepicker-range-calendar"
          aria-expanded=${b(a._showCalendar)}>

          <div class="dss-datepicker-range-inputs__start ${i(_)}">
            ${a.inputSize === "sm" ? d`
              <div class="${i({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": a._invalid
  })}"
							>
                <slot name="label-range-start"></slot>
              </div>
              ` : e}
            <div class="${i(R)}">
              ${a._iconRangeStart && a._iconRangeStart !== "" ? d`
                <${s} icon="${a._iconRangeStart}" class="dss-input-icon"></${s}>
                ` : e}
              <div class="dss-input-field">
                ${a.inputSize !== "sm" ? d`
                  <slot name="label-range-start"></slot>
                  ` : e}
                <slot name="input-range-start"
                  @click=${a._handleRangeStartClick}
                  @input=${a._handleRangeStartInput}
                  @focusin=${a._handleRangeStartFocusIn}
                  @keydown=${a._handleRangeKeydown}
                ></slot>
              </div>
							<${r}
								hideTooltip
							  label="Netejar data"
								size="md"
								icon="close"
								@onClick=${() => a._clearDate("rangeStart")}
								?hidden=${!a._inputRangeStart?.value || a._inputRangeStart.readOnly || a._inputRangeStart.disabled}
							></${r}>
            </div>
          </div>

          <div class="dss-datepicker-range-inputs__end ${i($)}">
            ${a.inputSize === "sm" ? d`
              <div class="${i({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": a._invalid
  })}"
							>
                <slot name="label-range-end"></slot>
              </div>
              ` : e}
            <div class="${i(v)}">
              ${a._iconRangeEnd && a._iconRangeEnd !== "" ? d`
                <${s} icon="${a._iconRangeEnd}" class="dss-input-icon"></${s}>
                ` : e}
              <div class="dss-input-field">
                ${a.inputSize !== "sm" ? d`
                  <slot name="label-range-end"></slot>
                  ` : e}
                <slot name="input-range-end"
                  @click=${a._handleRangeEndClick}
                  @input=${a._handleRangeEndInput}
                  @focusin=${a._handleRangeEndFocusIn}
                  @keydown=${a._handleRangeKeydown}
                ></slot>
              </div>
							<${r}
								hideTooltip
 								label="Netejar data"
								size="md"
								icon="close"
								@onClick=${() => a._clearDate("rangeEnd")}
								?hidden=${!a._inputRangeEnd?.value || a._inputRangeEnd.readOnly || a._inputRangeEnd.disabled}
							></${r}>
            </div>
          </div>
       
        </div>

        ${a._helpText ? d`
              <div class="dss-datepicker-range-help ${i(p)}">
                ${a._helpText}
              </div>
            ` : null}
       
        <${n}
          range
          .isRangeStartFocused=${a._isStartFocused}
          .isRangeEndFocused=${a._isEndFocused}
          role="listbox"
          aria-label="Datepicker Range Calendar"
          id="datepicker-range-calendar"
          class="${i(S)}"
          .selectedDate="${a._inputRangeStart?.value}"
          .rangeStartDate="${a._inputRangeStart?.value}"
          .rangeEndDate="${a._inputRangeEnd?.value}"
					.customCalendar=${a.customCalendar}
          .showButtons=${a._calendarShowButtons}
          .leftLabel=${a._calendarLeftButtonLabel}
          .rightLabel=${a._calendarRightButtonLabel}
          .minDate=${a._minDate}
          .maxDate=${a._maxDate}
          @onRangeChange=${a._onCalendarChange}
          @onCancel=${a._onCalendarCancel}
        ></${n}>
      </div>
    `;
};
export {
  f as template
};
//# sourceMappingURL=ng-datepicker-range.template.js.map
