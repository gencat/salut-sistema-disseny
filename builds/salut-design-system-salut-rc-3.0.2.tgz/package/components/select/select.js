import { LitElement as b, unsafeCSS as c } from "lit";
import { query as _, property as l, state as a } from "lit/decorators.js";
import { getPortalContainer as v } from "../../api/portal-manager/portal-manager.js";
import S from "../../shared/reset.style.css.js";
import { normalizeText as u } from "../../utils/helpers.js";
import { lazyLoading as w } from "../../utils/lazy-loading.js";
import { booleanType as r, booleanConverter as d } from "../../utils/property-types.js";
import { sort as V } from "../../utils/sorting.js";
import E from "../input/input.style.css.js";
import F from "./select.style.css.js";
import { template as C } from "./select.template.js";
var k = Object.defineProperty, s = (f, e, t, h) => {
  for (var o = void 0, n = f.length - 1, p; n >= 0; n--)
    (p = f[n]) && (o = p(e, t, o) || o);
  return o && k(e, t, o), o;
};
const m = class m extends b {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "", this.hasActions = !1, this.elements = null, this.selectedValue = null, this.placeholderOnDropdown = "Seleccionar", this.placeholderIfEmpty = "Escriu per cercar", this.type = "default", this.multiple = !1, this.tick = !0, this.autoSort = !1, this.deselectable = !1, this.boxStyle = "", this.dropdownStyle = "", this.labelSelectAll = "Seleccionar-ho tot", this.labelDeselectAll = "Deseleccionar-ho tot", this.filterThreshold = 1, this.searchThreshold = 2, this.selectAll = !1, this.showDropdown = !1, this.openWithSearch = !1, this.advancedFilter = !1, this.serverSideFilter = !1, this._defaultId = `dss-select-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._isFiltering = !1, this._inputValidity = !0, this._selectElements = 0, this._multipleSelectedCounter = 0, this._portalManager = null, this._isInitialized = !1, this._syncFromValue = !1, this._placeholder = "", this._previousValue = null, this._elements = [], this._filteredElements = [], this._copyElements = [], this._multipleSelection = [], this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || this.showDropdown && (this._closeDropdown(), this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFiltering = !1, this._isFocused = !1);
      },
      {
        root: null,
        threshold: 0
      }
    ), this._isFirstInitSelectedElements = !0, this._isOverflowChecked = !1, this._handleInputMouseOver = () => {
      this._isOverflowChecked || (this._checkInputOverflow(), this._isOverflowChecked = !0);
    }, this.internals = this.attachInternals(), this._handleClickOutside = this._handleClickOutside.bind(this);
  }
  static get styles() {
    return [c(S), c(E), c(F)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeListenerClickOutside(), this.visibleObserver.disconnect();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    setTimeout(() => {
      this.value = "", this._input.value = "", this._hiddenInput.value = "", this.selectedValue = null, this._placeholder = "", this._isFocused = !1;
    }, 0);
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "", this._input.value = e ?? "", this._hiddenInput.value = e ?? "";
  }
  updated(e) {
    e.has("value") && (this.internals.setFormValue(this.value), queueMicrotask(() => {
      this._isInitialized && this._applyValue();
      const t = this.value.split(",");
      this._multipleSelectedCounter = t.length;
    })), e.has("elements") && queueMicrotask(() => {
      (!this.showDropdown || this._isFiltering) && this._applyElements(this.elements), this._applyOpenWithSearch(this.openWithSearch);
    }), e.has("selectedValue") && queueMicrotask(() => {
      if (this._syncFromValue) {
        this._syncFromValue = !1;
        return;
      }
      this._isInitialized && this._applySelectedValue(this.selectedValue), this.selectedValue && this.selectedValue.length > 1 && (this._multipleSelectedCounter = this.selectedValue ? this.selectedValue.length : 0);
    }), e.has("placeholder") && queueMicrotask(() => {
      this._placeholder = this.placeholder;
    }), e.has("openWithSearch") && queueMicrotask(() => {
      this.openWithSearch && this._placeholder === "" && (this._placeholder = this.placeholderOnDropdown);
    });
  }
  async firstUpdated() {
    await this.updateComplete;
    try {
      this._syncFormValue(), this._enableAnimations(), this._setupSearchMode(), w(this, () => {
        this.visibleObserver.observe(this._input), this._portalManager = v(), this._initializeElements(), this._checkTruncatedIfMultipleSelection();
      });
    } catch (e) {
      console.error("Error in firstUpdated:", e);
    }
    this.requestUpdate();
  }
  render() {
    return C(this);
  }
  _syncFormValue() {
    if (this.value && !this.selectedValue) {
      const e = this.value.split(",");
      this._syncFromValue = !0, this.selectedValue = e;
    }
    this.multiple && this.selectedValue && this.selectedValue.length && !this._multipleSelection.length && (this._multipleSelection = [...this.selectedValue]);
  }
  _onChange() {
    this._emitChange();
  }
  _handleValidity() {
    const e = this._input?.checkValidity();
    this.invalid = !e, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  // METHODS FROM dss-input-dropdown
  _addListenerClickOutside() {
    document.addEventListener("mousedown", this._handleClickOutside);
  }
  _removeListenerClickOutside() {
    document.removeEventListener("mousedown", this._handleClickOutside);
  }
  _handleClickOutside(e) {
    if (this.showDropdown) {
      const t = e.composedPath(), h = `${this._getEffectiveId()}-options`, o = this._portalManager?.querySelector(`.${h}`);
      !t.includes(this) && !t.includes(o) && (this._input && (this._input.value = "", this.internals.setFormValue(this.value), this._isFiltering = !1), this._elements?.length && (this._initSelectedElements(), (!this.selectedValue || this.selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())), this._elements?.length || (this._placeholder = this.placeholder), this._hidePlaceholder(), this._closeDropdown());
    }
  }
  _enableAnimations() {
    this._combobox.classList.add("animation-enabled");
  }
  _disableAnimations() {
    this._getPortalCombobox()?.classList.remove("animation-enabled");
  }
  _initializeElements() {
    this._elements && (this._filteredElements = this._getFilteredElements(), this._initSelectedElements(), this._isInitialized = !0);
  }
  _setupSearchMode() {
    this.openWithSearch && this._input && (this._input.value = "", this.internals.setFormValue(this.value), this._input.hasAttribute("placeholder") || this._input.setAttribute("placeholder", this.placeholderOnDropdown));
  }
  _applyValue() {
    const e = typeof this.value == "string" ? this.value.split(",").map((t) => t.trim()).filter((t) => t) : [];
    this.selectedValue = [...e], this._applySelectedValue(e);
  }
  _applyOpenWithSearch(e) {
    e && (this.showDropdown = e, this._isFocused = !0);
  }
  _applyElements(e) {
    e && (this._elements = this.autoSort ? V(e, "label", "asc", "string") : e, this._input && !this._isFiltering && (this._input.value = "", this.internals.setFormValue(this.value)), this._filteredElements = this._getFilteredElements(), this._copyElements = [...this._elements], this._isInitialized && this._initSelectedElements());
  }
  _applySelectedValue(e) {
    !e || !this._elements || this.openWithSearch || (e.length > 0 && (this._isFocused = !0), this._initSelectedElements());
  }
  _getSelectedElements(e) {
    const t = e ? this._multipleSelection : this.selectedValue;
    return !t || t.length <= 0 ? [] : this._elements?.filter((h) => t.includes(h.value));
  }
  _getFilteredElements() {
    if (this.serverSideFilter) return this._elements;
    const e = this._elements?.filter(
      (t) => this.selectedValue?.includes(t.value)
      // Asumiendo que _selectedValue es un array de valores seleccionados
    ) || [];
    if (this._input?.value && this._input.value.length >= this.searchThreshold) {
      const t = u(this._input?.value);
      return this.advancedFilter ? this._applyAdvancedFilter(t, e) : this._applyDefaultFilter(t, e);
    }
    return this._elements;
  }
  _applyDefaultFilter(e, t) {
    if (e) {
      const h = this._elements?.filter(
        (o) => !this.selectedValue?.includes(o.value) && // Excluir elementos ya seleccionados del filtro
        u(o.label).includes(e)
      ) || [];
      return [...t, ...h];
    }
    return [...t];
  }
  _applyAdvancedFilter(e, t) {
    const h = u(e).split(/\s+/).filter((n) => n.length >= this.searchThreshold);
    if (h.length === 0)
      return [...t];
    const o = this._elements?.filter(
      (n) => !this.selectedValue?.includes(n.value) && // Excluir seleccionados
      h.every((p) => u(n.label).includes(p))
    ) || [];
    return [...t, ...o];
  }
  _initSelectedElements() {
    this._showSelectedValues(this.selectedValue ? this.selectedValue : []), this._isOverflowChecked = !1, this.showDropdown && this.requestUpdate();
  }
  _checkTruncatedIfMultipleSelection() {
    this.multiple && this.selectedValue && this.selectedValue.length > 1 && (this._checkInputOverflow(), this._isOverflowChecked = !0);
  }
  _showSelectedValues(e) {
    !this.multiple && Array.isArray(e) && e.length > 1 && e.splice(1);
    const t = this._elements?.filter((h) => e.includes(h.value));
    this._elements = [...this._copyElements ?? []], this._selectElements = this.openWithSearch ? 0 : t.length, t.length > 0 && (this._elements = this._reorderElements(t), this._filteredElements = [...this._elements]), this._updateInputValue(t);
  }
  _reorderElements(e) {
    const t = this._elements.filter((o) => e.includes(o)), h = this._elements.filter((o) => !e.includes(o));
    return [...t, ...h];
  }
  _updateInputValue(e) {
    !this._input || this._isFiltering || this.openWithSearch || (this.multiple ? this._input.value = e?.map((t) => t.label).join(", ") ?? "" : (this._input.value = e?.[0]?.label ?? "", this.deselectable && this._input.value === "" && (this._filteredElements = [...this._copyElements ?? []])), this.internals.setFormValue(this.value), this.requestUpdate());
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const e = window.getComputedStyle(this._input), t = `${e.fontWeight} ${e.fontSize} ${e.fontFamily}`, o = document.createElement("canvas").getContext("2d");
    if (!o) return;
    o.font = t;
    const n = Number.parseFloat(e.paddingLeft), p = Number.parseFloat(e.paddingRight), y = this._input.offsetWidth - n - p, g = o.measureText(this._input.value).width;
    this._isTruncated = g > y;
  }
  _handleClick() {
    !this.disabled && !this.readonly && (this._input && (!this.openWithSearch && !this._isFiltering && (this._input.value = "", this.internals.setFormValue(this.value)), this._showPlaceholder()), this._isFocused = !0, this.showDropdown = !0, setTimeout(() => {
      this._disableAnimations();
    }, 240), this._addListenerClickOutside());
  }
  _handleInput() {
    this._isFiltering = !0, this._dispatchFilterChange(), this._filteredElements = this._getFilteredElements(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0;
  }
  _handleFocusOut(e) {
    const t = e.relatedTarget, h = this._getPortalCombobox();
    if (t instanceof HTMLElement && t.contains(this)) return;
    const o = this.shadowRoot?.querySelector(".dss-input-dropdown__toggle"), n = this.shadowRoot?.querySelector("dss-chip");
    t !== null && t !== this._input && t !== this._combobox && t !== h && t !== o && t !== n && (this.selectedValue && this._initSelectedElements(), this._hidePlaceholder(), this._closeDropdown());
  }
  _handleBlurEsc() {
    this.readonly || this.openWithSearch || this._closeDropdown();
  }
  _handleOptionsFocusOut() {
    this.readonly || this.disabled || this.showDropdown && (this._closeDropdown(), this._input?.focus());
  }
  _handleKeyDown(e) {
    e?.key === "Enter" ? this.showDropdown ? this._keyboardFilterMatch() : this._handleClick() : e?.key === "Escape" ? (this._closeDropdown(), this._initSelectedElements(), this._hidePlaceholder(), (!this.selectedValue || this.selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : e?.key === "ArrowDown" || e?.key === "ArrowUp" ? (e.preventDefault(), e.stopPropagation(), this._getPortalCombobox().moveFocus()) : e?.key !== "Tab" && (this.showDropdown || this._handleClick()), this.requestUpdate();
  }
  _cleanInput() {
    this._isFiltering = !1, this._input.value = "", this.internals.setFormValue(this.value), this._filteredElements = this._getFilteredElements();
  }
  _keyboardFilterMatch() {
    if (!this._filteredElements?.find(
      (h) => h.label.toLowerCase() === this._input?.value.toLowerCase()
    )) return;
    const t = this._getPortalCombobox();
    t && t.selectFirstMatch();
  }
  _showPlaceholder() {
    this._input && (this.placeholder || (this._elements?.length ? this._input.setAttribute("placeholder", this.placeholderOnDropdown) : this._input.setAttribute("placeholder", this.placeholderIfEmpty)));
  }
  _hidePlaceholder() {
    this.placeholder || this._input?.removeAttribute("placeholder");
  }
  _getPortalCombobox() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-options`);
  }
  // Selector handling
  _handleSelectorChange(e) {
    const t = e.detail;
    this.multiple ? (this._multipleSelection = typeof t == "string" ? [t] : t, this._multipleSelectedCounter = this._multipleSelection.length, this._dispatchValueChange(!0)) : (this.openWithSearch || (this._isFiltering = !1, this._closeDropdown()), this.selectedValue = typeof t == "string" ? [t] : t, this._handleValidity(), this._dispatchValueChange(), this._updateInternalValue(t));
  }
  _handleBlurSelector(e, t) {
    if (e !== t.target) {
      if (this.openWithSearch) return;
      this._input?.focus(), this._handleBlurEsc(), this._showSelectedValues(this.selectedValue ? this.selectedValue : []);
    }
  }
  _updateInternalValue(e) {
    this.deselectable && !e ? (this.value = "", this._input.value = "", this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this._isTruncated = !1) : this.value = e.toString(), this._hiddenInput.dispatchEvent(new Event("change", { bubbles: !0 }));
  }
  _dispatchValueChange(e) {
    this._input && setTimeout(() => {
      const t = this._hiddenInput.value === "" && e ? this._multipleSelection.toString() : this._hiddenInput.value, h = e ? this._multipleSelection : this.selectedValue, o = this._getSelectedElements(e), n = {
        detail: { inputValue: t, selectedValue: h, selectedItems: o },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("value-changed", n));
    }, 0);
  }
  _dispatchFilterChange() {
    const t = {
      detail: this._input?.value || "",
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("filter-changed", t));
  }
  _toggleDropdown() {
    if (!this._input) return;
    const e = !!this._elements?.length;
    this.showDropdown ? (this.showDropdown = !1, e ? (this._input.value = "", this.internals.setFormValue(this.value), this._showPlaceholder(), this._input.focus()) : (this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFiltering = !1, this._isFocused = !1), this.multiple && this._multipleSelection && (this.selectedValue = [...this._multipleSelection], this._updateInternalValue(this.selectedValue)), this._applySelectedValue(this.selectedValue)) : (e && (this.selectedValue?.length || (this._filteredElements = this._getFilteredElements())), this._handleClick(), this._input.focus());
  }
  _closeDropdown() {
    this._removeListenerClickOutside(), this.showDropdown = !1, this._isFiltering = !1, this._isFocused = !1, this.multiple && this._multipleSelection ? (this.selectedValue = [...this._multipleSelection], this._updateInternalValue(this.selectedValue)) : this._applySelectedValue(this.selectedValue), setTimeout(() => {
      this._checkTruncatedIfMultipleSelection();
    }, 0), setTimeout(() => {
      this._enableAnimations();
    }, 400);
  }
};
m.formAssociated = !0;
let i = m;
s([
  _("input.dss-input")
], i.prototype, "_input");
s([
  _("input.dss-hidden-value")
], i.prototype, "_hiddenInput");
s([
  _(".combobox")
], i.prototype, "_combobox");
s([
  l({ type: String })
], i.prototype, "label");
s([
  l(r)
], i.prototype, "hideLabel");
s([
  l({ type: String })
], i.prototype, "name");
s([
  l({ type: String })
], i.prototype, "id");
s([
  l({ type: String })
], i.prototype, "placeholder");
s([
  l({ type: String })
], i.prototype, "value");
s([
  l({ converter: d, reflect: !0 })
], i.prototype, "disabled");
s([
  l({ converter: d, reflect: !0 })
], i.prototype, "readonly");
s([
  l({ converter: d, reflect: !0 })
], i.prototype, "required");
s([
  l({ converter: d, reflect: !0 })
], i.prototype, "invalid");
s([
  l({ type: Number })
], i.prototype, "step");
s([
  l({ type: Number })
], i.prototype, "min");
s([
  l({ type: Number })
], i.prototype, "max");
s([
  l({ type: Number })
], i.prototype, "minLength");
s([
  l({ type: Number })
], i.prototype, "maxLength");
s([
  l({ type: String })
], i.prototype, "pattern");
s([
  l({ type: String })
], i.prototype, "inputmode");
s([
  l({ type: String })
], i.prototype, "autocapitalize");
s([
  l({ type: String })
], i.prototype, "autocomplete");
s([
  l(r)
], i.prototype, "autocorrect");
s([
  l(r)
], i.prototype, "autofocus");
s([
  l(r)
], i.prototype, "spellcheck");
s([
  l({ type: String })
], i.prototype, "size");
s([
  l({ type: String })
], i.prototype, "icon");
s([
  l({ type: String })
], i.prototype, "helpText");
s([
  l({ type: String })
], i.prototype, "maskRegex");
s([
  l({ type: String })
], i.prototype, "maskReplace");
s([
  l({ type: String })
], i.prototype, "allowedChars");
s([
  l({ type: String })
], i.prototype, "unit");
s([
  l({ type: String })
], i.prototype, "inputPrefix");
s([
  l(r)
], i.prototype, "hasActions");
s([
  l({ type: Array })
], i.prototype, "elements");
s([
  l({ type: Array })
], i.prototype, "selectedValue");
s([
  l({ type: String })
], i.prototype, "placeholderOnDropdown");
s([
  l({ type: String })
], i.prototype, "placeholderIfEmpty");
s([
  l({ type: String })
], i.prototype, "type");
s([
  l(r)
], i.prototype, "multiple");
s([
  l(r)
], i.prototype, "tick");
s([
  l(r)
], i.prototype, "autoSort");
s([
  l(r)
], i.prototype, "deselectable");
s([
  l({ type: String })
], i.prototype, "boxStyle");
s([
  l({ type: String })
], i.prototype, "dropdownStyle");
s([
  l({ type: String })
], i.prototype, "labelSelectAll");
s([
  l({ type: String })
], i.prototype, "labelDeselectAll");
s([
  l({ type: Number })
], i.prototype, "filterThreshold");
s([
  l({ type: Number })
], i.prototype, "searchThreshold");
s([
  l(r)
], i.prototype, "selectAll");
s([
  l(r)
], i.prototype, "showDropdown");
s([
  l(r)
], i.prototype, "openWithSearch");
s([
  l(r)
], i.prototype, "advancedFilter");
s([
  l(r)
], i.prototype, "serverSideFilter");
s([
  a()
], i.prototype, "_isFocused");
s([
  a()
], i.prototype, "_isTruncated");
s([
  a()
], i.prototype, "_onHoldInterval");
s([
  a()
], i.prototype, "_isFiltering");
s([
  a()
], i.prototype, "_inputValidity");
s([
  a()
], i.prototype, "_selectElements");
s([
  a()
], i.prototype, "_multipleSelectedCounter");
export {
  i as Select
};
//# sourceMappingURL=select.js.map
