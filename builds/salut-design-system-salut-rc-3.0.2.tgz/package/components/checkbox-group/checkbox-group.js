import { LitElement as m, unsafeCSS as p } from "lit";
import { query as b, queryAssignedElements as f, property as n } from "lit/decorators.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
import v from "../../shared/reset.style.css.js";
import { booleanType as k, booleanConverter as g } from "../../utils/property-types.js";
import C from "./checkbox-group.style.css.js";
import { template as _ } from "./checkbox-group.template.js";
var y = Object.defineProperty, a = (l, e, i, h) => {
  for (var s = void 0, o = l.length - 1, r; o >= 0; o--)
    (r = l[o]) && (s = r(e, i, s) || s);
  return s && y(e, i, s), s;
};
const x = `dss-checkbox${d()}`, c = class c extends m {
  constructor() {
    super(), this.name = "checkbox-group-host", this.label = "", this.hideLabel = !1, this.value = [], this.orientation = "vertical", this.disabled = !1, this._onCheckboxChange = (e) => {
      const h = e.composedPath()[0], s = `DSS-CHECKBOX${d()}`.toUpperCase();
      if (h.tagName !== s) return;
      e.stopPropagation();
      const o = e.target, r = o.value;
      o.checked ? this.value.includes(r) || (this.value = [...this.value, r]) : this.value = this.value.filter((u) => u !== r), this._emitChange();
    }, this.internals = this.attachInternals();
  }
  static get styles() {
    return [p(v), p(C)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("change", this._onCheckboxChange);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("change", this._onCheckboxChange);
  }
  updated(e) {
    if (e.has("value")) {
      const i = new FormData();
      this.value.forEach((h) => i.append(this.name, h)), this.internals.setFormValue(i), this._updateCheckedState();
    }
    e.has("name") && this._updateNameState(), e.has("disabled") && this._updateDisabledState();
  }
  formResetCallback() {
    this.value = [];
  }
  formStateRestoreCallback(e) {
    this.value = e ? e.split(",") : [];
  }
  render() {
    return _(this);
  }
  _emitChange() {
    const e = {
      detail: { value: this.value },
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("value-changed", e)), this._hiddenInput.value = this.value.toString(), this.dispatchEvent(new Event("change", { bubbles: !0, composed: !1 }));
  }
  _updateCheckedState() {
    if (this._checkboxes)
      for (const e of this._checkboxes)
        e.checked = this.value.includes(e.value);
  }
  _updateNameState() {
    if (this._checkboxes)
      for (const e of this._checkboxes)
        e.name = `${this.name}-checkbox`;
  }
  _updateDisabledState() {
    this._checkboxes && this._checkboxes.forEach((e) => {
      e.disabled = this.disabled;
    });
  }
};
c.formAssociated = !0;
let t = c;
a([
  b("input.dss-hidden-value")
], t.prototype, "_hiddenInput");
a([
  f({ selector: x.toString() })
], t.prototype, "_checkboxes");
a([
  n({ type: String })
], t.prototype, "name");
a([
  n({ type: String })
], t.prototype, "label");
a([
  n(k)
], t.prototype, "hideLabel");
a([
  n({ type: Array })
], t.prototype, "value");
a([
  n({ type: String })
], t.prototype, "orientation");
a([
  n({ converter: g, reflect: !0 })
], t.prototype, "disabled");
export {
  t as CheckboxGroup
};
//# sourceMappingURL=checkbox-group.js.map
