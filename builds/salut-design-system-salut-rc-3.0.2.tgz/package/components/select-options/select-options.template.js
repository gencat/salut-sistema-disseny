import { classMap as c } from "lit/directives/class-map.js";
import { ifDefined as n } from "lit/directives/if-defined.js";
import { unsafeHTML as b } from "lit/directives/unsafe-html.js";
import { unsafeStatic as k, literal as h, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as A, highlightText as L } from "../../api/marker/marker.js";
const v = h`dss-icon${k(o())}`, C = h`dss-spinner${k(o())}`, T = (e) => e.elements?.map((s, u) => {
  const f = (s.label ?? "").trim().replace(/\s+/g, "-"), $ = (s.value ?? "").trim().replace(/\s+/g, "-"), l = `selector-${f}-${$}`, r = e._valueIsSelected(s.value), a = e.tick && !e.multiple, S = c({
    disabled: e.disabled,
    "dss-disabled": e.disabled,
    "dss-form-field": !0,
    "dss-form-field--simple": e.tick && !e.multiple,
    "dss-form-field--multiple": e.multiple,
    "dss-form-field--readonly": e.readonly,
    "dss-form-field--no-tick": !e.tick,
    "dss-type--default": e.type === "default",
    "dss-type--green": e.type === "green",
    "dss-ticked": a,
    "dss-selected": r && a,
    "dss-form-field--selected": r,
    "dss-first-unselected": u && u > 0 && u === e.selectedCounter,
    "dss-form-field--match": s.label?.toLowerCase() === e.filter?.toLowerCase()
  }), _ = c({
    "dss-checkbox": e.multiple,
    "dss-radio": !e.multiple,
    "dss-disabled": e.disabled,
    hidden: a
  }), g = t`
      <input
        id="${l}"
        name="${l}"
        type="checkbox"
        class="${_}"
        .value="${s.value}"
        .checked="${r}"
        @focus="${e._focusEvent}"
        @blur="${e._blurEvent}"
        ?disabled="${e.disabled || e.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `, p = t`<span
      class="dss-icon--checked"
      style="visibility: ${e.isOpen && a && r ? "visible" : "hidden"}"
    ></span>`;
  return t`
      <div
        class="${S}"
        @keydown="${(i) => {
    i.key === "Enter" || i.key === " " ? e._manuallySelect(i, s.value) : i.key === "ArrowUp" ? i.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : i.key === "ArrowDown" && i.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
  }}"
        @click="${(i) => {
    e._manuallySelect(i, s.value);
  }}"
        data-label="${s.label}"
      >
        ${g}
        <label for=${l}>
          ${e.advancedFilter ? b(A(s.label, e.filter || "", e.searchThreshold)) : b(L(s.label, e.filter || ""))}
        </label>
        ${p}
      </div>
    `;
}), D = (e) => e._elementSelectAll?.map((s) => {
  const u = c({
    disabled: e.disabled || e.readonly,
    "dss-form-field": !0,
    "dss-type--default": e.type === "default",
    "dss-type--green": e.type === "green",
    "dss-selectAll": !0,
    "dss-disabled": e.disabled || e.readonly,
    "dss-form-field--match": s.toLowerCase() === e.filter?.toLowerCase()
  }), y = c({
    "dss-checkbox": e.multiple
  }), f = t`
      <input
        id="${e._elementId}"
        name="${e._elementId}"
        type="checkbox"
        class="${y}"
        .value="${s}"
        .checked="${e._isAllSelected}"
        @focus="${e._focusEvent}"
        @blur="${e._blurEvent}"
        ?disabled="${e.disabled || e.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `;
  return t`
      <div
        class="${u}"
        @keydown="${(l) => {
    l.key === "Enter" || l.key === " " ? e._manuallySelectAll(l) : l.key === "ArrowUp" ? l.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : l.key === "ArrowDown" && l.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
  }}"
        @click="${(l) => {
    e._manuallySelectAll(l);
  }}"
        data-label="${s}"
      >
        ${f}
        <label for="${e._elementId}">${s}</label>
      </div>
    `;
}), U = (e) => {
  let d = T(e);
  const s = D(e);
  return e.multiple && e.selectAll && (d?.unshift(s[0]), d = d?.length === 1 ? [] : d), t`
    ${e.elements && e.elements.length > 0 ? t`
        <div
          aria-label="${n(e.ariaLabel)}"
          part="selector"
          class="dss-select-options list dss-selector-list-wrapper ${e.boxShadow ? "dss-selector-list-wrapper--box-shadow" : ""}"
			  	@keydown=${e._handleKeyDown}
			  	@focusout=${e._handleFocusOut}
          style="${e._style}"
        >
          ${d}
        </div>
      ` : t`
        <div
          part="selector"
          class="dss-select-options list dss-selector-list-wrapper"
			  @keydown=${e._handleKeyDown}
			  @focusout=${e._handleFocusOut}
          style="${e._style}"
        >
          ${e.filter && e.filter.length >= e.filterThreshold ? t`
                <div class="dss-selector-empty">
                  <${v} icon="info" size="sm"></${v}>
                  <span class="text">
                    ${e.filter || e.filter === "" ? t` ${e.emptySelectorLabel}: ${e.filter} ` : t`${e.emptyFilterLabel}`}
                  </span>
                </div>
              ` : t`
                <div class="dss-selector-empty">
                  <${C} size="md"/>
                </div>
              `}
        </div>
      `}
		<button
			class="dss-select-options__sentinel"
			type="button"
			aria-hidden="true"
			@focus=${e._focusSentinel}
		>
			Focus Sentinel
		</button>
  `;
};
export {
  U as template
};
//# sourceMappingURL=select-options.template.js.map
