import { LitElement as y, unsafeCSS as f } from "lit";
import { query as m, property as r, state as p } from "lit/decorators.js";
import { unsafeStatic as g, literal as v } from "lit/static-html.js";
import { getCustomElementSuffix as S } from "../../api/custom-element-scope.js";
import w from "../../api/marker/marker.style.css.js";
import { getPortalContainer as C } from "../../api/portal-manager/portal-manager.js";
import { normalizeText as h } from "../../utils/helpers.js";
import { lazyLoading as b } from "../../utils/lazy-loading.js";
import { booleanType as l, booleanConverter as u } from "../../utils/property-types.js";
import F from "./searchbar.style.css.js";
import { template as D } from "./searchbar.template.js";
var T = Object.defineProperty, i = (_, t, s, a) => {
  for (var o = void 0, n = _.length - 1, c; n >= 0; n--)
    (c = _[n]) && (o = c(t, s, o) || o);
  return o && T(t, s, o), o;
};
const I = v`dss-chip${g(S())}`, d = class d extends y {
  constructor() {
    super(), this.value = "", this.multiple = !1, this.icon = "search", this.size = "lg", this.helpText = void 0, this.innerFocus = !1, this.threshold = 3, this.maxTermChips = 5, this.searchTerms = [], this.searchItems = [], this.emptyDropdownText = "Sense resultats per", this.catalogLabel = "Resultats de la cerca", this.catalog = [], this.recentSearchesLabel = "Últimes cerques", this.recentSearches = [], this.isCatalogLoading = !1, this.catalogStyle = "", this.advancedFilter = !1, this.placeholder = "Escriu per cercar", this._filter = "", this._isFocused = !1, this._showClearButton = !1, this._filteredCatalog = [], this._filteredRecentSearches = [], this._showAllChips = !1, this._showDropdown = !1, this.serverSideFilter = !1, this.id = "", this.name = "", this.label = "Cercador", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this._defaultId = `dss-searchbar-input-${crypto.randomUUID()}`, this.tooltipFixed = !1, this.forceViewport = !1, this._isTruncated = !1, this._isCatalogLoaded = !1, this._handleDocumentMouseDown = null, this._portalManager = null, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showDropdown && (this._closeDropdown(), this._isFocused = !1);
      },
      {
        root: null,
        threshold: 0
      }
    ), this._lastValue = null, this.internals = this.attachInternals(), this._handleClickOutside = this._handleClickOutside.bind(this);
  }
  static get styles() {
    return [f(w), f(F)];
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  _getPortalCombobox() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-catalog`);
  }
  updated(t) {
    t.has("value") && queueMicrotask(() => {
      this.internals.setFormValue(this.value), this.requestUpdate();
    }), (t.has("catalog") || t.has("recentSearches")) && queueMicrotask(() => {
      if (!this._isCatalogLoaded) {
        this._isCatalogLoaded = !0;
        return;
      }
      if (this._filter.length >= this.threshold) {
        this._filteredCatalog = this.serverSideFilter ? this.catalog : this._getFilterCatalog(this._filter), this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(this._filter);
        return;
      }
      if (this._filter.length === 0 && this.recentSearches.length > 0) {
        this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches;
        return;
      }
    });
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeDropdownListeners(), this.visibleObserver.disconnect();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  get _inputValidity() {
    return this._input && this._input.value !== "" ? this._input?.checkValidity() : !0;
  }
  _handleInput() {
    this.multiple || this._handleValidity(), this.value = this._input.value, this._filter = this._input.value;
    const t = this._input.value;
    if (t.length === 0) {
      this.recentSearches.length > 0 ? (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches) : this._hideDropdown(), this._emitInput();
      return;
    }
    if (t.length >= this.threshold)
      if (this._showDropdown = !0, this._filteredCatalog = this.serverSideFilter ? this.catalog : this._getFilterCatalog(t), this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(t), this.multiple) {
        if (t.endsWith(",")) {
          const s = t.slice(0, -1);
          this.searchTerms.push(s), this._input.value = "", this.searchTerms.length && this._dispatchSearchChange();
        }
      } else
        this.searchTerms = [t];
    else this.recentSearches.length > 0 ? (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(t)) : this._hideDropdown();
    this._emitInput();
  }
  _handleClickOutside(t) {
    const s = t.composedPath(), a = `${this._getEffectiveId()}-catalog`, o = this._portalManager?.querySelector(`.${a}`);
    !s.includes(this) && !s.includes(o) && (this._showDropdown && this._closeDropdown(), this._isFocused = !1, this._showClearButton = !1);
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0, this._input.value.length === 0 && this.recentSearches.length > 0 && (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches);
  }
  _handleFocusOut(t) {
    const s = t.relatedTarget, a = this._getPortalCombobox();
    s instanceof HTMLElement && s.contains(this) || s !== null && s !== this._input && s !== this._combobox && s !== a && s !== I && (this._isFocused = !1, this._showClearButton = !1, this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value), this._hideDropdown());
  }
  _handleCatalogFocusOut() {
    this.readonly || this.disabled || this._showDropdown && (this._closeDropdown(), this._input?.focus());
  }
  _handleKeyDown(t) {
    t?.key === "Enter" ? (this._showDropdown = !0, !this.multiple && this._input.value !== "" && (this.searchTerms = [], this.searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1)) : t?.key === "Escape" ? this._showDropdown = !1 : (t?.key === "ArrowDown" || t?.key === "ArrowUp") && (t.preventDefault(), t.stopPropagation(), this._getPortalCombobox().moveFocus(), this._isFocused = !1);
  }
  _focusInput() {
    this._input?.focus();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    this.invalid = !t, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus(), this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value)), this.searchTerms = [], this.searchItems = [], this._dispatchSearchChange(), this.recentSearches.length === 0 && this._hideDropdown();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [], this._filteredRecentSearches = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedCatalogFilter(t) : this._applyDefaultCatalogFilter(t);
  }
  _applyDefaultCatalogFilter(t) {
    const s = h(t);
    return this.catalog.filter((a) => h(a.value).includes(s));
  }
  _applyAdvancedCatalogFilter(t) {
    if (!h(t.trim())) return this.catalog;
    const a = h(t).split(/\s+/).filter((o) => o.length >= this.threshold);
    return a.length === 0 ? this.catalog : this.catalog.filter((o) => {
      const n = h(o.value);
      return a.every((c) => n.includes(c));
    });
  }
  _getFilterSearches(t) {
    return this.advancedFilter ? this._applyAdvancedSearchesFilter(t) : this._applyDefaultSearchesFilter(t);
  }
  _applyDefaultSearchesFilter(t) {
    const s = h(t);
    return this.recentSearches.filter((a) => h(a.value).includes(s));
  }
  _applyAdvancedSearchesFilter(t) {
    if (!h(t.trim())) return this.recentSearches;
    const a = h(t).split(/\s+/).filter((o) => o.length >= this.threshold);
    return a.length === 0 ? this.recentSearches : this.recentSearches.filter((o) => {
      const n = h(o.value);
      return a.every((c) => n.includes(c));
    });
  }
  _handleMultipleTermDelete(t) {
    this.disabled || this.readonly || (this.searchTerms = this.searchTerms.filter((s) => s !== t), this.searchItems = this.searchItems.filter((s, a) => this.searchTerms[a] !== t), this._dispatchSearchChange());
  }
  _dispatchSearchChange(t) {
    let s = {};
    t && t.data ? s = {
      values: this.searchTerms,
      selectedItems: this.searchItems
    } : s = this.searchTerms;
    const a = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("search", a)), this.multiple ? this.value = this.searchTerms.toString() : this.value = this.searchTerms[0] || "", this._emitChange();
  }
  _emitInput() {
    !this._input || this.multiple || (this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 })), this._handleChange());
  }
  _handleChange() {
    !this._input || this.multiple || this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _closeDropdown() {
    this._addDropdownListeners(), this._hideDropdown();
  }
  _addDropdownListeners() {
    this._removeDropdownListeners(), document.addEventListener("mousedown", this._handleClickOutside);
  }
  _removeDropdownListeners() {
    this._handleDocumentMouseDown && (document.removeEventListener("mousedown", this._handleClickOutside), this._handleDocumentMouseDown = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && this._closeDropdown(), b(this, () => {
        this.visibleObserver.observe(this._input), this._portalManager = C();
      });
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _handleMouseOver() {
    this._input?.value !== this._lastValue && (this._checkInputOverflow(), this._lastValue = this._input?.value || null);
  }
  _handleCatalogItemSelected(t) {
    const s = t.detail.item;
    !s || s.disabled || (this.multiple ? this.searchTerms.includes(s.value) ? (this.searchTerms = this.searchTerms.filter((o) => o !== s.value), s.data && (this.searchItems = this.searchItems.filter((o) => o !== s.data))) : (this.searchTerms.push(s.value), s.data && this.searchItems.push(s.data)) : (this._input.value = s.value, this._showDropdown = !1, this._isFocused = !1, this.searchTerms = [], this.searchTerms.push(s.value), s.data && (this.searchItems = [], this.searchItems.push(s.data))), this._input.value = this.multiple ? "" : s.value, this._filter = this._input.value, this._dispatchSearchChange());
  }
  _checkInputOverflow() {
    if (this.multiple) {
      this._isTruncated = !1;
      return;
    }
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), s = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, o = document.createElement("canvas").getContext("2d");
    if (!o) return;
    o.font = s;
    const n = o.measureText(this._input.value).width;
    this._isTruncated = n > this._input.offsetWidth, this._isTruncated && (this.shadowRoot?.querySelector(".dss-input-tooltip")).updateTooltip();
  }
  render() {
    return D(this);
  }
};
d.formAssociated = !0;
let e = d;
i([
  m("input.dss-input")
], e.prototype, "_input");
i([
  m(".combobox")
], e.prototype, "_combobox");
i([
  r({ type: String })
], e.prototype, "value");
i([
  r(l)
], e.prototype, "multiple");
i([
  r({ type: String })
], e.prototype, "icon");
i([
  r({ type: String })
], e.prototype, "size");
i([
  r({ type: String })
], e.prototype, "helpText");
i([
  r(l)
], e.prototype, "innerFocus");
i([
  r({ type: Number })
], e.prototype, "threshold");
i([
  r({ type: Number })
], e.prototype, "maxTermChips");
i([
  r({ type: Array })
], e.prototype, "searchTerms");
i([
  r({ type: Array })
], e.prototype, "searchItems");
i([
  r({ type: String })
], e.prototype, "emptyDropdownText");
i([
  r({ type: String })
], e.prototype, "catalogLabel");
i([
  r({ type: Array })
], e.prototype, "catalog");
i([
  r({ type: String })
], e.prototype, "recentSearchesLabel");
i([
  r({ type: Array })
], e.prototype, "recentSearches");
i([
  r(l)
], e.prototype, "isCatalogLoading");
i([
  r({ type: String })
], e.prototype, "catalogStyle");
i([
  r(l)
], e.prototype, "advancedFilter");
i([
  r({ type: String })
], e.prototype, "placeholder");
i([
  p()
], e.prototype, "_filter");
i([
  p()
], e.prototype, "_isFocused");
i([
  p()
], e.prototype, "_showClearButton");
i([
  p()
], e.prototype, "_filteredCatalog");
i([
  p()
], e.prototype, "_filteredRecentSearches");
i([
  p()
], e.prototype, "_showAllChips");
i([
  p()
], e.prototype, "_showDropdown");
i([
  r(l)
], e.prototype, "serverSideFilter");
i([
  r({ type: String })
], e.prototype, "id");
i([
  r({ type: String })
], e.prototype, "name");
i([
  r({ type: String })
], e.prototype, "label");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "disabled");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "readonly");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "required");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "invalid");
i([
  r({ type: String })
], e.prototype, "pattern");
i([
  r({ type: String })
], e.prototype, "inputmode");
i([
  r({ type: String })
], e.prototype, "autocapitalize");
i([
  r({ type: String })
], e.prototype, "autocomplete");
i([
  r(l)
], e.prototype, "autocorrect");
i([
  r(l)
], e.prototype, "autofocus");
i([
  r(l)
], e.prototype, "spellcheck");
i([
  r(l)
], e.prototype, "tooltipFixed");
i([
  r(l)
], e.prototype, "forceViewport");
i([
  p()
], e.prototype, "_isTruncated");
export {
  e as SearchBar
};
//# sourceMappingURL=searchbar.js.map
