import { LitElement as A, unsafeCSS as g } from "lit";
import { property as S, state as E, query as C } from "lit/decorators.js";
import { classMap as H } from "lit/directives/class-map.js";
import { unsafeStatic as q, literal as R, html as x } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import { getPortalContainer as I } from "../../api/portal-manager/portal-manager.js";
import P from "../../shared/reset.style.css.js";
import { scheduleShow as F, executeShow as L, hideFloating as U, updateFloatingCombobox as V, updateFloatingPosition as D } from "../../utils/floating-combobox.js";
import { booleanType as j } from "../../utils/property-types.js";
import W from "./timepicker-options.style.css.js";
import { template as Q } from "./timepicker-options.template.js";
var K = Object.defineProperty, d = (v, t, i, s) => {
  for (var e = void 0, l = v.length - 1, f; l >= 0; l--)
    (f = v[l]) && (e = f(t, i, e) || e);
  return e && K(t, i, e), e;
};
const O = R`dss-icon${q($())}`;
class m extends A {
  constructor() {
    super(...arguments), this._manualValueSyncQueued = !1, this.open = !0, this.value = null, this.variant = "list", this.timeListOptions = [], this.customTimeListOptions = [], this.timeManualHourOptions = [], this.timeManualMinutesOptions = [], this.manualHourSelector = "", this.manualMinuteSelector = "", this._isFirstUpdated = !0, this.delay = 0, this._initialParent = null, this._portalManager = null, this._toggle = () => {
      this.open ? this.show() : this.hide();
    };
  }
  static get styles() {
    return [g(P), g(W)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = I(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    if (t.has("open") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    }), t.has("value") && (this.variant === "manual" ? this._scheduleManualValueSync() : setTimeout(() => {
      this._timeListOptionsScrollTo(this.value || void 0);
    }, 240)), t.has("manualHourSelector")) {
      if (!this.open) return;
      setTimeout(() => {
        this._hourManualScrollTo(this.manualHourSelector);
      }, 240);
    }
    if (t.has("manualMinuteSelector")) {
      if (!this.open) return;
      setTimeout(() => {
        this._minutesManualScrollTo(this.manualMinuteSelector);
      }, 240);
    }
  }
  show() {
    F({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    }), this.value && (this.variant === "manual" ? setTimeout(() => {
      this._hourManualScrollTo(this.manualHourSelector), this._minutesManualScrollTo(this.manualMinuteSelector);
    }, 240) : this._timeListOptionsScrollTo(this.value));
  }
  _executeShow() {
    L({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCombobox()
    });
  }
  hide() {
    U({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCombobox() {
    V({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    this._parent && await D(this._parent, this, {
      matchWidth: this.variant === "list"
    });
  }
  _generateTimeListOptionsHTML(t, i) {
    let s = !0;
    const e = i && i.length > 0;
    return (e ? i : t).map((o) => {
      const h = (u) => {
        u && u.focus();
      }, c = (u) => {
        let r = 0;
        const n = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), a = n.length - 1;
        u === n[0] ? h(n[a]) : (n.forEach((p, b) => {
          p === u && (r = b);
        }), h(n[r - 1]));
      }, _ = (u) => {
        let r = 0;
        const n = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), a = n.length - 1;
        u === n[a] ? h(n[0]) : (n.forEach((p, b) => {
          p === u && (r = b);
        }), h(n[r + 1]));
      }, w = (u) => {
        const r = u.target.getAttribute("value");
        r && this._emitValueChange(r);
      }, k = (u) => {
        const r = u.currentTarget, n = u;
        let a = !1;
        switch (n.key) {
          case "ArrowUp":
            c(r), a = !0;
            break;
          case "ArrowDown":
            _(r), a = !0;
            break;
          case "Escape":
            this._emitCancel();
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const p = u.target.querySelector("input"), b = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
            b?.setAttribute("tabindex", "-1"), b?.closest(".dss-timepicker-dropdown__option")?.classList.remove("dss-timepicker-dropdown__option--selected"), u.target.setAttribute("tabindex", "0"), p?.click(), a = !0;
            break;
          }
        }
        a && (u.stopPropagation(), u.preventDefault());
      }, y = {
        "option--busy": typeof o == "object" && o.state === "ocupat",
        "option--selected": typeof o == "object" && o.state === "ocupat"
      }, M = x`
				<div class="dss-timepicker-dropdown__option ${H(y)}">
					<label
						class="dss-timepicker-dropdown__label"
						tabindex="${s ? 0 : -1}"
						@keydown=${k}
					>
						${e && typeof o == "object" ? o.value : o}

						<input
							class="dss-timepicker-dropdown__input-radio"
							name="timeList"
							type="radio"
							@click="${w}"
							.value="${e && typeof o == "object" ? o.value : o}"
						/>
						<${O} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${O}>
					</label>
				</div>
			`;
      return s = !1, M;
    });
  }
  _generateTimeManualOptionsHTML(t, i) {
    let s = !0;
    return i.map((l) => {
      const f = (c) => {
        const _ = c.target.getAttribute("value");
        _ && (t === "timepickerManualHour" ? this.manualHourSelector = _ : t === "timepickerManualMinutes" && (this.manualMinuteSelector = _));
      }, o = (c) => {
        const _ = c.currentTarget, w = c;
        let k = !1;
        const y = (r) => {
          r && r.focus();
        }, M = (r) => {
          let n = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), p = a.length - 1;
          r === a[0] ? y(a[p]) : (a.forEach((b, T) => {
            b === r && (n = T);
          }), y(a[n - 1]));
        }, u = (r) => {
          let n = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), p = a.length - 1;
          r === a[p] ? y(a[0]) : (a.forEach((b, T) => {
            b === r && (n = T);
          }), y(a[n + 1]));
        };
        switch (w.key) {
          case "ArrowUp":
            M(_), k = !0;
            break;
          case "ArrowDown":
            u(_), k = !0;
            break;
          case "Escape":
            this._emitCancel();
            break;
          case "Enter": {
            const n = c.target.parentElement?.querySelector("input");
            if (this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            )?.setAttribute("tabindex", "-1"), c.target.setAttribute("tabindex", "0"), n?.click(), t === "timepickerManualHour") {
              const p = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              y(p);
            } else if (t === "timepickerManualMinutes") {
              const p = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                p.focus();
              }, 0);
            }
            k = !0;
            break;
          }
        }
        k && (c.stopPropagation(), c.preventDefault());
      }, h = x`
				<div class="dss-timepicker-manual-item">
					<input
						id="${t + l}"
						class="dss-timepicker-manual-item__input-radio"
						name="${t}"
						type="radio"
						@click="${f}"
						.value="${l}"
					/>
					<label
						for="${t + l}"
						class="dss-timepicker-manual-item__label ${t}"
						tabindex="${s ? 0 : -1}"
						@keydown=${o}
					>
						${l}
					</label>
				</div>
			`;
      return s = !1, h;
    });
  }
  _handleManualCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((i) => {
      i.checked = !1;
    }), this.manualHourSelector = "", this.manualMinuteSelector = "", this._emitCancel();
  }
  _handleManualAccept() {
    const t = `${this.manualHourSelector}:${this.manualMinuteSelector}`;
    this._emitValueChange(t);
  }
  _checkDisableTimeManualSelector() {
    return this.manualHourSelector === "" || this.manualMinuteSelector === "";
  }
  _timeListOptionsScrollTo(t) {
    if (!t) return;
    const i = t.trim(), s = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
    let e = !1;
    s.forEach((l) => {
      const f = l.value;
      if (!e && f.startsWith(i)) {
        const o = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
        o?.setAttribute("tabindex", "-1"), o?.closest(".dss-timepicker-dropdown__option")?.classList.remove("dss-timepicker-dropdown__option--selected");
        const c = l.closest("label");
        if (c?.setAttribute("tabindex", "0"), e = !0, c) {
          setTimeout(() => {
            c.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0);
          const _ = l.closest(".dss-timepicker-dropdown__option");
          f === i ? (l.checked = !0, _?.classList.add("dss-timepicker-dropdown__option--selected")) : _?.classList.remove("dss-timepicker-dropdown__option--selected");
        }
      }
    });
  }
  _timeManualOptionsScrollTo() {
    if (!this.value) return;
    const t = this.value.trim();
    t.length <= 2 ? this._hourManualScrollTo(t) : this._minutesManualScrollTo(t);
  }
  _updateManualValues() {
    if (!this.value) return;
    const { hour: t, minute: i } = this._parsePartialTime(this.value), s = !!t && t !== this.manualHourSelector, e = !!i && i !== this.manualMinuteSelector;
    !s && !e || (s && (this.manualHourSelector = t), e && (this.manualMinuteSelector = i));
  }
  _scheduleManualValueSync() {
    this._manualValueSyncQueued || (this._manualValueSyncQueued = !0, queueMicrotask(() => {
      this._manualValueSyncQueued = !1, this._updateManualValues();
    }));
  }
  _parsePartialTime(t) {
    if (!t) return {};
    const i = t.trim();
    if (i.length < 2) return {};
    const s = i.slice(0, 2);
    if (!/^\d{2}$/.test(s)) return {};
    if (i.length >= 5) {
      const e = i.slice(3, 5);
      return /^\d{2}$/.test(e) ? { hour: s, minute: e } : { hour: s };
    }
    return { hour: s };
  }
  _hourManualScrollTo(t) {
    if (!t) return;
    let i = !1;
    this.renderRoot.querySelectorAll(
      ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
    ).forEach((e) => {
      const l = e.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
      if (!i && l.startsWith(t)) {
        i = !0, this.renderRoot.querySelector(
          '.dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label[tabindex="0"]'
        )?.setAttribute("tabindex", "-1"), e?.setAttribute("tabindex", "0");
        const o = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--hour");
        if (o) {
          const h = e.offsetTop - o.clientHeight / 2;
          setTimeout(() => {
            o.scrollTo({
              top: h,
              behavior: "smooth"
            });
          }, 0);
        }
        l === t && e.click();
      }
    });
  }
  _minutesManualScrollTo(t) {
    if (!t) return;
    const i = this.renderRoot.querySelectorAll(
      ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
    );
    let s = !1;
    i.forEach((e) => {
      const l = e.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
      if (!s && l.startsWith(t)) {
        s = !0, this.renderRoot.querySelector(
          '.dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label[tabindex="0"]'
        )?.setAttribute("tabindex", "-1"), e?.setAttribute("tabindex", "0");
        const o = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--minute");
        if (o) {
          const h = e.offsetTop - o.clientHeight / 2;
          setTimeout(() => {
            o.scrollTo({
              top: h,
              behavior: "smooth"
            });
          }, 0);
        }
        l === t && e.click();
      }
    });
  }
  _emitValueChange(t) {
    this.dispatchEvent(
      new CustomEvent("option-changed", {
        detail: { value: t },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _emitCancel() {
    this.dispatchEvent(
      new CustomEvent("option-cancelled", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  _focusFirstElement() {
    this.variant === "manual" ? this._focusManualHourItem() : this._focusListItem();
  }
  _focusListItem() {
    const t = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]'), i = this.renderRoot.querySelector(".dss-timepicker-dropdown__label");
    (t || i)?.focus();
  }
  _focusManualHourItem() {
    this.renderRoot.querySelector('.dss-timepicker-manual-item__label[tabindex="0"]').focus();
  }
  _focusSentinel() {
    this.dispatchEvent(
      new CustomEvent("option-focusout", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    return Q(this);
  }
}
d([
  S(j)
], m.prototype, "open");
d([
  S({ type: String })
], m.prototype, "value");
d([
  S({ type: String })
], m.prototype, "variant");
d([
  S({ type: Array })
], m.prototype, "timeListOptions");
d([
  S({ type: Array })
], m.prototype, "customTimeListOptions");
d([
  S({ type: Array })
], m.prototype, "timeManualHourOptions");
d([
  S({ type: Array })
], m.prototype, "timeManualMinutesOptions");
d([
  S({ type: String })
], m.prototype, "manualHourSelector");
d([
  S({ type: String })
], m.prototype, "manualMinuteSelector");
d([
  E()
], m.prototype, "_isFirstUpdated");
d([
  C(".dss-timepicker-dropdown")
], m.prototype, "_floatingCombobox");
d([
  S({ type: Number })
], m.prototype, "delay");
export {
  m as TimepickerOptions
};
//# sourceMappingURL=timepicker-options.js.map
