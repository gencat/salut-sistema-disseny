import { classMap as $ } from "lit/directives/class-map.js";
import { ifDefined as r } from "lit/directives/if-defined.js";
import { unsafeStatic as t, literal as d, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const l = d`dss-icon${t(u())}`, a = d`dss-tooltip${t(u())}`, f = (s) => i`
  <button
    type=${s.type}
    class=${$({
  "dss-button": !0,
  "dss-button--full-width": !!s.fullWidth,
  [`dss-button--${s.variant}`]: !!s.variant,
  [`dss-button--${s.variant}-${s.status}`]: !!s.variant && s.status !== "default",
  [`dss-button--${s.size}`]: !!s.size,
  "dss-button--icon-left": !!s.icon && !s.onlyIcon && s.iconPosition === "left",
  "dss-button--icon-right": !!s.icon && !s.onlyIcon && s.iconPosition === "right",
  "dss-button--only-icon": !!s.onlyIcon,
  "dss-button--loading": !!s.loading
})}
    aria-label="${s.label}"
		aria-busy="${r(s.loading ? "true" : void 0)}"
    ?disabled=${s.disabled}
    ?hidden=${s.hidden}
    @click=${s._handleClick}
	  @mouseenter=${s.checkTextTruncate}
  >
    ${s.icon ? i`
          <${l}
						class="dss-icon"
            size=${s._getIconSize()}
            icon=${s.icon}
            ></${l}>
        ` : null}
    ${s.onlyIcon ? null : i`
					<span class="dss-button-text">
						${s.label}
					</span>
        `}

		${s.loading ? i`
          <${l}
						class="dss-button-loading-icon"
            size=${s._getIconSize()}
            icon=${s.loadingIcon}
						spin
						aria-hidden="true"
            ></${l}>
        ` : null}
		
		<${a} class="dss-button__tooltip" ?hidden=${!s._isTextTruncated} aria-hidden="true">
			${s.label}
		</${a}>
  </button>
`;
export {
  f as template
};
//# sourceMappingURL=button.template.js.map
