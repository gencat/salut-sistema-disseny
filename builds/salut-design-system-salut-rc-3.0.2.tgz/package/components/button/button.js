import { LitElement as u, unsafeCSS as y } from "lit";
import { property as i, state as c } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import m from "./button.style.css.js";
import { template as g } from "./button.template.js";
var b = Object.defineProperty, e = (d, s, r, p) => {
  for (var o = void 0, l = d.length - 1, h; l >= 0; l--)
    (h = d[l]) && (o = h(s, r, o) || o);
  return o && b(s, r, o), o;
};
const a = class a extends u {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.status = "default", this.label = "", this.icon = void 0, this.iconPosition = "left", this.disabled = !1, this.hidden = !1, this.onlyIcon = !1, this.fullWidth = !1, this.size = "md", this.loading = !1, this.loadingIcon = "progress_activity", this._isTextTruncated = !1;
  }
  static get styles() {
    return [y(f), y(m)];
  }
  _handleClick() {
    if (this.disabled || this.loading) return;
    const s = this.closest("form");
    this.type === "submit" && s ? s.requestSubmit() : this.type === "reset" && s && s.reset(), this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  checkTextTruncate(s) {
    if (!s) return;
    if (this.onlyIcon) {
      this._isTextTruncated = !0;
      return;
    }
    const r = s.target;
    let p = !1;
    if (this.onlyIcon)
      p = !0;
    else {
      const o = r.querySelector(".dss-button-text");
      p = o.scrollWidth > o.offsetWidth;
    }
    r.setAttribute("data-truncated", p.toString());
  }
  render() {
    return g(this);
  }
};
a.shadowRootOptions = {
  ...u.shadowRootOptions,
  delegatesFocus: !0
};
let t = a;
e([
  i({ type: String })
], t.prototype, "type");
e([
  i({ type: String })
], t.prototype, "variant");
e([
  i({ type: String })
], t.prototype, "status");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "iconPosition");
e([
  i(n)
], t.prototype, "disabled");
e([
  i(n)
], t.prototype, "hidden");
e([
  i(n)
], t.prototype, "onlyIcon");
e([
  i(n)
], t.prototype, "fullWidth");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i(n)
], t.prototype, "loading");
e([
  c()
], t.prototype, "_isTextTruncated");
export {
  t as Button
};
//# sourceMappingURL=button.js.map
