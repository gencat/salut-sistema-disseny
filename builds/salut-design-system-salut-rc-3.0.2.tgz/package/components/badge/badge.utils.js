const n = [
  { key: "danger", icon: "warning", hasFill: !0 },
  { key: "moderate", icon: "emergency_home", hasFill: !0 },
  { key: "slight", icon: "error", hasFill: !0 },
  { key: "correct", icon: "check_circle", hasFill: !0 },
  { key: "undeterminated", icon: "circle", hasFill: !1 },
  { key: "undetermined", icon: "circle", hasFill: !1 },
  { key: "critic", icon: "cancel", hasFill: !1 },
  { key: "alert", icon: "report", hasFill: !1 },
  { key: "ideal", icon: "check_circle", hasFill: !1 },
  { key: "info", icon: "info", hasFill: !1 },
  { key: "neutral", icon: "circle", hasFill: !1 },
  { key: "above", icon: "arrow_upward", hasFill: !0 },
  { key: "below", icon: "arrow_downward", hasFill: !0 }
], c = (e, l) => {
  if (e) return e;
  const i = n.find((a) => l.includes(a.key));
  return i ? i.icon : "warning";
}, r = (e) => e.includes("-low") ? !1 : !!n.find((i) => e.includes(i.key))?.hasFill, t = (e) => ["ideal", "critical", "critic", "alert", "info", "info-alt", "neutral"].includes(e);
export {
  c as getBadgeIcon,
  r as getBadgeIconFill,
  t as isInformativeStatus
};
//# sourceMappingURL=badge.utils.js.map
