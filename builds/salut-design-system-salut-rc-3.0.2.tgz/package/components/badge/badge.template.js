import { nothing as r } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as l, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const i = l`dss-icon${t(e())}`, d = l`dss-tooltip${t(e())}`, o = (s) => {
  const $ = {
    "dss-badge": !0,
    [`dss-badge--${s.size}`]: !!s.size,
    [`dss-badge--${s.status}`]: !!s.status && !s.outlined,
    [`dss-badge--${s.status}-outlined`]: !!s.status && s.outlined && s._isInformativeStatus(),
    "dss-badge--disabled": s.disabled,
    "dss-badge--dot": s.dot
  };
  return a`
		<div class="${u($)}">
			${s.hideIcon && s._isInformativeStatus() ? r : a`
					<${i} 
						class="dss-badge-button__icon" 
						icon="${s._icon}" 
						size="${s._iconSize}" 
						?fill="${s._iconFill}">
					</${i}>
				`}
			<span class="dss-badge__text">${s.label}</span>
			${s._isLabelTruncated ? a`<${d}>${s.label}</${d}>` : a`<slot name="tooltip"></slot>`}
		</div>	
  `;
};
export {
  o as template
};
//# sourceMappingURL=badge.template.js.map
