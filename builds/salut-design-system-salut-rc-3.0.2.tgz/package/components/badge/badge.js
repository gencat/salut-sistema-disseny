import { LitElement as u, unsafeCSS as h } from "lit";
import { property as o, state as c } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import f from "./badge.states.css.js";
import y from "./badge.style.css.js";
import { template as _ } from "./badge.template.js";
import { getBadgeIcon as g, getBadgeIconFill as T, isInformativeStatus as b } from "./badge.utils.js";
var S = Object.defineProperty, w = Object.getOwnPropertyDescriptor, e = (p, t, l, r) => {
  for (var s = r > 1 ? void 0 : r ? w(t, l) : t, n = p.length - 1, d; n >= 0; n--)
    (d = p[n]) && (s = (r ? d(t, l, s) : d(s)) || s);
  return r && s && S(t, l, s), s;
};
class i extends u {
  constructor() {
    super(...arguments), this.icon = void 0, this.size = "sm", this.label = "", this.status = "", this.disabled = !1, this.outlined = !1, this.dot = !1, this.hideIcon = !1, this.width = void 0, this._isFirstUpdated = !0, this._tooltipUpdateTimeout = null, this._isLabelTruncated = !1;
  }
  static get styles() {
    return [h(m), h(y), h(f)];
  }
  get _tooltip() {
    return (this.shadowRoot?.querySelector('slot[name="tooltip"]') || void 0)?.assignedElements()[0];
  }
  set text(t) {
    this.label = t;
  }
  get text() {
    return this.label;
  }
  set state(t) {
    this.status = t;
  }
  get state() {
    return this.status;
  }
  get _iconSize() {
    return this.size === "xl" ? "md" : "sm";
  }
  get _icon() {
    return g(this.icon, this.status);
  }
  get _iconFill() {
    return T(this.status);
  }
  async firstUpdated() {
    if (await this.updateComplete, this.width) {
      const t = this.shadowRoot?.querySelector(".dss-badge");
      t && (t.style.width = this.width);
    }
    this._tooltip && (this._tooltipUpdateTimeout = window.setTimeout(() => {
      const t = this._tooltip;
      t?.updateTooltip && t.updateTooltip(), this._tooltipUpdateTimeout = null;
    }, 200)), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._tooltipUpdateTimeout !== null && (window.clearTimeout(this._tooltipUpdateTimeout), this._tooltipUpdateTimeout = null);
  }
  willUpdate(t) {
    !this._isFirstUpdated && (t.has("text") || t.has("label")) && this._checkTextTruncated();
  }
  _checkTextTruncated() {
    const t = this.shadowRoot?.querySelector(".dss-badge__text");
    t && (this._isLabelTruncated = t.scrollWidth > t.offsetWidth);
  }
  _isInformativeStatus() {
    return b(this.status);
  }
  render() {
    return _(this);
  }
}
e([
  o({ type: String })
], i.prototype, "icon", 2);
e([
  o({ type: String })
], i.prototype, "size", 2);
e([
  o({ type: String })
], i.prototype, "label", 2);
e([
  o({ type: String })
], i.prototype, "status", 2);
e([
  o(a)
], i.prototype, "disabled", 2);
e([
  o(a)
], i.prototype, "outlined", 2);
e([
  o(a)
], i.prototype, "dot", 2);
e([
  o(a)
], i.prototype, "hideIcon", 2);
e([
  o({ type: String })
], i.prototype, "width", 2);
e([
  o({ type: String })
], i.prototype, "text", 1);
e([
  o({ type: String })
], i.prototype, "state", 1);
e([
  c()
], i.prototype, "_isLabelTruncated", 2);
export {
  i as Badge
};
//# sourceMappingURL=badge.js.map
