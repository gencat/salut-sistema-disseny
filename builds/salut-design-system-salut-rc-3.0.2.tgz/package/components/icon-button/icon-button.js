import { LitElement as y, unsafeCSS as h } from "lit";
import { property as e } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as i } from "../../utils/property-types.js";
import m from "./icon-button.style.css.js";
import { template as b } from "./icon-button.template.js";
var u = Object.defineProperty, o = (a, l, n, c) => {
  for (var r = void 0, p = a.length - 1, d; p >= 0; p--)
    (d = a[p]) && (r = d(l, n, r) || r);
  return r && u(l, n, r), r;
};
const s = class s extends y {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.size = "md", this.label = "", this.icon = void 0, this.fill = !1, this.disabled = !1, this.hidden = !1, this.disableTabindex = !1, this.ariaLabel = null, this.ariaExpanded = void 0, this.tooltipInteractive = !1, this.tooltipPosition = "top", this.hideTooltip = !1;
  }
  static get styles() {
    return [h(f), h(m)];
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  render() {
    return b(this);
  }
};
s.shadowRootOptions = {
  ...y.shadowRootOptions,
  delegatesFocus: !0
};
let t = s;
o([
  e({ type: String })
], t.prototype, "type");
o([
  e({ type: String })
], t.prototype, "variant");
o([
  e({ type: String })
], t.prototype, "size");
o([
  e({ type: String })
], t.prototype, "label");
o([
  e({ type: String })
], t.prototype, "icon");
o([
  e(i)
], t.prototype, "fill");
o([
  e(i)
], t.prototype, "disabled");
o([
  e(i)
], t.prototype, "hidden");
o([
  e(i)
], t.prototype, "disableTabindex");
o([
  e({ type: String })
], t.prototype, "ariaLabel");
o([
  e(i)
], t.prototype, "ariaExpanded");
o([
  e(i)
], t.prototype, "tooltipInteractive");
o([
  e({ type: String })
], t.prototype, "tooltipPosition");
o([
  e(i)
], t.prototype, "hideTooltip");
export {
  t as IconButton
};
//# sourceMappingURL=icon-button.js.map
