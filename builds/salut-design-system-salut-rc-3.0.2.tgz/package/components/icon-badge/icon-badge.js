import { LitElement as g, unsafeCSS as u } from "lit";
import { property as e } from "lit/decorators.js";
import c from "../../foundations/icon/icon.style.css.js";
import { booleanType as m } from "../../utils/property-types.js";
import { getBadgeIcon as f, getBadgeIconFill as h, isInformativeStatus as y } from "../badge/badge.utils.js";
import d from "../badge/badge.states.css.js";
import { template as b } from "./icon-badge.template.js";
import S from "./icon.badge.style.css.js";
var _ = Object.defineProperty, v = Object.getOwnPropertyDescriptor, s = (n, i, p, o) => {
  for (var t = o > 1 ? void 0 : o ? v(i, p) : i, a = n.length - 1, l; a >= 0; a--)
    (l = n[a]) && (t = (o ? l(i, p, t) : l(t)) || t);
  return o && t && _(i, p, t), t;
};
class r extends g {
  constructor() {
    super(...arguments), this.icon = void 0, this.size = "sm", this.label = "", this.status = "", this.disabled = !1, this.outlined = !1;
  }
  static get styles() {
    return [u(c), u(S), u(d)];
  }
  set state(i) {
    this.status = i;
  }
  get state() {
    return this.status;
  }
  get _iconSize() {
    return this.size === "lg" || this.size === "xl" ? "md" : "sm";
  }
  get _icon() {
    return f(this.icon, this.status);
  }
  get _iconFill() {
    return h(this.status);
  }
  get _bubble() {
    return this.status.includes("above") || this.status.includes("below");
  }
  _isInformativeState() {
    return y(this.status);
  }
  render() {
    return b(this);
  }
}
s([
  e({ type: String })
], r.prototype, "icon", 2);
s([
  e({ type: String })
], r.prototype, "size", 2);
s([
  e({ type: String })
], r.prototype, "label", 2);
s([
  e({ type: String })
], r.prototype, "status", 2);
s([
  e(m)
], r.prototype, "disabled", 2);
s([
  e(m)
], r.prototype, "outlined", 2);
s([
  e({ type: String })
], r.prototype, "state", 1);
export {
  r as IconBadge
};
//# sourceMappingURL=icon-badge.js.map
