import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as t, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as b } from "../../api/custom-element-scope.js";
const i = t`dss-icon${l(b())}`, o = (s) => {
  const a = {
    [`dss-icon-badge--${s.size}`]: !!s.size,
    [`dss-badge--${s.status}`]: !!s.status && !s.outlined,
    [`dss-badge--${s.status}-outlined`]: !!s.status && s.outlined && s._isInformativeState(),
    "dss-badge--disabled": s.disabled,
    "dss-icon-badge--bubble": s._bubble
  };
  return e`
		<div class="dss-wrapper">
      <div class="dss-icon-badge dss-icon ${d(a)}">
				<${i}
					size="${s._iconSize}"
					icon="${s._icon}"
					?fill="${s._iconFill}"
				></${i}>
			</div>
      <slot name="tooltip"></slot>
    </div>
  `;
};
export {
  o as template
};
//# sourceMappingURL=icon-badge.template.js.map
