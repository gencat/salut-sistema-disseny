import { LitElement as f, unsafeCSS as c } from "lit";
import { query as d, property as s, state as h } from "lit/decorators.js";
import { getPortalContainer as m } from "../../api/portal-manager/portal-manager.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as l, booleanConverter as p } from "../../utils/property-types.js";
import v from "../input/input.style.css.js";
import S from "./datepicker-range.style.css.js";
import { template as R } from "./datepicker-range.template.js";
var b = Object.defineProperty, a = (g, t, i, n) => {
  for (var r = void 0, o = g.length - 1, u; o >= 0; o--)
    (u = g[o]) && (r = u(t, i, r) || r);
  return r && b(t, i, r), r;
};
const _ = class _ extends f {
  constructor() {
    super(), this.labelRangeStart = "", this.labelRangeEnd = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholderRangeStart = "", this.placeholderRangeEnd = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.iconRangeStart = "calendar_today", this.iconRangeEnd = "calendar_today", this.showCalendar = !1, this.showButtons = !1, this.minDate = "", this.maxDate = "", this.timepicker = "", this.timepickerLabel = "Selecciona una hora", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this.customCalendar = void 0, this.customTimeListOptions = [], this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this.calendarLeftButtonLabel = "Cancel·lar", this.calendarRightButtonLabel = "Seleccionar", this._defaultStartId = `dss-datepicker-range-start-${crypto.randomUUID()}`, this._defaultEndId = `dss-datepicker-range-end-${crypto.randomUUID()}`, this._isStartFocused = !1, this._isEndFocused = !1, this._isTruncated = !1, this._helpText = "", this._dateformatPlaceholder = "DD/MM/AAAA", this._copyInputRangeStartPlaceholder = "", this._copyInputRangeEndPlaceholder = "", this._placeholderStart = "", this._placeholderEnd = "", this._helpTextBackup = "", this._isFirstUpdated = !0, this._portalManager = null, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this.showCalendar && this._closeCalendar();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._defaultId = `dss-datepicker-range-${crypto.randomUUID()}`, this._backFromCalendar = !1, this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [c(y), c(v), c(S)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeCalendarListener(), this.visibleObserver.disconnect(), this.showCalendar && this._closeCalendar();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _getEffectiveStartId() {
    return this.id !== "" ? `${this.id}-start` : this._defaultStartId;
  }
  _getEffectiveEndId() {
    return this.id !== "" ? `${this.id}-end` : this._defaultEndId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.visibleObserver.observe(this._inputRangeStart), this._helpTextBackup = this.helpText ?? "", this._inputRangeStart && this._inputRangeEnd && (this._inputRangeStart.classList.add("dss-input-skip-native"), this._inputRangeEnd.classList.add("dss-input-skip-native")), this._portalManager = m(), this._enableAnimations();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && (this.internals.setFormValue(this.value), queueMicrotask(() => {
      this._applyValue();
    })), t.has("placeholderRangeStart") && this._isFirstUpdated && (this._placeholderStart = this.placeholderRangeStart, this._copyInputRangeStartPlaceholder = this.placeholderRangeStart), t.has("placeholderRangeEnd") && this._isFirstUpdated && (this._placeholderEnd = this.placeholderRangeEnd, this._copyInputRangeEndPlaceholder = this.placeholderRangeEnd), t.has("helpText") && queueMicrotask(() => {
      this._helpText = this.helpText ?? "";
    });
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._hiddenInput.value = "", this._inputRangeStart.value = "", this._inputRangeEnd.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._hiddenInput.value = t ?? "", this._inputRangeStart.value = t ?? "", this._inputRangeEnd.value = t ?? "";
  }
  render() {
    return R(this);
  }
  /* Handle Input Events */
  _applyValue() {
    if (this.value === this._hiddenInput.value) return;
    const t = this.value.includes(",");
    let i = "", n = "";
    if (t) {
      const r = this.value.split(",");
      i = r[0] || "", n = r[1] || "";
    } else
      i = this.value, n = "";
    this._inputRangeStart.value = i, this._inputRangeEnd.value = n;
  }
  _handleRangeStartInput(t) {
    if (t.target) {
      const n = t.target.value.replace(/\D/g, "");
      this._inputRangeStart.value = this._formatDate(n), this._updateHiddenInput();
    }
  }
  _handleRangeEndInput(t) {
    if (t.target) {
      const n = t.target.value.replace(/\D/g, "");
      this._inputRangeEnd.value = this._formatDate(n), this._updateHiddenInput();
    }
  }
  _handleRangeStartClick() {
    this.showCalendar = !0, this._addCalendarListener(), this._disableAnimations(), this.requestUpdate();
  }
  _handleRangeEndClick() {
    this.showCalendar = !0, this._addCalendarListener(), this._disableAnimations(), this.requestUpdate();
  }
  _handleRangeStartFocusIn() {
    this._backFromCalendar || (this._isStartFocused || (this._isStartFocused = !0, this._isEndFocused = !1, this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder"), this._updatePlaceholders(), this.requestUpdate()), this._backFromCalendar = !1);
  }
  _handleRangeEndFocusIn() {
    this._isEndFocused || (this._isStartFocused = !1, this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._isEndFocused = !0, this._updatePlaceholders(), this.requestUpdate());
  }
  _handleRangeKeydown(t) {
    t?.key === "Tab" ? this.showCalendar && (t.preventDefault(), this.dispatchEvent(
      new CustomEvent("range-focus-calendar", {
        bubbles: !0,
        composed: !0
      })
    )) : t?.key === "Enter" && this.showCalendar && this._inputRangeStart.value?.length > 7 && this._inputRangeEnd.value?.length > 7 ? this._closeCalendar() : t?.key === "Enter" || t?.key === " " ? (this.showCalendar = !0, this._addCalendarListener(), this._disableAnimations(), this.requestUpdate()) : t?.key === "Escape" && (this.showCalendar = !1, this._removeCalendarListener(), this.requestUpdate());
  }
  _dispatchValueChange(t) {
    const i = new CustomEvent("value-changed", {
      detail: t,
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(i), this._updateHiddenInput();
  }
  _updateHiddenInput() {
    if (!this._hiddenInput) return;
    const t = this._inputRangeStart?.value || "", i = this._inputRangeEnd?.value || "";
    let n = "";
    t && i ? n = `${t},${i}` : t ? n = t : i && (n = i), this._hiddenInput.value = n, this.value = n, this._emitChange();
  }
  _emitChange() {
    this._hiddenInput.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _onCalendarChange(t) {
    const i = t.detail;
    if (i.rangeStart) {
      this._inputRangeStart.value = t.detail.rangeStart;
      const n = this._convertToISO(i.rangeStart), r = this._convertToISO(this._inputRangeEnd.value);
      this._inputRangeEnd.value && new Date(r) < new Date(n) && (this._inputRangeEnd.value = "", i.rangeEnd = null);
    }
    i.rangeEnd ? this._inputRangeEnd.value = t.detail.rangeEnd : this._inputRangeEnd.value = "", this._inputRangeEnd.value || (this._inputRangeEnd.focus(), this._isStartFocused = !1, this._isEndFocused = !0), this._inputRangeStart.value && this._inputRangeEnd.value && (this.showCalendar = !1, this._isStartFocused = !1, this._isEndFocused = !1, this._removeCalendarListener()), this.validate && this._validateDate(), this._dispatchValueChange(i), this.requestUpdate();
  }
  _onCalendarCancel() {
    this.showCalendar = !1, this._removeCalendarListener(), this.requestUpdate();
  }
  _updatePlaceholders() {
    this._isStartFocused && !this._copyInputRangeStartPlaceholder && (this._inputRangeStart.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate()), this._isEndFocused && !this._copyInputRangeEndPlaceholder && (this._inputRangeEnd.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate());
  }
  _removePlaceholders() {
    this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
  }
  _validateDate() {
    let t = this._checkDateFormat(this._inputRangeStart?.value);
    t || (t = this._checkDateFormat(this._inputRangeEnd?.value)), this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    if (!t || t === void 0)
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t === "")
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t.length < 10)
      return this._helpText = this.errorMessageFormat, this.invalid = !0, !0;
    if (this.minDate || this.maxDate) {
      const n = new Date(this._convertToISO(t)), r = new Date(this._convertToISO(this.minDate)), o = new Date(this._convertToISO(this.maxDate));
      if (r && n < r)
        return this._helpText = this.errorMessageMinDate, this.invalid = !0, !0;
      if (o && n > o)
        return this._helpText = this.errorMessageMaxDate, this.invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
  }
  _convertToISO(t) {
    const [i, n, r] = t.split("/");
    return `${r}-${n}-${i}`;
  }
  _dispatchOnValidate(t) {
    const i = {
      detail: {
        rangeStart: this._inputRangeStart?.value,
        rangeEnd: this._inputRangeEnd?.value,
        invalid: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("validate", i));
  }
  // Datepicker specific methods
  _formatDate(t) {
    let i = t.substring(0, 2), n = t.substring(2, 4);
    const r = t.substring(4, 8);
    return Number(i) > 3 && (i = i?.padStart(2, "0")), Number(n) > 1 && (n = n?.padStart(2, "0")), Number(i) > 31 && (i = "31"), Number(n) > 12 && (n = "12"), n === "02" && Number(i) > 28 && r?.length === 4 && (i = new Date(Number(r), 1, 29).getMonth() === 1 ? "29" : "28"), `${i}${n ? `/${n}` : ""}${r ? `/${r}` : ""}`;
  }
  _clearDate(t) {
    switch (t) {
      case "rangeStart":
        if (!this._inputRangeStart) return;
        this._inputRangeStart.value = "", this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder");
        break;
      case "rangeEnd":
        if (!this._inputRangeEnd) return;
        this._inputRangeEnd.value = "", this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
        break;
    }
    this._validateDate(), this._updateHiddenInput(), this.requestUpdate();
  }
  _closeCalendar() {
    this._removePlaceholders(), this._isStartFocused = !1, this._isEndFocused = !1, this.showCalendar = !1, this._inputRangeStart?.blur(), this._inputRangeEnd?.blur(), this._removeCalendarListener(), this.validate && this._validateDate(), setTimeout(() => {
      this._enableAnimations();
    }, 400), this.requestUpdate();
  }
  _checkClickOutside(t) {
    const i = t.composedPath(), n = `${this._getEffectiveId()}-calendar`, r = this._portalManager?.querySelector(`.${n}`);
    !i.includes(this) && !i.includes(r) && this.showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const i = t.relatedTarget, n = this._getPortalCalendar();
    i !== null && i !== this && i !== this._inputRangeStart && i !== this._inputRangeEnd && i !== this._calendar && i !== n && this.showCalendar && this._closeCalendar();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _getPortalCalendar() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-calendar`);
  }
  _enableAnimations() {
    this._calendar.classList.add("animation-enabled");
  }
  _disableAnimations() {
    setTimeout(() => {
      this._getPortalCalendar()?.classList.remove("animation-enabled");
    }, 240);
  }
  _handleCalendarFocusOut() {
    this.readonly || this.disabled || this.showCalendar && (this._backFromCalendar = !0, this._closeCalendar(), setTimeout(() => {
      this._inputRangeStart?.focus();
    }, 0));
  }
};
_.formAssociated = !0;
let e = _;
a([
  d("input.dss-input.dss-input--start")
], e.prototype, "_inputRangeStart");
a([
  d("input.dss-input.dss-input--end")
], e.prototype, "_inputRangeEnd");
a([
  d("input.dss-hidden-value")
], e.prototype, "_hiddenInput");
a([
  s({ type: String })
], e.prototype, "labelRangeStart");
a([
  s({ type: String })
], e.prototype, "labelRangeEnd");
a([
  s(l)
], e.prototype, "hideLabel");
a([
  s({ type: String })
], e.prototype, "name");
a([
  s({ type: String })
], e.prototype, "id");
a([
  s({ type: String })
], e.prototype, "type");
a([
  s({ type: String })
], e.prototype, "placeholderRangeStart");
a([
  s({ type: String })
], e.prototype, "placeholderRangeEnd");
a([
  s({ type: String })
], e.prototype, "value");
a([
  s({ converter: p, reflect: !0 })
], e.prototype, "disabled");
a([
  s({ converter: p, reflect: !0 })
], e.prototype, "readonly");
a([
  s({ converter: p, reflect: !0 })
], e.prototype, "required");
a([
  s({ converter: p, reflect: !0 })
], e.prototype, "invalid");
a([
  s({ type: Number })
], e.prototype, "step");
a([
  s({ type: Number })
], e.prototype, "min");
a([
  s({ type: Number })
], e.prototype, "max");
a([
  s({ type: Number })
], e.prototype, "minLength");
a([
  s({ type: String })
], e.prototype, "pattern");
a([
  s({ type: String })
], e.prototype, "inputmode");
a([
  s({ type: String })
], e.prototype, "autocapitalize");
a([
  s({ type: String })
], e.prototype, "autocomplete");
a([
  s(l)
], e.prototype, "autocorrect");
a([
  s(l)
], e.prototype, "autofocus");
a([
  s(l)
], e.prototype, "spellcheck");
a([
  s({ type: String })
], e.prototype, "size");
a([
  s({ type: String })
], e.prototype, "iconRangeStart");
a([
  s({ type: String })
], e.prototype, "iconRangeEnd");
a([
  s({ type: String })
], e.prototype, "helpText");
a([
  s(l)
], e.prototype, "showCalendar");
a([
  s(l)
], e.prototype, "showButtons");
a([
  s({ type: String })
], e.prototype, "minDate");
a([
  s({ type: String })
], e.prototype, "maxDate");
a([
  s({ type: String })
], e.prototype, "timepicker");
a([
  s({ type: String })
], e.prototype, "timepickerLabel");
a([
  s({ type: Number })
], e.prototype, "minHour");
a([
  s({ type: Number })
], e.prototype, "maxHour");
a([
  s({ type: Number })
], e.prototype, "minutesRange");
a([
  s({ type: Array })
], e.prototype, "customCalendar");
a([
  s({ type: Array })
], e.prototype, "customTimeListOptions");
a([
  s(l)
], e.prototype, "validate");
a([
  s(l)
], e.prototype, "errorMessageFormat");
a([
  s(l)
], e.prototype, "errorMessageMinDate");
a([
  s(l)
], e.prototype, "errorMessageMaxDate");
a([
  s({ type: String })
], e.prototype, "calendarLeftButtonLabel");
a([
  s({ type: String })
], e.prototype, "calendarRightButtonLabel");
a([
  h()
], e.prototype, "_isStartFocused");
a([
  h()
], e.prototype, "_isEndFocused");
a([
  h()
], e.prototype, "_isTruncated");
a([
  h()
], e.prototype, "_helpText");
a([
  d(".dss-calendar")
], e.prototype, "_calendar");
a([
  h()
], e.prototype, "_backFromCalendar");
export {
  e as DatepickerRange
};
//# sourceMappingURL=datepicker-range.js.map
