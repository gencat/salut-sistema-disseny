import { nothing as e } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { when as l } from "lit/directives/when.js";
import { unsafeStatic as a, literal as d, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
const $ = d`dss-icon${a(c())}`, t = d`dss-icon-button${a(c())}`, h = d`dss-tooltip${a(c())}`, b = (s) => i`
  ${l(
  s.icon,
  () => i`
    <span class="dss-chip__icon">
      <${$}
        icon="${s.icon}"
        size="${s.size === "lg" ? "md" : "sm"}">
      </${$}>
    </span>
  `,
  () => e
)}

  ${l(
  s.label,
  () => i`
      <span class="dss-chip__label">
        ${s.label}
      </span>
    `,
  () => e
)}
`, z = (s) => i`
  <div
    class=${r({
  "dss-chip": !0,
  "dss-chip--disabled": s.disabled,
  "dss-chip--not-clickable": s.disableSelect,
  "dss-chip--selected": s.selected,
  "dss-chip--has-icons": !!s.icon || s.hasDelete,
  "dss-chip--only-icon": !!(s.icon && !s.label) && !s.hasDelete,
  "dss-chip--select-focus": s._isSelectFocused,
  [`dss-chip--${s.size}`]: !!s.size
})}
  >

     ${l(
  s.disableSelect,
  () => i`
        <div class="dss-chip-content">
          ${b(s)}
        </div>
      `,
  () => i`
        <button
          class="dss-chip-content dss-chip-button"
          aria-label="Seleccionar ${s.label || ""}"
          aria-pressed=${s.selected}
          ?disabled=${s.disabled}
          @click=${s.handleToggle}
          @keydown=${s.handleKeydown}
          @focusin=${s.onSelectFocusIn}
          @focusout=${s.onSelectFocusOut}
        >
          ${b(s)}
        </button>
      `
)}

    ${l(
  s.hasDelete,
  () => i`
      <div class="dss-chip__delete">
        <${t}
          variant="info"
          icon="cancel"
          label="Eliminar ${s.label || ""}"
          hideTooltip
          size="${s.size === "sm" ? "sm" : "md"}"
          ?disabled=${s.disabled}
          @click=${s.handleDelete}>
        </${t}>
      </div>
      `,
  () => e
)}

    ${l(
  s._isLabelTruncated,
  () => i`
        <${h}>
          ${s.label}
        </${h}>
      `,
  () => e
)}
  </div>
`;
export {
  z as template
};
//# sourceMappingURL=chip.template.js.map
