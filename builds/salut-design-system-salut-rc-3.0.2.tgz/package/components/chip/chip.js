import { LitElement as p, unsafeCSS as c } from "lit";
import { property as i, state as n } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as o } from "../../utils/property-types.js";
import f from "./chip.style.css.js";
import { template as b } from "./chip.template.js";
var y = Object.defineProperty, t = (r, e, a, m) => {
  for (var l = void 0, d = r.length - 1, h; d >= 0; d--)
    (h = r[d]) && (l = h(e, a, l) || l);
  return l && y(e, a, l), l;
};
class s extends p {
  constructor() {
    super(...arguments), this.size = "lg", this.icon = "", this.label = "", this.hasDelete = !1, this.disabled = !1, this.selected = !1, this.disableSelect = !1, this._isSelectFocused = !1, this._isLabelTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [c(u), c(f)];
  }
  handleToggle() {
    this.disableSelect || this.disabled || (this.selected = !this.selected, this.dispatchEvent(
      new CustomEvent("toggle", {
        detail: {
          text: this.label,
          selected: this.selected
        }
      })
    ));
  }
  handleKeydown(e) {
    e.stopPropagation(), (e.key === "Enter" || e.key === "Space") && this.handleToggle();
  }
  handleDelete(e) {
    e.stopPropagation(), this.dispatchEvent(
      new CustomEvent("delete", {
        detail: {
          text: this.label
        }
      })
    );
  }
  onSelectFocusIn(e) {
    if (this.disabled || this.disableSelect) return;
    const a = e.target;
    this._isSelectFocused = !!a?.matches(":focus-visible");
  }
  onSelectFocusOut() {
    this._isSelectFocused = !1;
  }
  async firstUpdated() {
    await this.updateComplete, this._checkLabelTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(e) {
    !this._isFirstUpdated && e.has("label") && this._checkLabelTruncated();
  }
  _checkLabelTruncated() {
    const e = this.shadowRoot?.querySelector(".dss-chip__label");
    e && (this._isLabelTruncated = e.scrollWidth > e.offsetWidth, this.requestUpdate());
  }
  render() {
    return b(this);
  }
}
t([
  i({ type: String })
], s.prototype, "size");
t([
  i({ type: String })
], s.prototype, "icon");
t([
  i({ type: String })
], s.prototype, "label");
t([
  i(o)
], s.prototype, "hasDelete");
t([
  i(o)
], s.prototype, "disabled");
t([
  i(o)
], s.prototype, "selected");
t([
  i(o)
], s.prototype, "disableSelect");
t([
  n()
], s.prototype, "_isSelectFocused");
export {
  s as Chip
};
//# sourceMappingURL=chip.js.map
