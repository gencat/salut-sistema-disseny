import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as e, literal as r, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const d = r`dss-icon${e(l())}`, b = (i) => {
  let s;
  return !i.dot && i.icon ? s = a`<${d} size="sm" icon="${i.icon}"></${d}>` : !i.dot && i.value ? s = a`<span class="dss-notification-badge-value"
      >${i.value}</span
    >` : s = null, a`
    <div class="${t({
    "dss-notification-badge": !0,
    [`dss-notification-badge--${i.type}`]: !!i.type,
    [`dss-notification-badge--${i.variant}`]: !!i.variant,
    [`dss-notification-badge--${i.status}`]: !!i.status,
    "dss-notification-badge--dot": i.dot,
    "dss-notification-badge--inverted": i.inverted,
    "dss-notification-badge--hide-border": i.hideBorder,
    "dss-notification-badge--hover": !i.hideBorder && i.isHover,
    "dss-notification-badge--active": !i.hideBorder && i.isActive
  })}">
      ${s}
    </div>
  `;
};
export {
  b as template
};
//# sourceMappingURL=notification-badge.template.js.map
