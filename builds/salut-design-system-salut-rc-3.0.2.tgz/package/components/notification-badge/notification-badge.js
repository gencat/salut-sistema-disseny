import { LitElement as f, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import { booleanType as i } from "../../utils/property-types.js";
import d from "./notification-badge.style.css.js";
import { template as v } from "./notification-badge.template.js";
var u = Object.defineProperty, e = (p, a, n, h) => {
  for (var o = void 0, s = p.length - 1, y; s >= 0; s--)
    (y = p[s]) && (o = y(a, n, o) || o);
  return o && u(a, n, o), o;
};
class r extends f {
  constructor() {
    super(...arguments), this.variant = "default", this.type = "default", this.status = "default", this.dot = !1, this.inverted = !1, this.icon = void 0, this.value = "", this.hideBorder = !1, this.isHover = !1, this.isActive = !1;
  }
  static get styles() {
    return [l(d)];
  }
  render() {
    return v(this);
  }
}
e([
  t({ type: String })
], r.prototype, "variant");
e([
  t({ type: String })
], r.prototype, "type");
e([
  t({ type: String })
], r.prototype, "status");
e([
  t(i)
], r.prototype, "dot");
e([
  t(i)
], r.prototype, "inverted");
e([
  t({ type: String })
], r.prototype, "icon");
e([
  t({ type: String })
], r.prototype, "value");
e([
  t(i)
], r.prototype, "hideBorder");
e([
  t(i)
], r.prototype, "isHover");
e([
  t(i)
], r.prototype, "isActive");
export {
  r as NotificationBadge
};
//# sourceMappingURL=notification-badge.js.map
