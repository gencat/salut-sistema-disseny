import { LitElement as u, unsafeCSS as y } from "lit";
import { property as e } from "lit/decorators.js";
import { booleanType as h } from "../../utils/property-types.js";
import f from "./progress-indicator.style.css.js";
import { template as c } from "./progress-indicator.template.js";
var g = Object.defineProperty, m = Object.getOwnPropertyDescriptor, r = (o, t, a, p) => {
  for (var i = p > 1 ? void 0 : p ? m(t, a) : t, n = o.length - 1, l; n >= 0; n--)
    (l = o[n]) && (i = (p ? l(t, a, i) : l(i)) || i);
  return p && i && g(t, a, i), i;
};
class s extends u {
  constructor() {
    super(...arguments), this.titleText = "", this.description = "", this.status = "default", this.percentage = 0, this.hidePercentage = !1, this.hasFailed = !1;
  }
  static get styles() {
    return y(f);
  }
  set state(t) {
    this.status = t;
  }
  get state() {
    return this.status;
  }
  set title(t) {
    this.titleText = t;
  }
  get title() {
    return this.titleText;
  }
  updated(t) {
    t.has("hasFailed") && this.hasFailed && queueMicrotask(() => {
      this.status = "error";
    });
  }
  render() {
    return c(this);
  }
}
r([
  e({ type: String })
], s.prototype, "titleText", 2);
r([
  e({ type: String })
], s.prototype, "description", 2);
r([
  e({ type: String })
], s.prototype, "status", 2);
r([
  e({ type: Number })
], s.prototype, "percentage", 2);
r([
  e(h)
], s.prototype, "hidePercentage", 2);
r([
  e(h)
], s.prototype, "hasFailed", 2);
r([
  e({ type: String })
], s.prototype, "state", 1);
r([
  e({ type: String })
], s.prototype, "title", 1);
export {
  s as ProgressIndicator
};
//# sourceMappingURL=progress-indicator.js.map
