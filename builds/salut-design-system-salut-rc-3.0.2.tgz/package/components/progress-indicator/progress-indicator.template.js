import { nothing as a } from "lit";
import { classMap as i } from "lit/directives/class-map.js";
import { styleMap as e } from "lit/directives/style-map.js";
import { when as t } from "lit/directives/when.js";
import { html as r } from "lit/static-html.js";
const c = (s) => r`
  <div 
    class="${i({
  "dss-progress-indicator": !0,
  "dss-progress-indicator--error": s.hasFailed,
  [`dss-progress-indicator--${s.status}`]: s.status !== "default"
})}" 
    role="progressbar"
    aria-label="Barra de progrés ${s.titleText || ""}"
    aria-valuemin="0"
    aria-valuemax="100"
    aria-valuenow="${s.percentage}"
  >
    ${t(
  s.titleText,
  () => r`<h2 class="dss-progress-indicator__title">${s.titleText}</h2>`,
  () => a
)}
    <div class="dss-progress-indicator__bar-wrapper">
      <div class="dss-progress-indicator__bar">
        <div
          class="dss-progress-indicator__progress"
          style="${e({
  width: `${s.percentage}%`
})}"
        >
        </div>
      </div>
      ${s.hidePercentage ? a : r` 
        <span class="dss-progress-indicator__percentage">
          ${s.percentage}%
        </span>
      `}
    </div>
    <div class="dss-progress-indicator__content">
      <span class="dss-progress-indicator__description">
        ${s.description}
      </span>
    </div>
  </div>
`;
export {
  c as template
};
//# sourceMappingURL=progress-indicator.template.js.map
