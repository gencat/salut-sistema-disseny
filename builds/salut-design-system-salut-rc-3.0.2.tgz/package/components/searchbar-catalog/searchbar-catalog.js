import { LitElement as m, unsafeCSS as p } from "lit";
import { property as s, query as f, state as y } from "lit/decorators.js";
import g from "../../api/marker/marker.style.css.js";
import { getPortalContainer as _ } from "../../api/portal-manager/portal-manager.js";
import b from "../../shared/reset.style.css.js";
import w from "../../shared/scrollbar.style.css.js";
import { scheduleShow as S, executeShow as T, hideFloating as A, updateFloatingCombobox as E, updateFloatingPosition as C } from "../../utils/floating-combobox.js";
import { booleanType as h } from "../../utils/property-types.js";
import P from "./searchbar-catalog.style.css.js";
import { template as U } from "./searchbar-catalog.template.js";
var x = Object.defineProperty, e = (u, t, r, n) => {
  for (var a = void 0, o = u.length - 1, l; o >= 0; o--)
    (l = u[o]) && (a = l(t, r, a) || a);
  return a && x(t, r, a), a;
};
class i extends m {
  constructor() {
    super(...arguments), this.multiple = !1, this.isOpen = !1, this.isLoading = !1, this.filter = "", this.threshold = 3, this.advancedFilter = !1, this.catalogTitle = "Resultats de la cerca", this.catalog = [], this.recentSearchesTitle = "Últimes cerques", this.recentSearches = [], this.resultsEmptyLabel = "Sense resultats per", this.searchTerms = [], this.catalogStyle = void 0, this.delay = 0, this._initialParent = null, this._portalManager = null, this._isTabbingOut = !1, this._isFirstUpdated = !0, this._toggle = () => {
      this.isOpen ? this.show() : this.hide();
    };
  }
  static get styles() {
    return [p(b), p(w), p(g), p(P)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0;
  }
  show() {
    S({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    });
  }
  _executeShow() {
    T({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCombobox()
    });
  }
  hide() {
    A({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCombobox() {
    E({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    this._parent && await C(this._parent, this);
  }
  updated(t) {
    t.has("isOpen") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = _(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _handleKeydown(t) {
    t.key === "Tab" && (this._isTabbingOut = !0), (t.key === "ArrowDown" || t.key === "ArrowUp") && t.preventDefault();
  }
  _handleFocusout(t) {
    const r = t.relatedTarget;
    r && this.contains(r) || (this._isTabbingOut && this.dispatchEvent(
      new CustomEvent("catalog-focusout", {
        bubbles: !0,
        composed: !0
      })
    ), this._isTabbingOut = !1);
  }
  moveFocus() {
    const t = this.shadowRoot?.querySelectorAll('.dss-searchbar-catalog-item[tabindex="0"]');
    if (!t || t.length === 0) return;
    t[0].focus();
  }
  _focusSentinel() {
    this.dispatchEvent(
      new CustomEvent("catalog-focusout", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  _dispatchItemSelected(t) {
    this.dispatchEvent(
      new CustomEvent("catalog-item-selected", {
        detail: { item: t },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _handleItemClick(t, r) {
    t.preventDefault(), t.stopPropagation(), !(!r.value || r.disabled || this.searchTerms.includes(r.value)) && (this._dispatchItemSelected(r), this.multiple && this.requestUpdate());
  }
  _handleItemKeydown(t, r) {
    if (r.disabled) return;
    if (t.key === "Enter") {
      this._handleItemClick(t, r);
      return;
    }
    if (t.key !== "ArrowDown" && t.key !== "ArrowUp") return;
    t.preventDefault(), t.stopPropagation();
    const n = t.currentTarget;
    if (!n) return;
    const a = n.closest(".dss-searchbar-catalog-wrapper") || this.shadowRoot;
    if (!a) return;
    const o = Array.from(
      a.querySelectorAll(".dss-searchbar-catalog-item:not(.dss-searchbar-catalog-item--disabled)")
    ), l = o.indexOf(n);
    if (l === -1) return;
    const c = t.key === "ArrowDown" ? l + 1 : l - 1;
    if (c < 0 || c >= o.length) return;
    const d = o[c];
    n.setAttribute("tabindex", "-1"), d.setAttribute("tabindex", "0"), d.focus();
  }
  render() {
    return U(this);
  }
}
e([
  s(h)
], i.prototype, "multiple");
e([
  s(h)
], i.prototype, "isOpen");
e([
  s(h)
], i.prototype, "isLoading");
e([
  s({ type: String })
], i.prototype, "filter");
e([
  s({ type: Number })
], i.prototype, "threshold");
e([
  s(h)
], i.prototype, "advancedFilter");
e([
  s({ type: String })
], i.prototype, "catalogTitle");
e([
  s({ type: Array })
], i.prototype, "catalog");
e([
  s({ type: String })
], i.prototype, "recentSearchesTitle");
e([
  s({ type: Array })
], i.prototype, "recentSearches");
e([
  s({ type: String })
], i.prototype, "resultsEmptyLabel");
e([
  s({ type: Array })
], i.prototype, "searchTerms");
e([
  s({ type: String })
], i.prototype, "catalogStyle");
e([
  f(".dss-searchbar-catalog")
], i.prototype, "_floatingCombobox");
e([
  s({ type: Number })
], i.prototype, "delay");
e([
  y()
], i.prototype, "_isFirstUpdated");
export {
  i as SearchBarCatalog
};
//# sourceMappingURL=searchbar-catalog.js.map
