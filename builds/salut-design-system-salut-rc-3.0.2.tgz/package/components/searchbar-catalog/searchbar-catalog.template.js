import { nothing as r } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeHTML as d } from "lit/directives/unsafe-html.js";
import { unsafeStatic as u, literal as v, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as f } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as _, highlightText as y } from "../../api/marker/marker.js";
const e = v`dss-icon${u(f())}`, S = v`dss-spinner${u(f())}`, h = v`dss-typography${u(f())}`, F = (a) => {
  const g = a.recentSearches?.slice(0, 8) ?? [], i = g.length > 0, $ = (a.catalog?.length ?? 0) > 0, b = a.filter.length >= a.threshold && $, w = i || b, L = (s) => s === g.length - 1 && !b, T = (s) => s === (a.catalog?.length ?? 0) - 1;
  return l`
		<div class="${o({
    "dss-searchbar-catalog": !0
  })}"
			style=${a.catalogStyle ?? r}
			@keydown=${a._handleKeydown}
			@focusout=${a._handleFocusout}
		>

			${a.isLoading && !i && !$ && a.filter.length >= a.threshold ? l`
						<div
							class="dss-searchbar-catalog-loading"
						>
							<${S} size="md"/>
						</div>
					` : r}

			${!a.isLoading && a.filter.length >= a.threshold && !$ && !i ? l`
					<div
						class="dss-searchbar-catalog-empty"
					>
						<${e} size="sm" icon="info"></${e}>
						<span class="text">
							${a.resultsEmptyLabel}: ${a.filter}
						</span>
					</div>
					` : r}

			${w ? l`
						<div
							class="dss-searchbar-catalog-wrapper"
 						  role="listbox" 
						>
							${i ? l`
								<div class="dss-searchbar-catalog-title">
									<${h} variant="body-3" fontweight="semibold">
										${a.recentSearchesTitle}
									</${h}>
								</div>
								` : r}

							${i ? g.map(
    (s, c) => l`
								<div 
									class="${o({
      "dss-searchbar-catalog-item": !0,
      "dss-searchbar-catalog-item--selected": a.multiple && a.searchTerms.includes(s.value),
      "dss-searchbar-catalog-item--match": !a.multiple && a.searchTerms.length > 0 && a.searchTerms[0].toLowerCase() === s.value.toLowerCase(),
      "dss-searchbar-catalog-item--disabled": !!s.disabled,
      "dss-searchbar-catalog-item--last": L(c)
    })}"
									role="option"
									aria-label="${s.value}"
									tabindex="${c === 0 ? "0" : "-1"}"
									@click=${(t) => a._handleItemClick(t, s)}
									@keydown=${(t) => a._handleItemKeydown(t, s)}
								>
									<${e} class="dss-searchbar-catalog-item__icon" size="md" icon="${s.icon ? s.icon : "history"}"></${e}>
									<span class="dss-searchbar-catalog-item__label">
										${a.advancedFilter ? d(_(s.value, a.filter, a.threshold)) : d(y(s.value, a.filter))}
									</span>
									<${e} class="dss-searchbar-catalog-item__selected" size="md" icon="check"></${e}>
								</div>
								`
  ) : r}

							${b ? l`
								<div class="dss-searchbar-catalog-title">
									<${h} variant="body-3" fontweight="semibold">
										${a.catalogTitle}
									</${h}>
								</div>

								${a.catalog.map(
    (s, c) => l`
									<div 
										class="${o({
      "dss-searchbar-catalog-item": !0,
      "dss-searchbar-catalog-item--selected": a.multiple && a.searchTerms.includes(s.value),
      "dss-searchbar-catalog-item--match": !a.multiple && a.searchTerms.length > 0 && a.searchTerms[0].toLowerCase() === s.value.toLowerCase(),
      "dss-searchbar-catalog-item--disabled": !!s.disabled,
      "dss-searchbar-catalog-item--last": T(c)
    })}"
										role="option"
										aria-label="${s.value}"
										tabindex="${!i && c === 0 ? "0" : "-1"}"
										@click=${(t) => a._handleItemClick(t, s)}
										@keydown=${(t) => a._handleItemKeydown(t, s)}
									>
										<${e} class="dss-searchbar-catalog-item__icon" size="md" icon="${s.icon ? s.icon : "search"}"></${e}>
										<span class="dss-searchbar-catalog-item__label">
											${a.advancedFilter ? d(_(s.value, a.filter, a.threshold)) : d(y(s.value, a.filter))}
										</span>
										<${e} class="dss-searchbar-catalog-item__selected" size="md" icon="check"></${e}>
									</div>
									`
  )}
							` : r}
						</div>
					` : r}

			

    </div>

		${a.isOpen ? l`
			<button
				class="dss-searchbar-catalog__sentinel"
				type="button"
				aria-hidden="true"
				@focus=${a._focusSentinel}
			>
				Focus Sentinel
			</button>
			` : r}
  `;
};
export {
  F as template
};
//# sourceMappingURL=searchbar-catalog.template.js.map
