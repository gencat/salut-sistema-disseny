import { classMap as t } from "lit/directives/class-map.js";
import { unsafeHTML as v } from "lit/directives/unsafe-html.js";
import { html as l } from "lit/static-html.js";
const k = (s) => {
  const a = s._steps?.length, b = Math.round(s.currentStep / a * 100), c = {
    "dss-stepper--vertical": s.column,
    "dss-stepper--sm": s.size === "sm",
    "dss-stepper--md": s.size === "md"
  };
  return l`
      ${s.circular ? l`
            <div class="dss-circular-stepper">
              <div class="dss-circular-stepper__item">
                <svg viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="33" cy="33" r="28" pathLength="100"></circle>
                  <circle
                    cx="33"
                    cy="33"
                    r="28"
                    style="--percent: ${b}"
                    pathLength="100"
                  ></circle>
                </svg>
                <span class="dss-circular-stepper__counter">
                  <b>${s.currentStep}</b>/${a}
                </span>
              </div>
              <span class="dss-circular-stepper__label">
                ${s._steps[s.currentStep - 1].label}
              </span>
            </div>
          ` : l`
            <style>
              :host {
                --active-bar-width: ${s._activeBarWidth};
              }
            </style>
            <ol class="dss-stepper ${t(c)}">
              ${s._steps?.map((e, d) => {
    const r = d + 1, i = ($) => {
      $.key === "Enter" && s._onStepClick(e, r);
    }, u = e.state === "disabled", p = {
      "dss-bubble--active": r === s.currentStep,
      "dss-bubble--completed": r < s.currentStep,
      "dss-bubble--checked": e.state === "checked" && r !== s.currentStep,
      "dss-bubble--error": e.state === "error" && r !== s.currentStep,
      "dss-bubble--info": e.state === "info" && r !== s.currentStep,
      "dss-bubble--alert": e.state === "alert" && r !== s.currentStep,
      "dss-bubble--disabled": e.state === "disabled",
      "dss-bubble--icon": !!e?.icon && s.size !== "sm"
    }, h = {
      "dss-bubble-label--disabled": e.state === "disabled",
      "hide-label": s.hideLabel
    };
    return l`
                  <li
                    class="dss-bubble ${t(p)}"
                    icon="${e?.icon || ""}"
                    tabindex="${u ? -1 : 0}"
                    aria-label="Step ${e?.state}"
                    @click=${() => s._onStepClick(e, r)}
                    @keydown=${i}
                  >
                    <span class="dss-bubble-label ${t(h)}"
                      >${v(e.label)}</span
                    >
                  </li>
                `;
  })}
            </ol>
          `}
    `;
};
export {
  k as template
};
//# sourceMappingURL=stepper.template.js.map
