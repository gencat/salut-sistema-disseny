import { LitElement, unsafeCSS } from "lit";
import { property, state } from "lit/decorators.js";
import { booleanType } from "../../utils/property-types.js";
import styles from "./stepper.style.css.js";
import { template } from "./stepper.template.js";
var __defProp = Object.defineProperty, __getOwnPropDesc = Object.getOwnPropertyDescriptor, __decorateClass = (t, p, r, e) => {
  for (var s = e > 1 ? void 0 : e ? __getOwnPropDesc(p, r) : p, o = t.length - 1, i; o >= 0; o--)
    (i = t[o]) && (s = (e ? i(p, r, s) : i(s)) || s);
  return e && s && __defProp(p, r, s), s;
};
class Stepper extends LitElement {
  constructor() {
    super(...arguments), this._steps = [], this.currentStep = 1, this.column = !1, this.circular = !1, this.hideLabel = !1, this.size = "md", this._activeBarWidth = "0", this._isFirstUpdate = !0;
  }
  static get styles() {
    return unsafeCSS(styles);
  }
  set steps(steps) {
    const oldValue = this._steps;
    this._steps = steps, typeof steps == "string" && (this._steps = eval(`(${steps})`)), this.requestUpdate("steps", oldValue);
  }
  get steps() {
    return this._steps;
  }
  async firstUpdated() {
    await this.updateComplete, this._setActiveBarWidth(), this._isFirstUpdate = !1, this.requestUpdate();
  }
  willUpdate(t) {
    this._isFirstUpdate || (t.has("currentStep") || t.has("steps") || t.has("column")) && (this._setActiveBarWidth(), this.requestUpdate());
  }
  _setActiveBarWidth() {
    const t = this._steps.length, r = this.shadowRoot?.querySelector(".dss-stepper")?.getBoundingClientRect(), e = this.column ? r?.height : r?.width;
    if (e) {
      const s = Math.floor(e / (t - 1));
      this._activeBarWidth = `${s}px`;
    }
  }
  _onStepClick(t, p) {
    if (t.state === "disabled") return;
    const e = {
      detail: { step: t, stepNumber: p },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("step-click", e));
  }
  render() {
    return template(this);
  }
}
__decorateClass([
  property({ type: [] })
], Stepper.prototype, "steps", 1);
__decorateClass([
  state()
], Stepper.prototype, "_steps", 2);
__decorateClass([
  property({ type: Number })
], Stepper.prototype, "currentStep", 2);
__decorateClass([
  property(booleanType)
], Stepper.prototype, "column", 2);
__decorateClass([
  property(booleanType)
], Stepper.prototype, "circular", 2);
__decorateClass([
  property(booleanType)
], Stepper.prototype, "hideLabel", 2);
__decorateClass([
  property({ type: String })
], Stepper.prototype, "size", 2);
__decorateClass([
  state()
], Stepper.prototype, "_activeBarWidth", 2);
export {
  Stepper
};
//# sourceMappingURL=stepper.js.map
