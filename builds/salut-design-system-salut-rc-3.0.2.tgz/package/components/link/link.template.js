import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as r, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const l = r`dss-icon${d(t())}`, a = r`dss-tooltip${d(t())}`, k = (i) => s`
  <a
    href="${i.disabled ? "javascript:void(0)" : i.href}"
    target="${i.disabled ? "_self" : i.target}"
    ?download="${i.download}"
    class=${e({
  "dss-link": !0,
  "dss-link--standalone": !!i.size && !!i.variant,
  [`dss-link--${i.variant}`]: i.variant,
  [`dss-link--${i.size}`]: !!i.size,
  "dss-link--full-width": !!i.fullWidth,
  "dss-link--disabled": !!i.disabled,
  "dss-link--icon-right": !!i.icon && i.iconPosition === "right",
  [`dss-link--${i.fontWeight}`]: i.fontWeight !== "inherit"
})}
	 @mouseenter=${i.checkTextTruncate}
  >
    ${i.icon ? s`
          <${l} size="${i._getIconSize()}" icon="${i.icon}"></${l}>
        ` : null}
    <span class="dss-link-text">${i.label}</span>
		${i.size && i.variant ? s`
			<${a} 
				class="dss-link__tooltip"
				aria-hidden="true"
				?forceViewport="${i.forceViewport}" 
				?tooltipFixed="${i.tooltipFixed}" 
			>
				${i.label}
			</${a}>
			` : null}
  </a>
`;
export {
  k as template
};
//# sourceMappingURL=link.template.js.map
