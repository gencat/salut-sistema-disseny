import { LitElement as d, unsafeCSS as f } from "lit";
import { property as t } from "lit/decorators.js";
import y from "../../foundations/icon/icon.style.css.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import c from "./link.style.css.js";
import { template as S } from "./link.template.js";
var g = Object.defineProperty, e = (p, r, s, a) => {
  for (var o = void 0, l = p.length - 1, h; l >= 0; l--)
    (h = p[l]) && (o = h(r, s, o) || o);
  return o && g(r, s, o), o;
};
class i extends d {
  constructor() {
    super(...arguments), this.variant = "default", this.href = "#", this.label = "", this.icon = void 0, this.size = void 0, this.iconSize = "sm", this.iconPosition = "left", this.disabled = !1, this.download = !1, this.target = "_self", this.fontWeight = "inherit", this.fontSize = "inherit", this.fullWidth = !1, this.tooltipFixed = !1, this.forceViewport = !1;
  }
  static get styles() {
    return [f(y), f(u), f(c)];
  }
  updated(r) {
    r.has("variant") && queueMicrotask(() => {
      this.variant !== "default" && this.size === void 0 && (this.size = "lg");
    }), r.has("fontSize") && queueMicrotask(() => {
      if (this.variant !== "default" || this.size !== void 0) return;
      const s = this.shadowRoot?.querySelector("a.dss-link");
      s && (s.style.fontSize = this.fontSize);
    });
  }
  _getIconSize() {
    return this.size ? this.size === "lg" ? "md" : "sm" : this.iconSize;
  }
  checkTextTruncate(r) {
    if (!r) return;
    const s = r.target;
    let a = !1;
    const o = s.querySelector(".dss-link-text");
    a = o.scrollWidth > o.offsetWidth, s.setAttribute("data-truncated", a.toString());
  }
  render() {
    return S(this);
  }
}
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "href");
e([
  t({ type: String })
], i.prototype, "label");
e([
  t({ type: String })
], i.prototype, "icon");
e([
  t({ type: String })
], i.prototype, "size");
e([
  t({ type: String })
], i.prototype, "iconSize");
e([
  t({ type: String })
], i.prototype, "iconPosition");
e([
  t(n)
], i.prototype, "disabled");
e([
  t(n)
], i.prototype, "download");
e([
  t({ type: String })
], i.prototype, "target");
e([
  t({ type: String })
], i.prototype, "fontWeight");
e([
  t({ type: String })
], i.prototype, "fontSize");
e([
  t(n)
], i.prototype, "fullWidth");
e([
  t(n)
], i.prototype, "tooltipFixed");
e([
  t(n)
], i.prototype, "forceViewport");
export {
  i as Link
};
//# sourceMappingURL=link.js.map
