import { LitElement as u, unsafeCSS as d } from "lit";
import { property as s } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import { getBadgeIcon as y, getBadgeIconFill as m, isInformativeStatus as _ } from "../badge/badge.utils.js";
import g from "./badge-button.states.css.js";
import b from "./badge-button.style.css.js";
import { template as w } from "./badge-button.template.js";
var S = Object.defineProperty, v = Object.getOwnPropertyDescriptor, i = (c, t, n, r) => {
  for (var o = r > 1 ? void 0 : r ? v(t, n) : t, p = c.length - 1, h; p >= 0; p--)
    (h = c[p]) && (o = (r ? h(t, n, o) : h(o)) || o);
  return r && o && S(t, n, o), o;
};
const l = class l extends u {
  constructor() {
    super(...arguments), this.type = "button", this.icon = void 0, this.size = "sm", this.status = "", this.label = "", this.action = "dropdown", this.disabled = !1, this.hidden = !1, this.hideIcon = !1, this.outlined = !1, this.width = void 0, this._isTextTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [d(f), d(b), d(g)];
  }
  get _tooltip() {
    const t = this.shadowRoot?.querySelector('slot[name="tooltip"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set state(t) {
    this.status = t;
  }
  get state() {
    return this.status;
  }
  get _actionIcon() {
    switch (this.action) {
      case "details":
        return "visibility";
      case "external":
        return "open_in_new";
      default:
        return "expand_more";
    }
  }
  get _iconSize() {
    return this.size === "xl" ? "md" : "sm";
  }
  get _icon() {
    return y(this.icon, this.status);
  }
  get _iconFill() {
    return m(this.status);
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !1, composed: !1 }));
  }
  _isInformativeStatus() {
    return _(this.status);
  }
  _checkTextTruncated() {
    const t = this.shadowRoot?.querySelector(".dss-badge-button__label");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("label") && this._checkTextTruncated();
  }
  async firstUpdated() {
    if (await this.updateComplete, this.width) {
      const t = this.shadowRoot?.querySelector(".dss-badge-button");
      t && (t.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  render() {
    return w(this);
  }
};
l.shadowRootOptions = {
  ...u.shadowRootOptions,
  delegatesFocus: !0
};
let e = l;
i([
  s({ type: String })
], e.prototype, "type", 2);
i([
  s({ type: String })
], e.prototype, "icon", 2);
i([
  s({ type: String })
], e.prototype, "size", 2);
i([
  s({ type: String })
], e.prototype, "status", 2);
i([
  s({ type: String })
], e.prototype, "label", 2);
i([
  s({ type: String })
], e.prototype, "action", 2);
i([
  s(a)
], e.prototype, "disabled", 2);
i([
  s(a)
], e.prototype, "hidden", 2);
i([
  s(a)
], e.prototype, "hideIcon", 2);
i([
  s(a)
], e.prototype, "outlined", 2);
i([
  s({ type: String })
], e.prototype, "width", 2);
i([
  s({ type: String })
], e.prototype, "state", 1);
export {
  e as BadgeButton
};
//# sourceMappingURL=badge-button.js.map
