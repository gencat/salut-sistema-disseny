import { nothing as b } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as l, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
const t = l`dss-icon${d($())}`, a = l`dss-tooltip${d($())}`, g = (s) => i`
  <button
    type=${s.type}
    class=${e({
  "dss-badge-button": !0,
  [`dss-badge-button--${s.size}`]: !!s.size,
  [`dss-badge-button--${s.size}`]: !!s.size,
  [`dss-badge-button--${s.status}`]: !!s.status,
  [`dss-badge-button--${s.status}-outlined`]: !!s.status && s.outlined && s._isInformativeStatus()
})}
    ?disabled=${s.disabled}
    ?hidden=${s.hidden}
    @click=${s._handleClick}
  >
		${s.hideIcon && s._isInformativeStatus() ? b : i`
				<${t} 
					class="dss-badge-button__icon" 
					icon="${s._icon}" 
					size="${s._iconSize}" 
					?fill="${s._iconFill}">
				</${t}>
			`}
		<span class="dss-badge-button__label">${s.label}</span>
		<div class="dss-badge-button__action">
			<${t} class="dss-badge-button__icon" icon="${s._actionIcon}" size="${s._iconSize}"></${t}>
		</div>
		${s._isTextTruncated ? i`<${a}>${s.label}</${a}>` : i`<slot name="tooltip"></slot>`}
  </button>
`;
export {
  g as template
};
//# sourceMappingURL=badge-button.template.js.map
