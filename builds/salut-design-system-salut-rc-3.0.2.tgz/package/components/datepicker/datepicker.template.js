import { nothing as i } from "lit";
import { classMap as s } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as r, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const $ = r`dss-icon${l(u())}`, d = r`dss-icon-button${l(u())}`, t = r`dss-tooltip${l(u())}`, b = r`dss-calendar${l(u())}`, g = (a) => e`
  <div class="${s({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": a.required,
  "dss-input-wrapper--disabled": a.disabled,
  [`dss-input-wrapper--${a.size}`]: !!a.size,
  "dss-input-wrapper--no-label": a.hideLabel
})}">
  
      ${a.size === "sm" && !a.hideLabel ? e`
        <div class="${s({
  "dss-wrapper-label": !0,
  "dss-wrapper-label--invalid": a.invalid
})}">
          <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
        </div>
        ` : i}
  
      <div class="${s({
  "dss-input-group": !0,
  [`dss-input-group--${a.size}`]: !!a.size,
  "dss-input-group--invalid": a.invalid || !a._inputValidity,
  "dss-input-group--required": a.required,
  "dss-input-group--disabled": a.disabled,
  "dss-input-group--focused": a.value || a._input?.value || a.placeholder || a._isFocused,
  "dss-input-group--read-only": a.readonly,
  "dss-input-group--no-label": a.hideLabel,
  "dss-input-group--read-only-empty": a.readonly && a.placeholder === "" && !a.value
})}"
        role="combobox"
        aria-controls="datepicker-calendar"
        aria-expanded=${a.showCalendar ? "true" : "false"}
        aria-haspopup="dialog"
        aria-owns="datepicker-calendar"
      >
  
        ${a.icon ? e`
          <${$} icon="${a.icon}" class="dss-input-icon"></${$}>
          ` : i}
  
        <div class="dss-input-field">
        
          ${a.size !== "sm" && !a.hideLabel ? e`
            <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
            ` : i}
  
          <input
            class="dss-input"
            id=${a._getEffectiveId()}
            .type=${a.type}
            .name="${a.name ?? i}"
            .placeholder=${a.placeholder}
            .value=${a.value}
            ?disabled=${a.disabled}
            ?readonly=${a.readonly}
            ?required=${a.required}
            ?autofocus=${a.autofocus}
            spellcheck=${a.spellcheck ? "true" : "false"}
            autocorrect=${a.autocorrect ? "on" : "off"}
            autocomplete=${a.autocomplete}
            autocapitalize=${a.autocapitalize}
            pattern=${a.pattern ?? i}
            inputmode=${a.inputmode ?? i}
            aria-label="${a.hideLabel ? a.label : i}"
            @input=${a._handleInput}
            @focusin=${a._handleFocusin}
            @keydown=${a._handleKeydown}
          />

          ${!a.showCalendar && a._isTruncated ? e`
              <${t} aria-hidden="true">${a._input?.value}</${t}>
            ` : i}
  
        </div>

        ${!a.hasStepper && a._input?.value ? e`
            <${d}
              class="dss-datepicker-clear-button"
              hideTooltip
              label="Netejar"
              size="md"
              icon="close"
              @onClick=${a._clearDate}
              ?hidden=${!a._input?.value || a.readonly || a.disabled}
            ></${d}>
          ` : i}

        ${a.hasStepper && a._input?.value && a.isValidDate() ? e`
          <div class="${s({
  "dss-datepicker-stepper-divider": !0,
  [`dss-datepicker-stepper-divider--${a.size}`]: !!a.size
})}"
          >
          </div>
          <div class="dss-datepicker-stepper-arrows">
            <${d}
              size="md"
              icon="chevron_left"
              hideTooltip
              label="Data anterior"
              @onClick=${a._prevDate}
              ?disabled=${a._isPrevDateDisabled()}
              ?hidden=${a.readonly || a.disabled}
            ></${d}>

            <${d}
              size="md"
              icon="chevron_right"
              hideTooltip
              label="Següent data"
              @onClick=${a._nextDate}
              ?disabled=${a._isNextDateDisabled()}
              ?hidden=${a.readonly || a.disabled}
            ></${d}>
          
          </div>
          ` : i}

        <${b}
          role="listbox"
          aria-label="Datepicker Calendar"
          id="datepicker-calendar"
          class="${s({
  [`dss-calendar ${a._getEffectiveId()}-calendar`]: !0,
  // 'dss-calendar--visible': component.showCalendar && !component.readonly,
  // 'dss-calendar--disabled': component.disabled,
  "dss-calendar--md": a.size !== "lg"
})}"
          .open=${a.showCalendar && !a.readonly}
          ?disabled=${a.disabled}
          .selectedDate=${a.value}
          .showTime=${a.showTime}
          .showButtons=${a.showButtons}
          .leftLabel=${a.leftLabel}
          .rightLabel=${a.rightLabel}
          .minDate=${a.minDate}
          .maxDate=${a.maxDate}
          timepickerLabel=${a.timepickerLabel}
          .timepicker=${a.timepicker}
          .customCalendar=${a.customCalendar}
          .customTimeListOptions=${a.customTimeListOptions}
          .minutesRange=${a.minutesRange}
          .minHour=${a.minHour}
          .maxHour=${a.maxHour}
          @date-changed=${a._onDateChange}
          @cancel=${a._onCancel}
          @calendar-focusout=${a._handleCalendarFocusOut}
        ></${b}>
  
      </div>
      
      ${a._helpText ? e`
        <div class="${s({
  "dss-input-help": !0,
  "dss-input-help--invalid": a.invalid,
  "dss-input-help--disabled": a.disabled
})}">
          <span>${a._helpText}</span>
        </div>
        ` : i}

      
    </div> 


  
`;
export {
  g as template
};
//# sourceMappingURL=datepicker.template.js.map
