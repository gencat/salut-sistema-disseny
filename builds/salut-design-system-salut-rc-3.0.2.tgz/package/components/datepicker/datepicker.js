import { LitElement as g, unsafeCSS as _ } from "lit";
import { query as m, property as a, state as d } from "lit/decorators.js";
import { getPortalContainer as b } from "../../api/portal-manager/portal-manager.js";
import D from "../../shared/reset.style.css.js";
import { booleanType as h, booleanConverter as c } from "../../utils/property-types.js";
import C from "../input/input.style.css.js";
import T from "./datepicker.style.css.js";
import { template as S } from "./datepicker.template.js";
var x = Object.defineProperty, s = (y, t, e, r) => {
  for (var n = void 0, o = y.length - 1, l; o >= 0; o--)
    (l = y[o]) && (n = l(t, e, n) || n);
  return n && x(t, e, n), n;
};
const f = class f extends g {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "calendar_today", this.showCalendar = !1, this.showTime = !1, this.showButtons = !1, this.leftLabel = "Cancel·lar", this.rightLabel = "Seleccionar", this.minDate = "", this.maxDate = "", this.timepicker = "", this.timepickerLabel = "Selecciona una hora", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this.customCalendar = void 0, this.customTimeListOptions = [], this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this.hasStepper = !1, this._defaultId = `dss-datepicker-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._externalPlaceholder = "", this._previousDate = "", this._inputValidity = !0, this._placeholder = "", this._helpText = "", this._helpTextBackup = "", this._oldHelpText = "", this._isFirstUpdated = !0, this._portalManager = null, this._backFromCalendar = !1, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this.showCalendar && this._closeCalendar();
      },
      {
        root: null,
        threshold: 0
      }
    ), this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [_(D), _(C), _(T)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeCalendarListener(), this.visibleObserver.disconnect(), this.showCalendar && this._closeCalendar();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.visibleObserver.observe(this._input), this._helpTextBackup = this.helpText ?? "", this._portalManager = b(), this._enableAnimations(), this._input.classList.add("dss-input-skip-native"), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && queueMicrotask(() => {
      this._input.value = this.value, this.internals.setFormValue(this.value);
    }), t.has("placeholder") && queueMicrotask(() => {
      this._placeholder = this.placeholder, this._externalPlaceholder = this.placeholder;
    }), t.has("showTime") && this.showTime && queueMicrotask(() => {
      this.showButtons = !0;
    }), t.has("helpText") && queueMicrotask(() => {
      this._helpText = this.helpText ?? "", this._oldHelpText = this.helpText ?? "";
    });
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  render() {
    return S(this);
  }
  /* Handle Input Events */
  _handleInput(t) {
    const e = t.target.value?.replace(/\D/g, "");
    this._input && (this._input.value = this._formatDate(e), this.value = this._formatDate(e), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _handleFocusin() {
    this._backFromCalendar || this._isFocused || this.readonly || (this._externalPlaceholder !== "" ? this._placeholder = this._externalPlaceholder : this._placeholder = this.showTime ? "DD/MM/AAAA HH:MM" : "DD/MM/AAAA", this._input?.setAttribute("placeholder", this._placeholder), this.showCalendar = !0, this._addCalendarListener(), this._isFocused = !0, this._disableAnimations(), this._backFromCalendar = !1);
  }
  _focusInput() {
    !this.disabled && !this.readonly && this._input?.focus();
  }
  _handleKeydown(t) {
    if (t?.key === "Tab" ? (this._isFocused = !0, this._checkInputOverflow(), this.showCalendar && (t.preventDefault(), t.stopPropagation(), this._getPortalCalendar()._focusFirstElement())) : t?.key === "Enter" || t?.key === " " ? (this.showCalendar = !0, this._checkInputOverflow(), this._addCalendarListener(), this._disableAnimations()) : t?.key === "Escape" && this._closeCalendar(), t.key === "Enter" && this._input && this._input.value?.length > 7 && this._input) {
      const e = this._input.value?.replace(/(\d+[/])(\d+[/])/, "$2$1"), r = new Date(e), n = r.getDate()?.toString().padStart(2, "0"), o = (r.getMonth() + 1).toString().padStart(2, "0"), l = r.getFullYear(), p = r.getHours()?.toString().padStart(2, "0"), u = r.getMinutes()?.toString().padStart(2, "0");
      let v = `${n}/${o}/${l}`;
      this.showTime && (v += ` ${p}:${u}`, this._handleValidity()), this._input && (this._input.value = v), this._dispatchValueChange(), this.showCalendar ? this._closeCalendar() : this.requestUpdate();
    }
  }
  _handleCalendarFocusOut() {
    this.readonly || this.disabled || this.showCalendar && (this._backFromCalendar = !0, this._closeCalendar(), setTimeout(() => {
      this._input?.focus();
    }, 0));
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, n = document.createElement("canvas").getContext("2d");
    if (!n) return;
    n.font = e;
    const o = n.measureText(this._input.value).width;
    this._isTruncated = o > this._input.offsetWidth;
  }
  /* Hamdle Datepicker Validations */
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t), this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _validateDate() {
    const t = this._checkDateFormat(this._input?.value);
    t ? (this._input.setCustomValidity(this._helpText), this.internals.setValidity({ customError: !0 }, this._helpText, this._input)) : (this._input.setCustomValidity(""), this.internals.setValidity({})), this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    const e = this.showTime ? 16 : 10;
    if (t === "")
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t.length < e)
      return this._helpText = this.errorMessageFormat, this.invalid = !0, !0;
    if (this.minDate || this.maxDate) {
      const r = this.showTime ? t.substring(0, 10) : t, n = new Date(this._convertToISO(r)), o = new Date(this._convertToISO(this.minDate)), l = new Date(this._convertToISO(this.maxDate));
      if (o && n < o)
        return this._helpText = this.errorMessageMinDate, this.invalid = !0, !0;
      if (l && n > l)
        return this._helpText = this.errorMessageMaxDate, this.invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
  }
  _convertToISO(t) {
    const [e, r, n] = t.split("/");
    return `${n}-${r}-${e}`;
  }
  _dispatchOnValidate(t) {
    const e = {
      detail: {
        date: this._input?.value,
        invalid: t,
        status: this.invalid ? "INVALID" : "VALID"
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("value-changed", e));
  }
  // Datepicker specific methods
  _formatDate(t) {
    let e = t.substring(0, 2), r = t.substring(2, 4);
    const n = t.substring(4, 8);
    let o = t.substring(8, 10), l = t.substring(10, 12);
    Number(e) > 3 && (e = e?.padStart(2, "0")), Number(r) > 1 && (r = r?.padStart(2, "0")), Number(e) > 31 && (e = "31"), Number(r) > 12 && (r = "12"), r === "02" && Number(e) > 28 && n?.length === 4 && (e = new Date(Number(n), 1, 29).getMonth() === 1 ? "29" : "28");
    let p = `${e}${r ? `/${r}` : ""}${n ? `/${n}` : ""}`;
    return this.showTime && (Number(o) > 2 && (o = o?.padStart(2, "0")), Number(o) > 23 && (o = "23"), Number(l) > 5 && (l = l?.padStart(2, "0")), p = `${p}${o ? ` ${o}` : ""}${l ? `:${l}` : ""}`), p;
  }
  _onDateChange(t) {
    const e = t.detail;
    this._input && (this._input.value = e, this.value = e, this._handleValidity()), this._closeCalendar(), this._dispatchValueChange();
  }
  _onCancel() {
    this._closeCalendar(), this._input && (this._input.value = this._previousDate || "", this._handleValidity()), this.requestUpdate();
  }
  _dispatchValueChange() {
    this._emitInput(), this._emitChange();
  }
  _clearDate() {
    this._input && (this._input.value = "", this._input.setCustomValidity(""), this.internals.setValidity({}), this.value = "", this._handleValidity(), this._helpText = this._helpTextBackup, this.invalid = this._input ? !this._input.checkValidity() : !1, this._dispatchValueChange(), this.requestUpdate());
  }
  _closeCalendar() {
    this._removeCalendarListener(), this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this.showCalendar = !1, this._input?.blur(), this.validate && this._validateDate(), setTimeout(() => {
      this._enableAnimations();
    }, 400), this._checkInputOverflow(), this.requestUpdate();
  }
  _checkClickOutside(t) {
    const e = t.composedPath(), r = `${this._getEffectiveId()}-calendar`, n = this._portalManager?.querySelector(`.${r}`);
    !e.includes(this) && !e.includes(n) && this.showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget, r = this._getPortalCalendar();
    e !== null && e !== this && e !== this._input && e !== this._label && e !== this._calendar && e !== r && this.showCalendar && this._closeCalendar();
  }
  _getPortalCalendar() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-calendar`);
  }
  _enableAnimations() {
    this._calendar.classList.add("animation-enabled");
  }
  _disableAnimations() {
    setTimeout(() => {
      this._getPortalCalendar()?.classList.remove("animation-enabled");
    }, 240);
  }
  _prevDate() {
    if (!this._input) return;
    const t = this._input?.value, e = this._currentValueToDate(t || "");
    e.setDate(e.getDate() - 1);
    const r = this._newDateToValue(e);
    this._input.value = r, this.value = r, this._handleValidity(), this._dispatchValueChange(), this._checkInputOverflow(), this.requestUpdate();
  }
  _nextDate() {
    if (!this._input) return;
    const t = this._input?.value, e = this._currentValueToDate(t || "");
    e.setDate(e.getDate() + 1);
    const r = this._newDateToValue(e);
    this._input.value = r, this.value = r, this._handleValidity(), this._dispatchValueChange(), this._checkInputOverflow(), this.requestUpdate();
  }
  _isPrevDateDisabled() {
    const t = this._getDateFromValue(this.value || this._input?.value), e = this._getDateFromValue(this.minDate);
    return !t || !e ? !1 : t <= e;
  }
  _isNextDateDisabled() {
    const t = this._getDateFromValue(this.value || this._input?.value), e = this._getDateFromValue(this.maxDate);
    return !t || !e ? !1 : t >= e;
  }
  _currentValueToDate(t) {
    const e = t?.split(" ")[0].split("/"), r = Number.parseInt(e ? e[0] : "0", 10), n = Number.parseInt(e ? e[1] : "0", 10) - 1, o = Number.parseInt(e ? e[2] : "0", 10), l = new Date(o, n, r);
    return new Date(l);
  }
  _getDateFromValue(t) {
    if (!t) return null;
    const r = (this.showTime ? t.substring(0, 10) : t).split("/");
    if (r.length !== 3) return null;
    const [n, o, l] = r;
    if (!n || !o || !l) return null;
    const p = this._convertToISO(`${n}/${o}/${l}`), u = new Date(p);
    return Number.isNaN(u.getTime()) ? null : u;
  }
  _newDateToValue(t) {
    const e = t.getDate().toString().padStart(2, "0"), r = (t.getMonth() + 1).toString().padStart(2, "0"), n = t.getFullYear();
    return `${e}/${r}/${n}`;
  }
  isValidDate() {
    if (!this._input) return !1;
    const t = this._input.value?.split(" ")[0].split("/");
    if (!t || t.length !== 3) return !1;
    const e = Number.parseInt(t[0], 10), r = Number.parseInt(t[1], 10) - 1, n = Number.parseInt(t[2], 10), o = new Date(n, r, e);
    return !Number.isNaN(o.getTime());
  }
};
f.formAssociated = !0;
let i = f;
s([
  m("input.dss-input")
], i.prototype, "_input");
s([
  m("label.dss-label")
], i.prototype, "_label");
s([
  a({ type: String })
], i.prototype, "label");
s([
  a(h)
], i.prototype, "hideLabel");
s([
  a({ type: String })
], i.prototype, "name");
s([
  a({ type: String })
], i.prototype, "id");
s([
  a({ type: String })
], i.prototype, "type");
s([
  a({ type: String })
], i.prototype, "placeholder");
s([
  a({ type: String })
], i.prototype, "value");
s([
  a({ converter: c, reflect: !0 })
], i.prototype, "disabled");
s([
  a({ converter: c, reflect: !0 })
], i.prototype, "readonly");
s([
  a({ converter: c, reflect: !0 })
], i.prototype, "required");
s([
  a({ converter: c, reflect: !0 })
], i.prototype, "invalid");
s([
  a({ type: Number })
], i.prototype, "step");
s([
  a({ type: Number })
], i.prototype, "min");
s([
  a({ type: Number })
], i.prototype, "max");
s([
  a({ type: Number })
], i.prototype, "minLength");
s([
  a({ type: String })
], i.prototype, "pattern");
s([
  a({ type: String })
], i.prototype, "inputmode");
s([
  a({ type: String })
], i.prototype, "autocapitalize");
s([
  a({ type: String })
], i.prototype, "autocomplete");
s([
  a(h)
], i.prototype, "autocorrect");
s([
  a(h)
], i.prototype, "autofocus");
s([
  a(h)
], i.prototype, "spellcheck");
s([
  a({ type: String })
], i.prototype, "size");
s([
  a({ type: String })
], i.prototype, "icon");
s([
  a({ type: String })
], i.prototype, "helpText");
s([
  a(h)
], i.prototype, "showCalendar");
s([
  a(h)
], i.prototype, "showTime");
s([
  a(h)
], i.prototype, "showButtons");
s([
  a({ type: String })
], i.prototype, "leftLabel");
s([
  a({ type: String })
], i.prototype, "rightLabel");
s([
  a({ type: String })
], i.prototype, "minDate");
s([
  a({ type: String })
], i.prototype, "maxDate");
s([
  a({ type: String })
], i.prototype, "timepicker");
s([
  a({ type: String })
], i.prototype, "timepickerLabel");
s([
  a({ type: Number })
], i.prototype, "minHour");
s([
  a({ type: Number })
], i.prototype, "maxHour");
s([
  a({ type: Number })
], i.prototype, "minutesRange");
s([
  a({ type: Array })
], i.prototype, "customCalendar");
s([
  a({ type: Array })
], i.prototype, "customTimeListOptions");
s([
  a(h)
], i.prototype, "validate");
s([
  a(h)
], i.prototype, "errorMessageFormat");
s([
  a(h)
], i.prototype, "errorMessageMinDate");
s([
  a(h)
], i.prototype, "errorMessageMaxDate");
s([
  a(h)
], i.prototype, "hasStepper");
s([
  d()
], i.prototype, "_isFocused");
s([
  d()
], i.prototype, "_isTruncated");
s([
  d()
], i.prototype, "_helpText");
s([
  m(".dss-calendar")
], i.prototype, "_calendar");
s([
  d()
], i.prototype, "_backFromCalendar");
export {
  i as Datepicker
};
//# sourceMappingURL=datepicker.js.map
