import { LitElement as c, unsafeCSS as l } from "lit";
import { property as s, state as n } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as h } from "../../utils/property-types.js";
import v from "./upload-file.style.css.js";
import { template as m } from "./upload-file.template.js";
var _ = Object.defineProperty, e = (a, o, p, u) => {
  for (var i = void 0, r = a.length - 1, d; r >= 0; r--)
    (d = a[r]) && (i = d(o, p, i) || i);
  return i && _(o, p, i), i;
};
class t extends c {
  constructor() {
    super(...arguments), this.state = "uploading", this.fileName = "", this.message = void 0, this.disableActions = !1, this.disableOpenFile = !1, this._decorativeIcon = "downloading", this._decorativeState = "info", this._isTruncated = !1, this._fileEventOptions = {
      detail: {
        fileName: this.fileName
      },
      bubbles: !0,
      composed: !0
    };
  }
  static get styles() {
    return [l(f), l(v)];
  }
  /* METHODS */
  _updateState() {
    switch (this.state) {
      case "uploading":
        this._decorativeIcon = "downloading", this._decorativeState = "info";
        break;
      case "error":
        this._decorativeIcon = "error", this._decorativeState = "danger";
        break;
      case "uploaded":
        this._decorativeIcon = "check", this._decorativeState = "success";
        break;
    }
  }
  _handleOpen() {
    this.dispatchEvent(new CustomEvent("open", this._fileEventOptions));
  }
  _handleStop() {
    this.dispatchEvent(new CustomEvent("stop", this._fileEventOptions));
  }
  _handleReload() {
    this.dispatchEvent(new CustomEvent("reload", this._fileEventOptions));
  }
  _handleDelete() {
    this.dispatchEvent(new CustomEvent("delete", this._fileEventOptions));
  }
  updated(o) {
    o.has("state") && queueMicrotask(() => {
      this._updateState();
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._fileEventOptions.detail.fileName = this.fileName;
  }
  render() {
    return m(this);
  }
}
e([
  s({ type: String })
], t.prototype, "state");
e([
  s({ type: String })
], t.prototype, "fileName");
e([
  s({ type: String })
], t.prototype, "message");
e([
  s(h)
], t.prototype, "disableActions");
e([
  s(h)
], t.prototype, "disableOpenFile");
e([
  n()
], t.prototype, "_decorativeIcon");
e([
  n()
], t.prototype, "_decorativeState");
e([
  n()
], t.prototype, "_isTruncated");
export {
  t as UploadFile
};
//# sourceMappingURL=upload-file.js.map
