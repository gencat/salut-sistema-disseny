import { nothing as d } from "lit";
import { checkTextTruncate as c } from "../../utils/helpers.js";
import { unsafeStatic as s, literal as l, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const r = l`dss-decorative-icon${s(t())}`, e = l`dss-icon-button${s(t())}`, $ = l`dss-tooltip${s(t())}`, n = (i) => a`
    <div class="upload-file">
      
      <${r} icon="${i._decorativeIcon}" size="sm" state="${i._decorativeState}">
      </${r}>

      <div class="upload-file-description">

        <div class="upload-file-description__name" @mouseenter=${c}>
          ${i.state === "uploading" ? a`
            ${i.fileName} <span class="dot-flashing"></span>
            ` : !i.disableOpenFile && i.state === "uploaded" ? a`
                <span class="upload-file-description__link" @click="${() => i._handleOpen()}">
                  ${i.fileName}
                </span>
              ` : a`
                ${i.fileName}
              `}
          <${$} aria-hidden="true">${i.fileName}</${$}>
        </div>

        ${i.state === "error" && i.message ? a`
              <p class="upload-file-description__error">
                ${i.message}
              </p>
            ` : d}      
      </div>

      ${i.disableActions ? d : a`
        <div class="upload-file-actions">
          ${i.state === "uploading" ? a`
                <${e}
                size="sm"
                icon="block"
                variant="danger"
                label="Cancel·lar"
                hideTooltip
                @click="${() => i._handleStop()}"
                ></${e}>
              ` : a`
                ${i.state === "error" ? a`
                      <${e}
                      size="sm"
                      label="Recarregar"
                      icon="restart_alt"
                      variant="primary"
                      hideTooltip
                      @click="${() => i._handleReload()}"
                      ></${e}>
                    ` : a``}
                <${e}
                size="sm"
                icon="delete"
                label="Eliminar"
                variant="danger"
                hideTooltip
                @click="${() => i._handleDelete()}"
                ></${e}>
              `}
        </div>
        `}
    </div>
  `;
export {
  n as template
};
//# sourceMappingURL=upload-file.template.js.map
