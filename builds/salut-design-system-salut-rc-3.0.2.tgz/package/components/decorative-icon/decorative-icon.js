import { LitElement as m, unsafeCSS as a } from "lit";
import { property as e } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as f } from "../../utils/property-types.js";
import d from "./decorative-icon.style.css.js";
import { template as u } from "./decorative-icon.template.js";
var c = Object.defineProperty, r = (i, p, l, h) => {
  for (var t = void 0, s = i.length - 1, n; s >= 0; s--)
    (n = i[s]) && (t = n(p, l, t) || t);
  return t && c(p, l, t), t;
};
class o extends m {
  constructor() {
    super(...arguments), this.icon = void 0, this.state = "default", this.size = "md", this.disabled = !1, this.fill = !1;
  }
  static get styles() {
    return [a(y), a(d)];
  }
  render() {
    return u(this);
  }
}
r([
  e({ type: String })
], o.prototype, "icon");
r([
  e({ type: String })
], o.prototype, "state");
r([
  e({ type: String })
], o.prototype, "size");
r([
  e(f)
], o.prototype, "disabled");
r([
  e(f)
], o.prototype, "fill");
export {
  o as DecorativeIcon
};
//# sourceMappingURL=decorative-icon.js.map
