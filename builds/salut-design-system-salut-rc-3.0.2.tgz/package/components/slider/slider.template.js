import { classMap as i } from "lit/directives/class-map.js";
import { html as r } from "lit/static-html.js";
const t = (s) => {
  const d = {
    "dss-slider--vertical": s._vertical
  }, l = {
    "dss-slider-tooltip--active": s._isTooltipTouched
  };
  return r`
    <div class="dss-slider-wrapper ${i(d)}">
      <input
        id="dss-slider-input"
        aria-label="${s.label}"
        type="range"
        class="dss-slider"
        min=${s.min}
        max=${s.max}
        .value=${s.value?.toString()}
        step=${s.step}
        direction="${s.orientation}"
        @input="${s._handleInput}"
        style="--progress: ${`${s._progress}%`}"
        ?disabled="${s.disabled}"
      />
      <div
        class="dss-slider-tooltip ${i(l)}"
        id="dss-slider-tooltip"
      ></div>
      <div class="dss-slider-info dss-slider-info--min">${s.min}</div>
      <div class="dss-slider-info dss-slider-info--medium">
        ${Math.round((s.max + s.min) / 2)}
      </div>
      <div class="dss-slider-info dss-slider-info--max">${s.max}</div>
      <div></div>
    </div>
  `;
};
export {
  t as template
};
//# sourceMappingURL=slider.template.js.map
