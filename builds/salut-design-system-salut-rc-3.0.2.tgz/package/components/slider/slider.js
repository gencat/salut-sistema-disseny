import { LitElement as c, unsafeCSS as _ } from "lit";
import { property as o, state as p } from "lit/decorators.js";
import { booleanType as v } from "../../utils/property-types.js";
import m from "./slider.style.css.js";
import { template as E } from "./slider.template.js";
var y = Object.defineProperty, f = Object.getOwnPropertyDescriptor, s = (u, t, e, h) => {
  for (var i = h > 1 ? void 0 : h ? f(t, e) : t, r = u.length - 1, a; r >= 0; r--)
    (a = u[r]) && (i = (h ? a(t, e, i) : a(i)) || i);
  return h && i && y(t, e, i), i;
};
class n extends c {
  constructor() {
    super(), this.label = "Input range", this.value = 0, this.min = 0, this.max = 0, this.step = 1, this.orientation = "horizontal", this.disabled = !1, this._progress = 0, this._vertical = !1, this._isTooltipTouched = !1, this._handleDomContentLoaded = this._updateTooltip.bind(this), this._handleInputEvent = this._updateTooltip.bind(this), this._handleMouseUp = this._dispatchValue.bind(this), this._handleKeyUp = this._dispatchValue.bind(this), this._handleTouchStartEvent = this._handleTouchStart.bind(this), this._handleTouchMoveEvent = this._handleTouchMove.bind(this), this._handleTouchEndEvent = this._handleTouchEnd.bind(this);
  }
  static get styles() {
    return _(m);
  }
  get _input() {
    return this.shadowRoot?.querySelector("input");
  }
  get _tooltip() {
    return this.shadowRoot?.querySelector("#dss-slider-tooltip");
  }
  set orient(t) {
    this.orientation = t;
  }
  get orient() {
    return this.orientation;
  }
  updated(t) {
    (t.has("value") || t.has("max")) && queueMicrotask(() => {
      this.max >= this.value && this._setProgress();
    }), t.has("orientation") && queueMicrotask(() => {
      this._vertical = this.orientation === "vertical";
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._setProgress(), document.addEventListener("DOMContentLoaded", this._handleDomContentLoaded), this._input.addEventListener("input", this._handleInputEvent), this._input.addEventListener("mouseup", this._handleMouseUp), this._input.addEventListener("keyup", this._handleKeyUp), this._input.addEventListener("touchstart", this._handleTouchStartEvent), this._input.addEventListener("touchmove", this._handleTouchMoveEvent), this._input.addEventListener("touchend", this._handleTouchEndEvent);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("DOMContentLoaded", this._handleDomContentLoaded), this._input?.removeEventListener("input", this._handleInputEvent), this._input?.removeEventListener("mouseup", this._handleMouseUp), this._input?.removeEventListener("keyup", this._handleKeyUp), this._input?.removeEventListener("touchstart", this._handleTouchStartEvent), this._input?.removeEventListener("touchmove", this._handleTouchMoveEvent), this._input?.removeEventListener("touchend", this._handleTouchEndEvent);
  }
  _handleTouchStart(t) {
    this._vertical && t.preventDefault(), this._isTooltipTouched = !0;
  }
  _handleTouchEnd(t) {
    this._vertical && t.preventDefault(), this._isTooltipTouched = !1, this._dispatchValue();
  }
  _handleTouchMove(t) {
    if (this._vertical) {
      if (!t.target) return;
      const e = t.target, h = Number.parseInt(e.max, 10), i = Number.parseInt(e.min, 10), r = t.touches[0], a = e.getBoundingClientRect(), l = (r.clientY - a.top) / a.height, d = Math.round(l * (h - i) + i);
      e.value = String(h - d + i), e.dispatchEvent(new Event("input"));
    }
  }
  _handleInput() {
    if (this._input) {
      const t = Number.parseFloat(this._input.value);
      this._progress = Math.round((t - this.min) / (this.max - this.min) * 100);
    }
  }
  _setProgress() {
    this._input && (this._input.value = this.value.toString()), this._progress = Math.round((this.value - this.min) / (this.max - this.min) * 100);
  }
  _updateTooltip() {
    if (this._tooltip) {
      const t = Number((+this._input.value - +this.min) * 100 / (+this.max - +this.min)), e = 10 - t * 0.2;
      this._tooltip.innerHTML = `<span class="tooltip-wrapper"><span class="tooltip-value">${this._input.value}</span></span>`, this._tooltip.style.left = `calc(${t}% + (${e}px))`;
    }
  }
  _dispatchValue() {
    const t = {
      detail: this._input.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("value-changed", t));
  }
  render() {
    return E(this);
  }
}
s([
  o({ type: String })
], n.prototype, "label", 2);
s([
  o({ type: Number })
], n.prototype, "value", 2);
s([
  o({ type: Number })
], n.prototype, "min", 2);
s([
  o({ type: Number })
], n.prototype, "max", 2);
s([
  o({ type: Number })
], n.prototype, "step", 2);
s([
  o({ type: Number })
], n.prototype, "orientation", 2);
s([
  o(v)
], n.prototype, "disabled", 2);
s([
  p()
], n.prototype, "_progress", 2);
s([
  p()
], n.prototype, "_vertical", 2);
s([
  p()
], n.prototype, "_isTooltipTouched", 2);
s([
  o({ type: String })
], n.prototype, "orient", 1);
export {
  n as Slider
};
//# sourceMappingURL=slider.js.map
