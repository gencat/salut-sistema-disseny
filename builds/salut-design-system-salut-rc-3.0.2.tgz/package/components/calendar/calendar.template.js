import { classMap as f } from "lit/directives/class-map.js";
import { unsafeStatic as _, literal as u, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { MONTH as g, WEEK as D } from "./calendar.js";
const b = u`dss-timepicker${_(o())}`, n = u`dss-icon${_(o())}`, s = u`dss-icon-button${_(o())}`, c = u`dss-button${_(o())}`, A = (e) => i`
  <div
    class=${f({
  calendar__container: !0,
  "calendar__container--standalone": e.standalone
})}
    @keydown="${e._handleCalendarKeydown}"
    @focusout="${e._handleCalendarFocusOut}"
  >
    <div class="calendar__content">
      <div class="calendar__header">
        <div class="calendar__header-item calendar__header-selector">
          <div
            id="firstCalendarElement"
            class="calendar__header-item calendar__header-item--click calendar__header-month"
            tabindex="0"
            role="button"
            @keydown="${e._onHeaderMonthKeyDown}"
            @click="${e._toggleMonthSelector}"
            aria-label="selecciona el mes, actualment ${g[e._currMonth]}"
          >
            ${g[e._currMonth]}
            <${n} icon="expand_more" size="sm"></${n}>
          </div>
          <div
            class="calendar__header-item calendar__header-item--click calendar__header-year"
            tabindex="0"
            role="button"
            @keydown="${e._onHeaderYearKeyDown}"
            @click=${e._toggleYearSelector}
            aria-label="selecciona l'any, actualment ${e._currYear}"
          >
            ${e._currYear}
            <${n} icon="expand_more" size="sm"></${n}>
          </div>
        </div>
        <div class="calendar__header-item calendar__header-buttons">
          <${s} hideTooltip variant="primary" icon="chevron_left" label="Anterior" @click=${e._prev}
            ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
          </${s}>
          <${s} hideTooltip variant="primary" icon="chevron_right" label="Següent" @click=${e._next}
            ?disabled=${e._currMonth === e._maxDate?.getMonth() && e._currYear === e._maxDate?.getFullYear()}>
          </${s}>
        </div>
      </div>

      <div class="calendar__days-content">
        <ul class="calendar__week-names">
          ${D.map((r) => i`<li>${r}</li>`)}
        </ul>
        <div
          class="calendar__days"
          @mouseleave=${e._removeRangeOverDate}
        >
          ${e._days.map((r) => {
  if (!r)
    return i`
                <span class="calendar__day-item calendar__day-item--empty" aria-hidden="true"></span>
              `;
  const m = {
    "calendar__day-item--active": e._isToday(r),
    "calendar__day-item--weekend": e._isWeekend(r),
    "calendar__day-item--selected": e._isSelected(r),
    [`calendar__day-item--${e._getCustomType(r)}`]: !!e._getCustomType(r),
    "calendar__day-item--range": e._isBetweenRange(r) || e._isBetweenRangeOnMouseOver(r),
    "calendar__day-item--selected-range-start": e._isSelectedRangeStart(r),
    "calendar__day-item--selected-range-end": e._isSelectedRangeEnd(r) || e._isOverRangeDate(r),
    "calendar__day-item--range-enabled": e._range
  }, k = (l) => {
    const a = l.target;
    if (l.key === "ArrowUp") {
      l.preventDefault();
      const t = h(a, -7);
      t ? t.focus() : v();
    }
    if (l.key === "ArrowDown") {
      l.preventDefault();
      const t = h(a, 7);
      t ? t.focus() : y();
    }
    if (l.key === "ArrowRight") {
      l.preventDefault();
      const t = a.nextElementSibling;
      t ? t.focus() : y();
    }
    if (l.key === "ArrowLeft") {
      l.preventDefault();
      const t = w(a);
      t ? t.focus() : v();
    }
  }, v = () => {
    e._prev(), setTimeout(() => {
      const l = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), a = Array.from(l).filter((d) => !d.disabled), t = a[a.length - 1];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, y = () => {
    e._next(), setTimeout(() => {
      const l = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), t = Array.from(l).filter((d) => !d.disabled)[0];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, w = (l) => {
    let a = l?.previousElementSibling;
    for (; a; ) {
      if (!a.classList.contains("calendar__day-item") || a.classList.contains("calendar__day-item--empty")) {
        a = a.previousElementSibling;
        continue;
      }
      if (!a.disabled)
        return a;
      a = a.previousElementSibling;
    }
    return null;
  }, h = (l, a) => {
    const d = Array.from(
      l.closest(".calendar__days")?.querySelectorAll(".calendar__day-item:not(.calendar__day-item--empty)") || []
    ).filter((x) => !x.disabled), $ = d.indexOf(l) + a;
    return $ < 0 || $ >= d.length ? null : d[$];
  };
  return i`
              <button
                tabindex="${e._isFocusable(r) ? 0 : -1}"
                class="calendar__day-item ${f(m)}"
                @click=${() => e._selectDate(r)}
                @mouseover=${() => e._selectRangeOverDate(r)}
                @focus=${() => e._selectRangeOverDate(r)}
                ?disabled=${e._isInactive(r)}
                @keydown="${k}"
              >
                ${r || null}
              </button>
            `;
})}
        </div>
      </div>
    </div>
    ${e._showMonthSelector ? i`
          <div class="calendar-selector calendar-selector--month">
            <div class="calendar-selector-title">Selecciona un mes</div>
            <div class="calendar-selector-options">
              ${e._generateMonthsOptions()}
            </div>
          </div>
        ` : null}
    ${e._showYearSelector ? i`
          <div class="calendar-selector calendar-selector--year">
            <div
              class="calendar-selector-title calendar-selector-title--years"
            >
              <div class="calendar-selector-title__years">
                ${e._yearsRangeStart} - ${e._yearsRangeEnd}
              </div>
              <div class="calendar-selector-title__actions">
                <${s}
                  hideTooltip
                  variant="primary" 
                  label="Anys anteriors"
                  icon="chevron_left"
                  @click=${e._onYearRangeStepDown}
                ></${s}>
                <${s}
                  hideTooltip
                  variant="primary" 
                  label="Anys posteriors"
                  icon="chevron_right"
                  @click=${e._onYearRangeStepUp}
                ></${s}>
              </div>
            </div>
            <div
              class="calendar-selector-options calendar-selector-options--4col"
            >
              ${e._generateYearsRangeOptions()}
            </div>
          </div>
        ` : null}
    ${e._showTime ? i`
          <div class="dss-datepicker__timepicker">
            <${b}
              label=${e._timepickerLabel}
              .dropdown="${e._timepicker}"
              .customTimeListOptions=${e._customTimeListOptions}
              .minutesRange=${e._minutesRange}
              .minHour=${e._minHour}
              .maxHour=${e._maxHour}
              maxLength="5"
              @value-changed=${e._onSelectTime}
              .value="${e._timepickerValue}"
            >
            </${b}>
          </div>
        ` : null}
    ${(e._showButtons || e._showTime) && !e.standalone ? i`
          <div class="calendar__content calendar__content--buttons">
            <div class="calendar__buttons">
              <${c}
                variant="secondary"
                label=${e._leftLabel}
                @click=${e._onCancel}
              >
              </${c}>
              <${c}
                variant="primary"
                label=${e._rightLabel}

                @click=${e._onAccept}
                ?disabled=${e._validateSelectedDate()}
              >
              </${c}>
            </div>
          </div>
        ` : null}
  </div>
`;
export {
  A as template
};
//# sourceMappingURL=calendar.template.js.map
