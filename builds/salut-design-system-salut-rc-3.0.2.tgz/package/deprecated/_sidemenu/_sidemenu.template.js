import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as i, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const a = i`dss-icon${t(l())}`, u = i`dss-notification-badge${t(l())}`, _ = (e) => s`
  <aside
    class=${d({
  "dss-sidemenu": !0,
  "dss-sidemenu--expanded": !!e._expanded
})}
  >
    <div class="dss-sidemenu-top-menu">
      <slot name="top-menu"></slot>
    </div>

    ${e._hideCreateMenu ? null : s`
          <div
            class="dss-sidemenu-create"
            @focusout="${e._handleCreateFocusout}"
          >
            <button
              class="dss-sidemenu-create__button"
              ?disabled=${e._createDisabled}
              @click="${e._toggleCreateMenu}"
              @mouseenter="${e._handleCreateMouseEnter}"
              @mouseleave="${e._handleCreateMouseLeave}"
              @mousedown="${e._handleCreateMouseDown}"
              @mouseup="${e._handleCreateMouseUp}"
              aria-label="${e._createLabel}"
            >
              <span class="dss-sidemenu-create__button__content">
                <${a} class="dss-sidemenu-create__icon" size="md" icon="add_circle_outline"></${a}>
                ${e._createNotifications && !e._showCreateDropdown ? s`
                      <${u}
                        class=${d({
  "dss-sidemenu-create__notification": !0,
  "dss-sidemenu-create__notification--expanded": !!e._expanded
})}
                        ?dot=${!e._expanded}
                        value="${e._createNotifications}"
                        state="success"
                        type="default"
                        borderWhite
                      />
                    ` : null}
              </span>
              ${e._expanded ? s` ${e._createLabel} ` : null}
            </button>
            <slot name="create-action-menu"></slot>
          </div>
        `}

    <div class="dss-sidemenu-bottom">
      <div class="dss-sidemenu-bottom-menu">
        <slot name="bottom-menu"></slot>
      </div>

      <button
        class="dss-sidemenu-toggle"
        ?disabled=${e._toggleDisabled}
        @click="${e._toggleSidemenu}"
        aria-label="${e._expanded ? "col·lapsar menú" : "expandir menú"}"
      >
        ${e._expanded ? s`
              <${a} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_left"></${a}>
            ` : s`
              <${a} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_right"></${a}>
            `}
        ${e._expanded ? s` ${e._toggleLabel} ` : null}
      </button>
    </div>
  </aside>
`;
export {
  _ as sidemenuTemplate
};
//# sourceMappingURL=_sidemenu.template.js.map
