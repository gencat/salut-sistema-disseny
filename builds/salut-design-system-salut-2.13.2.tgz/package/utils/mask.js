function M(t, n, s) {
  const c = s.match(/[^$\d\s]/), o = c ? c[0] : null;
  if (o && t.length > n.length) {
    const r = n.length;
    if (t[r] === o) {
      const a = t.slice(0, r - 1), e = t.slice(r + 1);
      return a + e;
    }
  }
  return n;
}
function R(t, n, s, c) {
  if (!n || !s) return t;
  const o = n.match(/^\/(.+)\/([gimsuy]*)$/);
  if (!o) return t;
  const [, g, r] = o, a = new RegExp(g, r);
  let e = t;
  const i = s.match(/[^$\d\s]/), h = i ? i[0] : null;
  if (h) {
    const l = new RegExp(h, "g");
    e = t.replace(l, "");
  }
  if (c) {
    const l = c.match(/^\/(.+)\/([gimsuy]*)$/);
    if (l) {
      const [, x, w] = l, d = new RegExp(x, w);
      let p = "";
      for (let f = 0; f < e.length; f++) {
        const m = e[f];
        d.test(m) && (p += m), d.lastIndex = 0;
      }
      e = p;
    }
  }
  return e.replace(a, s);
}
export {
  R as applyMask,
  M as deleteSeparatorMask
};
//# sourceMappingURL=mask.js.map
