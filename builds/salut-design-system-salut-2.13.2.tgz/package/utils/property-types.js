const n = {
  type: Boolean,
  converter: {
    fromAttribute: (t) => t !== null && t !== "false",
    toAttribute: (t) => t ? "true" : null
  }
}, o = {
  fromAttribute: (t) => !(t === null || t === "false"),
  toAttribute: (t) => t ? "" : null
}, i = {
  type: Array,
  converter: {
    fromAttribute: (t) => {
      if (!t) return [];
      const r = JSON.parse(t);
      return Array.isArray(r) ? r.map((e) => e.toString()) : [r.toString()];
    },
    toAttribute: (t) => JSON.stringify(t)
  }
};
export {
  o as booleanConverter,
  n as booleanType,
  i as selectedType
};
//# sourceMappingURL=property-types.js.map
