function a(t, e, n) {
  return t || (t = 0), e || (e = 0), n === "asc" ? t - e : e - t;
}
function f(t, e, n) {
  return t || (t = /* @__PURE__ */ new Date("1900-01-01")), e || (e = /* @__PURE__ */ new Date("1900-01-01")), n === "asc" ? t.getTime() - e.getTime() : e.getTime() - t.getTime();
}
function o(t, e, n) {
  return t || (t = ""), e || (e = ""), n === "asc" ? t.localeCompare(e) : e.localeCompare(t);
}
function d(t, e, n = "asc", r) {
  return [...t].sort((i, c) => {
    switch (r) {
      case "number":
        return a(i[e], c[e], n);
      case "date":
        const s = u(i[e]), m = u(c[e]);
        return f(s, m, n);
      case "string":
        return o(i[e], c[e], n);
      default:
        return 0;
    }
  });
}
function u(t) {
  if (!t) return null;
  if (t instanceof Date) return t;
  if (typeof t == "number") return new Date(t);
  const e = t.trim();
  if (/^\d{4}-\d{1,2}-\d{1,2}/.test(e)) {
    const r = new Date(e);
    return Number.isNaN(r.getTime()) ? null : r;
  }
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(e)) {
    const [r, i, c] = e.split("/").map(Number);
    return new Date(c, i - 1, r);
  }
  const n = new Date(e);
  return Number.isNaN(n.getTime()) ? null : n;
}
export {
  d as sort
};
//# sourceMappingURL=sorting.js.map
