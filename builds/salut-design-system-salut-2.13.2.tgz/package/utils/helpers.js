function c(e) {
  if (!e) return;
  const t = e.target, r = t.scrollWidth > t.offsetWidth;
  t.setAttribute("data-truncated", r.toString());
}
function n(e) {
  if (!e) return;
  const t = e.target, r = t.scrollHeight > t.clientHeight || t.scrollWidth > t.clientWidth;
  t.setAttribute("data-truncated", r.toString());
}
function i(e) {
  return e.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
export {
  c as checkTextTruncate,
  n as checkWebkitTruncate,
  i as normalizeText
};
//# sourceMappingURL=helpers.js.map
