function s(n, e, r) {
  if (!("IntersectionObserver" in window)) {
    e();
    return;
  }
  new IntersectionObserver(
    (o, i) => {
      o[0].isIntersecting && (i.disconnect(), e());
    },
    {
      rootMargin: "80px",
      // pre-carga antes de verse
      ...r
    }
  ).observe(n);
}
export {
  s as lazyLoading
};
//# sourceMappingURL=lazy-loading.js.map
