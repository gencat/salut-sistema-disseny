function n(t) {
  t && t.focus();
}
function f(t, i, l) {
  let o = 0;
  const e = t.querySelectorAll(l), s = e.length - 1;
  i === e[0] ? n(e[s]) : (e.forEach((c, a) => {
    c === i && (o = a);
  }), n(e[o - 1]));
}
function u(t, i, l) {
  let o = 0;
  const e = t.querySelectorAll(l), s = e.length - 1;
  i === e[s] ? n(e[0]) : (e.forEach((c, a) => {
    c === i && (o = a);
  }), n(e[o + 1]));
}
function r(t, i, l) {
  const o = t.querySelector(`${l}[tabindex="0"]`);
  o == null || o.setAttribute("tabindex", "-1"), i.setAttribute("tabindex", "0"), i.click();
}
export {
  u as moveFocusToNextTarget,
  f as moveFocusToPreviousTarget,
  n as moveFocusToTarget,
  r as onKeyboardEnter
};
//# sourceMappingURL=keyboard-navigation.js.map
