import { nothing as t } from "lit";
import { classMap as v } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as a, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const l = a`dss-icon-button${d(e())}`, $ = a`dss-badge${d(e())}`, o = a`dss-icon-badge${d(e())}`, f = a`dss-notification-badge${d(e())}`, g = a`dss-decorative-icon${d(e())}`, r = a`dss-tooltip${d(e())}`, h = a`dss-typography${d(e())}`, T = (i) => {
  const u = {
    "dss-widget": !0,
    [`dss-widget--${i.variant}`]: !!i.variant,
    "dss-widget--scroll": i.hasScroll,
    "dss-widget--folded": i.folded
  };
  return s`
  <div class="${v(u)}">
    <div class="dss-widget-header">
      <div class="dss-widget-header__info">
        <div class="dss-widget-title">
          ${i.icon ? s`
                <${g} icon=${i.icon} state=${i.iconStatus} size="sm"></${g}>
            ` : t}
          <div
            class="dss-widget-title__text" 
            @mouseenter=${i.checkTextTruncate}>
            ${i.titleText}
            <${r} 
              tooltipPosition="${i.tooltipPosition}" 
              ?tooltipFixed="${i.tooltipFixed}"
              ?forceViewport="${i.forceViewport}"
              class="title-tooltip" aria-hidden="true">
              ${i.titleText}
            </${r}>
          </div>
        </div>
      </div>

      <div class="dss-widget-header__config">
          <div class="dss-widget-header__config-info">
            ${i.helpText ? s`<${h} variant="body-3">${i.helpText}</${h}>` : null}
            ${i.results && i.resultsLabel === "" ? s`
                <${$}
                  size="md"
                  state="${i.resultsState}"
                  outlined
                  hideIcon
                  text="${i.results}"
                ></${$}>
              ` : i.results && i.resultsLabel !== "" ? s`
                <${$}
                  size="md"
                  state="${i.resultsState}"
                  outlined
                  hideIcon
                  text="${i.results} ${i.resultsLabel}"
                ></${$}>
              ` : t}
  
            ${i.info ? s`
                <${o}  size="md" state="${i.infoBadgeState}" icon="${i.infoBadgeIcon}" ?outlined="${i.infoBadgeOutlined}">
                  <${r} 
                    ?forceViewport="${i.forceViewport}" 
                    ?tooltipFixed="${i.tooltipFixed}" 
                    slot="tooltip">
                    <span>${i.info}</span>
                  </${r} >
                </${o} >
              ` : t}

            ${i.notifications ? s`
                <${f}
                  state="${i.notificationsState}"
                  value="${i.notifications}"
                >
                </${f}>
              ` : t}
          </div>

          ${(i.helpText || i.results || i.notifications || i.info) && (i.hasAction || i.hasNext || i.hasClose) ? s`
              <span class="dss-widget-header__divider"></span>
            ` : t}

          <div class="dss-widget-header__config-actions">
              ${i.hasAction ? s`
                  <${l}
                    size="md"
                    icon="${i.actionIcon}"
                    label="${i.actionLabel}"
                    variant="${i.actionVariant}"
                    ?fill=${i.actionFill}
                    ?disabled=${i.actionDisabled}
                    ?tooltipFixed=${i.tooltipFixed}
                    ?forceViewport="${i.forceViewport}"
                    tooltipPosition="${i.tooltipPosition}"
                    ?hideTooltip="${i.hideTooltip}"
                    @onClick=${i.handleAction}
                  ></${l}>
                ` : t}

            ${i.hasNext ? s`
                  <${l}
                    size="md"
                    variant="primary"
                    label="Següent"
                    icon="arrow_forward"
                    hideTooltip
                    @onClick="${i.handleNext}"
                  >
                  </${l}>
                ` : t}
            ${i.hasClose ? s`
                  <${l}
                    size="md"
                    variant="default"
                    icon="close"
                    label="Tancar"
                    hideTooltip
                    @onClick="${i.handleClose}"
                  >
                  </${l}>
                ` : t}
          </div>
      </div>
    </div>
    ${i.folded ? t : s`
      <div class="dss-widget-body">
        <slot></slot> 
      </div>
      `}
  </div>
  `;
};
export {
  T as template
};
//# sourceMappingURL=widget.template.js.map
