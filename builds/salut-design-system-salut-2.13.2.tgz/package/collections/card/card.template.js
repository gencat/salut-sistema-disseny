import { nothing as a } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as e, literal as i, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const l = i`dss-icon-button${e(o())}`, h = (s) => d`
  <div class="dss-card ${t({
  "dss-card--selected": s.selected,
  "dss-card--dragged": s.dragged,
  "dss-card--deleted": s.deleted,
  "dss-card--disabled": s.disabled
})}" 
  tabindex="0">
    ${s.hasClose || s.hasDetails ? d`
          <div class="dss-card-top">
            <div class="dss-card-top__details">
              <slot name="tags"></slot>
              <slot name="info"></slot>
            </div>
            ${s.hasClose ? d`
                  <div class="dss-card-top__close">
                    <${l}
                      size="md"
                      label="Tancar"
                      icon="close"
                      variant="default"
                      hideTooltip
                      ?disabled=${s.disabled}
                      @onClick=${s._dispatchClose}
                    ></${l}>
                  </div>
                ` : a}
          </div>
        ` : a}
    <slot name="header"></slot>
    <slot name="form"></slot>
    <slot name="image"></slot>
    <slot name="body"></slot>
    <slot name="highlights"></slot>
    <slot name="footer"></slot>
  </div>
`;
export {
  h as template
};
//# sourceMappingURL=card.template.js.map
