import { LitElement as m, unsafeCSS as p } from "lit";
import { property as r } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as o } from "../../utils/property-types.js";
import b from "./card.style.css.js";
import { template as y } from "./card.template.js";
var c = Object.defineProperty, i = (d, e, a, f) => {
  for (var s = void 0, t = d.length - 1, n; t >= 0; t--)
    (n = d[t]) && (s = n(e, a, s) || s);
  return s && c(e, a, s), s;
};
class l extends m {
  constructor() {
    super(...arguments), this.selected = !1, this.dragged = !1, this.deleted = !1, this.disabled = !1, this.hasClose = !1, this.hasDetails = !1;
  }
  static get styles() {
    return [p(u), p(h), p(b)];
  }
  /* METHODS */
  _propagateProperties() {
    var a;
    const e = (a = this.shadowRoot) == null ? void 0 : a.querySelectorAll("slot");
    e && e.forEach((f) => {
      f.assignedElements().forEach((t) => {
        this.deleted ? t.setAttribute("deleted", "true") : t.removeAttribute("deleted"), this.disabled ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled");
      });
    });
  }
  /* EVENTS */
  _dispatchClose() {
    this.dispatchEvent(new CustomEvent("onClose", { bubbles: !0 }));
  }
  /* LIT LIFECYCLE */
  updated(e) {
    super.updated(e), (e.has("deleted") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    return y(this);
  }
}
i([
  r(o)
], l.prototype, "selected");
i([
  r(o)
], l.prototype, "dragged");
i([
  r(o)
], l.prototype, "deleted");
i([
  r(o)
], l.prototype, "disabled");
i([
  r(o)
], l.prototype, "hasClose");
i([
  r(o)
], l.prototype, "hasDetails");
export {
  l as Card
};
//# sourceMappingURL=card.js.map
