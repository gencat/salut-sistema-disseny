import { LitElement as m, css as u, html as f } from "lit";
import { property as o } from "lit/decorators.js";
import { booleanType as l } from "../../../utils/property-types.js";
var h = Object.defineProperty, p = (d, e, r, i) => {
  for (var s = void 0, t = d.length - 1, a; t >= 0; t--)
    (a = d[t]) && (s = a(e, r, s) || s);
  return s && h(e, r, s), s;
};
class n extends m {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return u`
      :host {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(10px, 1fr));
        gap: var(--dss-spacing-sm);
      }
    `;
  }
  _propagateProperties() {
    var r;
    const e = (r = this.shadowRoot) == null ? void 0 : r.querySelectorAll("slot");
    e && e.forEach((i) => {
      i.assignedElements().forEach((t) => {
        this.deleted ? t.setAttribute("deleted", "true") : t.removeAttribute("deleted"), this.disabled ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(e) {
    super.updated(e), (e.has("deleted") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    return f` <slot></slot> `;
  }
}
p([
  o(l)
], n.prototype, "deleted");
p([
  o(l)
], n.prototype, "disabled");
export {
  n as CardHighlights
};
//# sourceMappingURL=card-highlights.js.map
