import { LitElement as n, unsafeCSS as c, css as f, html as m } from "lit";
import { property as d } from "lit/decorators.js";
import { classMap as h } from "lit/directives/class-map.js";
import u from "../../../shared/reset.style.css.js";
import { booleanType as a } from "../../../utils/property-types.js";
var b = Object.defineProperty, i = (r, t, o, v) => {
  for (var e = void 0, s = r.length - 1, l; s >= 0; s--)
    (l = r[s]) && (e = l(t, o, e) || e);
  return e && b(t, o, e), e;
};
class p extends n {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      c(u),
      f`
        :host {
          display: block;
        }
        .dss-card-title {
          font-size: 18px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          color: var(--color-neutral-900);
        }

        .dss-card-title.deleted {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    const t = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return m`
      <h3 class="dss-card-title ${h(t)}">
        <slot></slot>
      </h3>
    `;
  }
}
i([
  d(a)
], p.prototype, "deleted");
i([
  d(a)
], p.prototype, "disabled");
export {
  p as CardTitle
};
//# sourceMappingURL=card-title.js.map
