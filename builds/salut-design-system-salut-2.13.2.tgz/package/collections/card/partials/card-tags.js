import { LitElement as t, css as s, html as e } from "lit";
class i extends t {
  static get styles() {
    return s`
      :host {
        display: flex;
        align-items: center;
        width: 100%;
        gap: var(--dss-spacing-xxs);
        flex-wrap: wrap;
        min-width: 150px;
      }
    `;
  }
  /* LIT LIFECYCLE */
  render() {
    return e` <slot></slot> `;
  }
}
export {
  i as CardTags
};
//# sourceMappingURL=card-tags.js.map
