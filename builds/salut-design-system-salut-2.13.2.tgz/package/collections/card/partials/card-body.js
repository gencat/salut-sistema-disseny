import { LitElement as f, unsafeCSS as u, css as m, html as b } from "lit";
import { property as l } from "lit/decorators.js";
import { booleanType as a } from "../../../utils/property-types.js";
import c from "../../../foundations/icon/icon.style.css.js";
var h = Object.defineProperty, p = (d, e, r, o) => {
  for (var s = void 0, t = d.length - 1, i; t >= 0; t--)
    (i = d[t]) && (s = i(e, r, s) || s);
  return s && h(e, r, s), s;
};
class n extends f {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      u(c),
      m`
        :host {
          display: flex;
          flex-direction: column;
          gap: var(--dss-spacing-xxs);
        }
      `
    ];
  }
  _propagateProperties() {
    var r;
    const e = (r = this.shadowRoot) == null ? void 0 : r.querySelectorAll("slot");
    e && e.forEach((o) => {
      o.assignedElements().forEach((t) => {
        this.deleted ? t.setAttribute("deleted", "true") : t.removeAttribute("deleted"), this.disabled ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(e) {
    super.updated(e), (e.has("deleted") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    return b` <slot></slot> `;
  }
}
p([
  l(a)
], n.prototype, "deleted");
p([
  l(a)
], n.prototype, "disabled");
export {
  n as CardBody
};
//# sourceMappingURL=card-body.js.map
