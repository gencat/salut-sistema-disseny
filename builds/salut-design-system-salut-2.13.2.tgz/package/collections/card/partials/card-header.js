import { LitElement as m, unsafeCSS as p, css as u } from "lit";
import { property as r } from "lit/decorators.js";
import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as b, literal as v, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as y } from "../../../api/custom-element-scope.js";
import _ from "../../../foundations/icon/icon.style.css.js";
import S from "../../../shared/reset.style.css.js";
import { booleanType as i } from "../../../utils/property-types.js";
var x = Object.defineProperty, l = (n, e, d, c) => {
  for (var t = void 0, s = n.length - 1, f; s >= 0; s--)
    (f = n[s]) && (t = f(e, d, t) || t);
  return t && x(e, d, t), t;
};
const h = v`dss-icon${b(y())}`;
class o extends m {
  constructor() {
    super(...arguments), this.flag = !1, this.hasMenu = !1, this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      p(S),
      p(_),
      // actionMenuStyles,
      u`
        .dss-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-lg);
					width: 100%;
        }

        .dss-card-header-title {
          flex: 1;
        }

        .dss-card-header-actions {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-xs);
        }

        .dss-card-header-actions__flag {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* METHODS */
  _propagateProperties() {
    var d;
    const e = (d = this.shadowRoot) == null ? void 0 : d.querySelectorAll("slot");
    e && e.forEach((c) => {
      c.assignedElements().forEach((s) => {
        this.deleted ? s.setAttribute("deleted", "true") : s.removeAttribute("deleted"), this.disabled ? s.setAttribute("disabled", "true") : s.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(e) {
    super.updated(e), (e.has("deleted") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    const e = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return a`
      <div class="dss-card-header">
        <div class="dss-card-header-title ${g(e)}">
          <slot name="title"></slot>
        </div>
        ${this.flag || this.hasMenu ? a`
              <div class="dss-card-header-actions">
                ${this.flag ? a`<${h} icon="flag" size="md" fill class="dss-card-header-actions__flag"></${h}>` : ""}
                ${this.hasMenu ? a` <slot name="menu"></slot> ` : a``}
              </div>
            ` : a``}
      </div>
    `;
  }
}
l([
  r(i)
], o.prototype, "flag");
l([
  r(i)
], o.prototype, "hasMenu");
l([
  r(i)
], o.prototype, "deleted");
l([
  r(i)
], o.prototype, "disabled");
export {
  o as CardHeader
};
//# sourceMappingURL=card-header.js.map
