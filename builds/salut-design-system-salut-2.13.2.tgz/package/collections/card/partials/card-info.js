import { LitElement as t, css as e, html as s } from "lit";
class i extends t {
  static get styles() {
    return e`
      :host {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        width: 100%;
        gap: var(--dss-spacing-sm);
        flex-wrap: wrap;
        min-width: 150px;
      }
    `;
  }
  /* LIT LIFECYCLE */
  render() {
    return s` <slot></slot> `;
  }
}
export {
  i as CardInfo
};
//# sourceMappingURL=card-info.js.map
