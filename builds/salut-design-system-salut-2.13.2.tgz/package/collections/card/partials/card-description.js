import { LitElement as n, unsafeCSS as c, css as f, html as m } from "lit";
import { property as l } from "lit/decorators.js";
import { classMap as u } from "lit/directives/class-map.js";
import { booleanType as i } from "../../../utils/property-types.js";
import h from "../../../shared/reset.style.css.js";
var v = Object.defineProperty, a = (t, r, o, b) => {
  for (var e = void 0, s = t.length - 1, d; s >= 0; s--)
    (d = t[s]) && (e = d(r, o, e) || e);
  return e && v(r, o, e), e;
};
class p extends n {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      c(h),
      f`
        .dss-card-description {
          font-size: 14px;
          line-height: 24px;
          color: var(--color-neutral-600);
        }

        .dss-card-description.deleted {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    const r = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return m`
      <p class="dss-card-description ${u(r)}">
        <slot></slot>
      </p>
    `;
  }
}
a([
  l(i)
], p.prototype, "deleted");
a([
  l(i)
], p.prototype, "disabled");
export {
  p as CardDescription
};
//# sourceMappingURL=card-description.js.map
