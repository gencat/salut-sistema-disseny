import { LitElement as h, unsafeCSS as p, css as m } from "lit";
import { property as s } from "lit/decorators.js";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as v, literal as b, html as i } from "lit/static-html.js";
import y from "../../../foundations/icon/icon.style.css.js";
import g from "../../../shared/reset.style.css.js";
import { booleanType as l } from "../../../utils/property-types.js";
import { getCustomElementSuffix as S } from "../../../api/custom-element-scope.js";
var k = Object.defineProperty, e = (a, o, n, x) => {
  for (var t = void 0, d = a.length - 1, c; d >= 0; d--)
    (c = a[d]) && (t = c(o, n, t) || t);
  return t && k(o, n, t), t;
};
const f = b`dss-icon${v(S())}`;
class r extends h {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1, this.hasLink = !1, this.hasIcon = !1, this.linkHref = "#", this.icon = "add_box";
  }
  static get styles() {
    return [
      p(g),
      p(y),
      m`
        :host {
					width: 100%;
					display: block;
        }
        .dss-card-subtitle {
          display: flex;
          align-items: center;
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          color: var(--color-neutral-900);
          gap: var(--dss-spacing-xxs);
        }

        .dss-card-subtitle.deleted {
          color: var(--color-red-500);
        }

        .dss-card-subtitle__link {
          color: var(--color-primary-500);

          &:visited {
            color: var(--color-purple-700);
          }

          &:hover {
            color: var(--color-primary-600);
          }

          &:active {
            color: var(--color-primary-400);
          }

          &:focus-visible {
            outline: var(--dss-border-width-md) solid var(--color-blue-200);
          }
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    const o = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return i`
      <h4 class="dss-card-subtitle ${u(o)}">
        ${this.hasIcon ? i`
          <${f} size="sm" icon="${this.icon}"></${f}>
          ` : null}
        ${this.hasLink ? i`
              <a class="dss-card-subtitle__link" href="${this.linkHref}">
                <slot></slot>
              </a>
            ` : i` <slot></slot> `}
      </h4>
    `;
  }
}
e([
  s(l)
], r.prototype, "deleted");
e([
  s(l)
], r.prototype, "disabled");
e([
  s(l)
], r.prototype, "hasLink");
e([
  s(l)
], r.prototype, "hasIcon");
e([
  s({ type: String })
], r.prototype, "linkHref");
e([
  s({ type: String })
], r.prototype, "icon");
export {
  r as CardSubitle
};
//# sourceMappingURL=card-subtitle.js.map
