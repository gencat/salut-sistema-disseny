import { LitElement as p, unsafeCSS as a, css as m } from "lit";
import { property as e } from "lit/decorators.js";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as f, literal as x, html as c } from "lit/static-html.js";
import _ from "../../../foundations/icon/icon.style.css.js";
import v from "../../../shared/reset.style.css.js";
import { booleanType as n } from "../../../utils/property-types.js";
import { getCustomElementSuffix as b } from "../../../api/custom-element-scope.js";
var y = Object.defineProperty, s = (d, t, o, S) => {
  for (var i = void 0, l = d.length - 1, h; l >= 0; l--)
    (h = d[l]) && (i = h(t, o, i) || i);
  return i && y(t, o, i), i;
};
const g = x`dss-icon${f(b())}`;
class r extends p {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1, this.icon = "", this.title = "Title", this.titleText = "Title", this.text = "Item";
  }
  static get styles() {
    return [
      a(v),
      a(_),
      m`
        .dss-card-highligth {
					width: 100%;
          background-color: var(--color-blue-50);
          padding: var(--dss-spacing-xxs) var(--dss-spacing-xs);
          border-radius: var(--dss-radius-sm);
        }

        .dss-card-highligth__title {
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          color: var(--color-blue-700);
        }

        .dss-card-highligth__item {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-xxs);
          font-size: 14px;
          line-height: 24px;
          color: var(--color-blue-700);
        }

        .dss-card-highligth.deleted {
          background-color: var(--color-red-50);
        }

        .dss-card-highligth.deleted .dss-card-highligth__title,
        .dss-card-highligth.deleted .dss-card-highligth__item {
          color: var(--color-red-700);
        }

        .dss-card-highligth.disabled {
          background-color: var(--color-neutral-50);
        }

        .dss-card-highligth.disabled .dss-card-highligth__title,
        .dss-card-highligth.disabled .dss-card-highligth__item {
          color: var(--color-neutral-700);
        }
      `
    ];
  }
  updated(t) {
    super.updated(t), t.has("title") && queueMicrotask(() => {
      this.title !== "Title" && (this.titleText = this.title);
    });
  }
  render() {
    const t = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return c`
      <div class="dss-card-highligth ${u(t)}">
        <h5 class="dss-card-highligth__title">${this.titleText}</h5>
        <p class="dss-card-highligth__item">
          ${this.icon ? c`
            <${g} size="sm" icon="${this.icon}"></${g}>
            ` : ""}
          ${this.text}
        </p>
      </div>
    `;
  }
}
s([
  e(n)
], r.prototype, "deleted");
s([
  e(n)
], r.prototype, "disabled");
s([
  e({ type: String })
], r.prototype, "icon");
s([
  e({ type: String })
], r.prototype, "title");
s([
  e({ type: String })
], r.prototype, "titleText");
s([
  e({ type: String })
], r.prototype, "text");
export {
  r as CardHighlightsItem
};
//# sourceMappingURL=card-highlights-item.js.map
