import { LitElement as l, unsafeCSS as m, css as d } from "lit";
import { property as e } from "lit/decorators.js";
import { classMap as h } from "lit/directives/class-map.js";
import { unsafeStatic as u, literal as y, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as g } from "../../../api/custom-element-scope.js";
import v from "../../../foundations/icon/icon.style.css.js";
import { booleanType as x } from "../../../utils/property-types.js";
var S = Object.defineProperty, s = (o, i, c, $) => {
  for (var t = void 0, r = o.length - 1, p; r >= 0; r--)
    (p = o[r]) && (t = p(i, c, t) || t);
  return t && S(i, c, t), t;
};
const f = y`dss-icon${u(g())}`;
class n extends l {
  constructor() {
    super(...arguments), this.icon = "add_box", this.text = "Info", this.critic = !1;
  }
  static get styles() {
    return [
      m(v),
      d`
        :host {
          display: inline-block;
        }

        .info {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-tiny);
          font-size: 12px;
          line-height: 16px;
          font-weight: var(--font-regular);
        }

        .info--critic {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    const i = {
      "info--critic": this.critic
    };
    return a`
      <div class="info ${h(i)}">
        ${this.icon ? a`
           <${f} size="sm" icon="${this.icon}"></${f}>
          ` : ""}
        <span>${this.text}</span>
      </div>
    `;
  }
}
s([
  e({ type: String })
], n.prototype, "icon");
s([
  e({ type: String })
], n.prototype, "text");
s([
  e(x)
], n.prototype, "critic");
export {
  n as CardInfoItem
};
//# sourceMappingURL=card-info-item.js.map
