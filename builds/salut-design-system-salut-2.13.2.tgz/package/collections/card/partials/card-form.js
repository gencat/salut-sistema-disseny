import { LitElement as a, unsafeCSS as d, css as n, html as p } from "lit";
import { property as f } from "lit/decorators.js";
import { booleanType as u } from "../../../utils/property-types.js";
import m from "../../../foundations/icon/icon.style.css.js";
var c = Object.defineProperty, h = (r, t, e, o) => {
  for (var s = void 0, i = r.length - 1, l; i >= 0; i--)
    (l = r[i]) && (s = l(t, e, s) || s);
  return s && c(t, e, s), s;
};
class b extends a {
  constructor() {
    super(...arguments), this.disabled = !1;
  }
  static get styles() {
    return [
      d(m),
      n`
        :host {
          display: flex;
          flex-direction: column;
					align-items: flex-start;
          gap: var(--dss-spacing-xxs);
					width: 100%;
        }

				::slotted(*) {
					width: 100%;
				}
      `
    ];
  }
  get _formContent() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector("slot")) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements();
  }
  _propagateProperties() {
    if (this._formContent)
      for (const t of this._formContent)
        t.querySelectorAll("input").forEach((o) => {
          this.disabled ? o.setAttribute("disabled", "true") : o.removeAttribute("disabled");
        });
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), t.has("disabled") && this._propagateProperties();
  }
  render() {
    return p` <slot></slot> `;
  }
}
h([
  f(u)
], b.prototype, "disabled");
export {
  b as CardForm
};
//# sourceMappingURL=card-form.js.map
