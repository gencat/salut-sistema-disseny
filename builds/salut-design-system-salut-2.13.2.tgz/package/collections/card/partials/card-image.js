import { LitElement as p, css as c, html as l } from "lit";
import { property as a } from "lit/decorators.js";
var m = Object.defineProperty, n = (r, s, i, u) => {
  for (var t = void 0, e = r.length - 1, o; e >= 0; e--)
    (o = r[e]) && (t = o(s, i, t) || t);
  return t && m(s, i, t), t;
};
class d extends p {
  constructor() {
    super(...arguments), this.source = "", this.alt = "";
  }
  static get styles() {
    return [
      c`
        :host {
          display: flex;
          justify-content: center;
          align-items: center;
          max-height: 124px;
          overflow: hidden;
          border-radius: var(--dss-radius-sm);
        }

        img {
          width: 100%;
          max-width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          border-radius: var(--dss-radius-sm);
        }
      `
    ];
  }
  render() {
    return l` <img src="${this.source}" alt="${this.alt}" /> `;
  }
}
n([
  a({ type: String })
], d.prototype, "source");
n([
  a({ type: String })
], d.prototype, "alt");
export {
  d as CardImage
};
//# sourceMappingURL=card-image.js.map
