import { nothing as x } from "lit";
import { repeat as u } from "lit/directives/repeat.js";
import { unsafeHTML as v } from "lit/directives/unsafe-html.js";
import { unsafeStatic as t, literal as l, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
import { highlightText as g } from "../../api/marker/marker.js";
import _ from "../../assets/img/feedback-empty.svg.js";
import C from "../../assets/img/feedback-not_found.svg.js";
const o = l`dss-modal${t(d())}`, f = l`dss-content-switcher${t(d())}`, h = l`dss-tile${t(d())}`, r = l`dss-button${t(d())}`, n = l`dss-search-bar${t(d())}`, $ = l`dss-user-feedback${t(d())}`, L = (e) => {
  const a = e._filterItems(), b = a.findIndex((i) => i.text === e._selectedText);
  return s`
    <${o} 
      modalTitle="${e.titleText}" 
      ?open=${e.open}
      hideCloseIcon
      hasScroll
      fullHeight
      fullWidth
      flexBody
      removeBodyPadding
      @onModalClosed=${e._onClose}>
      
      <div slot="body" class="dss-predefined-texts-wrapper">

        <div class="dss-predefined-texts-header">
          <${f}
          size="lg"
          .tabs="${e._categories}"
          @onChange=${e._handleTabChange}
          ></${f}>

          <${n}
            class="dss-predefined-texts-searchbar"
            inputsize="md"
            innerFocus
            @onSearchChange=${e._clearFilter}
            >
            <label slot="label" for="searchbar1" aria-hidden="false">Search bar</label>
            <input slot="input" id="searchbar1" type="text" @input=${e._handleSearch} />
          </${n}>

        </div>

        <div class="dss-predefined-texts-content">

          ${a.length > 0 ? s`
            <div class="dss-predefined-texts-options">
              ${u(
    a,
    (i, c) => s`
                  <${h} 
                    type="selector" 
                    tiletitle="${i.title}" 
                    description="${i.text}"
                    selected=${e._selectedIndex ? c === e._selectedIndex : c === b}
                    marker="${e._filter}"
                    @onTileClick=${() => e._onSelectText(c, i.text)}
                  >
                  </${h} >
              `
  )}
          
            </div>

            <div class="dss-predefined-texts-value">
              ${e._selectedText !== "" ? s`
                  <div class="preset-text">
                    ${v(g(e._selectedText, e._filter))}
                  </div>
                  <div class="description">${e.descriptionLabel}</div>
                ` : x}
            </div>
            ` : s`
            <div class="dss-predefined-texts-no-results">

              ${e._filter.length > 0 ? s`
                  <${$} 
                    size="md" 
                    imagesrc="${C}"  
                    title="${e.noResultsTitle}" 
                    description="${e.noResultsLabel}"">
                  </${$}>
                ` : s`
                  <${$} 
                    size="md" 
                    imagesrc="${_}" 
                    title="${e.noDataTitle}" 
                    description="${e.noDataLabel}"">
                  </${$}>
                `}
              
            </div>
            `}
        </div>
      </div>
      <div class="dss-modal-footer" slot="footer">
        <${r} 
          variant="secondary" 
          size="lg" 
          label="${e.buttonLabelCancel}"
          @onClick=${e._handleCancel}
        ></${r}>
        <${r} 
          size="lg" 
          label="${e.buttonLabelSelect}"
          @onClick=${e._handleSelect}
          ?disabled=${a.length === 0}
        ></${r}>
      </div>
    </${o}>
  `;
};
export {
  L as template
};
//# sourceMappingURL=preset-texts.template.js.map
