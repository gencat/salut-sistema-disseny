import { LitElement as C, unsafeCSS as _ } from "lit";
import { property as a } from "lit/decorators.js";
import { getCustomElementSuffix as b } from "../../api/custom-element-scope.js";
import w from "../../foundations/icon/icon.style.css.js";
import y from "../../shared/reset.style.css.js";
import M from "../../shared/scrollbar.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import S from "./side-menu.style.css.js";
import { sidemenuTemplate as L } from "./side-menu.template.js";
var x = Object.defineProperty, v = Object.getOwnPropertyDescriptor, d = (f, e, t, i) => {
  for (var o = i > 1 ? void 0 : i ? v(e, t) : e, s = f.length - 1, n; s >= 0; s--)
    (n = f[s]) && (o = (i ? n(e, t, o) : n(o)) || o);
  return i && o && x(e, t, o), o;
};
class l extends C {
  constructor() {
    super(), this.createMenuItems = [], this.roleMenuItems = [], this.globalMenuItems = [], this.axiaHidden = !1, this.axiaDisabled = !1, this.axiaLabel = "Axia", this._hasManualSelected = !1, this._disabled = !1, this._expanded = !1, this._toggleDisabled = !1, this._toggleLabel = "Tancar menú", this._hideCreateMenu = !1, this._createDisabled = !1, this._createLabel = "Crear", this._createMenuPosition = "top", this._createNotifications = 0, this._showCreateDropdown = !1, this._scrollContainerClass = "dss-layout-sidebar", this._resizeTimer = null, this._othersTopItem = null, this._dropdown = null, this._isFirstUpdated = !0, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleResizeBound = this._handleResize.bind(this), this._handleContainerScrollBound = this._handleContainerScroll.bind(this);
  }
  static get styles() {
    return [_(y), _(M), _(w), _(S)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), document.addEventListener("mousedown", this._handleDocumentClickBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), document.removeEventListener("mousedown", this._handleDocumentClickBound), this._scrollContainer && this._scrollContainer.removeEventListener("scroll", this._handleContainerScrollBound);
  }
  set expanded(e) {
    const t = this._expanded;
    this._expanded = e, this.requestUpdate("expanded", t);
  }
  get expanded() {
    return this._expanded;
  }
  set disabled(e) {
    const t = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", t);
  }
  get disabled() {
    return this._disabled;
  }
  set toggleLabel(e) {
    const t = this._toggleLabel;
    this._toggleLabel = e, this.requestUpdate("toggleLabel", t);
  }
  get toggleLabel() {
    return this._toggleLabel;
  }
  set createLabel(e) {
    const t = this._createLabel;
    this._createLabel = e, this.requestUpdate("createLabel", t);
  }
  get createLabel() {
    return this._createLabel;
  }
  set createMenuPosition(e) {
    const t = this._createMenuPosition;
    this._createMenuPosition = e, this.requestUpdate("createMenuPosition", t);
  }
  get createMenuPosition() {
    return this._createMenuPosition;
  }
  set createNotifications(e) {
    const t = this._createNotifications;
    this._createNotifications = e, this.requestUpdate("createNotifications", t);
  }
  get createNotifications() {
    return this._createNotifications;
  }
  set createDisabled(e) {
    const t = this._createDisabled;
    this._createDisabled = e, this.requestUpdate("createDisabled", t);
  }
  get createDisabled() {
    return this._createDisabled;
  }
  set hideCreateMenu(e) {
    const t = this._hideCreateMenu;
    this._hideCreateMenu = e, this.requestUpdate("hideCreateMenu", t);
  }
  get hideCreateMenu() {
    return this._hideCreateMenu;
  }
  set scrollContainerClass(e) {
    const t = this._scrollContainerClass;
    this._scrollContainerClass = e, this.requestUpdate("scrollContainerClass", t);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  get _createNotification() {
    var e;
    return ((e = this.shadowRoot) == null ? void 0 : e.querySelector("dss-notification-badge")) || void 0;
  }
  get _createSection() {
    var t;
    return (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-sidemenu-create");
  }
  _propagateProperties() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelectorAll("slot");
    e && e.forEach((i) => {
      i.assignedElements().forEach((s) => {
        this._expanded ? s.setAttribute("expanded", "true") : s.removeAttribute("expanded"), this._scrollContainerClass ? s.setAttribute("scrollContainerClass", this._scrollContainerClass) : s.removeAttribute("scrollContainerClass");
      });
    });
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._checkWindowInnerwidth(), this._updateTopMenu(), this._getHiddenRoleNotifications();
    }, 250);
  }
  _getHiddenRoleNotifications() {
    if (!this._othersTopItem) return;
    const e = this._othersTopItem.querySelectorAll("dss-action-menu-item"), t = Array.from(e).filter(
      (o) => {
        var s;
        return ((s = o.parentElement) == null ? void 0 : s.parentElement) === this._othersTopItem && o.classList.contains("hidden") === !1;
      }
    );
    let i = 0;
    for (const o of t) {
      const s = o.getAttribute("notifications");
      s && (i += Number(s));
    }
    this._othersTopItem.setAttribute("notifications", i.toString());
  }
  _getTopMenuItems(e) {
    const t = e.querySelectorAll("dss-sidemenu-list-item"), i = Array.from(t).filter(
      (r) => r.classList.contains("dss-sidemenu-top-menu__other-items") === !1
    ), s = e.querySelector(".dss-sidemenu-top-menu__other-items").querySelectorAll("dss-action-menu");
    if (!s) return;
    const n = s[0], c = Array.from(n.querySelectorAll("dss-action-menu-item")).filter(
      (r) => r.parentElement === n
    );
    return { defaultItems: i, hiddenItems: c };
  }
  async _updateTopMenu() {
    var n, c, r, m;
    const e = (n = this.shadowRoot) == null ? void 0 : n.querySelector(".dss-sidemenu-top-menu");
    if (!e) return;
    const t = this._getTopMenuItems(e);
    if (!t) return;
    const i = 40;
    let o = 0, s = 0;
    for (const [p, h] of t.defaultItems.entries()) {
      if (o += i, p === 0) {
        h.classList.remove("hidden");
        continue;
      }
      o <= e.clientHeight ? h.classList.remove("hidden") : (h.classList.add("hidden"), s += 1), o += 4;
    }
    if (this._othersTopItem = (c = this.shadowRoot) == null ? void 0 : c.querySelector(".dss-sidemenu-top-menu__other-items"), s > 0) {
      if ((r = this._othersTopItem) == null || r.classList.remove("hidden"), e.scrollHeight > e.clientHeight) {
        const p = t.defaultItems.filter((g) => !g.classList.contains("hidden")), h = p[p.length - 1];
        h !== t.defaultItems[0] && (h.classList.add("hidden"), s += 1);
      }
      t.hiddenItems && (t.hiddenItems.forEach((h) => h.classList.add("hidden")), t.hiddenItems.slice(-s).forEach((h) => h.classList.remove("hidden")));
    } else
      (m = this._othersTopItem) == null || m.classList.add("hidden");
  }
  _checkWindowInnerwidth() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-sidemenu-toggle");
    window.innerWidth < 1024 ? (this.removeAttribute("expanded"), this._toggleDisabled = !0, e.disabled = !0, e.classList.add("dss-sidemenu-toggle--hidden")) : (this._toggleDisabled = !1, e.disabled = !1, e.classList.remove("dss-sidemenu-toggle--hidden"));
  }
  _clickedOutsideCreateMenu(e, t) {
    t.composedPath().includes(e) || this._closeCreateDropdown();
  }
  _closeCreateDropdown() {
    this._showCreateDropdown && (this._showCreateDropdown = !1, this._toggleCreateMenuTooltip(), this.requestUpdate());
  }
  _handleKeydownEscape(e) {
    var r;
    const i = (r = e.detail.shadowRoot) == null ? void 0 : r.querySelector("slot");
    if (!i) return;
    const s = `dss-action-menu${b()}`, c = i.assignedElements({ flatten: !0 }).find((m) => m.tagName.toLowerCase() === s);
    c && c.classList.contains("visible") && c._closeMenu();
  }
  _handleDocumentClick(e) {
    this._createSection && this._clickedOutsideCreateMenu(this._createSection, e);
  }
  _openCreateMenu() {
    this._showCreateDropdown = !0, this._toggleCreateMenuTooltip(), this.requestUpdate();
  }
  _toggleCreateMenuTooltip() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-sidemenu-create__tooltip");
    this._showCreateDropdown ? e == null || e.classList.add("force-hidden") : e == null || e.classList.remove("force-hidden");
  }
  _toggleSidemenu() {
    this._expanded ? this.removeAttribute("expanded") : this.setAttribute("expanded", "true");
  }
  _handleCreateMouseEnter() {
    this._createNotification && this._createNotification.setAttribute("isHover", "true");
  }
  _handleCreateMouseLeave() {
    this._createNotification && this._createNotification.removeAttribute("isHover");
  }
  _handleCreateMouseDown() {
    this._createNotification && this._createNotification.setAttribute("isActive", "true");
  }
  _handleCreateFocusout(e) {
    if (this._showCreateDropdown) {
      const t = e.relatedTarget;
      t === null && this._closeCreateDropdown(), t && !this._createSection.contains(t) && t.tagName !== "DSS-ACTION-MENU-ITEM" && this._closeCreateDropdown();
    }
  }
  _handleCreateMouseUp() {
    this._createNotification && this._createNotification.removeAttribute("isActive");
  }
  _handleMenuClick(e, t) {
    if (t.nestedMenu || t.disabled) return;
    t.external || this._selectSidenenuItem(e);
    const i = e.composedPath(), o = i.some((r) => r instanceof HTMLElement && r.classList.contains("dss-sidemenu-top-menu")), s = i.some(
      (r) => r instanceof HTMLElement && r.classList.contains("dss-sidemenu-bottom-menu")
    );
    let n = "";
    o ? n = "role" : s ? n = "global" : n = "create";
    const c = {
      detail: {
        menu: n,
        label: t.label,
        item: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onSidemenuClick", c));
  }
  _selectSidenenuItem(e) {
    var s;
    const t = (s = this.shadowRoot) == null ? void 0 : s.querySelectorAll('dss-sidemenu-list-item[selected="true"]');
    t == null || t.forEach((n) => {
      n.removeAttribute("selected");
    });
    const o = e.currentTarget.closest("dss-sidemenu-list-item");
    o && o.setAttribute("selected", "true"), this._hasManualSelected = !0, this.requestUpdate();
  }
  get _scrollContainer() {
    return document.querySelector(`.${this._scrollContainerClass}`);
  }
  _getCreateDropdownFixedPosition() {
    var i;
    const e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-sidemenu-create");
    if (!e) return;
    const t = e.getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-create__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _handleContainerScroll() {
    this._getCreateDropdownFixedPosition();
  }
  _handleAxia() {
    const e = {
      detail: !0,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onToggleAxia", e));
  }
  async firstUpdated() {
    var t, i;
    await this.updateComplete, this._propagateProperties();
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-sidemenu-create__dropdown");
    e && (this._dropdown = e, this._getCreateDropdownFixedPosition()), this._scrollContainer && this._scrollContainer.addEventListener("scroll", this._handleContainerScrollBound), this._othersTopItem = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-sidemenu-top-menu__other-items"), this._expanded && this.requestUpdate(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), (e.has("expanded") || e.has("disabled")) && (this._propagateProperties(), this._getCreateDropdownFixedPosition()), this._isFirstUpdated || requestAnimationFrame(() => this._updateTopMenu());
  }
  render() {
    return L(this);
  }
}
d([
  a({ type: Array })
], l.prototype, "createMenuItems", 2);
d([
  a({ type: Array })
], l.prototype, "roleMenuItems", 2);
d([
  a({ type: Array })
], l.prototype, "globalMenuItems", 2);
d([
  a(u)
], l.prototype, "axiaHidden", 2);
d([
  a(u)
], l.prototype, "axiaDisabled", 2);
d([
  a({ type: String })
], l.prototype, "axiaLabel", 2);
d([
  a(u)
], l.prototype, "expanded", 1);
d([
  a(u)
], l.prototype, "disabled", 1);
d([
  a({ type: String })
], l.prototype, "toggleLabel", 1);
d([
  a({ type: String })
], l.prototype, "createLabel", 1);
d([
  a({ type: String })
], l.prototype, "createMenuPosition", 1);
d([
  a({ type: Number })
], l.prototype, "createNotifications", 1);
d([
  a(u)
], l.prototype, "createDisabled", 1);
d([
  a(u)
], l.prototype, "hideCreateMenu", 1);
d([
  a({ type: String })
], l.prototype, "scrollContainerClass", 1);
export {
  l as Sidemenu_
};
//# sourceMappingURL=side-menu.js.map
