import { nothing as l } from "lit";
import { classMap as x } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as n, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
import g from "../../assets/img/logo_axia.svg.js";
const r = n`dss-icon${t(u())}`, _ = n`dss-tooltip${t(u())}`, v = n`dss-notification-badge${t(u())}`, b = n`dss-sidemenu-list${t(u())}`, c = n`dss-sidemenu-list-item${t(u())}`, f = n`dss-action-menu${t(u())}`, M = n`dss-action-menu-item${t(u())}`, h = (e, s, i) => a`
    <${f} class="dss-sidemenu-nested-menu">
      ${e.map(
  (d) => a`
        <${M}
          class=${x({
    hidden: !!s
  })}
          lefticon=${d.icon}
          label=${d.label}
          notifications=${d.notifications}
          ?disabled=${d.disabled}
          ?hasNestedMenu=${!!d.nestedMenu}
           @click=${($) => i._handleMenuClick($, d)}
        >
          ${d.nestedMenu ? h(d.nestedMenu, !1, i) : l}
        </${M}>
      `
)}
    </${f}>
  `, k = (e) => {
  if (!e._othersTopItem) return 0;
  const s = e._othersTopItem.querySelectorAll("dss-action-menu-item"), i = Array.from(s).filter(
    ($) => {
      var o;
      return ((o = $.parentElement) == null ? void 0 : o.parentElement) === e._othersTopItem && $.classList.contains("hidden") === !1;
    }
  );
  let d = 0;
  for (const $ of i) {
    const o = $.getAttribute("notifications");
    o && (d += Number(o));
  }
  return d;
}, E = (e) => a`
  <aside
    class=${x({
  "dss-sidemenu": !0,
  "dss-sidemenu--expanded": !!e._expanded
})}
  >
    ${e.roleMenuItems.length > 0 ? a`
        <div class="dss-sidemenu-top-menu">
          <${b} ?expanded=${e._expanded}>
            ${e.roleMenuItems.map(
  (s) => a`
              <${c}
                icon=${s.icon}
                label=${s.label}
                notifications=${s.notifications}
                ?selected=${s.selected && !e._hasManualSelected}
                ?disabled=${s.disabled}
                ?hasNestedMenu=${!!s.nestedMenu}
                ?expanded=${e._expanded}
                @click=${(i) => e._handleMenuClick(i, s)}
                @keydownEscape=${e._handleKeydownEscape}
                >
                ${s.nestedMenu ? h(s.nestedMenu, !1, e) : l}
              </${c}>
            `
)}
            <${c} 
              class="dss-sidemenu-top-menu__other-items hidden"
              expanded=${e._expanded}
              icon="more_horiz"
              label="Altres"
              notifications=${k(e)}
              @keydownEscape=${e._handleKeydownEscape}
              hasNestedMenu>
               ${h(e.roleMenuItems, !0, e)}
            </${c}>
          </${b}>
        </div>
    ` : l}

    ${e._hideCreateMenu ? l : a`
          <div
            class="dss-sidemenu-create"
            @focusout="${e._handleCreateFocusout}"
          >
            <button
              class="dss-sidemenu-create__button"
              ?disabled=${e._createDisabled}
              @click="${e._openCreateMenu}"
              @mouseenter="${e._handleCreateMouseEnter}"
              @mouseleave="${e._handleCreateMouseLeave}"
              @mousedown="${e._handleCreateMouseDown}"
              @mouseup="${e._handleCreateMouseUp}"
              aria-label="${e._createLabel}"
            >
              <span class="dss-sidemenu-create__button__content">
                <${r} class="dss-sidemenu-create__icon" size="md" icon="add"></${r}>
                ${e._createNotifications && !e._showCreateDropdown && !e._createDisabled ? a`
                      <${v}
                        class=${x({
  "dss-sidemenu-create__notification": !0,
  "dss-sidemenu-create__notification--expanded": !0
})}
                        value="${e._createNotifications}"
                        state="error"
                        type="default"
                        borderWhite
                      />
                    ` : null}
              </span>
              ${e._expanded ? a` ${e._createLabel} ` : null}
            </button>

            <${_} position="right" class="dss-sidemenu-create__tooltip">
              ${e._createLabel}
            </${_}>

            <${f}>
              ${e.createMenuItems.map(
  (s) => a`
                <${M}
                  label=${s.label}
                  notifications=${s.notifications}
                  @click=${(i) => e._handleMenuClick(i, s)}
                  >
                </${M}>
              `
)}
            </${f}>
          </div>
        `}

    <div class="dss-sidemenu-bottom">
      <div class="dss-sidemenu-bottom-menu">
        <div class="dss-sidemenu-divider"></div>
          ${e.globalMenuItems.length > 0 ? a`
            <${b} ?expanded=${e._expanded}>
              ${e.globalMenuItems.map(
  (s) => a`
                <${c}
                  icon=${s.icon}
                  label=${s.label}
                  notifications=${s.notifications}
                  ?selected=${s.selected && !e._hasManualSelected}
                  ?disabled=${s.disabled}
                  ?hasNestedMenu=${!!s.nestedMenu}
                  ?expanded=${e._expanded}
                  @click=${(i) => e._handleMenuClick(i, s)}
                  @keydownEscape=${e._handleKeydownEscape}
                  >
                  ${s.nestedMenu ? h(s.nestedMenu, !1, e) : l}
                </${c}>
              `
)}
            </${b}>
           ` : l}
          ${e.axiaHidden ? l : a`
            <div class="dss-sidemenu-toggle-axia">
              <button
                class="dss-sidemenu-axia"
                ?disabled=${e.axiaDisabled}
                @click="${e._handleAxia}"
              >
                <span class="dss-sidemenu-axia__content">
                  <img src="${g}" alt="Logo Axia" class="dss-sidemenu-axia__logo" />
                  <span class="dss-sidemenu-axia__label">${e.axiaLabel}</span>
                </span>
              </button>
              <${_} position="right" class="dss-sidemenu-axia__tooltip">
                ${e.axiaLabel}
              </${_}>
            </div>
          `}
        </div>
     
      
      <button
        class="dss-sidemenu-toggle"
        ?disabled=${e._toggleDisabled}
        @click="${e._toggleSidemenu}"
        aria-label="${e._expanded ? "col·lapsar menú" : "expandir menú"}"
      >
        ${e._expanded ? a`
              <${r} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_left"></${r}>
            ` : a`
              <${r} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_right"></${r}>
            `}
        ${e._expanded ? a` ${e._toggleLabel} ` : null}
      </button>
    </div>
  </aside>
`;
export {
  E as sidemenuTemplate
};
//# sourceMappingURL=side-menu.template.js.map
