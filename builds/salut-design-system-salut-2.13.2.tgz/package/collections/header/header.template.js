import { html as e } from "lit";
import { classMap as a } from "lit/directives/class-map.js";
import d from "../../assets/img/salut-logotip-default.svg.js";
const r = (s) => e`
  <header
    class=${a({
  "dss-header": !0
})}
  >
    <div class="dss-header-left">
      <div class="dss-header-brand">
        <img
          class="dss-header-logo"
          src="${s.logoSrc ? s.logoSrc : d}"
          alt="Salut logotip"
        />
        ${s.titleText ? e`
              <div  class=${a({
  "dss-header-title": !0,
  "dss-header-title--full-width": s.titleFullWidth
})}
              >
                ${s.area ? e`
                      <span class="dss-header-title__area"
                        >${s.area}</span
                      >
                    ` : null}
                <span class="dss-header-title__name">${s.titleText}</span>
              </div>
            ` : null}
      </div>
      <div class="dss-header-divider"></div>
      <slot name="patient-menu"></slot>
      <div class="dss-header-divider"></div>
      <slot name="allergies"></slot>
      <div class="dss-header-divider"></div>
      <slot name="situation-marks"></slot>
    </div>
    <div class="dss-header-right">
      <slot name="links"></slot>
      <slot name="notifications"></slot>
      <div class="dss-header-divider"></div>
      <slot name="professional-menu"></slot>
    </div>
  </header>
`;
export {
  r as headerTemplate
};
//# sourceMappingURL=header.template.js.map
