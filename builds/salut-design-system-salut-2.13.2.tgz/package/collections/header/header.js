import { LitElement as c, unsafeCSS as f } from "lit";
import { property as o } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import g from "./header.style.css.js";
import { headerTemplate as S } from "./header.template.js";
var v = Object.defineProperty, l = (d, t, e, p) => {
  for (var r = void 0, s = d.length - 1, i; s >= 0; s--)
    (i = d[s]) && (r = i(t, e, r) || r);
  return r && v(t, e, r), r;
};
class a extends c {
  constructor() {
    super(...arguments), this.title = "", this.titleText = "", this.titleFullWidth = !1, this.area = void 0, this.logoSrc = void 0, this.jcef = !1;
  }
  static get styles() {
    return [f(y), f(m), f(g)];
  }
  _propagateProperties() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelectorAll("slot");
    t && t.forEach((p) => {
      p.assignedElements().forEach((s) => {
        this.jcef ? s.setAttribute("jcef", "true") : s.removeAttribute("jcef");
      });
    });
  }
  _updateSlotsDivider() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelectorAll("slot");
    t && t.forEach((p) => {
      const s = p.assignedNodes({ flatten: !0 }).filter((n) => {
        var h;
        return !(n.nodeType === Node.TEXT_NODE && ((h = n == null ? void 0 : n.textContent) == null ? void 0 : h.trim()) === "");
      }).length > 0, i = p.previousElementSibling;
      i && i.classList.contains("dss-header-divider") && (i.style.display = s ? "block" : "none");
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties(), this._updateSlotsDivider();
  }
  updated(t) {
    super.updated(t), t.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return S(this);
  }
}
l([
  o({ type: String })
], a.prototype, "title");
l([
  o({ type: String })
], a.prototype, "titleText");
l([
  o(u)
], a.prototype, "titleFullWidth");
l([
  o({ type: String })
], a.prototype, "area");
l([
  o({ type: String })
], a.prototype, "logoSrc");
l([
  o(u)
], a.prototype, "jcef");
export {
  a as Header
};
//# sourceMappingURL=header.js.map
