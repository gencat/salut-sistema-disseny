import { LitElement as g, unsafeCSS as d, nothing as S } from "lit";
import { property as l } from "lit/decorators.js";
import { unsafeStatic as C, literal as q, html as E } from "lit/static-html.js";
import { getCustomElementSuffix as x } from "../../api/custom-element-scope.js";
import { booleanType as p } from "../../utils/property-types.js";
import U from "../../foundations/icon/icon.style.css.js";
import A from "../badge/badge.states.css.js";
import O from "../button/button.style.css.js";
import R from "../checkbox/checkbox.style.css.js";
import z from "../chip/chip.style.css.js";
import M from "../icon-button/icon-button.style.css.js";
import B from "../radio-button/radio-button.style.css.js";
import W from "./custom-table-header.style.css.js";
import { template as V } from "./custom-table-header.template.js";
var P = Object.defineProperty, $ = Object.getOwnPropertyDescriptor, r = (_, e, t, s) => {
  for (var i = s > 1 ? void 0 : s ? $(e, t) : e, n = _.length - 1, a; n >= 0; n--)
    (a = _[n]) && (i = (s ? a(e, t, i) : a(i)) || i);
  return s && i && P(e, t, i), i;
};
const T = q`dss-chip${C(x())}`;
class o extends g {
  constructor() {
    super(), this._resizeTimer = null, this.tableInfo = void 0, this.showConfig = !1, this.configTableLabel = "Configurar taula", this.hideActionExpand = !1, this.showActionFilters = !1, this.jcef = !1, this.customActions = !1, this._filters = void 0, this._visibleFilters = [], this._hiddenFilters = [], this._filtersExpanded = !1, this._filtersShowMore = !1, this._tableTitle = "", this._innerFilters = !1, this._expandTable = !1, this._expandLabel = "Ampliar", this._collapseLabel = "Reduir", this._rowsOnCollapsed = 5, this._filtersLabel = "Selecció", this._cleanFiltersLabel = "Netejar filtres", this._openFiltersLabel = "Filtres", this._hidetableTitleAndExpand = !1, this._isFirstUpdated = !0, this._isSideMenuLoaded = !1, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [
      d(U),
      d(O),
      d(M),
      d(z),
      d(R),
      d(B),
      d(W),
      d(A)
    ];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), this._sideMenuResizeObserver = new ResizeObserver(() => {
      this._isSideMenuLoaded && this._handleResize(), this._isSideMenuLoaded = !0;
    }), setTimeout(() => {
      var t;
      const e = document.querySelector(`dss-side-menu${x()}`);
      e && ((t = this._sideMenuResizeObserver) == null || t.observe(e));
    }, 0);
  }
  disconnectedCallback() {
    var e;
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), (e = this._sideMenuResizeObserver) == null || e.disconnect();
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      var e, t;
      if (this._filters && !this._innerFilters) {
        this._visibleFilters = this._filters, this._hiddenFilters = [];
        const s = (e = this.shadowRoot) == null ? void 0 : e.querySelector("#filtersWrapper"), i = s == null ? void 0 : s.querySelector(".filters-list");
        i == null || i.classList.add("hide"), this.requestUpdate(), setTimeout(() => {
          this._splitFiltersByLine();
        }, 0);
      }
      if (this._innerFilters) {
        const s = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-custom-table-header");
        s == null || s.classList.remove("dss-custom-table-header--innerfilters-overflow"), setTimeout(() => {
          this._checkInnerFiltersOverflow();
        }, 0);
      }
    }, 250);
  }
  set filters(e) {
    const t = this._filters;
    this._filters = e, this._visibleFilters = e, this._hiddenFilters = [], this.requestUpdate("filters", t);
  }
  get filters() {
    return this._filters ?? [];
  }
  set tableTitle(e) {
    const t = this._tableTitle;
    this._tableTitle = e, this.requestUpdate("tableTitle", t);
  }
  get tableTitle() {
    return this._tableTitle;
  }
  set hidetableTitleAndExpand(e) {
    const t = this._hidetableTitleAndExpand;
    this._hidetableTitleAndExpand = e, this.requestUpdate("hidetableTitleAndExpand", t);
  }
  get hidetableTitleAndExpand() {
    return this._hidetableTitleAndExpand;
  }
  set innerFilters(e) {
    const t = this._innerFilters;
    this._innerFilters = e, this.requestUpdate("innerFilters", t);
  }
  get innerFilters() {
    return this._innerFilters;
  }
  set expandTable(e) {
    const t = this._expandTable;
    this._expandTable = e, this.requestUpdate("expandTable", t);
  }
  get expandTable() {
    return this._expandTable;
  }
  set expandLabel(e) {
    const t = this._expandLabel;
    this._expandLabel = e, this.requestUpdate("expandLabel", t);
  }
  get expandLabel() {
    return this._expandLabel;
  }
  set collapseLabel(e) {
    const t = this._collapseLabel;
    this._collapseLabel = e, this.requestUpdate("collapseLabel", t);
  }
  get collapseLabel() {
    return this._collapseLabel;
  }
  set rowsOnCollapsed(e) {
    const t = this._rowsOnCollapsed;
    this._rowsOnCollapsed = e, this.requestUpdate("rowsOnCollapsed", t);
  }
  get rowsOnCollapsed() {
    return this._rowsOnCollapsed;
  }
  set filtersLabel(e) {
    const t = this._filtersLabel;
    this._filtersLabel = e, this.requestUpdate("filtersLabel", t);
  }
  get filtersLabel() {
    return this._filtersLabel;
  }
  set cleanFiltersLabel(e) {
    const t = this._cleanFiltersLabel;
    this._cleanFiltersLabel = e, this.requestUpdate("cleanFiltersLabel", t);
  }
  get cleanFiltersLabel() {
    return this._cleanFiltersLabel;
  }
  _generateFilterChips(e) {
    let t;
    return e && (t = e.map((s, i) => {
      if (!s) return S;
      const n = (c) => {
        const h = c.detail.text;
        typeof s == "string" ? this._filters = this._filters.filter((f) => f !== h) : this._filters = this._filters.filter((f) => f.value.trim() !== (h == null ? void 0 : h.trim())), this._emitChangeFilters(), this.requestUpdate();
      };
      return E`
					<${T} 
						class="filter-chip"
						data-index="${i}"
						label="${typeof s === "string" ? s : s.value}" 
						size="sm" 
						disableSelect
						hasDelete
						@onDelete="${n}">
					</${T}>
        `;
    })), t;
  }
  _clearFilters() {
    this._filters = [], this._visibleFilters = [], this._hiddenFilters = [], this._emitChangeFilters(), this.requestUpdate();
  }
  // Output events
  _emitExpandAction() {
    this._expandTable = !this._expandTable;
    const e = {
      detail: this._expandTable,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onExpand", e)), this.requestUpdate();
  }
  _emitOpenFilters() {
    const e = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenFilters", e)), this.requestUpdate();
  }
  _emitConfigTable() {
    const e = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onConfigTable", e)), this.requestUpdate();
  }
  _emitChangeFilters() {
    const e = {
      detail: this._filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onChangeFilters", e)), this.requestUpdate();
  }
  async _splitFiltersByLine() {
    var f, F, w, L;
    const e = (f = this.shadowRoot) == null ? void 0 : f.querySelector("#filtersWrapper"), t = (F = this.shadowRoot) == null ? void 0 : F.querySelector("#filtersClean"), s = e == null ? void 0 : e.querySelector(".filters-list"), i = (w = this.shadowRoot) == null ? void 0 : w.querySelector(".filters-show-more"), n = i ? i.clientWidth : 72;
    if (!e || !t || !s) return;
    s.classList.remove("hide"), await this.updateComplete, await new Promise(requestAnimationFrame);
    const a = Array.from(s.querySelectorAll(".filter-chip"));
    if (a.length === 0) {
      this._visibleFilters = [], this._hiddenFilters = [], this._filtersShowMore = !1, this.requestUpdate();
      return;
    }
    let u = e.clientWidth - t.clientWidth - n - 8 - 8;
    const c = [], h = [];
    for (const b of a) {
      const v = Math.ceil(b.getBoundingClientRect().width), m = b.dataset.index ? Number(b.dataset.index) : -1, y = m >= 0 && ((L = this._filters) != null && L[m]) ? this._filters[m] : null;
      y && (v > u ? h.push(y) : (c.push(y), u -= v + 8));
    }
    this._visibleFilters = [...c], this._hiddenFilters = [...h], this._filtersShowMore = h.length > 0, this.requestUpdate();
  }
  _filtersToggleMore() {
    this._filtersExpanded = !this._filtersExpanded, this.requestUpdate();
  }
  _checkInnerFiltersOverflow() {
    const e = window.innerWidth, t = this.jcef ? 1419 : 1440;
    e >= t && setTimeout(() => {
      var a, u, c;
      const s = (a = this.shadowRoot) == null ? void 0 : a.querySelector(".dss-custom-table-header"), i = (u = this.shadowRoot) == null ? void 0 : u.querySelector(".dss-custom-table-header__filters"), n = (c = this.shadowRoot) == null ? void 0 : c.querySelector(".dss-custom-table-header__main-actions");
      !s || !i || !n || (i.scrollWidth + n.scrollWidth > s.clientWidth ? s.classList.add("dss-custom-table-header--innerfilters-overflow") : s.classList.remove("dss-custom-table-header--innerfilters-overflow"));
    }, 0);
  }
  filtersPopoverClose() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector("dss-popover");
    e && e._closePopover();
  }
  async firstUpdated() {
    await this.updateComplete, this._innerFilters ? this._checkInnerFiltersOverflow() : this._splitFiltersByLine(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), e.has("filters") && !this._isFirstUpdated && this._splitFiltersByLine();
  }
  render() {
    return V(this);
  }
}
r([
  l({ type: String })
], o.prototype, "tableInfo", 2);
r([
  l(p)
], o.prototype, "showConfig", 2);
r([
  l({ type: String })
], o.prototype, "configTableLabel", 2);
r([
  l({ type: Array })
], o.prototype, "filters", 1);
r([
  l({ type: String })
], o.prototype, "tableTitle", 1);
r([
  l(p)
], o.prototype, "hidetableTitleAndExpand", 1);
r([
  l(p)
], o.prototype, "innerFilters", 1);
r([
  l(p)
], o.prototype, "expandTable", 1);
r([
  l({ type: String })
], o.prototype, "expandLabel", 1);
r([
  l({ type: String })
], o.prototype, "collapseLabel", 1);
r([
  l({ type: Number })
], o.prototype, "rowsOnCollapsed", 1);
r([
  l({ type: String })
], o.prototype, "filtersLabel", 1);
r([
  l({ type: String })
], o.prototype, "cleanFiltersLabel", 1);
r([
  l(p)
], o.prototype, "hideActionExpand", 2);
r([
  l(p)
], o.prototype, "showActionFilters", 2);
r([
  l(p)
], o.prototype, "jcef", 2);
r([
  l(p)
], o.prototype, "customActions", 2);
export {
  o as CustomTableHeader
};
//# sourceMappingURL=custom-table-header.js.map
