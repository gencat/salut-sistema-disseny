const e = ':root{--legend-bg-color: var(--color-neutral-100)}.dss-legend{display:flex;flex-direction:row;gap:8px;height:-moz-fit-content;height:fit-content;font-weight:400;font-size:12px;line-height:16px}.dss-legend--column{flex-direction:column;gap:8px}.dss-legend__item{list-style:none;display:flex;align-items:center}.dss-legend__icon{display:flex;align-items:center;gap:8px;height:-moz-fit-content;height:fit-content;font-weight:400;font-size:12px;line-height:16px}.dss-legend__item:before{content:"";display:inline-block;background-color:var(--legend-bg-color);width:16px;height:16px;border-radius:4px;margin-right:8px}';
export {
  e as default
};
//# sourceMappingURL=legend.style.css.js.map
