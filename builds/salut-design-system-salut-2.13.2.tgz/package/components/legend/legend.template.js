import { unsafeStatic as o, literal as i, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const a = i`dss-icon${o(t())}`, c = (l) => e`
  <li class="dss-legend__icon" aria-label=${l.label}>
    <${a} style="color: var(--color-${l.color}-${l.shade});" icon="${l.icon || ""}"></${a}>
    ${l.label}
  </li>
`, n = (l) => e`
  <li
    class="dss-legend__item"
    style="--legend-bg-color: var(--color-${l.color}-${l.shade});"
    aria-label=${l.label}
  >
    ${l.label}
  </li>
`, g = (l) => {
  const r = Array.isArray(l.items) ? l.items.slice(0, Math.min(l.itemsPerRowOrColumn, 5)) : [];
  return e`
    <div aria-label="Legenda informativa del gràfic">
      <ul
        class="dss-legend ${l.orientation === "column" ? "dss-legend--column" : ""}"
      >
        ${r.map((s) => l.type === "icon" ? c(s) : n(s))}
      </ul>
    </div>
  `;
};
export {
  g as template
};
//# sourceMappingURL=legend.template.js.map
