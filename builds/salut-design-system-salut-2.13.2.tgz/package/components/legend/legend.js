import { LitElement as l, unsafeCSS as y } from "lit";
import { property as e } from "lit/decorators.js";
import a from "../../shared/reset.style.css.js";
import f from "./legend.style.css.js";
import { template as u } from "./legend.template.js";
var d = Object.defineProperty, r = (p, s, n, h) => {
  for (var t = void 0, i = p.length - 1, m; i >= 0; i--)
    (m = p[i]) && (t = m(s, n, t) || t);
  return t && d(s, n, t), t;
};
class o extends l {
  constructor() {
    super(...arguments), this.orientation = "row", this.items = [], this.itemsPerRowOrColumn = 5, this.type = "color";
  }
  static get styles() {
    return [y(a), y(f)];
  }
  render() {
    return u(this);
  }
}
r([
  e({ type: String })
], o.prototype, "orientation");
r([
  e({ type: Array })
], o.prototype, "items");
r([
  e({ type: Number })
], o.prototype, "itemsPerRowOrColumn");
r([
  e({ type: String })
], o.prototype, "type");
export {
  o as Legend
};
//# sourceMappingURL=legend.js.map
