import { createPopper as f } from "@popperjs/core";
import { LitElement as m, unsafeCSS as u } from "lit";
import { query as c, property as s, state as p } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as o, booleanConverter as l } from "../../utils/property-types.js";
import v from "../form-input/form-input.style.css.js";
import S from "./form-datepicker-range.style.css.js";
import { template as R } from "./form-datepicker-range.template.js";
var E = Object.defineProperty, i = (g, t, a, n) => {
  for (var r = void 0, h = g.length - 1, d; h >= 0; h--)
    (d = g[h]) && (r = d(t, a, r) || r);
  return r && E(t, a, r), r;
};
const _ = class _ extends m {
  constructor() {
    super(), this.labelRangeStart = "", this.labelRangeEnd = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholderRangeStart = "", this.placeholderRangeEnd = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.iconRangeStart = "calendar_today", this.iconRangeEnd = "calendar_today", this.showCalendar = !1, this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.showButtons = !1, this.minDate = "", this.maxDate = "", this.timepicker = "", this.timepickerLabel = "Selecciona una hora", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this.customCalendar = void 0, this.customTimeListOptions = [], this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this.calendarLeftButtonLabel = "Cancel·lar", this.calendarRightButtonLabel = "Seleccionar", this._defaultStartId = `dss-datepicker-range-start-${crypto.randomUUID()}`, this._defaultEndId = `dss-datepicker-range-end-${crypto.randomUUID()}`, this._isStartFocused = !1, this._isEndFocused = !1, this._isTruncated = !1, this._helpText = "", this._dateformatPlaceholder = "DD/MM/AAAA", this._copyInputRangeStartPlaceholder = "", this._copyInputRangeEndPlaceholder = "", this._popperInstance = null, this._placeholderStart = "", this._placeholderEnd = "", this._helpTextBackup = "", this._isFirstUpdated = !0, this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [u(y), u(v), u(S)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeCalendarListener();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _getEffectiveStartId() {
    return this.id !== "" ? `${this.id}-start` : this._defaultStartId;
  }
  _getEffectiveEndId() {
    return this.id !== "" ? `${this.id}-end` : this._defaultEndId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._helpTextBackup = this.helpText ?? "", this._createPopperCalendar(), this._inputRangeStart && this._inputRangeEnd && (this._inputRangeStart.classList.add("dss-input-skip-native"), this._inputRangeEnd.classList.add("dss-input-skip-native"));
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && (this.internals.setFormValue(this.value), queueMicrotask(() => {
      this._applyValue();
    })), t.has("placeholderRangeStart") && this._isFirstUpdated && (this._placeholderStart = this.placeholderRangeStart, this._copyInputRangeStartPlaceholder = this.placeholderRangeStart), t.has("placeholderRangeEnd") && this._isFirstUpdated && (this._placeholderEnd = this.placeholderRangeEnd, this._copyInputRangeEndPlaceholder = this.placeholderRangeEnd), t.has("helpText") && queueMicrotask(() => {
      this._helpText = this.helpText ?? "";
    });
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._hiddenInput.value = "", this._inputRangeStart.value = "", this._inputRangeEnd.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._hiddenInput.value = t ?? "", this._inputRangeStart.value = t ?? "", this._inputRangeEnd.value = t ?? "";
  }
  render() {
    return R(this);
  }
  /* Handle Input Events */
  _applyValue() {
    if (this.value === this._hiddenInput.value) return;
    const t = this.value.includes(",");
    let a = "", n = "";
    if (t) {
      const r = this.value.split(",");
      a = r[0] || "", n = r[1] || "";
    } else
      a = this.value, n = "";
    this._inputRangeStart.value = a, this._inputRangeEnd.value = n;
  }
  _handleRangeStartInput(t) {
    if (t.target) {
      const n = t.target.value.replace(/\D/g, "");
      this._inputRangeStart.value = this._formatDate(n), this._updateHiddenInput();
    }
  }
  _handleRangeEndInput(t) {
    if (t.target) {
      const n = t.target.value.replace(/\D/g, "");
      this._inputRangeEnd.value = this._formatDate(n), this._updateHiddenInput();
    }
  }
  _handleRangeStartClick() {
    this.showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate();
  }
  _handleRangeEndClick() {
    this.showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate();
  }
  _handleRangeStartFocusIn() {
    this._isStartFocused || (this._isStartFocused = !0, this._isEndFocused = !1, this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder"), this._updatePlaceholders(), this.requestUpdate());
  }
  _handleRangeEndFocusIn() {
    this._isEndFocused || (this._isStartFocused = !1, this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._isEndFocused = !0, this._updatePlaceholders(), this.requestUpdate());
  }
  _handleRangeKeydown(t) {
    var a, n;
    (t == null ? void 0 : t.key) === "Tab" ? this.showCalendar && this._isStartFocused && (t.preventDefault(), this.dispatchEvent(
      new CustomEvent("range-focus-calendar", {
        bubbles: !0,
        composed: !0
      })
    )) : (t == null ? void 0 : t.key) === "Enter" && this.showCalendar && ((a = this._inputRangeStart.value) == null ? void 0 : a.length) > 7 && ((n = this._inputRangeEnd.value) == null ? void 0 : n.length) > 7 ? this._closeCalendar() : (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this.showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate()) : (t == null ? void 0 : t.key) === "Escape" && (this.showCalendar = !1, this._popperInstance.update(), this._removeCalendarListener(), this.requestUpdate());
  }
  _dispatchValueChange(t) {
    const a = new CustomEvent("value-changed", {
      detail: t,
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(a), this._updateHiddenInput();
  }
  _updateHiddenInput() {
    var r, h;
    if (!this._hiddenInput) return;
    const t = ((r = this._inputRangeStart) == null ? void 0 : r.value) || "", a = ((h = this._inputRangeEnd) == null ? void 0 : h.value) || "";
    let n = "";
    t && a ? n = `${t},${a}` : t ? n = t : a && (n = a), this._hiddenInput.value = n, this.value = n, this._emitChange();
  }
  // _emitInput() {
  // 	this._hiddenInput.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
  // }
  _emitChange() {
    this._hiddenInput.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _onCalendarChange(t) {
    const a = t.detail;
    if (a.rangeStart) {
      this._inputRangeStart.value = t.detail.rangeStart;
      const n = this._convertToISO(a.rangeStart), r = this._convertToISO(this._inputRangeEnd.value);
      this._inputRangeEnd.value && new Date(r) < new Date(n) && (this._inputRangeEnd.value = "", a.rangeEnd = null);
    }
    a.rangeEnd ? this._inputRangeEnd.value = t.detail.rangeEnd : this._inputRangeEnd.value = "", this._inputRangeEnd.value || (this._inputRangeEnd.focus(), this._isStartFocused = !1, this._isEndFocused = !0), this._inputRangeStart.value && this._inputRangeEnd.value && (this.showCalendar = !1, this._isStartFocused = !1, this._isEndFocused = !1, this._removeCalendarListener()), this.validate && this._validateDate(), this._dispatchValueChange(a), this.requestUpdate();
  }
  _onCalendarCancel() {
    this.showCalendar = !1, this._removeCalendarListener(), this.requestUpdate();
  }
  _updatePlaceholders() {
    this._isStartFocused && !this._copyInputRangeStartPlaceholder && (this._inputRangeStart.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate()), this._isEndFocused && !this._copyInputRangeEndPlaceholder && (this._inputRangeEnd.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate());
  }
  _removePlaceholders() {
    this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
  }
  // _checkInputOverflow() {
  // 	if (!this._input) return;
  // 	const inputStyle = window.getComputedStyle(this._input);
  // 	const inputFont = `${inputStyle.fontWeight} ${inputStyle.fontSize} ${inputStyle.fontFamily}`;
  // 	const canvas = document.createElement('canvas');
  // 	const context = canvas.getContext('2d');
  // 	if (!context) return;
  // 	context.font = inputFont;
  // 	const textWidth = context.measureText(this._input.value).width;
  // 	this._isTruncated = textWidth > this._input.offsetWidth;
  // }
  /* Hamdle Datepicker Validations */
  // _handleValidity() {
  // 	const validity = this._input?.checkValidity();
  // 	if (validity !== undefined) this._inputValidity = validity;
  // 	this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  // }
  _validateDate() {
    var a, n;
    let t = this._checkDateFormat((a = this._inputRangeStart) == null ? void 0 : a.value);
    t || (t = this._checkDateFormat((n = this._inputRangeEnd) == null ? void 0 : n.value)), this._dispatchOnValidate(t);
  }
  // _validateDate() {
  // 	const invalid = this._checkDateFormat(this._input?.value);
  // 	if (invalid) {
  // 		this._input.setCustomValidity(this._helpText);
  // 		this.internals.setValidity(
  // 			{ customError: true },
  // 			this._helpText,
  // 			this._input
  // 		);
  // 	} else {
  // 		this._input.setCustomValidity('');
  // 		this.internals.setValidity({});
  // 	}
  // 	this._dispatchOnValidate(invalid);
  // }
  _checkDateFormat(t) {
    if (!t || t === void 0)
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t === "")
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t.length < 10)
      return this._helpText = this.errorMessageFormat, this.invalid = !0, !0;
    if (this.minDate || this.maxDate) {
      const n = new Date(this._convertToISO(t)), r = new Date(this._convertToISO(this.minDate)), h = new Date(this._convertToISO(this.maxDate));
      if (r && n < r)
        return this._helpText = this.errorMessageMinDate, this.invalid = !0, !0;
      if (h && n > h)
        return this._helpText = this.errorMessageMaxDate, this.invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
  }
  _convertToISO(t) {
    const [a, n, r] = t.split("/");
    return `${r}-${n}-${a}`;
  }
  _dispatchOnValidate(t) {
    var n, r;
    const a = {
      detail: {
        rangeStart: (n = this._inputRangeStart) == null ? void 0 : n.value,
        rangeEnd: (r = this._inputRangeEnd) == null ? void 0 : r.value,
        invalid: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("validate", a));
  }
  // Datepicker specific methods
  _formatDate(t) {
    let a = t.substring(0, 2), n = t.substring(2, 4);
    const r = t.substring(4, 8);
    return Number(a) > 3 && (a = a == null ? void 0 : a.padStart(2, "0")), Number(n) > 1 && (n = n == null ? void 0 : n.padStart(2, "0")), Number(a) > 31 && (a = "31"), Number(n) > 12 && (n = "12"), n === "02" && Number(a) > 28 && (r == null ? void 0 : r.length) === 4 && (a = new Date(Number(r), 1, 29).getMonth() === 1 ? "29" : "28"), `${a}${n ? `/${n}` : ""}${r ? `/${r}` : ""}`;
  }
  _clearDate(t) {
    switch (t) {
      case "rangeStart":
        if (!this._inputRangeStart) return;
        this._inputRangeStart.value = "", this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder");
        break;
      case "rangeEnd":
        if (!this._inputRangeEnd) return;
        this._inputRangeEnd.value = "", this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
        break;
    }
    this._validateDate(), this._updateHiddenInput(), this.requestUpdate();
  }
  /* Handle Popper */
  _createPopperCalendar() {
    var n, r;
    const t = (n = this.shadowRoot) == null ? void 0 : n.querySelector(".dss-datepicker-range-inputs__start"), a = (r = this.shadowRoot) == null ? void 0 : r.querySelector(".dss-calendar");
    t && a && (this._popperInstance = f(t, a, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  _closeCalendar() {
    var t, a;
    this._removePlaceholders(), this._isStartFocused = !1, this._isEndFocused = !1, this.showCalendar = !1, (t = this._inputRangeStart) == null || t.blur(), (a = this._inputRangeEnd) == null || a.blur(), this._removeCalendarListener(), this.validate && this._validateDate(), this.requestUpdate();
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this.showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const a = t.relatedTarget;
    a !== null && a !== this && a !== this._inputRangeStart && a !== this._inputRangeEnd && this.showCalendar && this._closeCalendar();
  }
};
_.formAssociated = !0;
let e = _;
i([
  c("input.dss-input.dss-input--start")
], e.prototype, "_inputRangeStart");
i([
  c("input.dss-input.dss-input--end")
], e.prototype, "_inputRangeEnd");
i([
  c("input.dss-hidden-value")
], e.prototype, "_hiddenInput");
i([
  s({ type: String })
], e.prototype, "labelRangeStart");
i([
  s({ type: String })
], e.prototype, "labelRangeEnd");
i([
  s(o)
], e.prototype, "hideLabel");
i([
  s({ type: String })
], e.prototype, "name");
i([
  s({ type: String })
], e.prototype, "id");
i([
  s({ type: String })
], e.prototype, "type");
i([
  s({ type: String })
], e.prototype, "placeholderRangeStart");
i([
  s({ type: String })
], e.prototype, "placeholderRangeEnd");
i([
  s({ type: String })
], e.prototype, "value");
i([
  s({ converter: l, reflect: !0 })
], e.prototype, "disabled");
i([
  s({ converter: l, reflect: !0 })
], e.prototype, "readonly");
i([
  s({ converter: l, reflect: !0 })
], e.prototype, "required");
i([
  s({ converter: l, reflect: !0 })
], e.prototype, "invalid");
i([
  s({ type: Number })
], e.prototype, "step");
i([
  s({ type: Number })
], e.prototype, "min");
i([
  s({ type: Number })
], e.prototype, "max");
i([
  s({ type: Number })
], e.prototype, "minLength");
i([
  s({ type: String })
], e.prototype, "pattern");
i([
  s({ type: String })
], e.prototype, "inputmode");
i([
  s({ type: String })
], e.prototype, "autocapitalize");
i([
  s({ type: String })
], e.prototype, "autocomplete");
i([
  s(o)
], e.prototype, "autocorrect");
i([
  s(o)
], e.prototype, "autofocus");
i([
  s(o)
], e.prototype, "spellcheck");
i([
  s({ type: String })
], e.prototype, "size");
i([
  s({ type: String })
], e.prototype, "iconRangeStart");
i([
  s({ type: String })
], e.prototype, "iconRangeEnd");
i([
  s({ type: String })
], e.prototype, "helpText");
i([
  s(o)
], e.prototype, "showCalendar");
i([
  s({ type: String })
], e.prototype, "dropdownPlacement");
i([
  s(o)
], e.prototype, "dropdownFixed");
i([
  s(o)
], e.prototype, "showButtons");
i([
  s({ type: String })
], e.prototype, "minDate");
i([
  s({ type: String })
], e.prototype, "maxDate");
i([
  s({ type: String })
], e.prototype, "timepicker");
i([
  s({ type: String })
], e.prototype, "timepickerLabel");
i([
  s({ type: Number })
], e.prototype, "minHour");
i([
  s({ type: Number })
], e.prototype, "maxHour");
i([
  s({ type: Number })
], e.prototype, "minutesRange");
i([
  s({ type: Array })
], e.prototype, "customCalendar");
i([
  s({ type: Array })
], e.prototype, "customTimeListOptions");
i([
  s(o)
], e.prototype, "validate");
i([
  s(o)
], e.prototype, "errorMessageFormat");
i([
  s(o)
], e.prototype, "errorMessageMinDate");
i([
  s(o)
], e.prototype, "errorMessageMaxDate");
i([
  s({ type: String })
], e.prototype, "calendarLeftButtonLabel");
i([
  s({ type: String })
], e.prototype, "calendarRightButtonLabel");
i([
  p()
], e.prototype, "_isStartFocused");
i([
  p()
], e.prototype, "_isEndFocused");
i([
  p()
], e.prototype, "_isTruncated");
i([
  p()
], e.prototype, "_helpText");
export {
  e as FormDatepickerRange
};
//# sourceMappingURL=form-datepicker-range.js.map
