import { nothing as e } from "lit";
import { classMap as s } from "lit/directives/class-map.js";
import { ifDefined as V } from "lit/directives/if-defined.js";
import { unsafeStatic as r, literal as t, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const P = t`dss-calendar${r(u())}`, i = t`dss-icon${r(u())}`, l = t`dss-icon-button${r(u())}`, aa = (a) => {
  var g, $, n, _, R, b, v, p, h, f, E, S, y, k, C, z, w, c, I, q, D, x, B, L, F, O, T, j, G, K, N;
  const W = {
    "dss-datepicker-range--sm": a.size !== "lg"
  }, M = {
    "dss-datepicker-range-help--invalid": a.invalid || !((g = a._inputRangeStart) != null && g.validity.valid) && (($ = a._inputRangeStart) == null ? void 0 : $.value) !== "" || !((n = a._inputRangeEnd) != null && n.validity.valid) && ((_ = a._inputRangeEnd) == null ? void 0 : _.value) !== "",
    "dss-datepicker-range-help--disabled": ((R = a._inputRangeStart) == null ? void 0 : R.disabled) && ((b = a._inputRangeEnd) == null ? void 0 : b.disabled)
  }, A = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": (v = a._inputRangeStart) == null ? void 0 : v.required,
    "dss-input-wrapper--disabled": (p = a._inputRangeStart) == null ? void 0 : p.disabled,
    [`dss-input-wrapper--${a.size}`]: !!a.size
  }, H = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": (h = a._inputRangeEnd) == null ? void 0 : h.required,
    "dss-input-wrapper--disabled": (f = a._inputRangeEnd) == null ? void 0 : f.disabled,
    [`dss-input-wrapper--${a.size}`]: !!a.size
  }, J = {
    "dss-input-group": !0,
    [`dss-input-group--${a.size}`]: !!a.size,
    "dss-input-group--invalid": a.invalid || !((E = a._inputRangeStart) != null && E.validity.valid) && ((S = a._inputRangeStart) == null ? void 0 : S.value) !== "",
    "dss-input-group--required": (y = a._inputRangeStart) == null ? void 0 : y.required,
    "dss-input-group--disabled": (k = a._inputRangeStart) == null ? void 0 : k.disabled,
    "dss-input-group--focused": ((C = a._inputRangeStart) == null ? void 0 : C.value) || a._isStartFocused || a._copyInputRangeStartPlaceholder,
    "dss-input-group--read-only": (z = a._inputRangeStart) == null ? void 0 : z.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, Q = {
    "dss-input-group": !0,
    [`dss-input-group--${a.size}`]: !!a.size,
    "dss-input-group--invalid": a.invalid || !((w = a._inputRangeEnd) != null && w.validity.valid) && ((c = a._inputRangeEnd) == null ? void 0 : c.value) !== "",
    "dss-input-group--required": (I = a._inputRangeEnd) == null ? void 0 : I.required,
    "dss-input-group--disabled": (q = a._inputRangeEnd) == null ? void 0 : q.disabled,
    "dss-input-group--focused": ((D = a._inputRangeEnd) == null ? void 0 : D.value) || a._isEndFocused || a._copyInputRangeEndPlaceholder,
    "dss-input-group--read-only": (x = a._inputRangeEnd) == null ? void 0 : x.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, U = {
    "dss-calendar": !0,
    "dss-calendar--visible": a.showCalendar && !((B = a._inputRangeStart) != null && B.readOnly) && !((L = a._inputRangeEnd) != null && L.readOnly),
    "dss-calendar--disabled": ((F = a._inputRangeStart) == null ? void 0 : F.disabled) && ((O = a._inputRangeEnd) == null ? void 0 : O.disabled),
    "dss-calendar--sm": a.size !== "lg"
  };
  return d`
      <div class="dss-datepicker-range ${s(W)}">
        <input 
          type="hidden" 
          class="dss-hidden-value" 
          .name=${a.name}
        />

        <div 
          class="dss-datepicker-range-inputs" 
          role="combobox"
          aria-controls="datepicker-range-calendar"
          aria-haspopup="dialog"
          aria-expanded=${V(a.showCalendar)}>

          <div class="dss-datepicker-range-inputs__start ${s(A)}">
            ${a.size === "sm" ? d`
                <div class="dss-wrapper-label">
                  <label class="dss-label dss-label--start" for="${a._getEffectiveStartId()}">${a.labelRangeStart}</label>
                </div>
              ` : e}
            <div class="${s(J)}">
              ${a.iconRangeStart && a.iconRangeStart !== "" ? d`
                <${i} icon="${a.iconRangeStart}" class="dss-input-icon"></${i}>
                ` : e}
              <div class="dss-input-field">
                ${a.size !== "sm" && !a.hideLabel ? d`
                      <label class="dss-label dss-label--start" for="${a._getEffectiveStartId()}">${a.labelRangeStart}</label>
                    ` : e}
        
                <input
                  class="dss-input dss-input--start"
                  id=${a._getEffectiveStartId()}
                  .type=${a.type}
                  .name="${a.name ? `${a.name}-start` : e}"
                  .placeholder=${a.placeholderRangeStart}
                  ?disabled=${a.disabled}
                  ?readonly=${a.readonly}
                  ?required=${a.required}
                  ?autofocus=${a.autofocus}
                  spellcheck=${a.spellcheck ? "true" : "false"}
                  autocorrect=${a.autocorrect ? "on" : "off"}
                  autocomplete=${a.autocomplete}
                  autocapitalize=${a.autocapitalize}
                  pattern=${a.pattern ?? e}
                  inputmode=${a.inputmode ?? e}
                  aria-label="${a.hideLabel ? a.labelRangeStart : e}"
                  @click=${a._handleRangeStartClick}
                  @input=${a._handleRangeStartInput}
                  @focusin=${a._handleRangeStartFocusIn}
                  @keydown=${a._handleRangeKeydown}
                />
              </div>
              <${l}
                hideTooltip
                size="md"
                icon="close"
                label="Netejar"
                @onClick=${() => a._clearDate("rangeStart")}
                ?hidden=${!((T = a._inputRangeStart) != null && T.value) || a._inputRangeStart.readOnly || a._inputRangeStart.disabled}
              ></${l}>
            </div>
          </div>

          <div class="dss-datepicker-range-inputs__end ${s(H)}">
            ${a.size === "sm" ? d`
                <div class="dss-wrapper-label">
                  <label class="dss-label dss-label--end" for="${a._getEffectiveEndId()}">${a.labelRangeEnd}</label>
                </div>
              ` : e}
            <div class="${s(Q)}">
              ${a.iconRangeEnd && a.iconRangeEnd !== "" ? d`
                <${i} icon="${a.iconRangeEnd}" class="dss-input-icon"></${i}>
                ` : e}
              <div class="dss-input-field">
                ${a.size !== "sm" && !a.hideLabel ? d`
                      <label class="dss-label dss-label--end" for="${a._getEffectiveEndId()}">${a.labelRangeEnd}</label>
                    ` : e}
        
                <input
                  class="dss-input dss-input--end"
                  id=${a._getEffectiveEndId()}
                  .type=${a.type}
                  .name="${a.name ? `${a.name}-end` : e}"
                  .placeholder=${a.placeholderRangeEnd}
                  ?disabled=${a.disabled}
                  ?readonly=${a.readonly}
                  ?required=${a.required}
                  ?autofocus=${a.autofocus}
                  spellcheck=${a.spellcheck ? "true" : "false"}
                  autocorrect=${a.autocorrect ? "on" : "off"}
                  autocomplete=${a.autocomplete}
                  autocapitalize=${a.autocapitalize}
                  pattern=${a.pattern ?? e}
                  inputmode=${a.inputmode ?? e}
                  aria-label="${a.hideLabel ? a.labelRangeEnd : e}"
                  @click=${a._handleRangeEndClick}
                  @input=${a._handleRangeEndInput}
                  @focusin=${a._handleRangeEndFocusIn}
                  @keydown=${a._handleRangeKeydown}
                />
              </div>
              <${l}
                hideTooltip
                size="md"
                icon="close"
                label="Netejar"
                @onClick=${() => a._clearDate("rangeEnd")}
                ?hidden=${!((j = a._inputRangeEnd) != null && j.value) || a._inputRangeEnd.readOnly || a._inputRangeEnd.disabled}
              ></${l}>
            </div>
          </div>
       
        </div>

        ${a._helpText ? d`
              <div class="dss-datepicker-range-help ${s(M)}">
                ${a._helpText}
              </div>
            ` : null}
       
        <${P}
          range
          .isRangeStartFocused=${a._isStartFocused}
          .isRangeEndFocused=${a._isEndFocused}
          role="listbox"
          aria-label="Datepicker Range Calendar"
          id="datepicker-range-calendar"
          class="${s(U)}"
          .selectedDate="${(G = a._inputRangeStart) == null ? void 0 : G.value}"
          .rangeStartDate="${(K = a._inputRangeStart) == null ? void 0 : K.value}"
          .rangeEndDate="${(N = a._inputRangeEnd) == null ? void 0 : N.value}"
          .customCalendar=${a.customCalendar}
          .showButtons=${a.showButtons}
          .leftLabel=${a.calendarLeftButtonLabel}
          .rightLabel=${a.calendarRightButtonLabel}
          .minDate=${a.minDate}
          .maxDate=${a.maxDate}
          @range-changed=${a._onCalendarChange}
          @onCancel=${a._onCalendarCancel}
        ></${P}>
      </div>
    `;
};
export {
  aa as template
};
//# sourceMappingURL=form-datepicker-range.template.js.map
