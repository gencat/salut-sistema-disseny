import { LitElement as f, unsafeCSS as d } from "lit";
import { property as o, state as p } from "lit/decorators.js";
import y from "../../api/marker/marker.style.css.js";
import S from "../../shared/reset.style.css.js";
import _ from "../../shared/scrollbar.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import v from "./form-select-options.style.css.js";
import { template as b } from "./form-select-options.template.js";
var A = Object.defineProperty, s = (u, e, t, l) => {
  for (var r = void 0, a = u.length - 1, c; a >= 0; a--)
    (c = u[a]) && (r = c(e, t, r) || r);
  return r && A(e, t, r), r;
};
class i extends f {
  constructor() {
    super(...arguments), this.isOpen = !1, this.elements = null, this.value = null, this._value = null, this.type = "default", this.filter = null, this.multiple = !1, this.tick = !0, this.deselectable = !1, this.selectAll = !1, this.isDisplayed = !1, this.readonly = !1, this.disabled = !1, this.boxShadow = !1, this.advancedFilter = !1, this.searchThreshold = 1, this.filterThreshold = 1, this.boxStyle = "", this.selectedCounter = 0, this.ariaLabel = null, this.labelSelectAll = "Seleccionar-ho tot", this.labelDeselectAll = "Deseleccionar-ho tot", this.emptySelectorLabel = "Sense resultats per", this.emptyFilterLabel = "Escriu per cercar.", this._elementId = `dss-selector-${(/* @__PURE__ */ new Date()).getTime()}`, this._elementSelectAll = [], this._style = null, this._isAllSelected = !1, this._syncSelectedValue = !1;
  }
  static get styles() {
    return [d(S), d(_), d(y), d(v)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  // LIT LIFECYCLE
  updated(e) {
    e.has("value") && queueMicrotask(() => {
      this._updateSelectedValues();
    }), e.has("elements") && queueMicrotask(() => {
      this._checkElements();
    }), e.has("boxStyle") && queueMicrotask(() => {
      this._style = this.boxStyle;
    }), e.has("filter") && this.selectAll && queueMicrotask(() => {
      this._areAllElementsSelected();
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._elementSelectAll = [this.labelSelectAll], this._areAllElementsSelected();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  // METHODS
  _checkElements() {
    var e;
    this._syncSelectedValue || (e = this.elements) != null && e.length && (!this.value || this.value.length === 0 || (console.log("Checking elements and selected value:", this, this.elements, this.value, this._syncSelectedValue), this._updateSelectedValues(), this._syncSelectedValue = !0));
  }
  _updateSelectedValues() {
    var t, l;
    if (!((t = this.elements) != null && t.length)) return;
    if (!this.value || this.value.length === 0) {
      this._value = null;
      return;
    }
    this.multiple && setTimeout(() => {
      var r;
      this._value = ((r = this.elements) == null ? void 0 : r.filter((a) => this.value.includes(a.value))) || null;
    }, 0);
    const e = (l = this.elements) == null ? void 0 : l.find((r) => r.value === this.value[0]);
    this._value = e ? [e] : null;
  }
  _areAllElementsSelected() {
    if (!this.elements || !this._value) {
      this._elementSelectAll = [this.labelSelectAll], this._isAllSelected = !1;
      return;
    }
    const e = this._value.map((l) => l.value), t = this.elements.map((l) => l.value);
    this._isAllSelected = e.length === t.length && e.every((l) => t.includes(l)), this._isAllSelected ? this._elementSelectAll = [this.labelDeselectAll] : this._elementSelectAll = [this.labelSelectAll];
  }
  _valueIsSelected(e) {
    var t;
    return ((t = this._value) == null ? void 0 : t.some((l) => l.value === e)) || !1;
  }
  _manuallySelect(e, t) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly) return;
    const l = this._valueIsSelected(t);
    if (!this.multiple && !this.deselectable && l) return;
    const r = e.target, a = r.className.includes("dss-mark") ? r.parentElement : r;
    a && a.className.includes("dss-form-field") ? a.querySelector("input").checked = !l : a && (a.parentElement.querySelector("input").checked = !l), this._returnSelectedValues(t), this._areAllElementsSelected();
  }
  _manuallySelectAll(e) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly || !this.multiple && !this.deselectable && this._isAllSelected) return;
    const t = e.target;
    t.className.includes("dss-form-field") ? (t.querySelector("input").checked = !t.querySelector("input").checked, this._returnSelecteAllValues(t.querySelector("input").checked)) : (t.parentElement.querySelector("input").checked = !t.parentElement.querySelector("input").checked, this._returnSelecteAllValues(t.parentElement.querySelector("input").checked)), this._areAllElementsSelected();
  }
  _returnSelecteAllValues(e) {
    var r, a;
    e ? this._value = ((r = this.elements) == null ? void 0 : r.filter((c) => c.value)) || [] : this._value = [];
    const l = {
      detail: ((a = this._value) == null ? void 0 : a.map((c) => c.value)) || null,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", l)), this.requestUpdate();
  }
  _returnSelectedValues(e) {
    var c, m;
    const t = Array.from(((c = this.shadowRoot) == null ? void 0 : c.querySelectorAll("input:checked")) || []).map((h) => h.getAttribute("value")).filter((h) => h == null ? !1 : this.multiple ? !0 : h === e), l = t.indexOf(this._elementSelectAll[0]);
    l !== -1 && t.splice(l, 1), this._value = ((m = this.elements) == null ? void 0 : m.filter((h) => t.includes(h.value))) || [];
    let r;
    this.multiple ? r = t : r = t[0] || null;
    const a = {
      detail: r,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", a)), this.requestUpdate();
  }
  selectFirstMatch() {
    var l;
    const e = (l = this.shadowRoot) == null ? void 0 : l.querySelectorAll(".dss-form-field");
    let t = null;
    for (const r of e || []) {
      const a = r.getAttribute("data-label");
      if (a && this.filter && a.toLowerCase() === this.filter.toLowerCase()) {
        t = r;
        break;
      }
    }
    t && t.click();
  }
  moveFocus() {
    var r;
    const e = (r = this.shadowRoot) == null ? void 0 : r.querySelectorAll(".dss-form-field");
    if (!e || e.length === 0) return;
    const l = e[0].querySelector("input");
    l && l.focus();
  }
  _focusEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.add("dss-form-field__focus");
  }
  _blurEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.remove("dss-form-field__focus");
  }
  render() {
    return b(this);
  }
}
s([
  o(n)
], i.prototype, "isOpen");
s([
  o({ type: Array })
], i.prototype, "elements");
s([
  o({ type: Array })
], i.prototype, "value");
s([
  p()
], i.prototype, "_value");
s([
  o({ type: String })
], i.prototype, "type");
s([
  o({
    type: String,
    converter: (u) => (u == null ? void 0 : u.toLowerCase()) ?? null
  })
], i.prototype, "filter");
s([
  o(n)
], i.prototype, "multiple");
s([
  o(n)
], i.prototype, "tick");
s([
  o(n)
], i.prototype, "deselectable");
s([
  o(n)
], i.prototype, "selectAll");
s([
  o(n)
], i.prototype, "isDisplayed");
s([
  o(n)
], i.prototype, "readonly");
s([
  o(n)
], i.prototype, "disabled");
s([
  o(n)
], i.prototype, "boxShadow");
s([
  o(n)
], i.prototype, "advancedFilter");
s([
  o({ type: Number })
], i.prototype, "searchThreshold");
s([
  o({ type: Number })
], i.prototype, "filterThreshold");
s([
  o({ type: String })
], i.prototype, "boxStyle");
s([
  o({ type: Number })
], i.prototype, "selectedCounter");
s([
  o({ type: String })
], i.prototype, "ariaLabel");
s([
  o({ type: String })
], i.prototype, "labelSelectAll");
s([
  o({ type: String })
], i.prototype, "labelDeselectAll");
s([
  o({ type: String })
], i.prototype, "emptySelectorLabel");
s([
  o({ type: String })
], i.prototype, "emptyFilterLabel");
s([
  p()
], i.prototype, "_elementId");
s([
  p()
], i.prototype, "_elementSelectAll");
s([
  p()
], i.prototype, "_style");
s([
  p()
], i.prototype, "_isAllSelected");
s([
  p()
], i.prototype, "_syncSelectedValue");
export {
  i as FormSelectOptions
};
//# sourceMappingURL=form-select-options.js.map
