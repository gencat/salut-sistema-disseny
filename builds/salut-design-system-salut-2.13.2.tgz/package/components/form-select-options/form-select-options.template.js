import { classMap as w } from "lit/directives/class-map.js";
import { ifDefined as q } from "lit/directives/if-defined.js";
import { unsafeHTML as T } from "lit/directives/unsafe-html.js";
import { unsafeStatic as L, literal as D, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as I } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as M, highlightText as U } from "../../api/marker/marker.js";
const x = D`dss-icon${L(I())}`, z = D`dss-spinner${L(I())}`, F = (s) => {
  var f;
  return (f = s.elements) == null ? void 0 : f.map((e, r) => {
    var d;
    const S = e.label.trim().replace(/\s+/g, "-"), E = e.value.trim().replace(/\s+/g, "-"), v = `selector-${S}-${E}`, b = s._valueIsSelected(e.value), u = s.tick && !s.multiple, t = w({
      disabled: s.disabled,
      "dss-disabled": s.disabled,
      "dss-form-field": !0,
      "dss-form-field--simple": s.tick && !s.multiple,
      "dss-form-field--multiple": s.multiple,
      "dss-form-field--readonly": s.readonly,
      "dss-form-field--no-tick": !s.tick,
      "dss-type--default": s.type === "default",
      "dss-type--green": s.type === "green",
      "dss-ticked": u,
      "dss-selected": b && u,
      "dss-form-field--selected": b,
      "dss-first-unselected": r && r > 0 && r === s.selectedCounter,
      "dss-form-field--match": e.label.toLowerCase() === ((d = s.filter) == null ? void 0 : d.toLowerCase())
    }), k = w({
      "dss-checkbox": s.multiple,
      "dss-radio": !s.multiple,
      "dss-disabled": s.disabled,
      hidden: u
    }), h = l`
      <input
        id="${v}"
        name="${v}"
        type="checkbox"
        class="${k}"
        .value="${e.value}"
        .checked="${b}"
        @focus="${s._focusEvent}"
        @blur="${s._blurEvent}"
        ?disabled="${s.disabled || s.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `, g = l`<span
      class="dss-icon--checked"
      style="visibility: ${s.isOpen && u && b ? "visible" : "hidden"}"
    ></span>`;
    return l`
      <div
        class="${t}"
        @keydown="${(a) => {
      var _, A, p, C;
      if (a.key === "Enter" || a.key === " ")
        s._manuallySelect(a, e.value);
      else if (a.key === "ArrowUp") {
        const y = a.target, $ = (A = (_ = y == null ? void 0 : y.closest(".dss-form-field")) == null ? void 0 : _.previousElementSibling) == null ? void 0 : A.querySelector("input");
        $ == null || $.focus();
      } else if (a.key === "ArrowDown") {
        const y = a.target, $ = (C = (p = y == null ? void 0 : y.closest(".dss-form-field")) == null ? void 0 : p.nextElementSibling) == null ? void 0 : C.querySelector("input");
        $ == null || $.focus();
      }
    }}"
        @click="${(a) => {
      s._manuallySelect(a, e.value);
    }}"
        data-label="${e.label}"
      >
        ${h}
        <label for=${v}>
          ${s.advancedFilter ? T(M(e.label, s.filter || "", s.searchThreshold)) : T(U(e.label, s.filter || ""))}
        </label>
        ${g}
      </div>
    `;
  });
}, H = (s) => {
  var f;
  return (f = s._elementSelectAll) == null ? void 0 : f.map((e) => {
    var u;
    const r = w({
      disabled: s.disabled || s.readonly,
      "dss-form-field": !0,
      "dss-type--default": s.type === "default",
      "dss-type--green": s.type === "green",
      "dss-selectAll": !0,
      "dss-disabled": s.disabled || s.readonly,
      "dss-form-field--match": e.toLowerCase() === ((u = s.filter) == null ? void 0 : u.toLowerCase())
    }), S = w({
      "dss-checkbox": s.multiple
    }), E = l`
      <input
        id="${s._elementId}"
        name="${s._elementId}"
        type="checkbox"
        class="${S}"
        .value="${e}"
        .checked="${s._isAllSelected}"
        @focus="${s._focusEvent}"
        @blur="${s._blurEvent}"
        ?disabled="${s.disabled || s.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `;
    return l`
      <div
        class="${r}"
        @keydown="${(t) => {
      var k, h, g, o;
      if (t.key === "Enter" || t.key === " ")
        s._manuallySelectAll(t);
      else if (t.key === "ArrowUp") {
        const c = t.target, d = (h = (k = c == null ? void 0 : c.closest(".dss-form-field")) == null ? void 0 : k.previousElementSibling) == null ? void 0 : h.querySelector("input");
        d == null || d.focus();
      } else if (t.key === "ArrowDown") {
        const c = t.target, d = (o = (g = c == null ? void 0 : c.closest(".dss-form-field")) == null ? void 0 : g.nextElementSibling) == null ? void 0 : o.querySelector("input");
        d == null || d.focus();
      }
    }}"
        @click="${(t) => {
      s._manuallySelectAll(t);
    }}"
        data-label="${e}"
      >
        ${E}
        <label for="${s._elementId}">${e}</label>
      </div>
    `;
  });
}, K = (s) => {
  let i = F(s);
  const f = H(s);
  s.multiple && s.selectAll && (i == null || i.unshift(f[0]), i = (i == null ? void 0 : i.length) === 1 ? [] : i);
  const e = (r) => {
    (r.key === "ArrowDown" || r.key === "ArrowUp") && r.preventDefault();
  };
  return l`
    ${s.elements && s.elements.length > 0 ? l`
        <div
          aria-label="${q(s.ariaLabel)}"
          part="selector"
          class="list dss-selector-list-wrapper ${s.boxShadow ? "dss-selector-list-wrapper--box-shadow" : ""}"
          @keydown=${e}
          style="${s._style}"
        >
          ${i}
        </div>
      ` : l`
        <div
          part="selector"
          class="list dss-selector-list-wrapper"
          @keydown=${e}
          style="${s._style}"
        >
          ${s.filter && s.filter.length >= s.filterThreshold ? l`
                <div class="dss-selector-empty">
                  <${x} icon="info" size="sm"></${x}>
                  <span class="text">
                    ${s.filter || s.filter === "" ? l` ${s.emptySelectorLabel}: ${s.filter} ` : l`${s.emptyFilterLabel}`}
                  </span>
                </div>
              ` : l`
                <div class="dss-selector-empty">
                  <${z} size="md"/>
                </div>
              `}
        </div>
      `}
  `;
};
export {
  K as template
};
//# sourceMappingURL=form-select-options.template.js.map
