import { nothing as d, html as s } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
const g = (l) => s`
  <div class="${e({
  "dss-toggle": !0,
  "dss-toggle--sm": l.size === "sm",
  "dss-toggle--md": l.size === "md",
  "dss-toggle--lg": l.size === "lg",
  "dss-toggle--checked": l.checked,
  "dss-toggle--disabled": l.disabled,
  "dss-toggle--hide-label": l.hideLabel
})}">
    <div
      class="dss-toggle__slider"
      tabindex="${l.disabled ? -1 : 0}"
      @keydown="${l._handleKeydown}"
      @click="${l._handleClick}"
    ></div>
    <input
      class="dss-toggle-input"
      type="checkbox"
      .name="${l.name ?? d}"
      id="${l._getEffectiveId()}"
      .value="${l.value ? l.value : null}"
      ?disabled="${l.disabled}"
      ?readonly="${l.readonly}"
      ?required="${l.required}"
      .checked="${l.checked}"
      tabIndex="-1"
      aria-label="${l.hideLabel ? l.label : d}"
      @change=${l._handleChange}
    />
    <label 
      class="${e({
  "dss-toggle-label": !0,
  "dss-toggle-label--disabled": l.disabled
})}"
      for="${l._getEffectiveId()}" 
      aria-hidden="${l.hideLabel}"  
      @click="${l._handleClick}"
    >
      ${l.hideLabel ? d : l.label}
    </label>
  </div>
`;
export {
  g as template
};
//# sourceMappingURL=form-toggle.template.js.map
