import { LitElement as p, unsafeCSS as d } from "lit";
import { query as c, property as s, state as f } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as v, booleanConverter as l } from "../../utils/property-types.js";
import m from "./form-toggle.style.css.js";
import { template as b } from "./form-toggle.template.js";
var k = Object.defineProperty, i = (n, e, o, _) => {
  for (var a = void 0, r = n.length - 1, u; r >= 0; r--)
    (u = n[r]) && (a = u(e, o, a) || a);
  return a && k(e, o, a), a;
};
const h = class h extends p {
  constructor() {
    super(), this.size = "md", this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.value = !1, this.disabled = !1, this.readonly = !1, this.required = !1, this.checked = !1, this.tabIndex = 0, this._defaultId = `dss-toggle-${crypto.randomUUID()}`, this.defaultValue = this.value, this.internals = this.attachInternals();
  }
  static get styles() {
    return [d(y), d(m)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(e) {
    e.has("value") && typeof this.value == "string" && ((this.value === "" || this.value === "false") && (this._input.checked = !1), this.internals.setFormValue(this._input.checked ? this.value : null)), e.has("checked") && typeof this.value == "boolean" && this.internals.setFormValue(this._input.checked ? "on" : null);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    const e = typeof this.defaultValue == "boolean";
    this.value = e ? !1 : this.defaultValue, this._input.checked = !1, this.checked = !1;
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "";
  }
  focusInput() {
    var e;
    (e = this._input) == null || e.focus();
  }
  async firstUpdated() {
    await this.updateComplete, this.defaultValue = this.value, (this.checked || this.value === !0 || this.value === "true") && (this.checked = !0, this._input.checked = !0, this.internals.setFormValue(this._input.checked ? typeof this.value == "string" ? this.value : "on" : null));
  }
  render() {
    return b(this);
  }
  _handleClick() {
    !this.disabled && !this.readonly && this._input && (this.checked = !this.checked, this._handleChange());
  }
  _handleKeydown(e) {
    (e.key === "Enter" || e.key === " ") && this._handleClick();
  }
  _handleChange() {
    typeof this.value == "boolean" && (this.value = this.checked), this.internals.setFormValue(this.checked ? typeof this.value == "string" ? this.value : "on" : null), this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
};
h.formAssociated = !0;
let t = h;
i([
  c("input.dss-toggle-input")
], t.prototype, "_input");
i([
  s({ type: String })
], t.prototype, "size");
i([
  s({ type: String })
], t.prototype, "label");
i([
  s(v)
], t.prototype, "hideLabel");
i([
  s({ type: String })
], t.prototype, "name");
i([
  s({ type: String })
], t.prototype, "id");
i([
  s({ type: String })
], t.prototype, "value");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "disabled");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "readonly");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "required");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "checked");
i([
  s({ type: Number })
], t.prototype, "tabIndex");
i([
  f()
], t.prototype, "defaultValue");
export {
  t as FormToggle
};
//# sourceMappingURL=form-toggle.js.map
