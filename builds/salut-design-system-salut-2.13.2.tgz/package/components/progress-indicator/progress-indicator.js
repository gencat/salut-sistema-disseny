import { LitElement as d, unsafeCSS as g } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as n } from "../../utils/property-types.js";
import y from "./progress-indicator.style.css.js";
import { template as _ } from "./progress-indicator.template.js";
var c = Object.defineProperty, f = Object.getOwnPropertyDescriptor, s = (a, t, e, p) => {
  for (var r = p > 1 ? void 0 : p ? f(t, e) : t, l = a.length - 1, h; l >= 0; l--)
    (h = a[l]) && (r = (p ? h(t, e, r) : h(r)) || r);
  return p && r && c(t, e, r), r;
};
class o extends d {
  constructor() {
    super(...arguments), this.description = "", this.state = "default", this.percentage = 0, this.hasFailed = !1, this.hidePercentage = !1, this._title = void 0, this._label = "Barra de progrés";
  }
  static get styles() {
    return g(y);
  }
  set title(t) {
    const e = this._title;
    this._title = t, this._label = `Barra de progrés ${t}`, this.requestUpdate("title", e);
  }
  get title() {
    return this._title ?? "";
  }
  set titleText(t) {
    const e = this._title;
    this._title = t, this._label = `Barra de progrés ${t}`, this.requestUpdate("title", e);
  }
  get titleText() {
    return this._title ?? "";
  }
  updated(t) {
    t.has("hasFailed") && this.hasFailed && (this.state = "error");
  }
  render() {
    return _(this);
  }
}
s([
  i({ type: String })
], o.prototype, "description", 2);
s([
  i({ type: String })
], o.prototype, "state", 2);
s([
  i({ type: Number })
], o.prototype, "percentage", 2);
s([
  i(n)
], o.prototype, "hasFailed", 2);
s([
  i(n)
], o.prototype, "hidePercentage", 2);
s([
  i({ type: String })
], o.prototype, "title", 1);
s([
  i({ type: String })
], o.prototype, "titleText", 1);
export {
  o as ProgressIndicator
};
//# sourceMappingURL=progress-indicator.js.map
