import { nothing as a } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { styleMap as d } from "lit/directives/style-map.js";
import { when as l } from "lit/directives/when.js";
import { html as r } from "lit/static-html.js";
const n = (s) => {
  const i = {
    "dss-progress-indicator": !0,
    "dss-progress-indicator--error": s.hasFailed,
    [`dss-progress-indicator--${s.state}`]: s.state !== "default"
  }, e = {
    width: `${s.percentage}%`
  };
  return r`
    <div 
      class="${t(i)}" 
      role="progressbar"
      aria-label="${s._label}"
      aria-valuemin="0"
      aria-valuemax="100"
      aria-valuenow="${s.percentage}">
    ${l(
    s.title,
    () => r`<h2 class="dss-progress-indicator__title">${s.title}</h2>`,
    () => a
  )}
    <div class="dss-progress-indicator__bar-wrapper">
      <div class="dss-progress-indicator__bar">
        <div
          class="dss-progress-indicator__progress"
          style="${d(e)}">
        </div>
      </div>
      ${s.hidePercentage ? a : r` 
        <span class="dss-progress-indicator__percentage">
          ${s.percentage}%
        </span>
      `}
    </div>
    <div class="dss-progress-indicator__content">
      <span class="dss-progress-indicator__description">
        ${s.description}
      </span>
    </div>
  </div>
  `;
};
export {
  n as template
};
//# sourceMappingURL=progress-indicator.template.js.map
