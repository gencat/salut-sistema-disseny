const e = '.dss-skeleton{display:inline-block;width:100%;height:2rem;position:relative;overflow:hidden;background-color:#d8d8d8;border-radius:var(--dss-spacing-xs)}.dss-skeleton:after{position:absolute;top:0;right:0;bottom:0;left:0;transform:translate(-100%);background-image:linear-gradient(90deg,#fff0 0,#fff3 20%,#ffffff80 60%,#fff0);animation:shimmer 2s infinite;content:""}@keyframes shimmer{to{transform:translate(100%)}}';
export {
  e as default
};
//# sourceMappingURL=skeleton.style.css.js.map
