import { classMap as a } from "lit/directives/class-map.js";
import { styleMap as r } from "lit/directives/style-map.js";
import { html as l } from "lit/static-html.js";
const h = (t) => {
  const s = {
    "dss-skeleton": !0
  }, e = {
    width: t.width,
    height: t.height
  };
  return l`
    <span class="${a(s)}" style="${r(e)}" aria-hidden="true"></span>
  `;
};
export {
  h as template
};
//# sourceMappingURL=skeleton.template.js.map
