import { LitElement as d, unsafeCSS as n } from "lit";
import { property as p } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import y from "./skeleton.style.css.js";
import { template as c } from "./skeleton.template.js";
var g = Object.defineProperty, m = (t, i, o, l) => {
  for (var r = void 0, e = t.length - 1, s; e >= 0; e--)
    (s = t[e]) && (r = s(i, o, r) || r);
  return r && g(i, o, r), r;
};
const f = {
  type: String,
  converter: {
    fromAttribute: (t) => t && (/^\d+$/.test(t) ? `${t}%` : t),
    toAttribute: (t) => t
  }
};
class h extends d {
  constructor() {
    super(...arguments), this.width = void 0, this.height = void 0;
  }
  static get styles() {
    return [n(u), n(y)];
  }
  render() {
    return c(this);
  }
}
m([
  p(f)
], h.prototype, "width");
m([
  p(f)
], h.prototype, "height");
export {
  h as Skeleton
};
//# sourceMappingURL=skeleton.js.map
