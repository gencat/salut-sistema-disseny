import { LitElement as _, unsafeCSS as y } from "lit";
import { query as v, property as i, state as r } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { deleteSeparatorMask as m, applyMask as g } from "../../utils/mask.js";
import { booleanType as n, booleanConverter as h } from "../../utils/property-types.js";
import b from "./form-input.style.css.js";
import { template as S } from "./form-input.template.js";
var k = Object.defineProperty, e = (c, s, o, u) => {
  for (var l = void 0, a = c.length - 1, p; a >= 0; a--)
    (p = c[a]) && (l = p(s, o, l) || l);
  return l && k(s, o, l), l;
};
const d = class d extends _ {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.hasActions = !1, this._defaultId = `dss-input-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._previousValue = null, this._labelClicked = !1, this._lastValue = null, this.internals = this.attachInternals();
  }
  static get styles() {
    return [y(f), y(b)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._stopHold();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(s) {
    s.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(s) {
    this.disabled = s;
  }
  formResetCallback() {
    this.value = "", this._input.value = "", this._lastValue = "";
  }
  formStateRestoreCallback(s) {
    this.value = s ?? "", this._input.value = s ?? "", this._lastValue = s ?? "";
  }
  render() {
    return S(this);
  }
  _handleFocusin() {
    this._isFocused = !0;
  }
  _handleLabelClick(s) {
    s.preventDefault(), this._input.focus(), this._labelClicked = !0, setTimeout(() => {
      this._labelClicked = !1;
    }, 50);
  }
  _handleFocusout() {
    this._labelClicked || (this._isFocused = !1, this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value));
  }
  _onInput(s) {
    const o = s.target;
    if (this.maskRegex && this.maskReplace) {
      this._previousValue && this._previousValue.length > (o == null ? void 0 : o.value.length) && (o.value = m(this._previousValue, o.value, this.maskReplace));
      const u = g(o.value, this.maskRegex, this.maskReplace, this.allowedChars);
      u !== o.value && (o.value = u);
    }
    this._previousValue = o.value, this.value = o.value, this._handleValidity(), this.dispatchEvent(new Event("input", { bubbles: !1, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    var o;
    const s = (o = this._input) == null ? void 0 : o.checkValidity();
    this.invalid = !s, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _stepUp() {
    var s;
    (s = this._input) == null || s.stepUp(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _stepDown() {
    var s;
    (s = this._input) == null || s.stepDown(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _onHold(s) {
    this._onHoldInterval = window.setInterval(() => {
      s === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this._onHoldInterval !== null && (clearInterval(this._onHoldInterval), this._onHoldInterval = null);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _handleMouseOver() {
    var s, o;
    ((s = this._input) == null ? void 0 : s.value) !== this._lastValue && (this._checkInputOverflow(), this._lastValue = ((o = this._input) == null ? void 0 : o.value) || null);
  }
  _checkInputOverflow() {
    var p;
    if (!this._input || !this._input.value) return;
    const s = window.getComputedStyle(this._input), o = `${s.fontWeight} ${s.fontSize} ${s.fontFamily}`, l = document.createElement("canvas").getContext("2d");
    if (!l) return;
    l.font = o;
    const a = l.measureText(this._input.value).width;
    this._isTruncated = a > this._input.offsetWidth, this._isTruncated && ((p = this.shadowRoot) == null ? void 0 : p.querySelector(".dss-input-tooltip")).updateTooltip();
  }
};
d.formAssociated = !0;
let t = d;
e([
  v("input.dss-input")
], t.prototype, "_input");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i(n)
], t.prototype, "hideLabel");
e([
  i({ type: String })
], t.prototype, "name");
e([
  i({ type: String })
], t.prototype, "id");
e([
  i({ type: String })
], t.prototype, "type");
e([
  i({ type: String })
], t.prototype, "placeholder");
e([
  i({ type: String })
], t.prototype, "value");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "disabled");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "readonly");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "required");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "invalid");
e([
  i({ type: Number })
], t.prototype, "step");
e([
  i({ type: Number })
], t.prototype, "min");
e([
  i({ type: Number })
], t.prototype, "max");
e([
  i({ type: Number })
], t.prototype, "minLength");
e([
  i({ type: Number })
], t.prototype, "maxLength");
e([
  i({ type: String })
], t.prototype, "pattern");
e([
  i({ type: String })
], t.prototype, "inputmode");
e([
  i({ type: String })
], t.prototype, "autocapitalize");
e([
  i({ type: String })
], t.prototype, "autocomplete");
e([
  i(n)
], t.prototype, "autocorrect");
e([
  i(n)
], t.prototype, "autofocus");
e([
  i(n)
], t.prototype, "spellcheck");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "helpText");
e([
  i({ type: String })
], t.prototype, "maskRegex");
e([
  i({ type: String })
], t.prototype, "maskReplace");
e([
  i({ type: String })
], t.prototype, "allowedChars");
e([
  i({ type: String })
], t.prototype, "unit");
e([
  i({ type: String })
], t.prototype, "inputPrefix");
e([
  i(n)
], t.prototype, "hasActions");
e([
  r()
], t.prototype, "_isFocused");
e([
  r()
], t.prototype, "_isTruncated");
e([
  r()
], t.prototype, "_onHoldInterval");
e([
  r()
], t.prototype, "_previousValue");
e([
  r()
], t.prototype, "_labelClicked");
export {
  t as FormInput
};
//# sourceMappingURL=form-input.js.map
