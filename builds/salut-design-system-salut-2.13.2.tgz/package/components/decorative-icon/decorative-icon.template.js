import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as d, html as r } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const i = d`dss-icon${t(l())}`, $ = (s) => {
  const e = {
    "dss-decorative-icon": !0,
    [`dss-decorative-icon--${s.size}`]: !!s.size,
    [`dss-decorative-icon--${s.state}`]: s.state !== "default",
    "dss-decorative-icon--disabled": s.disabled
  };
  return r`
    <div class="${a(e)}" aria-hidden="true">
      <${i} icon="${s.icon}" size="${s.size}" ?fill="${s.fill}"></${i}>
    </div>
  `;
};
export {
  $ as template
};
//# sourceMappingURL=decorative-icon.template.js.map
