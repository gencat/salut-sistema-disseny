import { LitElement as m, unsafeCSS as a } from "lit";
import { property as e } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import { booleanType as f } from "../../utils/property-types.js";
import y from "./decorative-icon.style.css.js";
import { template as c } from "./decorative-icon.template.js";
var u = Object.defineProperty, r = (i, p, n, v) => {
  for (var t = void 0, s = i.length - 1, l; s >= 0; s--)
    (l = i[s]) && (t = l(p, n, t) || t);
  return t && u(p, n, t), t;
};
class o extends m {
  constructor() {
    super(...arguments), this.icon = void 0, this.state = "default", this.size = "md", this.disabled = !1, this.fill = !1;
  }
  static get styles() {
    return [a(d), a(y)];
  }
  render() {
    return c(this);
  }
}
r([
  e({ type: String })
], o.prototype, "icon");
r([
  e({ type: String })
], o.prototype, "state");
r([
  e({ type: String })
], o.prototype, "size");
r([
  e(f)
], o.prototype, "disabled");
r([
  e(f)
], o.prototype, "fill");
export {
  o as DecorativeIcon
};
//# sourceMappingURL=decorative-icon.js.map
