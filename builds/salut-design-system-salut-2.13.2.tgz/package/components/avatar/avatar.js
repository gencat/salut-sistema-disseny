import { LitElement as y, unsafeCSS as u } from "lit";
import { property as i } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import l from "./avatar.style.css.js";
import { template as f } from "./avatar.template.js";
var c = Object.defineProperty, n = (a, t, r, s) => {
  for (var e = void 0, o = a.length - 1, p; o >= 0; o--)
    (p = a[o]) && (e = p(t, r, e) || e);
  return e && c(t, r, e), e;
};
class m extends y {
  constructor() {
    super(...arguments), this.name = "", this.surname = "", this.imageUrl = "", this.size = "md", this._acronym = "";
  }
  static get styles() {
    return [u(h), u(l)];
  }
  willUpdate(t) {
    const r = t.has("name"), s = t.has("surname");
    (r || s) && this.formatAcronym();
  }
  formatAcronym() {
    var r, s;
    let t = (r = this.name) == null ? void 0 : r.trim().substring(0, 1).toUpperCase();
    this.name && this.surname ? t += this.surname.trim().substring(0, 1).toUpperCase() : t = (s = this.name) == null ? void 0 : s.trim().substring(0, 2).toUpperCase(), this._acronym = t, this.requestUpdate("acronym", t);
  }
  render() {
    return f(this);
  }
}
n([
  i({ type: String })
], m.prototype, "name");
n([
  i({ type: String })
], m.prototype, "surname");
n([
  i({ type: String })
], m.prototype, "imageUrl");
n([
  i({ type: String })
], m.prototype, "size");
export {
  m as Avatar
};
//# sourceMappingURL=avatar.js.map
