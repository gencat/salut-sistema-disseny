import { html as s } from "lit";
const t = (a) => {
  const r = a.imageUrl ? "" : "dss-avatar--border";
  return s`
      <div class="dss-avatar dss-avatar--${a.size} ${r}">
        ${a.imageUrl ? s`<img
              class="dss-avatar__img"
              src="${a.imageUrl}"
              alt="avatar"
            />` : s`${a._acronym ? s`<span class="dss-avatar__font">${a._acronym}</span>` : s`<span class="material-symbols-rounded dss-avatar__icon">
                  person
                </span>`}`}
      </div>
    `;
};
export {
  t as template
};
//# sourceMappingURL=avatar.template.js.map
