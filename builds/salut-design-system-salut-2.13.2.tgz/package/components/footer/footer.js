import { LitElement as l, unsafeCSS as o } from "lit";
import { property as n } from "lit/decorators.js";
import y from "../../foundations/typography/typography.css.js";
import a from "../../shared/reset.style.css.js";
import d from "./footer.style.css.js";
import { template as u } from "./footer.template.js";
var g = Object.defineProperty, m = (r, p, s, c) => {
  for (var t = void 0, e = r.length - 1, i; e >= 0; e--)
    (i = r[e]) && (t = i(p, s, t) || t);
  return t && g(p, s, t), t;
};
class f extends l {
  constructor() {
    super(...arguments), this.logo = void 0, this.description = "";
  }
  static get styles() {
    return [o(a), o(d), o(y)];
  }
  render() {
    return u(this);
  }
}
m([
  n({ type: String })
], f.prototype, "logo");
m([
  n({ type: String })
], f.prototype, "description");
export {
  f as Footer
};
//# sourceMappingURL=footer.js.map
