import { html as s } from "lit/static-html.js";
import t from "../../assets/img/gencat-logotip-default.svg.js";
const l = (o) => s`
  <footer class="dss-footer__container">
    <div class="dss-footer__logo-content">
      <img src="${o.logo ? o.logo : t}" alt="Gencat Logo"/>
    </div>
    <div class="dss-footer__content">
      <p class="dss-legend--sm">${o.description}</p>
    </div>
  </footer>
`;
export {
  l as template
};
//# sourceMappingURL=footer.template.js.map
