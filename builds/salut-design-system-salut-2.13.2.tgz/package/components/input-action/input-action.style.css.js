const t = '.dss-input-actions{position:relative;padding-left:var(--dss-spacing-xs)}.dss-input-actions:before{content:"";position:absolute;top:50%;left:0;transform:translateY(-50%);height:24px;width:var(--dss-border-width-sm);background-color:var(--color-neutral-500)}.dss-input-group--md .dss-input-actions:before{height:28px}.dss-input-group--sm .dss-input-actions:before{height:18px}';
export {
  t as default
};
//# sourceMappingURL=input-action.style.css.js.map
