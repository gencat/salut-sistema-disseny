import { LitElement as c, unsafeCSS as f } from "lit";
import { property as o } from "lit/decorators.js";
import { itemListTemplate as u } from "./item-list.template.js";
import h from "../../foundations/icon/icon.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import y from "../decorative-icon/decorative-icon.style.css.js";
import v from "./item-list.style.css.js";
import { getCustomElementSuffix as g } from "../../api/custom-element-scope.js";
var b = Object.defineProperty, s = (m, t, e, n) => {
  for (var i = void 0, p = m.length - 1, d; p >= 0; p--)
    (d = m[p]) && (i = d(t, e, i) || i);
  return i && b(t, e, i), i;
};
class r extends c {
  constructor() {
    super(...arguments), this.items = void 0, this.widget = !1, this.hideTooltip = !1, this.tooltipFixed = !1, this.forceViewport = !1, this.tooltipPosition = "top", this.variant = "default";
  }
  static get styles() {
    return [f(h), f(y), f(v)];
  }
  // 'checkbox' | 'radio' | 'default'
  /* METHODS */
  _dispatchItemAction(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItem", e));
  }
  _dispatchItemChip(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItemChip", e));
  }
  _dispatchWidgetAction(t, e) {
    const n = {
      detail: { item: t, action: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickWidgetAction", n));
  }
  _applyDivider() {
    var n, i;
    if ((n = this.items) != null && n.length) return;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelectorAll("slot");
    if (!t || t.length === 0) return;
    let e = !0;
    t.forEach((p) => {
      p.assignedElements({ flatten: !0 }).forEach((a) => {
        a instanceof HTMLElement && a.tagName.toLowerCase() === `dss-item-list-base${g()}` && (e ? (a.setAttribute("first", ""), e = !1) : a.removeAttribute("first"));
      });
    });
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    await this.updateComplete, this._applyDivider();
  }
  render() {
    return u(this);
  }
}
s([
  o({ type: Array })
], r.prototype, "items");
s([
  o(l)
], r.prototype, "widget");
s([
  o(l)
], r.prototype, "hideTooltip");
s([
  o(l)
], r.prototype, "tooltipFixed");
s([
  o(l)
], r.prototype, "forceViewport");
s([
  o({ type: String })
], r.prototype, "tooltipPosition");
s([
  o({ type: String })
], r.prototype, "variant");
export {
  r as ItemList
};
//# sourceMappingURL=item-list.js.map
