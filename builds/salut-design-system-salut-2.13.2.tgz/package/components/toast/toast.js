import { LitElement as p, unsafeCSS as d } from "lit";
import { property as i } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import l from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import f from "./toast.style.css.js";
import { template as y } from "./toast.template.js";
var b = Object.defineProperty, e = (h, t, n, c) => {
  for (var s = void 0, r = h.length - 1, u; r >= 0; r--)
    (u = h[r]) && (s = u(t, n, s) || s);
  return s && b(t, n, s), s;
};
class o extends p {
  constructor() {
    super(), this.isShow = !1, this.text = void 0, this.state = "info", this.position = "bottom-left", this.icon = void 0, this.hasIcon = !0, this.buttonLabel = "Button", this.hasButton = !1, this.hasButtonClose = !1, this.duration = 4e3, this._firstTimeRendered_ = !1, this.handleAnimationEnd = this.handleAnimationEnd.bind(this), this.onKeyDown = this.onKeyDown.bind(this);
  }
  static get styles() {
    return [d(l), d(f), d(m)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("keydown", this.onKeyDown);
  }
  update(t) {
    t.has("isShow") && this.addEventListener("animationend", this.handleAnimationEnd), super.update(t);
  }
  updated(t) {
    this._firstTimeRendered_ || (this._firstTimeRendered_ = !0), t.has("isShow") && (this.isShow && this.duration > 0 && this._timeoutId_ === void 0 ? this._timeoutId_ = window.setTimeout(() => this.handleClose(), this.duration) : !this.isShow && this.duration > 0 && this._timeoutId_ !== void 0 && (clearTimeout(this._timeoutId_), this._timeoutId_ = void 0)), (t.has("isShow") || t.has("position")) && this.updateHostAttributes(), super.updated(t);
  }
  updateHostAttributes() {
    this.removeAttribute("data-position"), this.removeAttribute("data-animation"), this.isShow ? this.setAttribute("data-animation", "show") : this.setAttribute("data-animation", "hide"), this.setAttribute("data-position", this.position);
  }
  handleAnimationEnd() {
    this.isShow || (this.dispatchEvent(new CustomEvent("onClose", { bubbles: !0, composed: !0 })), this.remove()), this.removeEventListener("animationend", this.handleAnimationEnd);
  }
  handleClickButton() {
    this.dispatchEvent(new CustomEvent("onClickButton", { bubbles: !0, composed: !0 }));
  }
  handleClose() {
    this.isShow = !1;
  }
  getText() {
    var t;
    return ((t = this.text) == null ? void 0 : t.split(/\\n|\n/).map((n) => n.trim())) || [];
  }
  onKeyDown(t) {
    (t.code === "Enter" || t.code === "NumpadEnter") && this.isShow && this.handleClose();
  }
  render() {
    return y(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._timeoutId_ !== void 0 && clearTimeout(this._timeoutId_), this.removeEventListener("animationend", this.handleAnimationEnd), window.removeEventListener("keydown", this.onKeyDown);
  }
}
e([
  i(a)
], o.prototype, "isShow");
e([
  i({ type: String })
], o.prototype, "text");
e([
  i({ type: String })
], o.prototype, "state");
e([
  i({ type: String })
], o.prototype, "position");
e([
  i({ type: String })
], o.prototype, "icon");
e([
  i(a)
], o.prototype, "hasIcon");
e([
  i({ type: String })
], o.prototype, "buttonLabel");
e([
  i(a)
], o.prototype, "hasButton");
e([
  i(a)
], o.prototype, "hasButtonClose");
e([
  i({ type: Number })
], o.prototype, "duration");
export {
  o as Toast
};
//# sourceMappingURL=toast.js.map
