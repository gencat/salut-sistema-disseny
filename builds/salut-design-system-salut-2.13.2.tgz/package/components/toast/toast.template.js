import { nothing as a } from "lit";
import { classMap as v } from "lit/directives/class-map.js";
import { when as i } from "lit/directives/when.js";
import { unsafeStatic as o, literal as r, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const f = r`dss-icon${o(e())}`, g = r`dss-button${o(e())}`, b = r`dss-icon-button${o(e())}`, S = (s) => {
  const l = {
    "dss-toast": !0,
    "dss-toast__icon-button-close": s.hasButtonClose,
    "dss-toast__animation": s._firstTimeRendered_ || s.isShow,
    [`dss-toast__${s.position}`]: !0,
    [`dss-toast__${s.state}`]: !0,
    "dss-toast__show": s.isShow,
    "dss-toast__hide": !s.isShow
  }, n = {
    info: "info",
    success: "check_circle",
    warning: "warning_amber",
    error: "cancel"
  }, d = {
    info: "alternative-light",
    success: "alternative-light",
    warning: "alternative-dark",
    error: "alternative-light"
  }, c = {
    info: "ghost",
    success: "ghost",
    warning: "neutral",
    error: "ghost"
  }, u = t`
    <div class="dss-toast__icon">
      <${f} icon="${s.icon || n[s.state]}"/>
    </div>
  `, _ = t`
    <div class="dss-toast__button">
      <${g}
        variant="${d[s.state]}"
        label="${s.buttonLabel}"
        size="sm"
        @onClick="${s.handleClickButton}"
      />
    </div>
  `, h = t`
    <div class="dss-toast__close-icon">
      <${b}
				variant="${c[s.state]}"
        icon="close"
				label="Tancar"
				hideTooltip
        @onClick="${s.handleClose}"
      />
    </div>
  `;
  return t`
    <div class="${v(l)}"
    role=${s.state === "error" ? "alert" : "status"}
    aria-live=${s.state === "error" ? "assertive" : "polite"}
    aria-atomic=${!0}>
      <div class="dss-toast__content">
      ${i(
    s.hasIcon,
    () => u,
    () => a
  )}
      <span class="dss-toast__text">${s.getText().map(($) => t`<p>${$}</p>`)}</span>
      ${i(
    s.hasButton && !s.hasButtonClose,
    () => _,
    () => a
  )}
      ${i(
    s.hasButtonClose && !s.hasButton,
    () => h,
    () => a
  )}
    </div>
  </div>`;
};
export {
  S as template
};
//# sourceMappingURL=toast.template.js.map
