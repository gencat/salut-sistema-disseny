import { LitElement as f, unsafeCSS as p } from "lit";
import { queryAssignedElements as m, property as d } from "lit/decorators.js";
import { getCustomElementSuffix as v } from "../../api/custom-element-scope.js";
import b from "../../shared/reset.style.css.js";
import { booleanType as _, booleanConverter as y } from "../../utils/property-types.js";
import g from "./form-radio-button-group.style.css.js";
import { template as C } from "./form-radio-button-group.template.js";
var S = Object.defineProperty, i = (l, t, e, a) => {
  for (var s = void 0, r = l.length - 1, o; r >= 0; r--)
    (o = l[r]) && (s = o(t, e, s) || s);
  return s && S(t, e, s), s;
};
const k = `dss-form-radio-button${v()}`, h = class h extends f {
  constructor() {
    super(), this.name = "radio-group-host", this.label = "", this.hideLabel = !1, this.value = "", this.orientation = "vertical", this.disabled = !1, this._onRadioChange = (t) => {
      this.value = t.target.value, this._emitChange();
    }, this._onKeyDown = (t) => {
      if (!this._radioButtons || this._radioButtons.length === 0) return;
      const e = Array.from(this._radioButtons), a = e.findIndex(
        (u) => {
          var c;
          return u === ((c = this.shadowRoot) == null ? void 0 : c.activeElement) || u === document.activeElement;
        }
      );
      if (a === -1) return;
      let s = a;
      switch (t.key) {
        case "ArrowRight":
        case "ArrowDown":
          s = (a + 1) % e.length;
          break;
        case "ArrowLeft":
        case "ArrowUp":
          s = (a - 1 + e.length) % e.length;
          break;
        default:
          return;
      }
      t.preventDefault();
      const r = e[a];
      if (!r) return;
      r.tabIndex = -1;
      const o = e[s];
      o && (o.tabIndex = 0, o.focusInput());
    }, this.internals = this.attachInternals();
  }
  static get styles() {
    return [p(b), p(g)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("change", this._onRadioChange), this.addEventListener("keydown", this._onKeyDown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("change", this._onRadioChange), this.removeEventListener("keydown", this._onKeyDown);
  }
  updated(t) {
    t.has("name") && this._updateNameState(), t.has("value") && (this.internals.setFormValue(this.value), this._updateCheckedState()), t.has("disabled") && this._updateDisabledState();
  }
  formResetCallback() {
    this.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "";
  }
  render() {
    return C(this);
  }
  _emitChange() {
    const t = {
      detail: { value: this.value },
      bubbles: !1,
      composed: !0
    }, e = new CustomEvent("value-changed", t);
    this.dispatchEvent(e);
  }
  _updateCheckedState() {
    if (!this._radioButtons) return;
    let t = !1;
    this._radioButtons.forEach((e) => {
      const a = e.value === this.value;
      e.checked = a, a ? (e.tabIndex = 0, t = !0) : e.tabIndex = -1;
    }), t || (this._radioButtons[0].tabIndex = 0);
  }
  _updateNameState() {
    this._radioButtons && this._radioButtons.forEach((t) => {
      t.name = this.name;
    });
  }
  _updateDisabledState() {
    this._radioButtons && this._radioButtons.forEach((t) => {
      t.disabled = this.disabled;
    });
  }
};
h.formAssociated = !0;
let n = h;
i([
  m({ selector: k.toString() })
], n.prototype, "_radioButtons");
i([
  d({ type: String })
], n.prototype, "name");
i([
  d({ type: String })
], n.prototype, "label");
i([
  d(_)
], n.prototype, "hideLabel");
i([
  d({ type: String })
], n.prototype, "value");
i([
  d({ type: String })
], n.prototype, "orientation");
i([
  d({ converter: y, reflect: !0 })
], n.prototype, "disabled");
export {
  n as FormRadioButtonGroup
};
//# sourceMappingURL=form-radio-button-group.js.map
