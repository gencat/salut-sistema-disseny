import { createPopper as w } from "@popperjs/core";
import { LitElement as g, unsafeCSS as f } from "lit";
import { query as S, property as l, state as u } from "lit/decorators.js";
import b from "../../shared/reset.style.css.js";
import { normalizeText as c } from "../../utils/helpers.js";
import { booleanType as p, booleanConverter as _ } from "../../utils/property-types.js";
import { sort as V } from "../../utils/sorting.js";
import E from "../form-input/form-input.style.css.js";
import F from "./form-select.style.css.js";
import { template as k } from "./form-select.template.js";
import { lazyLoading as I } from "../../utils/lazy-loading.js";
var O = Object.defineProperty, s = (y, e, t, o) => {
  for (var r = void 0, n = y.length - 1, h; n >= 0; n--)
    (h = y[n]) && (r = h(e, t, r) || r);
  return r && O(e, t, r), r;
};
const m = class m extends g {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "", this.hasActions = !1, this.elements = null, this.selectedValue = null, this.placeholderOnDropdown = "Seleccionar", this.placeholderIfEmpty = "Escriu per cercar", this.type = "default", this.multiple = !1, this.tick = !0, this.autoSort = !1, this.deselectable = !1, this.boxStyle = "", this.dropdownStyle = "", this.labelSelectAll = "Seleccionar-ho tot", this.labelDeselectAll = "Deseleccionar-ho tot", this.filterThreshold = 1, this.searchThreshold = 2, this.selectAll = !1, this.showDropdown = !1, this.openWithSearch = !1, this.dropdownOffsetX = void 0, this.dropdownOffsetY = void 0, this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.advancedFilter = !1, this.tooltipFixed = !1, this.forceViewport = !1, this._defaultId = `dss-select-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._isFiltering = !1, this._inputValidity = !0, this._selectElements = 0, this._popperInstance = null, this._intersectionObserver = null, this._isInitialized = !1, this._syncFromValue = !1, this._placeholder = "", this._previousValue = null, this._elements = [], this._filteredElements = [], this._copyElements = [], this._multipleSelection = [], this._isFirstInitSelectedElements = !0, this._isOverflowChecked = !1, this._handleInputMouseOver = () => {
      this._isOverflowChecked || (this._checkInputOverflow(), this._isOverflowChecked = !0);
    }, this.internals = this.attachInternals(), this._handleClickOutside = this._handleClickOutside.bind(this);
  }
  static get styles() {
    return [f(b), f(E), f(F)];
  }
  disconnectedCallback() {
    var e;
    super.disconnectedCallback(), this._removeListenerClickOutside(), (e = this._intersectionObserver) == null || e.disconnect();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    setTimeout(() => {
      this.value = "", this._input.value = "", this._hiddenInput.value = "", this.selectedValue = null, this._placeholder = "", this._isFocused = !1;
    }, 0);
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "", this._input.value = e ?? "", this._hiddenInput.value = e ?? "";
  }
  updated(e) {
    e.has("value") && (this.internals.setFormValue(this.value), queueMicrotask(() => {
      this._isInitialized && this._applyValue();
    })), e.has("elements") && (this.showDropdown || this._applyElements(this.elements), this._applyOpenWithSearch(this.openWithSearch)), e.has("selectedValue") && queueMicrotask(() => {
      if (this._syncFromValue) {
        this._syncFromValue = !1;
        return;
      }
      this._isInitialized && this._applySelectedValue(this.selectedValue);
    }), e.has("placeholder") && queueMicrotask(() => {
      this._placeholder = this.placeholder;
    }), e.has("openWithSearch") && queueMicrotask(() => {
      this.openWithSearch && this._placeholder === "" && (this._placeholder = this.placeholderOnDropdown);
    });
  }
  async firstUpdated() {
    await this.updateComplete;
    try {
      this._syncFormValue(), this._enableAnimations(), this._setupSearchMode(), I(this, () => {
        this._initializeElements(), this._checkTruncatedIfMultipleSelection();
      });
    } catch (e) {
      console.error("Error in firstUpdated:", e);
    }
    this.requestUpdate();
  }
  render() {
    return k(this);
  }
  _syncFormValue() {
    if (this.value && !this.selectedValue) {
      const e = this.value.split(",");
      this._syncFromValue = !0, this.selectedValue = e;
    }
    this.multiple && this.selectedValue && this.selectedValue.length && !this._multipleSelection.length && (this._multipleSelection = [...this.selectedValue]);
  }
  _onChange() {
    this._emitChange();
  }
  _handleValidity() {
    var t;
    const e = (t = this._input) == null ? void 0 : t.checkValidity();
    this.invalid = !e, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  // METHODS FROM dss-input-dropdown
  _addListenerClickOutside() {
    document.addEventListener("mousedown", this._handleClickOutside);
  }
  _removeListenerClickOutside() {
    document.removeEventListener("mousedown", this._handleClickOutside);
  }
  _handleClickOutside(e) {
    var t, o, r;
    this.showDropdown && (e.composedPath().includes(this) || (this._input && (this._input.value = "", this.internals.setFormValue(this.value), this._isFiltering = !1), (t = this._elements) != null && t.length && (this._initSelectedElements(), (!this.selectedValue || this.selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())), (o = this._elements) != null && o.length || ((r = this._input) == null || r.removeAttribute("placeholder"), this._placeholder = ""), this._hidePlaceholder(), this._closeDropdown()));
  }
  _enableAnimations() {
    this.classList.add("animation-enabled");
  }
  _initializeElements() {
    this._elements && (this._filteredElements = this._getFilteredElements(), this._initSelectedElements(), this._isInitialized = !0);
  }
  _setupSearchMode() {
    this.openWithSearch && this._input && (this._input.value = "", this.internals.setFormValue(this.value), this._input.hasAttribute("placeholder") || this._input.setAttribute("placeholder", this.placeholderOnDropdown));
  }
  _applyValue() {
    const e = typeof this.value == "string" ? this.value.split(",").map((t) => t.trim()).filter((t) => t) : [];
    this.selectedValue = [...e], this._applySelectedValue(e);
  }
  _applyOpenWithSearch(e) {
    var t;
    e && (this.showDropdown = e, (t = this._popperInstance) == null || t.update(), this._isFocused = !0);
  }
  _applyElements(e) {
    e && (this._elements = this.autoSort ? V(e, "label", "asc", "string") : e, this._input && !this._isFiltering && (this._input.value = "", this.internals.setFormValue(this.value)), this._filteredElements = this._getFilteredElements(), this._copyElements = [...this._elements], this._isInitialized && this._initSelectedElements());
  }
  _applySelectedValue(e) {
    !e || !this._elements || this.openWithSearch || (e.length > 0 && (this._isFocused = !0), this._initSelectedElements());
  }
  _getSelectedElements(e) {
    var o;
    const t = e ? this._multipleSelection : this.selectedValue;
    return !t || t.length <= 0 ? [] : (o = this._elements) == null ? void 0 : o.filter((r) => t.includes(r.value));
  }
  _getFilteredElements() {
    var t, o, r;
    const e = ((t = this._elements) == null ? void 0 : t.filter(
      (n) => {
        var h;
        return (h = this.selectedValue) == null ? void 0 : h.includes(n.value);
      }
    )) || [];
    if ((o = this._input) != null && o.value && this._input.value.length >= this.searchThreshold) {
      const n = c((r = this._input) == null ? void 0 : r.value);
      return this.advancedFilter ? this._applyAdvancedFilter(n, e) : this._applyDefaultFilter(n, e);
    }
    return this._elements;
  }
  _applyDefaultFilter(e, t) {
    var o;
    if (e) {
      const r = ((o = this._elements) == null ? void 0 : o.filter(
        (n) => {
          var h;
          return !((h = this.selectedValue) != null && h.includes(n.value)) && // Excluir elementos ya seleccionados del filtro
          c(n.label).includes(e);
        }
      )) || [];
      return [...t, ...r];
    }
    return [...t];
  }
  _applyAdvancedFilter(e, t) {
    var n;
    const o = c(e).split(/\s+/).filter((h) => h.length >= this.searchThreshold);
    if (o.length === 0)
      return [...t];
    const r = ((n = this._elements) == null ? void 0 : n.filter(
      (h) => {
        var a;
        return !((a = this.selectedValue) != null && a.includes(h.value)) && // Excluir seleccionados
        o.every((d) => c(h.label).includes(d));
      }
    )) || [];
    return [...t, ...r];
  }
  _initSelectedElements() {
    this._showSelectedValues(this.selectedValue ? this.selectedValue : []), this._isOverflowChecked = !1;
  }
  _checkTruncatedIfMultipleSelection() {
    this.multiple && this.selectedValue && this.selectedValue.length > 1 && (this._checkInputOverflow(), this._isOverflowChecked = !0);
  }
  _showSelectedValues(e) {
    var o;
    !this.multiple && Array.isArray(e) && e.length > 1 && e.splice(1);
    const t = (o = this._elements) == null ? void 0 : o.filter((r) => e.includes(r.value));
    this._elements = [...this._copyElements ?? []], this._selectElements = this.openWithSearch ? 0 : t.length, t.length > 0 && (this._elements = this._reorderElements(t), this._filteredElements = [...this._elements]), this._updateInputValue(t);
  }
  _reorderElements(e) {
    const t = this._elements.filter((r) => e.includes(r)), o = this._elements.filter((r) => !e.includes(r));
    return [...t, ...o];
  }
  _updateInputValue(e) {
    var t;
    !this._input || this._isFiltering || this.openWithSearch || (this.multiple ? this._input.value = (e == null ? void 0 : e.map((o) => o.label).join(", ")) ?? "" : (this._input.value = ((t = e == null ? void 0 : e[0]) == null ? void 0 : t.label) ?? "", this.deselectable && this._input.value === "" && (this._filteredElements = [...this._copyElements ?? []])), this.internals.setFormValue(this.value), this.requestUpdate());
  }
  _checkInputOverflow() {
    var v;
    if (!this._input || !this._input.value) return;
    const e = window.getComputedStyle(this._input), t = `${e.fontWeight} ${e.fontSize} ${e.fontFamily}`, r = document.createElement("canvas").getContext("2d");
    if (!r) return;
    r.font = t;
    const n = Number.parseFloat(e.paddingLeft), h = Number.parseFloat(e.paddingRight), a = this._input.offsetWidth - n - h, d = r.measureText(this._input.value).width;
    this._isTruncated = d > a, this._isTruncated && ((v = this.shadowRoot) == null ? void 0 : v.querySelector(".dss-input-tooltip")).updateTooltip();
  }
  _handleClick() {
    !this.disabled && !this.readonly && (this._input && (!this.openWithSearch && !this._isFiltering && (this._input.value = "", this.internals.setFormValue(this.value)), this._showPlaceholder()), this._isFocused = !0, this.showDropdown = !0, this._popperInstance ? this._updatePopperDropdown() : this._createPopperDropdown(), this._addListenerClickOutside());
  }
  _handleInput() {
    this._isFiltering = !0, this._filteredElements = this._getFilteredElements(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0;
  }
  _handleFocusOut(e) {
    var h, a, d;
    const t = e.relatedTarget;
    if (t instanceof HTMLElement && t.contains(this)) return;
    const o = (h = this.shadowRoot) == null ? void 0 : h.querySelector("dss-form-select-options"), r = (a = this.shadowRoot) == null ? void 0 : a.querySelector(".dss-input-dropdown__toggle"), n = (d = this.shadowRoot) == null ? void 0 : d.querySelector("dss-chip");
    t !== null && t !== this._input && t !== o && t !== r && t !== n && (this.selectedValue && this._initSelectedElements(), this._hidePlaceholder(), this._closeDropdown());
  }
  _handleBlurEsc() {
    this.readonly || this.openWithSearch || this._closeDropdown();
  }
  _handleKeyDown(e) {
    var t;
    (e == null ? void 0 : e.key) === "Enter" ? this.showDropdown ? this._keyboardFilterMatch() : this._handleClick() : (e == null ? void 0 : e.key) === "Escape" ? (this._closeDropdown(), this._initSelectedElements(), this._hidePlaceholder(), (!this.selectedValue || this.selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : (e == null ? void 0 : e.key) === "ArrowDown" || (e == null ? void 0 : e.key) === "ArrowUp" ? (e.preventDefault(), e.stopPropagation(), ((t = this.shadowRoot) == null ? void 0 : t.querySelector("#dss-form-select-options")).moveFocus()) : (e == null ? void 0 : e.key) !== "Tab" && (this.showDropdown || this._handleClick()), this.requestUpdate();
  }
  _cleanInput() {
    this._isFiltering = !1, this._input.value = "", this.internals.setFormValue(this.value), this._filteredElements = this._getFilteredElements();
  }
  _keyboardFilterMatch() {
    var o, r;
    if (!((o = this._filteredElements) == null ? void 0 : o.find(
      (n) => {
        var h;
        return n.label.toLowerCase() === ((h = this._input) == null ? void 0 : h.value.toLowerCase());
      }
    ))) return;
    const t = (r = this.shadowRoot) == null ? void 0 : r.querySelector("#dss-form-select-options");
    t && t.selectFirstMatch();
  }
  _showPlaceholder() {
    var e;
    this._input && (this.placeholder || ((e = this._elements) != null && e.length ? this._input.setAttribute("placeholder", this.placeholderOnDropdown) : this._input.setAttribute("placeholder", this.placeholderIfEmpty)));
  }
  _hidePlaceholder() {
    var e;
    this.placeholder || (e = this._input) == null || e.removeAttribute("placeholder");
  }
  // Selector handling
  _handleSelectorChange(e) {
    const t = e.detail;
    this.multiple ? (this._multipleSelection = typeof t == "string" ? [t] : t, this._dispatchValueChange(!0)) : (this.openWithSearch || (this._isFiltering = !1, this._closeDropdown(), this._initSelectedElements()), this.selectedValue = typeof t == "string" ? [t] : t, this._handleValidity(), this._dispatchValueChange(), this._updateInternalValue(t));
  }
  _handleBlurSelector(e, t) {
    var o;
    if (e !== t.target) {
      if (this.openWithSearch) return;
      (o = this._input) == null || o.focus(), this._handleBlurEsc(), this._showSelectedValues(this.selectedValue ? this.selectedValue : []);
    }
  }
  _updateInternalValue(e) {
    var t;
    this.deselectable && !e ? (this.value = "", this._input.value = "", (t = this._input) == null || t.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1) : this.value = e.toString(), this._hiddenInput.dispatchEvent(new Event("change", { bubbles: !0 })), console.log("+++ value updated:", this.value);
  }
  _dispatchValueChange(e) {
    this._input && setTimeout(() => {
      const t = this._hiddenInput.value === "" && e ? this._multipleSelection.toString() : this._hiddenInput.value, o = e ? this._multipleSelection : this.selectedValue, r = this._getSelectedElements(e), n = {
        detail: { inputValue: t, selectedValue: o, selectedItems: r },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("value-changed", n));
    }, 0);
  }
  // Popper.js dropdown handling
  _createPopperDropdown() {
    var o, r;
    if (this.openWithSearch) return;
    const e = (o = this.shadowRoot) == null ? void 0 : o.querySelector(".dss-input-group"), t = (r = this.shadowRoot) == null ? void 0 : r.querySelector(".dss-form-select-options");
    e && t && (this._popperInstance = w(e, t, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        },
        {
          name: "matchWidth",
          enabled: !0,
          phase: "beforeWrite",
          fn({ state: n }) {
            n.elements.popper.style.width = `${e.offsetWidth}px`;
          },
          effect: ({ state: n }) => {
            n.elements.popper.style.width = `${e.offsetWidth}px`;
          }
        }
      ]
    }));
  }
  _updatePopperDropdown() {
    if (this.dropdownOffsetX && this.dropdownOffsetY) {
      const e = this.dropdownOffsetX, t = this.dropdownOffsetY;
      this._popperInstance.setOptions({
        modifiers: [
          {
            name: "popperOffsets",
            phase: "write",
            fn({ state: o }) {
              o.modifiersData.popperOffsets = {
                x: e,
                // Coordenada X deseada
                y: t
                // Coordenada Y deseada
              };
            }
          },
          {
            name: "applyStyles",
            phase: "write",
            // Se ejecuta al final
            fn({ state: o }) {
              var r, n, h, a;
              Object.assign(o.elements.popper.style, {
                position: o.options.strategy,
                left: `${(n = (r = o == null ? void 0 : o.modifiersData) == null ? void 0 : r.popperOffsets) == null ? void 0 : n.x}px`,
                top: `${(a = (h = o == null ? void 0 : o.modifiersData) == null ? void 0 : h.popperOffsets) == null ? void 0 : a.y}px`,
                transform: "none"
                // Desactiva transformaciones automáticas
              });
            }
          }
        ]
      });
    } else
      this._popperInstance.update();
    setTimeout(() => {
      this.classList.remove("animation-enabled");
    }, 400);
  }
  _toggleDropdown() {
    var t, o, r;
    if (!this._input) return;
    const e = !!((t = this._elements) != null && t.length);
    this.showDropdown = !this.showDropdown, this.showDropdown ? (this._popperInstance || this._createPopperDropdown(), e && ((o = this.selectedValue) != null && o.length || (this._filteredElements = this._getFilteredElements()), this._handleClick())) : (e ? (this._input.value = "", this.internals.setFormValue(this.value), this._showPlaceholder(), this._input.focus()) : ((r = this._input) == null || r.removeAttribute("placeholder"), this._placeholder = "", this._isFiltering = !1, this._isFocused = !1), this.multiple && this._multipleSelection && (this.selectedValue = [...this._multipleSelection], this._updateInternalValue(this.selectedValue)), this._applySelectedValue(this.selectedValue));
  }
  _closeDropdown() {
    this._removeListenerClickOutside(), this.showDropdown = !1, this._isFiltering = !1, this._isFocused = !1, this.multiple && this._multipleSelection ? (this.selectedValue = [...this._multipleSelection], this._updateInternalValue(this.selectedValue)) : this._applySelectedValue(this.selectedValue), setTimeout(() => {
      this._checkTruncatedIfMultipleSelection();
    }, 0), setTimeout(() => {
      this.classList.add("animation-enabled");
    }, 400);
  }
};
m.formAssociated = !0;
let i = m;
s([
  S("input.dss-input")
], i.prototype, "_input");
s([
  S("input.dss-hidden-value")
], i.prototype, "_hiddenInput");
s([
  l({ type: String })
], i.prototype, "label");
s([
  l(p)
], i.prototype, "hideLabel");
s([
  l({ type: String })
], i.prototype, "name");
s([
  l({ type: String })
], i.prototype, "id");
s([
  l({ type: String })
], i.prototype, "placeholder");
s([
  l({ type: String })
], i.prototype, "value");
s([
  l({ converter: _, reflect: !0 })
], i.prototype, "disabled");
s([
  l({ converter: _, reflect: !0 })
], i.prototype, "readonly");
s([
  l({ converter: _, reflect: !0 })
], i.prototype, "required");
s([
  l({ converter: _, reflect: !0 })
], i.prototype, "invalid");
s([
  l({ type: Number })
], i.prototype, "step");
s([
  l({ type: Number })
], i.prototype, "min");
s([
  l({ type: Number })
], i.prototype, "max");
s([
  l({ type: Number })
], i.prototype, "minLength");
s([
  l({ type: Number })
], i.prototype, "maxLength");
s([
  l({ type: String })
], i.prototype, "pattern");
s([
  l({ type: String })
], i.prototype, "inputmode");
s([
  l({ type: String })
], i.prototype, "autocapitalize");
s([
  l({ type: String })
], i.prototype, "autocomplete");
s([
  l(p)
], i.prototype, "autocorrect");
s([
  l(p)
], i.prototype, "autofocus");
s([
  l(p)
], i.prototype, "spellcheck");
s([
  l({ type: String })
], i.prototype, "size");
s([
  l({ type: String })
], i.prototype, "icon");
s([
  l({ type: String })
], i.prototype, "helpText");
s([
  l({ type: String })
], i.prototype, "maskRegex");
s([
  l({ type: String })
], i.prototype, "maskReplace");
s([
  l({ type: String })
], i.prototype, "allowedChars");
s([
  l({ type: String })
], i.prototype, "unit");
s([
  l({ type: String })
], i.prototype, "inputPrefix");
s([
  l(p)
], i.prototype, "hasActions");
s([
  l({ type: Array })
], i.prototype, "elements");
s([
  l({ type: Array })
], i.prototype, "selectedValue");
s([
  l({ type: String })
], i.prototype, "placeholderOnDropdown");
s([
  l({ type: String })
], i.prototype, "placeholderIfEmpty");
s([
  l({ type: String })
], i.prototype, "type");
s([
  l(p)
], i.prototype, "multiple");
s([
  l(p)
], i.prototype, "tick");
s([
  l(p)
], i.prototype, "autoSort");
s([
  l(p)
], i.prototype, "deselectable");
s([
  l({ type: String })
], i.prototype, "boxStyle");
s([
  l({ type: String })
], i.prototype, "dropdownStyle");
s([
  l({ type: String })
], i.prototype, "labelSelectAll");
s([
  l({ type: String })
], i.prototype, "labelDeselectAll");
s([
  l({ type: Number })
], i.prototype, "filterThreshold");
s([
  l({ type: Number })
], i.prototype, "searchThreshold");
s([
  l(p)
], i.prototype, "selectAll");
s([
  l(p)
], i.prototype, "showDropdown");
s([
  l(p)
], i.prototype, "openWithSearch");
s([
  l({ type: Number })
], i.prototype, "dropdownOffsetX");
s([
  l({ type: Number })
], i.prototype, "dropdownOffsetY");
s([
  l({ type: String })
], i.prototype, "dropdownPlacement");
s([
  l(p)
], i.prototype, "dropdownFixed");
s([
  l(p)
], i.prototype, "advancedFilter");
s([
  l(p)
], i.prototype, "tooltipFixed");
s([
  l(p)
], i.prototype, "forceViewport");
s([
  u()
], i.prototype, "_isFocused");
s([
  u()
], i.prototype, "_isTruncated");
s([
  u()
], i.prototype, "_onHoldInterval");
s([
  u()
], i.prototype, "_isFiltering");
s([
  u()
], i.prototype, "_inputValidity");
s([
  u()
], i.prototype, "_selectElements");
export {
  i as FormSelect
};
//# sourceMappingURL=form-select.js.map
