import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as t, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const l = t`dss-icon${d(r())}`, h = (i) => s`
  <a
    href="${i.disabled ? "javascript:void(0)" : i.href}"
    target="${i.disabled ? "_self" : i.target}"
    ?download="${i.download}"
    style="font-size: ${i.fontSize};"
    class=${a({
  "dss-link": !0,
  "dss-link--disabled": !!i.disabled,
  "dss-link--icon-right": !!i.icon && i.iconPosition === "right",
  [`dss-link--${i.fontWeight}`]: i.fontWeight !== "inherit"
})}
  >
    ${i.icon ? s`
          <${l} size="${i.iconSize}" icon="${i.icon}"></${l}>
        ` : null}
    <span class="dss-link-text">${i.label}</span>
  </a>
`;
export {
  h as template
};
//# sourceMappingURL=link.template.js.map
