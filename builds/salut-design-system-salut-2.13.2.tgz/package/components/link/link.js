import { LitElement as a, unsafeCSS as n } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import S from "./link.style.css.js";
import { template as d } from "./link.template.js";
var g = Object.defineProperty, e = (i, s, y, c) => {
  for (var r = void 0, p = i.length - 1, f; p >= 0; p--)
    (f = i[p]) && (r = f(s, y, r) || r);
  return r && g(s, y, r), r;
};
class o extends a {
  constructor() {
    super(...arguments), this.href = "#", this.label = "", this.icon = void 0, this.iconSize = "sm", this.iconPosition = "left", this.disabled = !1, this.download = !1, this.target = "_self", this.fontWeight = "inherit", this.fontSize = "inherit";
  }
  static get styles() {
    return [n(h), n(m), n(S)];
  }
  render() {
    return d(this);
  }
}
e([
  t({ type: String })
], o.prototype, "href");
e([
  t({ type: String })
], o.prototype, "label");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "iconSize");
e([
  t({ type: String })
], o.prototype, "iconPosition");
e([
  t(l)
], o.prototype, "disabled");
e([
  t(l)
], o.prototype, "download");
e([
  t({ type: String })
], o.prototype, "target");
e([
  t({ type: String })
], o.prototype, "fontWeight");
e([
  t({ type: String })
], o.prototype, "fontSize");
export {
  o as Link
};
//# sourceMappingURL=link.js.map
