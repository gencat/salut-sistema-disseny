import { LitElement as E, unsafeCSS as g, render as D } from "lit";
import { unsafeStatic as w, literal as x, html as d } from "lit/static-html.js";
import { property as o, state as P } from "lit/decorators.js";
import { classMap as S } from "lit/directives/class-map.js";
import { ifDefined as U } from "lit/directives/if-defined.js";
import { getCustomElementSuffix as C } from "../../api/custom-element-scope.js";
import { booleanType as h } from "../../utils/property-types.js";
import { moveFocusToNextTarget as L, moveFocusToPreviousTarget as R, onKeyboardEnter as H } from "../../utils/keyboard-navigation.js";
import { sort as m } from "../../utils/sorting.js";
import z from "../../foundations/icon/icon.style.css.js";
import I from "../../shared/scrollbar.style.css.js";
import V from "../checkbox/checkbox.style.css.js";
import N from "./custom-table.style.css.js";
var M = Object.defineProperty, j = Object.getOwnPropertyDescriptor, r = (y, t, e, s) => {
  for (var i = s > 1 ? void 0 : s ? j(t, e) : t, n = y.length - 1, a; n >= 0; n--)
    (a = y[n]) && (i = (s ? a(t, e, i) : a(i)) || i);
  return s && i && M(t, e, i), i;
};
const v = x`dss-icon${w(C())}`, k = x`dss-custom-table-header${w(C())}`, $ = x`dss-table-pagination${w(C())}`;
class l extends E {
  constructor() {
    super(...arguments), this.internalSelectedCounter = 0, this.showConfig = !1, this.configTableLabel = "Configurar taula", this.customActions = !1, this._hideHeader = !1, this._hidePaginator = !1, this._columnsHeader = [], this._data = void 0, this._paginatedData = void 0, this._currentSortColumn = "", this._currentSortType = "string", this._currentSortOrder = "none", this._multiselect = !1, this._radioselect = !1, this._allRowsSelected = !1, this._selectedRowsLabel = "files seleccionades", this._isFirstUpdate = !0, this._shouldUpdate = !1, this._table = void 0, this._currentRowsChecked = 0, this._selectedRowsCounter = void 0, this._tableTitle = "", this._filters = void 0, this._innerFilters = !1, this._expandTable = !1, this._expandLabel = "Ampliar", this._collapseLabel = "Reduir", this._filtersLabel = "Selecció", this._cleanFiltersLabel = "Netejar filtres", this._isTableHeaderCreated = !1, this._hideHeaderTitleAndExpand = !1, this._disableSorting = !1, this.hideActionExpand = !1, this.showActionFilters = !1, this._isPaginationStarted = !1, this._totalResults = void 0, this._currentIndex = 1, this._pageSize = 10, this._pageSizeOptions = [5, 10, 20], this._resultstext = "Resultats", this._rowsperpagetext = "Files per pàgina", this._paginationState = void 0, this._pageSizeOptionsDisabled = !1, this._hidePaginationResults = !1, this._hideFooter = !1, this.fixedColumnsBefore = void 0, this.fixedColumnsAfter = void 0, this.tableInfo = void 0, this.jcef = !1, this._currentSortedData = void 0, this._tbody = void 0, this._tbodyObserver = void 0;
  }
  static get styles() {
    return [g(z), g(I), g(V), g(N)];
  }
  disconnectedCallback() {
    var t, e;
    super.disconnectedCallback(), (t = this._tbody) == null || t.removeEventListener("keydown", this._handleTableKeydown.bind(this)), (e = this._tbodyObserver) == null || e.disconnect(), this._tbodyObserver = void 0;
  }
  set hideHeader(t) {
    const e = this._hideHeader;
    this._hideHeader = t, this.requestUpdate("hideHeader", e);
  }
  get hideHeader() {
    return this._hideHeader;
  }
  set hidePaginator(t) {
    const e = this._hidePaginator;
    this._hidePaginator = t, this.requestUpdate("hidePaginator", e);
  }
  get hidePaginator() {
    return this._hidePaginator;
  }
  set columnsHeader(t) {
    const e = this._columnsHeader;
    this._columnsHeader = t, this.requestUpdate("columnsHeader", e);
  }
  get columnsHeader() {
    return this._columnsHeader;
  }
  set data(t) {
    const e = this._data;
    this._data = t, this.requestUpdate("data", e);
  }
  get data() {
    return this._data || [];
  }
  set multiselect(t) {
    const e = this._multiselect;
    this._multiselect = t, this.requestUpdate("multiselect", e);
  }
  get multiselect() {
    return this._multiselect;
  }
  set radioselect(t) {
    const e = this._radioselect;
    this._radioselect = t, this.requestUpdate("radioselect", e);
  }
  get radioselect() {
    return this._radioselect;
  }
  set selectedRowsLabel(t) {
    const e = this._selectedRowsLabel;
    this._selectedRowsLabel = t, this.requestUpdate("selectedRowsLabel", e);
  }
  get selectedRowsLabel() {
    return this._selectedRowsLabel;
  }
  set selectedRowsCounter(t) {
    const e = this._selectedRowsCounter;
    this._selectedRowsCounter = t, this.requestUpdate("selectedRowsCounter", e);
  }
  get selectedRowsCounter() {
    return this._selectedRowsCounter || 0;
  }
  set tableTitle(t) {
    const e = this._tableTitle;
    this._tableTitle = t, this.requestUpdate("tableTitle", e);
  }
  get tableTitle() {
    return this._tableTitle;
  }
  set filters(t) {
    const e = this._filters;
    this._filters = t, this.requestUpdate("filters", e);
  }
  get filters() {
    return this._filters ?? [];
  }
  set innerFilters(t) {
    const e = this._innerFilters;
    this._innerFilters = t, this.requestUpdate("innerFilters", e);
  }
  get innerFilters() {
    return this._innerFilters;
  }
  set expandTable(t) {
    const e = this._expandTable;
    this._expandTable = t, this.requestUpdate("expandTable", e);
  }
  get expandTable() {
    return this._expandTable;
  }
  set expandLabel(t) {
    const e = this._expandLabel;
    this._expandLabel = t, this.requestUpdate("expandLabel", e);
  }
  get expandLabel() {
    return this._expandLabel;
  }
  set collapseLabel(t) {
    const e = this._collapseLabel;
    this._collapseLabel = t, this.requestUpdate("collapseLabel", e);
  }
  get collapseLabel() {
    return this._collapseLabel;
  }
  set filtersLabel(t) {
    const e = this._filtersLabel;
    this._filtersLabel = t, this.requestUpdate("filtersLabel", e);
  }
  get filtersLabel() {
    return this._filtersLabel;
  }
  set cleanFiltersLabel(t) {
    const e = this._cleanFiltersLabel;
    this._cleanFiltersLabel = t, this.requestUpdate("cleanFiltersLabel", e);
  }
  get cleanFiltersLabel() {
    return this._cleanFiltersLabel;
  }
  set hideHeaderTitleAndExpand(t) {
    const e = this._hideHeaderTitleAndExpand;
    this._hideHeaderTitleAndExpand = t, this.requestUpdate("hideHeaderTitleAndExpand", e);
  }
  get hideHeaderTitleAndExpand() {
    return this._hideHeaderTitleAndExpand;
  }
  set disableSorting(t) {
    const e = this._disableSorting;
    this._disableSorting = t, this.requestUpdate("disableSorting", e);
  }
  get disableSorting() {
    return this._disableSorting;
  }
  set totalResults(t) {
    const e = this._totalResults;
    this._totalResults = t, this.requestUpdate("totalResults", e);
  }
  get totalResults() {
    return this._totalResults || 0;
  }
  set currentIndex(t) {
    const e = this._currentIndex;
    this._currentIndex = t, this.requestUpdate("currentIndex", e);
  }
  get currentIndex() {
    return this._currentIndex;
  }
  set pageSize(t) {
    const e = this._pageSize;
    this._pageSize = t, this.requestUpdate("pageSize", e);
  }
  get pageSize() {
    return this._pageSize;
  }
  set pageSizeOptions(t) {
    const e = this._pageSizeOptions;
    this._pageSizeOptions = t, this.requestUpdate("pageSizeOptions", e);
  }
  get pageSizeOptions() {
    return this._pageSizeOptions;
  }
  set resultsLabel(t) {
    const e = this._resultstext;
    this._resultstext = t, this.requestUpdate("resultsLabel", e);
  }
  get resultsLabel() {
    return this._resultstext;
  }
  set rowsPerPageLabel(t) {
    const e = this._rowsperpagetext;
    this._rowsperpagetext = t, this.requestUpdate("rowsperpageLabel", e);
  }
  get rowsPerPageLabel() {
    return this._rowsperpagetext;
  }
  set hidePaginationResults(t) {
    const e = this._hidePaginationResults;
    this._hidePaginationResults = t, this.requestUpdate("hidePaginationResults", e);
  }
  get hidePaginationResults() {
    return this._hidePaginationResults;
  }
  set pageSizeOptionsDisabled(t) {
    const e = this._pageSizeOptionsDisabled;
    this._pageSizeOptionsDisabled = t, this.requestUpdate("pageSizeOptionsDisabled", e);
  }
  get pageSizeOptionsDisabled() {
    return this._pageSizeOptionsDisabled;
  }
  set hideFooter(t) {
    const e = this._hideFooter;
    this._hideFooter = t, this.requestUpdate("hideFooter", e);
  }
  get hideFooter() {
    return this._hideFooter;
  }
  // @state() _currentSortedData: any[] | undefined = undefined;
  /* METHODS */
  _getDataLength() {
    let t = 0;
    return this._totalResults && this._totalResults >= 0 ? t = this._totalResults : this._data && (t = this._currentSortedData ? this._currentSortedData.length : this._data.length), t;
  }
  _sortBy(t, e, s) {
    this._currentSortColumn = t, this._currentSortType = e, s ? s === "none" ? this._currentSortOrder = "asc" : s === "asc" ? this._currentSortOrder = "desc" : s === "desc" && (this._currentSortOrder = "none") : this._currentSortOrder = "asc", this._updateColumnSortState(), this._currentSortOrder === "none" ? this._currentSortedData = this._data : this._currentSortedData = m(this._data, this._currentSortColumn, this._currentSortOrder, e);
    const i = this._resetPagination(this._currentSortedData || []);
    return this._dispatchSort(i || []), i;
  }
  _resetPagination(t) {
    this._currentIndex = 1;
    const e = this._currentIndex - 1, s = this._pageSize;
    if (t) {
      const i = s <= t.length ? s : t.length;
      this._paginatedData = [...t.slice(e, i)];
    }
    return this._paginatedData;
  }
  _updateColumnSortState() {
    this._columnsHeader.forEach((t) => {
      t.column === this._currentSortColumn ? t.sortOrder = this._currentSortOrder : t.sortOrder && (t.sortOrder = "none");
    });
  }
  _onSelectAll() {
    if (this._table) {
      this._allRowsSelected = !this._allRowsSelected;
      let t = 0, e = 0;
      const s = this._table.querySelectorAll(".dss-checkbox--multiselect");
      s.forEach((i) => {
        i.disabled ? e += 1 : (i.checked || (t += 1), i.checked = this._allRowsSelected);
      }), this._allRowsSelected ? this._currentRowsChecked += t : this._currentRowsChecked -= s.length - e, this._updateTableFooterRowsChecked(), this._dispatchMultiselect();
    }
  }
  _rowsCheckedListener(t) {
    if (!this._table || t.classList.contains("dss-checkbox--thead")) return;
    let s = !1;
    if (t.tagName === "INPUT" && t.type === "checkbox" && t.classList.contains("dss-checkbox") && !t.classList.contains("dss-checkbox--thead"))
      s = t.checked;
    else if (t.tagName === "DSS-FORM-CHECKBOX") {
      const i = t;
      s = i.checked ?? i.getAttribute("checked") !== null;
    }
    s ? this._currentRowsChecked += 1 : this._currentRowsChecked -= 1, this._updateTableFooterRowsChecked();
  }
  _updateTableFooterRowsChecked() {
    this._selectedRowsCounter === void 0 && (this.internalSelectedCounter = this._currentRowsChecked);
  }
  _updateTableHeader() {
    if (this._table) {
      const t = this._table.querySelector(".dss-custom-table");
      let e = t.querySelector("thead");
      e || (e = document.createElement("thead"), e.classList.add("dss-thead"), t.insertBefore(e, t.firstChild)), D(this._generateTableHeaderHTML(), e);
    }
  }
  _generateTableHeaderHTML() {
    let t = !0, e = d``, s = d``;
    this._multiselect && (e = d`
        <th class="dss-th dss-th--select">
          <div class="dss-th-content dss-th-content--select">
						<span class="sr-only">Seleccionar totes les files</span>
            <input
              type="checkbox"
              class="dss-checkbox dss-checkbox--thead"
              aria-label="Seleccionar totes les files"
              .checked=${this._allRowsSelected}
              @change="${this._onSelectAll.bind(this)}"
            />
          </div>
        </th>
      `), this._radioselect && (s = d`
        <th class="dss-th dss-th--select">
          <div class="dss-th-content dss-th-content--select">
						<span class="sr-only">Seleccionar fila</span>
					</div>
        </th>
      `);
    const i = this._columnsHeader.map((a) => {
      const c = () => {
        a.sortType && !this._disableSorting && (this._sortBy(a.column, a.sortType, a == null ? void 0 : a.sortOrder), this._updateTableHeaderIcons());
      }, u = (b) => {
        const T = b.currentTarget, F = b;
        let f = !1;
        switch (F.key) {
          case "ArrowLeft":
            this._table && R(this._table, T, ".dss-th-content--clickable"), f = !0;
            break;
          case "ArrowRight":
            this._table && L(this._table, T, ".dss-th-content--clickable"), f = !0;
            break;
          case "Enter": {
            const q = b.target;
            this._table && H(this._table, q, ".dss-th-content--clickable"), f = !0;
            break;
          }
        }
        f && (b.stopPropagation(), b.preventDefault());
      }, _ = {
        "dss-th--align-center": a.align === "center",
        "dss-th--align-right": a.align === "right",
        "dss-th--highlight": !!a.highlight
      };
      let p = !1;
      a.sortType && !this._disableSorting && (p = !0);
      const A = {
        "dss-th-content--clickable": p
        // 'table-th--review': columnType === 'review',
      }, O = d`
        <th
          class="dss-th ${S(_)}"
          style="${U(a.style)}"
        >
          <div
            class="dss-th-content ${S(A)}"
            tabindex="${t ? 0 : -1}"
            @click=${c}
            @keydown=${u}
          >
						${a.renderTemplate ? d`
									<span class="sr-only">${a.label}</span>
									${a.renderTemplate()}
								` : d`
								${a.srOnly ? d`<span class="sr-only">${a.label}</span>` : d`<span class="dss-th-content__label">${a.label}</span>`}
							`}

            ${a.sortType && !this._disableSorting ? d`${this._getTableHeaderSortIconHTML(a.column)}` : null}
          </div>
        </th>
      `;
      return t = !1, O;
    });
    return d` <tr class="dss-thead-row ${S({})}">
      ${e} ${s} ${i}
    </tr>`;
  }
  _getTableHeaderSortIconHTML(t) {
    let e = "swap_vert";
    if (this._currentSortColumn === t)
      switch (this._currentSortOrder) {
        case "asc":
          e = "arrow_upward";
          break;
        case "desc":
          e = "arrow_downward";
          break;
        default:
          e = "swap_vert";
          break;
      }
    return d`
			<${v} 
				class="dss-th-content__icon dss-icon--column-sort"
				column="${t}" 
				icon="${e}" 
				size="sm">
			</${v}>
    `;
  }
  _updateTableHeaderIcons() {
    this._table && this._table.querySelectorAll(
      ".dss-th-content--clickable > .dss-icon--column-sort"
    ).forEach((e) => {
      const s = e.getAttribute("column");
      let i = "swap_vert";
      if (this._currentSortColumn === s)
        switch (this._currentSortOrder) {
          case "asc":
            i = "arrow_upward";
            break;
          case "desc":
            i = "arrow_downward";
            break;
          default:
            i = "swap_vert";
            break;
        }
      e.setAttribute("icon", i);
    });
  }
  _paginate(t) {
    const e = t.startIndex, s = t.endIndex;
    if (this._currentSortedData) {
      const i = s <= this._currentSortedData.length ? s : this._currentSortedData.length;
      this._paginatedData = [...this._currentSortedData.slice(e - 1, i)];
    }
    return t.pageSize && (this._pageSize = t.pageSize), this._paginatedData;
  }
  /* OUTPUT EVENTS */
  _dispatchChangeFilters(t) {
    this._filters = t.detail;
    const e = {
      detail: this._filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onUpdateFilters", e));
  }
  _dispatchExpandTable(t) {
    this._expandTable = t.detail;
    const e = {
      detail: this._expandTable,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onExpandTable", e));
  }
  _dispatchOpenFilters() {
    const t = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenDrawer", t));
  }
  handleChangePage(t) {
    this._dispatchPagination(t);
  }
  _dispatchPagination(t) {
    var e;
    if (!this._totalResults || this._isPaginationStarted) {
      const s = {
        detail: t.detail,
        bubbles: !0,
        composed: !0
      };
      if (this._paginationState = s.detail, this._data && !this._totalResults && (s.detail.data = this._paginate(this._paginationState)), this._totalResults && (this._shouldUpdate = !0), this._allRowsSelected) {
        this._allRowsSelected = !1;
        const i = (e = this._table) == null ? void 0 : e.querySelector(".dss-checkbox--thead");
        i && (i.checked = !1);
      }
      setTimeout(() => {
        this.dispatchEvent(new CustomEvent("onPaginate", s));
      }, 0);
    }
    this._isPaginationStarted = !0;
  }
  _dispatchSort(t) {
    const e = {
      detail: {
        currentSortColumn: this._currentSortColumn,
        currentSortOrder: this._currentSortOrder,
        currentSortType: this._currentSortType,
        columnsHeader: this._columnsHeader,
        data: t
      },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onSort", e));
  }
  _dispatchMultiselect() {
    const t = {
      detail: this._allRowsSelected,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onMultiselect", t));
  }
  _handleTableKeydown(t) {
    if (!this._table) return;
    const e = t.target;
    let s = !1;
    const i = e.closest("tr");
    switch (t.key) {
      case "ArrowUp":
        R(this._table, i, ".dss-tbody-row"), s = !0;
        break;
      case "ArrowDown":
        L(this._table, i, ".dss-tbody-row"), s = !0;
        break;
      case "Enter":
        if (this._multiselect) {
          const n = i == null ? void 0 : i.querySelector(".dss-checkbox--multiselect");
          n && (n.checked = !(n != null && n.checked), this.requestUpdate()), s = !0;
        }
        if (this._radioselect) {
          const n = i == null ? void 0 : i.querySelector(".dss-radio");
          n && (n.checked = !(n != null && n.checked), this.requestUpdate()), s = !0;
        }
        break;
    }
    s && (t.stopPropagation(), t.preventDefault());
  }
  _initTable() {
    var e, s;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="table"]')) || void 0;
    this._table = t == null ? void 0 : t.assignedElements()[0], this._table && (this._columnsHeader.length && !this._isTableHeaderCreated && (this._updateTableHeader(), this._isTableHeaderCreated = !0), this._setFirstRowTabindex(), this._checkAllRowsSelected(), this._tbody = this._table.querySelector("tbody"), (s = this._tbody) == null || s.addEventListener("keydown", this._handleTableKeydown.bind(this)), this._detectNewRows());
  }
  _detectNewRows() {
    this._tbody && (this._tbodyObserver = new MutationObserver((t) => {
      let e = !1;
      for (const s of t)
        if (s.type === "childList" && (s.addedNodes.length > 0 || s.removedNodes.length > 0)) {
          e = !0;
          break;
        }
      e && (this._setFirstRowTabindex(), this._checkAllRowsSelected());
    }), this._tbodyObserver.observe(this._tbody, { childList: !0 }));
  }
  _setFirstRowTabindex() {
    if (!this._table) return;
    const t = this._table.querySelectorAll(".dss-tbody-row");
    let e = !0;
    t.forEach((s) => {
      e ? s.setAttribute("tabindex", "0") : s.setAttribute("tabindex", "-1"), e = !1;
    });
  }
  _checkAllRowsSelected() {
    var t;
    if (this._table) {
      const e = this._table.querySelectorAll(".dss-checkbox--multiselect");
      let s = !0;
      if (e.length === 0 && (s = !1), e.forEach((i) => {
        !i.checked && !i.disabled && (s = !1);
      }), this._allRowsSelected !== s) {
        this._allRowsSelected = s;
        const i = (t = this._table) == null ? void 0 : t.querySelector(".dss-checkbox--thead");
        i.checked = this._allRowsSelected;
      }
    }
  }
  _fixColumns() {
    if (this._table && (this.fixedColumnsBefore || this.fixedColumnsAfter)) {
      const t = this._table.querySelector("table"), e = t == null ? void 0 : t.querySelector("thead"), s = t == null ? void 0 : t.querySelector("tbody"), i = e == null ? void 0 : e.querySelectorAll("th"), n = s == null ? void 0 : s.querySelectorAll("tr");
      if (t == null || t.classList.add("dss-custom-table--max-content-width"), t == null || t.classList.add("dss-custom-table--sticky-columns-lit"), this.fixedColumnsBefore) {
        const a = Array.from(i || []).slice(0, this.fixedColumnsBefore);
        this._cellsToSticky(a, "left");
        for (const c of Array.from(n || [])) {
          const u = c.querySelectorAll("td"), _ = Array.from(u).slice(0, this.fixedColumnsBefore);
          this._cellsToSticky(_, "left");
        }
      }
      if (this.fixedColumnsAfter) {
        const a = Array.from(i || []).slice(-this.fixedColumnsAfter).reverse();
        this._cellsToSticky(a, "right");
        for (const c of Array.from(n || [])) {
          const u = c.querySelectorAll("td"), _ = Array.from(u).slice(-this.fixedColumnsAfter).reverse();
          this._cellsToSticky(_, "right");
        }
      }
    }
  }
  _cellsToSticky(t, e) {
    for (const [s, i] of Array.from(t || []).entries()) {
      const n = i;
      n.classList.add("dss-sticky-column");
      let a = 0;
      s > 0 && (a = a + t[s - 1].offsetWidth), e === "left" ? n.style.left = `${a}px` : n.style.right = `${a}px`, s === t.length - 1 && (e === "left" ? n.classList.add("dss-sticky-column--before-last") : n.classList.add("dss-sticky-column--after-first"));
    }
  }
  _initScrollX(t) {
    var e;
    (t == null ? void 0 : t.clientWidth) < (t == null ? void 0 : t.scrollWidth) && ((e = this._table) == null || e.classList.add("scroll-init"));
  }
  _handleScrollX(t) {
    var i, n, a, c, u, _, p;
    const e = t.target, s = (e == null ? void 0 : e.scrollWidth) - (e == null ? void 0 : e.clientWidth);
    s <= 0 || ((e == null ? void 0 : e.scrollLeft) === 0 && ((i = this._table) == null || i.classList.add("scroll-init"), (n = this._table) == null || n.classList.remove("scroll-middle")), (e == null ? void 0 : e.scrollLeft) > 0 && Math.round(e == null ? void 0 : e.scrollLeft) < s && ((a = this._table) == null || a.classList.add("scroll-middle"), (c = this._table) == null || c.classList.remove("scroll-init"), (u = this._table) == null || u.classList.remove("scroll-end")), Math.round(e == null ? void 0 : e.scrollLeft) === s && ((_ = this._table) == null || _.classList.add("scroll-end"), (p = this._table) == null || p.classList.remove("scroll-middle")));
  }
  _setDataState() {
    this._currentSortOrder === "none" ? this._currentSortedData = this._data : this._currentSortedData = m(
      this._data,
      this._currentSortColumn,
      this._currentSortOrder,
      this._currentSortType
    );
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    var t;
    if (await this.updateComplete, this._setDataState(), this._isFirstUpdate && !this._table && (this._initTable(), this.addEventListener("change", (e) => {
      this._rowsCheckedListener(e.target), this._checkAllRowsSelected();
    }), this._fixColumns()), this.fixedColumnsBefore || this.fixedColumnsAfter) {
      const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-custom-table-body");
      this._initScrollX(e), e == null || e.addEventListener("scroll", this._handleScrollX.bind(this));
    }
    this._isFirstUpdate = !1;
  }
  willUpdate(t) {
    const e = t.has("columnsHeader"), s = t.has("disableSorting"), i = t.has("data"), n = t.has("currentIndex");
    if (s && this._updateTableHeader(), e && (this._columnsHeader.forEach((a) => {
      a.sortOrder && (this._currentSortColumn = a.column, this._currentSortOrder = a.sortOrder, a.sortType && (this._currentSortType = a.sortType));
    }), !this._isTableHeaderCreated && this._table && (this._updateTableHeader(), this._isTableHeaderCreated = !0), this._fixColumns()), i && !this._isFirstUpdate) {
      if (this._setDataState(), this._totalResults) {
        if (this.internalSelectedCounter > this._totalResults && (this.internalSelectedCounter = this._totalResults), this._shouldUpdate) {
          if (this._currentSortColumn && this._currentSortType && this._currentSortOrder && this._currentSortOrder !== "none") {
            const a = m(
              this._data,
              this._currentSortColumn,
              this._currentSortOrder,
              this._currentSortType
            );
            this._dispatchSort(a);
          }
          this._shouldUpdate = !1;
        }
      } else {
        const a = this._getDataLength();
        if (this.internalSelectedCounter > a && (this.internalSelectedCounter = a, this._currentRowsChecked = a), this._paginationState) {
          this._paginationState.endIndex < this._pageSize && (this._paginationState.endIndex = this._pageSize);
          const c = {
            detail: this._paginationState,
            bubbles: !0,
            composed: !0
          };
          this._dispatchPagination(c);
        }
      }
      this._fixColumns();
    }
    n && !this._isFirstUpdate && (this._fixColumns(), this.requestUpdate());
  }
  filtersPopoverClose() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector("dss-custom-table-header");
    t && t.filtersPopoverClose();
  }
  _areRowsSelected() {
    return this._selectedRowsCounter !== void 0 ? this._selectedRowsCounter > 0 : this.internalSelectedCounter > 0;
  }
  render() {
    return d`
		${this._selectedRowsCounter}
      <div class="dss-custom-table">
        <div class="dss-custom-table-header">
          ${this._hideHeader ? null : d`
                <${k}
									?customActions=${this.customActions}
									?showConfig=${this.showConfig}
									?hideActionExpand=${this.hideActionExpand}
									?showActionFilters=${this.showActionFilters}
									?jcef=${this.jcef}
									.tableInfo=${this.tableInfo}
									.configTableLabel=${this.configTableLabel}
                  .tableTitle=${this._tableTitle}
                  .filters=${this._filters}
                  .innerFilters=${this._innerFilters}
                  .expandTable=${this._expandTable}
                  .expandLabel=${this._expandLabel}
                  .collapseLabel=${this._collapseLabel}
                  .filtersLabel=${this._filtersLabel}
                  .cleanFiltersLabel=${this._cleanFiltersLabel}
                  .hideHeaderTitleAndExpand=${this._hideHeaderTitleAndExpand}
                  @onChangeFilters=${this._dispatchChangeFilters}
                  @onExpand=${this._dispatchExpandTable}
                  @onOpenFilters=${this._dispatchOpenFilters}
                >
									${this.customActions ? d`
	                  <slot name="header-custom-actions" slot="header-custom-actions"></slot>
									` : null}
                  <slot name="filters-popover-body" slot="filters-popover-body"></slot>
                  <slot name="filters-popover-footer" slot="filters-popover-footer"></slot>
                  <slot name="filters" slot="filters"></slot>
                </${k}>
              `}
        </div>

        <div class="dss-custom-table-body">
          <slot name="table"></slot>
        </div>

        ${this._hideFooter ? null : d`
              <div class="dss-custom-table-footer">
                
                ${this._multiselect ? d`
                      <div class="${S({
      "table-footer": !0,
      "table-footer--hide": !this._areRowsSelected()
    })}">
                        <div class="table-footer-description">
                          <span class="table-footer-description__counter">
                            ${this._selectedRowsCounter !== void 0 ? this._selectedRowsCounter : this.internalSelectedCounter}
                          </span>
                          de ${this._getDataLength()} ${this._selectedRowsLabel}
                        </div>
                        <slot name="footer-actions"></slot>
                      </div>
                    ` : null}

								${this._hidePaginator ? null : d`
                      <${$}
                        .length=${this._getDataLength()}
                        pagesize=${this._pageSize}
                        .pageSizeOptions=${this._pageSizeOptions}
                        currentindex=${this._currentIndex}
                        .resultsText=${this._resultstext}
                        .rowsPerPageText=${this._rowsperpagetext}
                        ?pageSizeOptionsDisabled=${this._pageSizeOptionsDisabled}
                        ?hidePaginationResults=${this._hidePaginationResults}
                        @onChangePage=${this.handleChangePage}
                      ></${$}>
                    `}
              </div>
            `}
      </div>
    `;
  }
}
r([
  o({ type: Number })
], l.prototype, "internalSelectedCounter", 2);
r([
  o(h)
], l.prototype, "hideHeader", 1);
r([
  o(h)
], l.prototype, "hidePaginator", 1);
r([
  o({ type: Array })
], l.prototype, "columnsHeader", 1);
r([
  o({ type: Array })
], l.prototype, "data", 1);
r([
  o(h)
], l.prototype, "multiselect", 1);
r([
  o(h)
], l.prototype, "radioselect", 1);
r([
  o({ type: String })
], l.prototype, "selectedRowsLabel", 1);
r([
  o({ type: Number })
], l.prototype, "selectedRowsCounter", 1);
r([
  o(h)
], l.prototype, "showConfig", 2);
r([
  o({ type: String })
], l.prototype, "configTableLabel", 2);
r([
  o(h)
], l.prototype, "customActions", 2);
r([
  o({ type: String })
], l.prototype, "tableTitle", 1);
r([
  o({ type: Array })
], l.prototype, "filters", 1);
r([
  o(h)
], l.prototype, "innerFilters", 1);
r([
  o(h)
], l.prototype, "expandTable", 1);
r([
  o({ type: String })
], l.prototype, "expandLabel", 1);
r([
  o({ type: String })
], l.prototype, "collapseLabel", 1);
r([
  o({ type: String })
], l.prototype, "filtersLabel", 1);
r([
  o({ type: String })
], l.prototype, "cleanFiltersLabel", 1);
r([
  o(h)
], l.prototype, "hideHeaderTitleAndExpand", 1);
r([
  o(h)
], l.prototype, "disableSorting", 1);
r([
  o({ type: Number })
], l.prototype, "totalResults", 1);
r([
  o({ type: Number })
], l.prototype, "currentIndex", 1);
r([
  o({ type: Number })
], l.prototype, "pageSize", 1);
r([
  o({ type: Array })
], l.prototype, "pageSizeOptions", 1);
r([
  o({ type: String })
], l.prototype, "resultsLabel", 1);
r([
  o({ type: String })
], l.prototype, "rowsPerPageLabel", 1);
r([
  o(h)
], l.prototype, "hidePaginationResults", 1);
r([
  o(h)
], l.prototype, "pageSizeOptionsDisabled", 1);
r([
  o(h)
], l.prototype, "hideFooter", 1);
r([
  o(h)
], l.prototype, "hideActionExpand", 2);
r([
  o(h)
], l.prototype, "showActionFilters", 2);
r([
  o({ type: Number })
], l.prototype, "fixedColumnsBefore", 2);
r([
  o({ type: Number })
], l.prototype, "fixedColumnsAfter", 2);
r([
  o({ type: String })
], l.prototype, "tableInfo", 2);
r([
  o(h)
], l.prototype, "jcef", 2);
r([
  P()
], l.prototype, "_currentSortedData", 2);
export {
  l as CustomTable
};
//# sourceMappingURL=custom-table.js.map
