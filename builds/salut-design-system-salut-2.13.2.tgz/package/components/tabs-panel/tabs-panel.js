import { LitElement as d, unsafeCSS as h } from "lit";
import { property as s } from "lit/decorators.js";
import { booleanType as p } from "../../utils/property-types.js";
import c from "./tabs-panel.style.css.js";
import { tabsPanelTemplate as _ } from "./tabs-panel.template.js";
var u = Object.defineProperty, b = Object.getOwnPropertyDescriptor, r = (a, e, t, S) => {
  for (var l = b(e, t), i = a.length - 1, n; i >= 0; i--)
    (n = a[i]) && (l = n(e, t, l) || l);
  return l && u(e, t, l), l;
};
class o extends d {
  constructor() {
    super(...arguments), this._panelId = "", this._label = "", this._linkedTo = "", this._selected = !1, this._hasScroll = !1;
  }
  static get styles() {
    return h(c);
  }
  set panelId(e) {
    const t = this._panelId;
    this._panelId = e, this.requestUpdate("panelId", t);
  }
  get panelId() {
    return this._panelId;
  }
  set label(e) {
    const t = this._label;
    this._label = e, this.requestUpdate("label", t);
  }
  get label() {
    return this._label;
  }
  set linkedTo(e) {
    const t = this._linkedTo;
    this._linkedTo = e, this.requestUpdate("linkedTo", t);
  }
  get linkedTo() {
    return this._linkedTo;
  }
  set selected(e) {
    const t = this._selected;
    this._selected = e, this.requestUpdate("selected", t);
  }
  get selected() {
    return this._selected;
  }
  set hasScroll(e) {
    const t = this._hasScroll;
    this._hasScroll = e, this.requestUpdate("hasScroll", t);
  }
  get hasScroll() {
    return this._hasScroll;
  }
  render() {
    return _(this);
  }
}
r([
  s({ type: String })
], o.prototype, "panelId");
r([
  s({ type: String })
], o.prototype, "label");
r([
  s({ type: String })
], o.prototype, "linkedTo");
r([
  s(p)
], o.prototype, "selected");
r([
  s(p)
], o.prototype, "hasScroll");
export {
  o as TabsPanel
};
//# sourceMappingURL=tabs-panel.js.map
