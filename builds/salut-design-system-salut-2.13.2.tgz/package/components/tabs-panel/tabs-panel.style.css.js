const e = ":host{width:100%;height:-moz-fit-content;height:fit-content}:not(:defined){display:none}[role=tabpanel]{width:100%;display:none}[role=tabpanel].has-scroll{overflow:auto}[role=tabpanel].selected{display:block}";
export {
  e as default
};
//# sourceMappingURL=tabs-panel.style.css.js.map
