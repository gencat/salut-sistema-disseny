import { html as e } from "lit";
import { classMap as s } from "lit/directives/class-map.js";
const i = (l) => {
  const a = {
    selected: l._selected,
    "is-hidden": !l._selected,
    "has-scroll": l._hasScroll
  };
  return e`
    <div
      id="${l._panelId}"
      role="tabpanel"
      aria-label="${l._label}"
      linkedTo="${l._linkedTo}"
      class="${s(a)}"
    >
      <slot></slot>
    </div>
  `;
};
export {
  i as tabsPanelTemplate
};
//# sourceMappingURL=tabs-panel.template.js.map
