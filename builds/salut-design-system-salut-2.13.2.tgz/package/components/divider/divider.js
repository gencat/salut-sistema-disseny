import { LitElement as p, unsafeCSS as m } from "lit";
import { property as d } from "lit/decorators.js";
import { classMap as n } from "lit/directives/class-map.js";
import { html as l } from "lit/static-html.js";
import a from "../../shared/reset.style.css.js";
import f from "./divider.style.css.js";
var u = Object.defineProperty, v = (t, e, i, y) => {
  for (var r = void 0, s = t.length - 1, o; s >= 0; s--)
    (o = t[s]) && (r = o(e, i, r) || r);
  return r && u(e, i, r), r;
};
class c extends p {
  constructor() {
    super(...arguments), this.size = "sm";
  }
  static get styles() {
    return [m(a), m(f)];
  }
  render() {
    const e = {
      "dss-divider": !0,
      "dss-divider--bold": this.size === "md"
    };
    return l`<hr class=${n(e)} />`;
  }
}
v([
  d({ type: String })
], c.prototype, "size");
export {
  c as Divider
};
//# sourceMappingURL=divider.js.map
