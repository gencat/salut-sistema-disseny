const r = ".dss-divider{margin-top:var(--dss-spacing-xl);margin-bottom:var(--dss-spacing-xl);border-width:var(--dss-border-width-sm);border-style:solid;border-color:var(--color-neutral-100)}.dss-divider--bold{border-width:var(--dss-border-width-md)}";
export {
  r as default
};
//# sourceMappingURL=divider.style.css.js.map
