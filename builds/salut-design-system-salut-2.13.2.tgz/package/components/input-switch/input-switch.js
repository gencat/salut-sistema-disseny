import { LitElement as u, unsafeCSS as n } from "lit";
import { property as d } from "lit/decorators.js";
import p from "../../foundations/icon/icon.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import _ from "./input-switch.style.css.js";
import { template as b } from "./input-switch.template.js";
var f = Object.defineProperty, k = Object.getOwnPropertyDescriptor, o = (h, e, t, c) => {
  for (var s = k(e, t), i = h.length - 1, r; i >= 0; i--)
    (r = h[i]) && (s = r(e, t, s) || s);
  return s && f(e, t, s), s;
};
class a extends u {
  constructor() {
    super(...arguments), this._checked = !1, this._isCheckedPropDefined = !1, this._isFirstUpdate = !0, this._disabled = !1, this._readonly = !1, this._size = "md", this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [n(p), n(_)];
  }
  get _input() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  set size(e) {
    const t = this._size;
    this._size = e, this.requestUpdate("size", t);
  }
  get size() {
    return this._size;
  }
  set checked(e) {
    const t = this._checked;
    this._checked = e, this._isCheckedPropDefined = !0, this._isFirstUpdate || this._dispatchChange(), this.requestUpdate("checked", t);
  }
  get checked() {
    return this._checked;
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  /* END Input Observer */
  _checkInputAttributes() {
    var c, s, i;
    if (!this._isCheckedPropDefined) {
      const r = (c = this._input) == null ? void 0 : c.getAttribute("checked");
      this._checked = r !== null;
    }
    const e = (s = this._input) == null ? void 0 : s.getAttribute("disabled");
    this._disabled = e !== null;
    const t = (i = this._input) == null ? void 0 : i.getAttribute("readonly");
    this._readonly = t !== null;
  }
  _handleClick() {
    !this._disabled && !this._readonly && this._input && (this._checked = !this._checked, this._checked ? this._input.setAttribute("checked", "true") : this._input.removeAttribute("checked"), this._dispatchChange());
  }
  _handleKeydown(e) {
    (e.key === "Enter" || e.key === " ") && this._handleClick();
  }
  _dispatchChange() {
    this.dispatchEvent(
      new CustomEvent("onChangeValue", {
        detail: this._checked,
        bubbles: !0,
        composed: !0
      })
    );
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig)), this._isFirstUpdate = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return b(this);
  }
}
o([
  d({ type: String })
], a.prototype, "size");
o([
  d(l)
], a.prototype, "checked");
export {
  a as InputSwitch
};
//# sourceMappingURL=input-switch.js.map
