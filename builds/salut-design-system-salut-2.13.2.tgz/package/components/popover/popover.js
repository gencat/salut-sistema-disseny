import { createPopper as u } from "@popperjs/core";
import { LitElement as v, unsafeCSS as h } from "lit";
import { property as n, state as c } from "lit/decorators.js";
import f from "../../foundations/icon/icon.style.css.js";
import _ from "../../shared/reset.style.css.js";
import m from "../../shared/scrollbar.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import b from "./popover.style.css.js";
import { popoverTemplate as y } from "./popover.template.js";
var g = Object.defineProperty, o = (d, e, t, s) => {
  for (var i = void 0, p = d.length - 1, l; p >= 0; p--)
    (l = d[p]) && (i = l(e, t, i) || i);
  return i && g(e, t, i), i;
};
class r extends v {
  constructor() {
    super(), this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        if (t.type === "attributes" && t.attributeName === "data-popper-placement") {
          const s = this.getAttribute("data-popper-placement");
          s && this._propagatePlacement(s);
        }
    }, this.mutationObserver = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || this._closePopover();
      },
      {
        root: null,
        threshold: 0
      }
    ), this.maxHeightObserverTimeout = null, this.maxHeightObserver = new ResizeObserver(([e]) => {
      this.maxHeightObserverTimeout && clearTimeout(this.maxHeightObserverTimeout), this.maxHeightObserverTimeout = window.setTimeout(() => {
        const t = e.contentRect.height;
        this._onHeightChange(t);
      }, 100);
    }), this._parentMousedownHandler = null, this._parentKeydownHandler = null, this.open = !1, this.variant = "default", this.hideCloseIcon = !1, this.disableParentClick = !1, this.title = "", this.titleText = "", this.actionIcon = void 0, this.actionLabel = void 0, this.position = "top", this.popoverFixed = !1, this.removeMaxHeight = !1, this.fullWidth = !1, this.hideHeader = !1, this.tooltipFixed = !1, this.hideTooltip = !1, this.forceViewport = !1, this.tooltipPosition = "top", this._popperInstance = null, this._parent = null, this._disableClickOutside = !0, this._isFirstUpdate = !0, this._hasFooterSlot = !1, this.availableHeight = void 0, this.hasMaxHeight = !1, this.hasWidget = !1, this._resizeObserver = null, this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [h(_), h(m), h(f), h(b)];
  }
  connectedCallback() {
    super.connectedCallback(), this._handleConnectedCallback();
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.mutationObserver.disconnect(), this.visibleObserver.disconnect(), this.maxHeightObserver.disconnect(), this._popperInstance && (this._popperInstance.destroy(), this._popperInstance = null), this._parent && (this._parentMousedownHandler && (this._parent.removeEventListener("mousedown", this._parentMousedownHandler), this._parentMousedownHandler = null), this._parentKeydownHandler && (this._parent.removeEventListener("keydown", this._parentKeydownHandler), this._parentKeydownHandler = null));
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  _handleOutsideClick(e) {
    this._checkClickOutside(e);
  }
  _handleConnectedCallback() {
    if (requestAnimationFrame(() => {
      this.hasWidget = !!this.querySelector("dss-widget");
    }), this._isFirstUpdate) return;
    const e = this.style.position;
    e !== "absolute" && e !== "fixed" && e !== "relative" && (this._popperInstance ? this._popperInstance.update() : this._initPopover());
  }
  _handleAction() {
    this.dispatchEvent(new CustomEvent("onAction", { bubbles: !0, composed: !0 }));
  }
  _handleClose() {
    this._closePopover();
  }
  _checkClickOutside(e) {
    if (this.disableParentClick && this._disableClickOutside)
      return;
    const t = e.composedPath(), s = t.includes(this._parent);
    !t.includes(this) && !s && this._closePopover();
  }
  _closePopover() {
    setTimeout(() => {
      this.classList.contains("visible") && (this.classList.remove("visible"), this.open = !1, this._removeScrollListener(), this._removeDropdownListener(), this.dispatchEvent(new CustomEvent("onClose", { bubbles: !1, composed: !1 })));
    }, 0);
  }
  createPopperInstance(e) {
    var s;
    this._parent = e;
    const t = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-popover-arrow");
    this._popperInstance = u(e, this, {
      placement: this.variant !== "filter" ? this.position : "bottom",
      strategy: this.popoverFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "arrow",
          options: {
            element: t
          }
        },
        {
          name: "offset",
          options: {
            offset: [0, 16]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        },
        {
          name: "flip",
          enabled: this.variant !== "filter"
        }
      ],
      onFirstUpdate: (i) => {
        this._propagatePlacement(i.placement);
      }
    }), this.visibleObserver.observe(e), this._parentMousedownHandler = () => {
      this._popoverParentListener();
    }, this._parentKeydownHandler = (i) => {
      i.stopPropagation(), i.key === "Enter" || i.key === " " ? this._popoverParentListener() : i.key === "Escape" && this._closePopover();
    }, this._parent.addEventListener("mousedown", this._parentMousedownHandler), this._parent.addEventListener("keydown", this._parentKeydownHandler);
  }
  _popoverParentListener() {
    !this.open && !this.disableParentClick && (this.open = !0, this.classList.add("visible"), this._disableClickOutside = !1, this._popperInstance && (this._popperInstance.update(), this._checkMaxHeight(), this._handleScroll()), this._addDropdownListener());
  }
  _propagatePlacement(e) {
    const t = this.renderRoot.querySelector(".dss-popover");
    t && t.setAttribute("data-popper-placement", e);
  }
  _checkMaxHeight() {
    var p, l;
    if (this.variant !== "filter") return;
    const e = (p = this.shadowRoot) == null ? void 0 : p.querySelector(".dss-popover");
    if (!e) return;
    const t = e.getBoundingClientRect();
    let s = window.innerHeight - t.top;
    s = s - 24, s < 180 && (s = 180);
    const i = (l = this.shadowRoot) == null ? void 0 : l.querySelector(".dss-popover-box");
    i && (i.style.maxHeight = `${s}px`, this.availableHeight = s);
  }
  _handleScroll() {
    var t, s;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-popover-content");
    if (e && (e.addEventListener("scroll", this._checkPopoverScroll.bind(this, e)), this._resizeObserver = new ResizeObserver(this._checkPopoverScroll.bind(this, e)).observe(e), e.scrollHeight > e.clientHeight && e.scrollTop === 0)) {
      const i = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-popover-footer-wrapper");
      i == null || i.classList.add("dss-popover-footer-wrapper--scrolled");
    }
  }
  _removeScrollListener() {
    var t, s;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-popover-content");
    e.removeEventListener("scroll", this._checkPopoverScroll.bind(this, e)), (s = this._resizeObserver) == null || s.disconnect(), this._resizeObserver = null;
  }
  _checkPopoverScroll(e) {
    var i, p;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-popover-header"), s = (p = this.shadowRoot) == null ? void 0 : p.querySelector(".dss-popover-footer-wrapper");
    e.scrollTop > 0 ? t == null || t.classList.add("dss-popover-header--scrolled") : t == null || t.classList.remove("dss-popover-header--scrolled"), e.scrollHeight - e.scrollTop !== e.clientHeight ? s == null || s.classList.add("dss-popover-footer-wrapper--scrolled") : s == null || s.classList.remove("dss-popover-footer-wrapper--scrolled");
  }
  _initPopover() {
    const e = this.assignedSlot;
    this._parent = e ? e.parentElement : this.parentElement, this._parent && this.createPopperInstance(this._parent), this.mutationObserver.observe(this, this.observerConfig), this.maxHeightObserver.observe(this), setTimeout(() => {
      this.open && (this.classList.add("visible"), this._popperInstance.update(), this._checkMaxHeight(), this._handleScroll(), this.requestUpdate(), this._addDropdownListener());
    }, 0);
  }
  async firstUpdated() {
    var t;
    await this.updateComplete, this.classList.add("animation-enabled");
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="footer"]');
    if (e) {
      const s = e.assignedElements({ flatten: !0 });
      this._hasFooterSlot = s.length > 0;
    }
    this._initPopover(), this._isFirstUpdate = !1;
  }
  updated(e) {
    super.updated(e), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    }), e.has("position") && this._popperInstance && this._popperInstance.setOptions({
      placement: this.position
    }), e.has("open") && (this.open ? (this.classList.add("visible"), this._popperInstance && this._popperInstance.update(), this._addDropdownListener(), this.disableParentClick && (this._checkMaxHeight(), this._handleScroll(), setTimeout(() => {
      this._disableClickOutside = !1;
    }, 100))) : (this.classList.remove("visible"), this._removeDropdownListener(), this.disableParentClick && (this._disableClickOutside = !0)));
  }
  // Función que puedes definir si quieres manejar cambios de altura
  _onHeightChange(e) {
    this.availableHeight && (this.hasMaxHeight = e >= this.availableHeight);
  }
  render() {
    return y(this);
  }
}
o([
  n(a)
], r.prototype, "open");
o([
  n({ type: String })
], r.prototype, "variant");
o([
  n(a)
], r.prototype, "hideCloseIcon");
o([
  n(a)
], r.prototype, "disableParentClick");
o([
  n({ type: String })
], r.prototype, "title");
o([
  n({ type: String })
], r.prototype, "titleText");
o([
  n({ type: String })
], r.prototype, "actionIcon");
o([
  n({ type: String })
], r.prototype, "actionLabel");
o([
  n({ type: String })
], r.prototype, "position");
o([
  n(a)
], r.prototype, "popoverFixed");
o([
  n(a)
], r.prototype, "removeMaxHeight");
o([
  n(a)
], r.prototype, "fullWidth");
o([
  n(a)
], r.prototype, "hideHeader");
o([
  n(a)
], r.prototype, "tooltipFixed");
o([
  n(a)
], r.prototype, "hideTooltip");
o([
  n(a)
], r.prototype, "forceViewport");
o([
  n({ type: String })
], r.prototype, "tooltipPosition");
o([
  c()
], r.prototype, "availableHeight");
o([
  c()
], r.prototype, "hasMaxHeight");
o([
  c()
], r.prototype, "hasWidget");
export {
  r as Popover
};
//# sourceMappingURL=popover.js.map
