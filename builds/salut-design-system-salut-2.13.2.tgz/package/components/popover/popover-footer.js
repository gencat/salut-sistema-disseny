import { LitElement as e, css as s, html as t } from "lit";
class l extends e {
  static get styles() {
    return [
      s`
        .dss-popover-footer {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: var(--dss-spacing-xs);
          background-color: var(--color-white);
        }

        ::slotted(div) {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-xs);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    return t`
      <div class="dss-popover-footer">
        <slot></slot>
      </div>
    `;
  }
}
export {
  l as PopoverFooter
};
//# sourceMappingURL=popover-footer.js.map
