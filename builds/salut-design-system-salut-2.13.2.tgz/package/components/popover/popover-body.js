import { LitElement as e, css as o, html as t } from "lit";
class l extends e {
  static get styles() {
    return [
      o`
        .dss-popover-body {
          flex: 1 1 auto;
          min-height: 0;
          display: flex;
          flex-direction: column;
          padding: 0 var(--dss-spacing-md);
          gap: var(--dss-spacing-xs);
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-regular);
          color: var(--color-neutral-500);
        }

        ::slotted(p) {
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-regular);
          color: var(--color-neutral-900);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    return t`
      <div class="dss-popover-body">
        <slot></slot>
      </div>
    `;
  }
}
export {
  l as PopoverBody
};
//# sourceMappingURL=popover-body.js.map
