import { nothing as r } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as l, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const i = l`dss-icon-button${d(t())}`, $ = (s) => e`
  <div
    class=${o({
  "dss-popover": !0,
  "dss-popover--filter": s.variant === "filter",
  "dss-popover--open": !!s.open,
  "dss-popover--has-widget": s.hasWidget,
  "dss-popover--max-height": s.hasMaxHeight,
  "dss-popover--hide-header": s.hideHeader,
  "dss-popover--empty-footer": !s._hasFooterSlot,
  "dss-popover--header-empty": s.titleText === "" && !!s.hideCloseIcon,
  "dss-popover--remove-max-height": s.removeMaxHeight,
  "dss-popover--full-width": s.fullWidth,
  [`dss-popover--${s.position}`]: !!s.position
})}
  >
    <div class="dss-popover-box">
      ${s.hideHeader ? r : e`
        <div class="dss-popover-header">
          <div class="dss-popover-header-box">
            <div class="dss-popover-header__title">${s.titleText}</div>
            ${s.actionIcon ? e`
                  <${i}
                    icon="${s.actionIcon}"
                    label="${s.actionLabel}"
                    size="md"
                    variant="primary"
                    ?tooltipFixed=${s.tooltipFixed}
                    ?hideTooltip=${s.hideTooltip}
                    tooltipPosition="${s.tooltipPosition}"
                    ?forceViewport="${s.forceViewport}"
                    @onClick="${s._handleAction}"
                  ></${i}>
                ` : null}
            ${s.hideCloseIcon ? null : e`
                  <${i}
                    icon="close"
                    label="Tancar"
                    size="md"
                    variant="default"
                    hideTooltip
                    @onClick="${s._handleClose}"
                  ></${i}>
                `}
          </div>
        </div>
      `}
      <div 
        class=${o({
  "dss-popover-content": !0,
  "dss-popover-content--max-height": s.hasMaxHeight
})}
      >
        <slot name="body" class="dss-scrollable-content"></slot>
        <slot name="item-list"></slot>
      </div>
      ${s.variant === "filter" ? e`
        <div class="dss-popover-footer-wrapper">
          <slot name="footer"></slot>
        </div>
        ` : null}
    </div>
    <div class="dss-popover-arrow" data-popper-arrow></div>
  </div>
`;
export {
  $ as popoverTemplate
};
//# sourceMappingURL=popover.template.js.map
