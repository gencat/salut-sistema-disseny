import { nothing as d } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as r, literal as n, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { checkTextTruncate as t, checkWebkitTruncate as _ } from "../../utils/helpers.js";
const p = n`dss-icon-button${r(l())}`, $ = n`dss-button${r(l())}`, a = n`dss-icon${r(l())}`, u = n`dss-badge${r(l())}`, i = n`dss-tooltip${r(l())}`, m = (s) => e`
  <div
    class=${o({
  "dss-header-menu-patient": !0,
  "dss-header-menu-patient--jcef": s.jcef,
  [`dss-header-menu-patient--${s.variant}`]: !!s.variant
})}
  >
    <div class="dss-header-menu-patient-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-patient-details">
      <div class="dss-header-menu-patient-details__name">
        ${s.name}
      </div>
      <div class="dss-header-menu-patient-details__info">
        ${s.cip ? e`
            <span class="dss-header-menu-patient-details__info-label dss-header-menu-patient-details__info-label--cip">
              ${s.cip}
            </span>
            <span class="divider-v divider-v--cip"></span>
          ` : null}
        ${s.age ? e`
            <span class="dss-header-menu-patient-details__info-label">
              ${s.age}
            </span>
            <span class="divider-v"></span>
          ` : null}
        ${s.gender ? e`
            <span class="dss-header-menu-patient-details__info-label">
              ${s.gender}
            </span>
          ` : null}
      </div>
    </div>
    <${p}
      class="dss-header-menu-patient__toggle-action"
      icon="${s._toggleIcon}"
      label="${s._toggleLabel}"
      variant="primary"
      @onClick="${s._toggleDropdown}"
      ?disabled=${s.disabled}
      ariaLabel="${s._toggleLabel} menú pacient"
      ariaExpanded="${s._showDropdown ? "true" : "false"}"
      hideTooltip
    ></${p}>
    ${s._showDropdown ? e`
          <div
            id="menu-patient"
            class=${o({
  "dss-header-menu-patient-dropdown": !0,
  "dss-header-menu-patient-dropdown--expanded": !!s._showDropdown
})}
          >
            <div class="dss-header-menu-patient-dropdown__info">
              <div class="dss-header-menu-patient-dropdown__title">
                ${s.infoLabel}
              </div>

              <div class="dss-header-menu-patient-dropdown__content">
                <div class="dss-header-menu-patient-dropdown__subtitle">
                  ${s.name}
                </div>

                ${s.cip ? e`
                  <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--cip">
                    <span class="dss-header-menu-patient-dropdown__description__cip">
                      ${s.cip}
                    </span>
                    ${s.hideCopyCip ? d : e`
                        <${p}
                          icon="content_copy"
                          size="sm"
                          label="Copiar CIP"
                          variant="primary"
                          @onClick="${s._handleCIPClick}"
                          ?disabled=${s.disabled}
                          ?tooltipFixed=${s.tooltipFixed}
                        ></${p}>
                      `}
                   
                  </div>
                  ` : d}

                ${s.age ? e`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="person" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.age}
                      </div>
                    </div>
                  ` : d}

                ${s.gender ? e`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="${s._getGenderIcon()}" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.gender}
                      </div>
                    </div>
                  ` : d}

                ${s.phoneMain ? e`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.phoneMain}
                      </div>
                    </div>
                  ` : d}

                ${s.phoneAlt ? e`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.phoneAlt}
                      </div>
                    </div>
                  ` : d}

                ${s.mail ? e`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="mail" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                        
                        ${s.mail}
                        <${i} 
                          class="description-tooltip" 
                          aria-hidden="true" 
                          interactive
                          ?tooltipFixed=${s.tooltipFixed}      
                        >
                          ${s.mail}
                        </${i}>
                      </div>
                    </div>
                  ` : d}

                ${s.address ? e`
                    <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--address">
                      <${a} class="address-icon" icon="home_work" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description dss-header-menu-patient-dropdown__description--address" @mouseenter=${_}>
                        <a class="dss-header-menu-patient-dropdown__link" href="${s.addressURL}" target="_blank" rel="noopener">
                          ${s.address}
                        </a>
                        <${i} 
                          class="description-tooltip" 
                          aria-hidden="true" 
                          interactive
                          ?tooltipFixed=${s.tooltipFixed}
                        >
                          ${s.address}
                        </${i}>
                      </div>
                    </div>
                  ` : d}

                ${s.assignments ? e`
                  <div class="dss-header-menu-patient-dropdown__assignments">
                    <div class="dss-header-menu-patient-dropdown__title dss-header-menu-patient-dropdown__title--assigned">
                      ${s.assignedLabel}
                    </div>

                    ${s.assignments.uab ? e`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAB</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${s.assignments.uab}
                          <${i} 
                            class="description-tooltip" 
                            aria-hidden="true" 
                            interactive
                            ?tooltipFixed=${s.tooltipFixed}
                          >
                            ${s.assignments.uab}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${s.assignments.ui ? e`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UI</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${s.assignments.ui}
                          <${i} 
                            class="description-tooltip" 
                            aria-hidden="true" 
                            interactive
                            ?tooltipFixed=${s.tooltipFixed}
                          >
                            ${s.assignments.ui}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${s.assignments.uas ? e`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAS</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${s.assignments.uas}
                          <${i} 
                            class="description-tooltip" 
                            aria-hidden="true" 
                            interactive
                            ?tooltipFixed=${s.tooltipFixed}
                          >
                            ${s.assignments.uas}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${s.assignments.center ? e`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${s.assignments.center}
                          <${i} 
                            class="description-tooltip" 
                            aria-hidden="true" 
                            interactive
                            ?tooltipFixed=${s.tooltipFixed}
                          >
                            ${s.assignments.center}
                          </${i}>
                        </div>
                        ${s.assignments.up ? e`
                          <${u} size="sm" state="info" outlined text="${s.upLabel}">
                            <${i}
                              ?tooltipFixed=${s.tooltipFixed}
                              slot="tooltip"
                             > 
                              ${s.upMessage} 
                            </${i}>
                          </${u}>
                        ` : d}
                      </div>
                      ` : d} 
                  </div>
                ` : d}
              </div>
            </div>

            ${!s.hideViewDetails || s.edit ? e`
                <div class="dss-header-menu-patient-dropdown__actions">
                  ${s.hideViewDetails ? d : e`
                      <${$}
                        variant="link"
                        size="md"
                        label="${s.detailsLabel}"
                        fullWidth
                        @click="${s._handleViewDetails}"
                      </${$}>
                    `}
                  ${s.edit ? e`
                      <${$}
                        variant="link"
                        size="md"
                        label="${s.editLabel}"
                        icon="open_in_new" 
                        iconPosition="right"
                        fullWidth
                        @click="${s._handleEdit}"
                      </${$}>
                    ` : d}
                </div>` : d}

          </div>
        ` : null}
  </div>
`;
export {
  m as headerMenuPatientTemplate
};
//# sourceMappingURL=header-menu-patient.template.js.map
