import { LitElement as h, unsafeCSS as d } from "lit";
import { property as e } from "lit/decorators.js";
import c from "../../foundations/icon/icon.style.css.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import g from "./header-menu-patient.style.css.js";
import { headerMenuPatientTemplate as u } from "./header-menu-patient.template.js";
var m = Object.defineProperty, t = (r, i, s, f) => {
  for (var n = void 0, a = r.length - 1, l; a >= 0; a--)
    (l = r[a]) && (n = l(i, s, n) || n);
  return n && m(i, s, n), n;
};
class o extends h {
  constructor() {
    super(), this.disabled = !1, this.variant = "default", this.name = void 0, this.cip = void 0, this.age = void 0, this.gender = void 0, this.phoneMain = void 0, this.phoneAlt = void 0, this.mail = void 0, this.address = void 0, this.addressURL = "#", this.infoLabel = "Dades del pacient", this.assignedLabel = "Professionals assignats", this.detailsLabel = "Veure més detalls", this.editLabel = "Editar usuari", this.hideViewDetails = !1, this.jcef = !1, this.edit = !1, this.assignments = void 0, this.hideCopyCip = !1, this.upLabel = "UP", this.upMessage = "Usuari desplaçat: no pertany a l’equip d’atenció primària", this.tooltipFixed = !1, this.tooltipPosition = "top", this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Obrir", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [d(y), d(c), d(g)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Tancar" : "Obrir", this.requestUpdate();
  }
  _handleViewDetails() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("onViewDetails", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _handleEdit() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("onEdit", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _handleCIPClick(i) {
    this._handleCopyCIP(i), this._toggleDropdown();
  }
  _handleCopyCIP(i) {
    i.stopPropagation(), this.cip && (navigator.clipboard.writeText(this.cip), this.dispatchEvent(
      new CustomEvent("onCopyCIP", {
        detail: { text: this.cip },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _getGenderIcon() {
    var s;
    return ((s = this.gender) == null ? void 0 : s.toLowerCase()) === "femení" ? "female" : "male";
  }
  _handleDocumentClick(i) {
    this._clickedOutside(this, i);
  }
  _clickedOutside(i, s) {
    s.composedPath().includes(i) || this._showDropdown && this._toggleDropdown();
  }
  render() {
    return u(this);
  }
}
t([
  e(p)
], o.prototype, "disabled");
t([
  e({ type: String })
], o.prototype, "variant");
t([
  e({ type: String })
], o.prototype, "name");
t([
  e({ type: String })
], o.prototype, "cip");
t([
  e({ type: String })
], o.prototype, "age");
t([
  e({ type: String })
], o.prototype, "gender");
t([
  e({ type: String })
], o.prototype, "phoneMain");
t([
  e({ type: String })
], o.prototype, "phoneAlt");
t([
  e({ type: String })
], o.prototype, "mail");
t([
  e({ type: String })
], o.prototype, "address");
t([
  e({ type: String })
], o.prototype, "addressURL");
t([
  e({ type: String })
], o.prototype, "infoLabel");
t([
  e({ type: String })
], o.prototype, "assignedLabel");
t([
  e({ type: String })
], o.prototype, "detailsLabel");
t([
  e({ type: String })
], o.prototype, "editLabel");
t([
  e(p)
], o.prototype, "hideViewDetails");
t([
  e(p)
], o.prototype, "jcef");
t([
  e(p)
], o.prototype, "edit");
t([
  e({ type: Array })
], o.prototype, "assignments");
t([
  e(p)
], o.prototype, "hideCopyCip");
t([
  e({ type: String })
], o.prototype, "upLabel");
t([
  e({ type: String })
], o.prototype, "upMessage");
t([
  e(p)
], o.prototype, "tooltipFixed");
t([
  e({ type: String })
], o.prototype, "tooltipPosition");
export {
  o as HeaderMenuPatient
};
//# sourceMappingURL=header-menu-patient.js.map
