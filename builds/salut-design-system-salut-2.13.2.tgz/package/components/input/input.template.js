import { nothing as l } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as r, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const x = r`dss-icon${a(e())}`, u = r`dss-icon-button${a(e())}`, S = r`dss-tooltip${a(e())}`, O = (i) => {
  var p, t, _, $, n, b, v, h, f, g, w, y;
  const T = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": (p = i._input) == null ? void 0 : p.required,
    "dss-input-wrapper--disabled": (t = i._input) == null ? void 0 : t.disabled,
    [`dss-input-wrapper--${i.inputSize}`]: !!i.inputSize,
    "dss-input-wrapper--no-label": !i._labelSlot
  }, k = {
    "dss-input-group": !0,
    [`dss-input-group--${i.inputSize}`]: !!i.inputSize,
    "dss-input-group--invalid": i._invalid || !i._inputValidity,
    "dss-input-group--required": (_ = i._input) == null ? void 0 : _.required,
    "dss-input-group--disabled": ($ = i._input) == null ? void 0 : $.disabled,
    "dss-input-group--focused": ((n = i._input) == null ? void 0 : n.value) || i._placeholder || i._isFocused,
    "dss-input-group--read-only": (b = i._input) == null ? void 0 : b.readOnly,
    "dss-input-group--no-label": !i._labelSlot,
    "dss-input-group--numeric": i._isTypeNumeric,
    "dss-input-group--no-min-width": i._removeMinWidth,
    "dss-input-group--read-only-empty": ((v = i._input) == null ? void 0 : v.readOnly) && i._placeholder === "" && !((h = i._input) != null && h.value)
  }, z = {
    "dss-input-help": !0,
    "dss-input-help--invalid": i._invalid,
    "dss-input-help--disabled": (f = i._input) == null ? void 0 : f.disabled
  };
  return s`
    <div class="${d(T)}">
  
      ${i.inputSize === "sm" ? s`
        <div class="dss-wrapper-label">
          <slot name="label" @click=${i._focusInput}></slot>
        </div>
        ` : l}

      <div class="${d(k)}">

        ${i.icon && i.icon !== "" ? s`
          <${x} icon="${i.icon}" class="dss-input-icon"></${x}>
          ` : l}

        <div class="dss-input-field">
          ${i.inputSize !== "sm" ? s`
            <slot name="label" @click=${i._focusInput}></slot>
            ` : l}

          ${i.inputPrefix ? s`
            <span class="dss-input-inputPrefix">${i.inputPrefix}</span>
          ` : l}

          <slot name="input"
            @click=${i._handleClick}
            @input=${i._handleInput}
            @focusin=${i._handleFocusIn}
            @focusout=${i._handleFocusOut}
          ></slot>
        </div>

        ${i.unit ? s`
          <div class="dss-input-unit">${i.unit}</div>
          ` : l}

        ${i._isTypeNumeric ? s`
              <div class="dss-input-numeric-buttons">
                <${u}
                  label="Augmentar"
                  hideTooltip
                  size="sm"
                  icon="keyboard_arrow_up"
                  variant="primary"
                  ?disabled=${i._input.disabled || i._input.readOnly}
                  disableTabindex
                  @onClick=${i._stepUp}
                  @mousedown=${() => i._onHold("up")}
                  @mouseup=${i._stopHold}
                  @mouseleave=${i._stopHold}
                ></${u}>
                <${u}
                  label="Disminuir"
                  hideTooltip
                  size="sm"
                  icon="keyboard_arrow_down"
                  variant="primary"
                  ?disabled=${i._input.disabled || i._input.readOnly}
                  disableTabindex
                  @onClick=${i._stepDown}
                  @mousedown=${() => i._onHold("down")}
                  @mouseup=${i._stopHold}
                  @mouseleave=${i._stopHold}
                ></${u}>
              </div>
            ` : null}

        ${i._isTruncated ? s`
            <${S}>${(g = i._input) == null ? void 0 : g.value}</${S}>
          ` : null}
      </div>

      ${i._helpText ? s`
            <div class="${d(z)}">
              <span>${i._helpText}</span>
              ${i._maxLength ? s`<span>
                    ${(y = (w = i._input) == null ? void 0 : w.value) == null ? void 0 : y.length}/${i._maxLength}
                  </span>` : null}
            </div>
          ` : null}
    </div>
  `;
};
export {
  O as template
};
//# sourceMappingURL=input.template.js.map
