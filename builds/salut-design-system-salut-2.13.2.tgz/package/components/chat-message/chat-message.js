import { LitElement as y, unsafeCSS as m } from "lit";
import { property as t } from "lit/decorators.js";
import g from "../../foundations/icon/icon.style.css.js";
import S from "./chat-message.style.css.js";
import { template as h } from "./chat-message.template.js";
var v = Object.defineProperty, e = (p, s, i, u) => {
  for (var a = void 0, o = p.length - 1, n; o >= 0; o--)
    (n = p[o]) && (a = n(s, i, a) || a);
  return a && v(s, i, a), a;
};
class r extends y {
  constructor() {
    super(...arguments), this.username = "", this.message = "", this.date = "", this.who = "", this.avatarName = "", this.avatarSurname = "", this.avatarImageUrl = "", this.avatarSize = "md";
  }
  static get styles() {
    return [m(g), m(S)];
  }
  render() {
    return h(this);
  }
}
e([
  t({ type: String })
], r.prototype, "username");
e([
  t({ type: String })
], r.prototype, "message");
e([
  t({ type: String })
], r.prototype, "date");
e([
  t({ type: String })
], r.prototype, "who");
e([
  t({ type: String })
], r.prototype, "avatarName");
e([
  t({ type: String })
], r.prototype, "avatarSurname");
e([
  t({ type: String })
], r.prototype, "avatarImageUrl");
e([
  t({ type: String })
], r.prototype, "avatarSize");
export {
  r as ChatMessage
};
//# sourceMappingURL=chat-message.js.map
