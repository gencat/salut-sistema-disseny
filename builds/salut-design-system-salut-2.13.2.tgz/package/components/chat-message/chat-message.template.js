import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as m, literal as l, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as g } from "../../api/custom-element-scope.js";
const e = l`dss-avatar${m(g())}`, u = (a) => {
  const r = {
    "dss-chat-message--patient": a.who === "patient",
    "dss-chat-message--doctor": a.who === "doctor"
  }, i = () => s`
      <${e}
        .size="${a.avatarSize}"
        .imageUrl="${a.avatarImageUrl}"
      >
      </${e}>
    `, v = () => s`
      <${e}
        .size="${a.avatarSize}"
        .name="${a.avatarName}"
        .surname="${a.avatarSurname}"
      >
      </${e}>
    `, t = () => s` ${a.avatarImageUrl ? s`${i()}` : s`${v()}`}`;
  return s`
    <div class="chat-message ${d(r)}">
      <div class="chat-message-avatar">
        ${a.who === "patient" ? s`${t()}` : null}
      </div>

      <div class="chat-message-wrapper">
        <div class="chat-message-wrapper__message">
          <div class="message-username">${a.username}</div>
          <div class="message-text">${a.message}</div>
          <div class="message-attachments">
            <slot name="attachments"></slot>
          </div>
        </div>
        <div class="chat-message-wrapper__date">${a.date}</div>
      </div>

      <div class="chat-message-avatar chat-message-avatar--YYY">
        ${a.who === "doctor" ? s`${t()}` : null}
      </div>
    </div>
  `;
};
export {
  u as template
};
//# sourceMappingURL=chat-message.template.js.map
