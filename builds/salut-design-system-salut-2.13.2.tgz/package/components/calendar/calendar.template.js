import { classMap as M } from "lit/directives/class-map.js";
import { unsafeStatic as o, literal as u, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import { MONTH as x, WEEK as A } from "./calendar.js";
const D = u`dss-timepicker${o($())}`, n = u`dss-icon${o($())}`, s = u`dss-icon-button${o($())}`, _ = u`dss-button${o($())}`, H = (e) => {
  var h, b, f, g;
  return d`
  <div
        class="calendar__container"
        @keydown="${e._handleCalendarKeydown}"
      >
        <div class="calendar__content">
          <header class="calendar__header">
            <div class="calendar__header-item calendar__header-selector">
              <div
                id="firstCalendarElement"
                class="calendar__header-item calendar__header-item--click calendar__header-month"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderMonthKeyDown}"
                @click="${e._toggleMonthSelector}"
                aria-label="selecciona el mes, actualment ${x[e._currMonth]}"
              >
                ${x[e._currMonth]}
                <${n} icon="expand_more" size="sm"></${n}>
              </div>
              <div
                class="calendar__header-item calendar__header-item--click calendar__header-year"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderYearKeyDown}"
                @click=${e._toggleYearSelector}
                aria-label="selecciona l'any, actualment ${e._currYear}"
              >
                ${e._currYear}
                <${n} icon="expand_more" size="sm"></${n}>
              </div>
            </div>
            <div class="calendar__header-item calendar__header-buttons">
              <${s} hideTooltip variant="primary" icon="chevron_left" label="Anterior" @click=${e._prev}
                ?disabled=${e._currMonth === ((h = e._minDate) == null ? void 0 : h.getMonth()) && e._currYear === ((b = e._minDate) == null ? void 0 : b.getFullYear())}>
              </${s}>
              <${s} hideTooltip variant="primary" icon="chevron_right" label="Següent" @click=${e._next}
                ?disabled=${e._currMonth === ((f = e._minDate) == null ? void 0 : f.getMonth()) && e._currYear === ((g = e._minDate) == null ? void 0 : g.getFullYear())}>
              </${s}>
            </div>
          </header>

          <div class="calendar__days-content">
            <ul class="calendar__week-names">
              ${A.map((t) => d`<li>${t}</li>`)}
            </ul>
            <div
              class="calendar__days"
              @mouseleave=${e._removeRangeOverDate}
            >
              ${e._days.map((t) => {
    const S = {
      "calendar__day-item--active": e._isToday(t),
      "calendar__day-item--weekend": e._isWeekend(t),
      "calendar__day-item--selected": e._isSelected(t),
      [`calendar__day-item--${e._getCustomType(t)}`]: !!e._getCustomType(t),
      "calendar__day-item--range": e._isBetweenRange(t) || e._isBetweenRangeOnMouseOver(t),
      "calendar__day-item--selected-range-start": e._isSelectedRangeStart(t),
      "calendar__day-item--selected-range-end": e._isSelectedRangeEnd(t) || e._isOverRangeDate(t),
      "calendar__day-item--range-enabled": e._range
    }, T = (a) => {
      const r = a.target;
      if (a.key === "ArrowUp") {
        a.preventDefault();
        const l = m(r, -7);
        l ? l.focus() : y();
      }
      if (a.key === "ArrowDown") {
        a.preventDefault();
        const l = m(r, 7);
        l ? l.focus() : k();
      }
      if (a.key === "ArrowRight") {
        a.preventDefault();
        const l = r.nextElementSibling;
        l ? l.focus() : k();
      }
      if (a.key === "ArrowLeft") {
        a.preventDefault();
        const l = R(r);
        l ? l.focus() : y();
      }
    }, y = () => {
      e._prev(), setTimeout(() => {
        var i;
        const a = (i = e.shadowRoot) == null ? void 0 : i.querySelectorAll(".calendar__day-item"), r = Array.from(a).filter((c) => !c.disabled), l = r[r.length - 1];
        l && (l.setAttribute("tabindex", "0"), l.focus());
      }, 0);
    }, k = () => {
      e._next(), setTimeout(() => {
        var i;
        const a = (i = e.shadowRoot) == null ? void 0 : i.querySelectorAll(".calendar__day-item"), l = Array.from(a).filter((c) => !c.disabled)[0];
        l && (l.setAttribute("tabindex", "0"), l.focus());
      }, 0);
    }, R = (a) => {
      let r = a == null ? void 0 : a.previousElementSibling;
      for (; r; ) {
        if (!r.classList.contains("calendar__day-item")) {
          r = r.previousElementSibling;
          continue;
        }
        if (!r.disabled)
          return r;
        r = r.previousElementSibling;
      }
      return null;
    }, m = (a, r) => {
      var w;
      const i = Array.from(
        ((w = a.closest(".calendar__days")) == null ? void 0 : w.querySelectorAll(".calendar__day-item")) || []
      ).filter((B) => !B.disabled), v = i.indexOf(a) + r;
      return v < 0 || v >= i.length ? null : i[v];
    };
    return d`
                  <button
                    tabindex="${e._isFocusable(t) ? 0 : -1}"
                    class="calendar__day-item ${M(S)}"
                    @click=${() => e._selectDate(t)}
                    @mouseover=${() => e._selectRangeOverDate(t)}
                    @focus=${() => e._selectRangeOverDate(t)}
                    ?disabled=${e._isInactive(t)}
                    @keydown="${T}"
                  >
                    ${t || null}
                  </button>
                `;
  })}
            </div>
          </div>
        </div>
        ${e._showMonthSelector ? d`
              <div class="calendar-selector calendar-selector--month">
                <div class="calendar-selector-title">Selecciona un mes</div>
                <div class="calendar-selector-options">
                  ${e._generateMonthsOptions()}
                </div>
              </div>
            ` : null}
        ${e._showYearSelector ? d`
              <div class="calendar-selector calendar-selector--year">
                <div
                  class="calendar-selector-title calendar-selector-title--years"
                >
                  <div class="calendar-selector-title__years">
                    ${e._yearsRangeStart} - ${e._yearsRangeEnd}
                  </div>
                  <div class="calendar-selector-title__actions">
                    <${s}
                      hideTooltip
                      variant="primary" 
                      label="Anys anteriors"
                      icon="chevron_left"
                      @click=${e._onYearRangeStepDown}
                    ></${s}>
                    <${s}
                      hideTooltip
                      variant="primary" 
                      label="Anys posteriors"
                      icon="chevron_right"
                      @click=${e._onYearRangeStepUp}
                    ></${s}>
                  </div>
                </div>
                <div
                  class="calendar-selector-options calendar-selector-options--4col"
                >
                  ${e._generateYearsRangeOptions()}
                </div>
              </div>
            ` : null}
        ${e._showTime ? d`
              <div class="dss-datepicker__timepicker">
                <${D}
                  .dropdown="${e._timepicker}"
                  .customTimeListOptions=${e._customTimeListOptions}
                  .minutesRange=${e._minutesRange}
                  .minHour=${e._minHour}
                  .maxHour=${e._maxHour}
                  @onTimepickerChange=${e._onSelectTime}
                  .value="${e._timepickerValue}"
                >
                  <label slot="label" for="innerTimepicker"
                    >${e._timepickerLabel}</label
                  >
                  <input
                    slot="input"
                    id="innerTimepicker"
                    type="text"
                    maxlength="5"
                    .value="${e._timepickerValue}"
                  />
                </${D}>
              </div>
            ` : null}
        ${e._showButtons || e._showTime ? d`
              <div class="calendar__content calendar__content--buttons">
                <div class="calendar__buttons">
                  <${_}
                    variant="secondary"
                    label=${e._leftLabel}
                    @click=${e._onCancel}
                  >
                  </${_}>
                  <${_}
                    variant="primary"
                    label=${e._rightLabel}

                    @click=${e._onAccept}
                    ?disabled=${e._validateSelectedDate()}
                  >
                  </${_}>
                </div>
              </div>
            ` : null}
      </div>

`;
};
export {
  H as template
};
//# sourceMappingURL=calendar.template.js.map
