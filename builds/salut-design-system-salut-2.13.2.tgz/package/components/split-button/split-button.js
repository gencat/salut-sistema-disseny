import { LitElement as c, unsafeCSS as h } from "lit";
import { property as s } from "lit/decorators.js";
import { booleanType as a } from "../../utils/property-types.js";
import u from "../../foundations/icon/icon.style.css.js";
import _ from "../button/button.style.css.js";
import m from "./split-button.style.css.js";
import { splitButtonTemplate as y } from "./split-button.template.js";
var f = Object.defineProperty, b = Object.getOwnPropertyDescriptor, i = (l, t, e, r) => {
  for (var n = r > 1 ? void 0 : r ? b(t, e) : t, p = l.length - 1, d; p >= 0; p--)
    (d = l[p]) && (n = (r ? d(t, e, n) : d(n)) || n);
  return r && n && f(t, e, n), n;
};
class o extends c {
  // private _handleActionMenuClickBound: (event: Event) => void;
  constructor() {
    super(), this.secondaryLabelOpen = "Obrir", this.secondaryLabelClose = "Tamcar", this.icon = void 0, this.iconFill = !1, this.tooltipFixed = !1, this._iconSize = "md", this._size = "lg", this._iconClose = "expand_more", this._iconOpen = "expand_less", this._variant = "primary", this._text = "", this._disabled = !1, this._isOpen = !1, this._dropdownPosition = "bottom-right", this._hasMenu = !1, this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [h(u), h(_), h(m)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  get _actionMenu() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="menu"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set iconClose(t) {
    const e = this._iconClose;
    this._iconClose = t, this.requestUpdate("iconClose", e);
  }
  get iconClose() {
    return this._iconClose;
  }
  set iconOpen(t) {
    const e = this._iconOpen;
    this._iconOpen = t, this.requestUpdate("iconOpen", e);
  }
  get iconOpen() {
    return this._iconOpen;
  }
  set variant(t) {
    const e = this._variant;
    this._variant = t, this.requestUpdate("variant", e);
  }
  get variant() {
    return this._variant;
  }
  set text(t) {
    const e = this._text;
    this._text = t, this.requestUpdate("text", e);
  }
  get text() {
    return this._text;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set isOpen(t) {
    const e = this._isOpen;
    this._isOpen = t, this.requestUpdate("disabled", e);
  }
  get isOpen() {
    return this._isOpen;
  }
  set size(t) {
    const e = this._size;
    t === "md" || t === "sm" ? this._size = t : this._size = "lg", this.requestUpdate("size", e);
  }
  get size() {
    return this._size;
  }
  set dropdownPosition(t) {
    const e = this._dropdownPosition;
    this._dropdownPosition = t, this.requestUpdate("dropdownPosition", e);
  }
  get dropdownPosition() {
    return this._dropdownPosition;
  }
  set hasMenu(t) {
    const e = this._hasMenu;
    this._hasMenu = t, this.requestUpdate("hasMenu", e);
  }
  get hasMenu() {
    return this._hasMenu;
  }
  _dispatchMainClick() {
    const t = {
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onClick", t));
  }
  _dispatchIconClick() {
    this._hasMenu && this._toggleMenu();
    const t = {
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onSecondaryClick", t));
  }
  _toggleMenu() {
    this._isOpen = !this._isOpen, this.requestUpdate();
  }
  _handleActionMenuClosed() {
    this._isOpen = !1, this._actionMenu && !this._isOpen && this._actionMenu._closeMenu();
  }
  _handleDocumentClick(t) {
    this._clickedOutsideItem(this, t);
  }
  checkTextTruncate(t) {
    if (!t) return;
    const e = t.target, r = e.querySelector(".dss-button-text"), n = r.scrollWidth > r.offsetWidth;
    e.setAttribute("data-truncated", n.toString());
  }
  _clickedOutsideItem(t, e) {
    e.composedPath().includes(t) || this._isOpen && (this._isOpen = !1, this.requestUpdate());
  }
  async firstUpdated() {
    await this.updateComplete, this._actionMenu && this._actionMenu.addEventListener("onCloseActionMenu", () => {
      this._handleActionMenuClosed();
    });
  }
  willUpdate(t) {
    t.has("size") && (this._iconSize = this.size === "lg" ? "md" : "sm");
  }
  render() {
    return y(this);
  }
}
i([
  s({ type: String })
], o.prototype, "iconClose", 1);
i([
  s({ type: String })
], o.prototype, "iconOpen", 1);
i([
  s({ type: String })
], o.prototype, "variant", 1);
i([
  s({ type: String })
], o.prototype, "text", 1);
i([
  s(a)
], o.prototype, "disabled", 1);
i([
  s(a)
], o.prototype, "isOpen", 1);
i([
  s({ type: String })
], o.prototype, "size", 1);
i([
  s({ type: String })
], o.prototype, "dropdownPosition", 1);
i([
  s(a)
], o.prototype, "hasMenu", 1);
i([
  s({ type: String })
], o.prototype, "secondaryLabelOpen", 2);
i([
  s({ type: String })
], o.prototype, "secondaryLabelClose", 2);
i([
  s({ type: String })
], o.prototype, "icon", 2);
i([
  s(a)
], o.prototype, "iconFill", 2);
i([
  s(a)
], o.prototype, "tooltipFixed", 2);
export {
  o as SplitButton
};
//# sourceMappingURL=split-button.js.map
