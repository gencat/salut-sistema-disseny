import { classMap as i } from "lit/directives/class-map.js";
import { unsafeStatic as r, literal as u, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const t = u`dss-icon${r(e())}`, d = u`dss-tooltip${r(e())}`, _ = (s) => {
  const b = {
    "dss-split-button--primary": s._variant === "primary",
    "dss-split-button--secondary": s._variant === "secondary",
    "dss-split-button--open": s._isOpen,
    "dss-split-button--disabled": s._disabled,
    [`dss-split-button--${s._size}`]: !!s._size
  }, a = {
    "dss-button--primary": s._variant === "primary",
    "dss-button--secondary": s._variant === "secondary"
  };
  return l`
    <div class="dss-split-button ${i(b)}" @mouseenter=${s.checkTextTruncate}>
      <button
        type="button"
        class="dss-button ${i(a)} dss-split-button-main"
        ?disabled=${s._disabled}
        @click="${s._dispatchMainClick}"
      >
        ${s.icon ? l`
              <${t}
                size=${s._iconSize}
                icon=${s.icon}
                ?fill=${s.iconFill}
                >${s.icon}</${t}>
            ` : null}
        <span class="dss-button-text">
          ${s._text}
				</span>
      </button>
      <div class="dss-split-button-action" data-expanded="${s._isOpen}">
        <button
          aria-label="${s._isOpen ? s.secondaryLabelClose : s.secondaryLabelOpen}"
          type="button" 
          class="dss-button ${i(a)} dss-button--only-icon dss-split-button-icon"
          ?disabled=${s._disabled}
          @click="${s._dispatchIconClick}"
        >
          <${t} 
            icon="${s._isOpen ? s._iconOpen : s._iconClose}"
            size="md">
          </${t}>
        </button>
        <slot name="menu"></slot>
      </div>
      <${d} ?tooltipFixed="${s.tooltipFixed}" class="dss-split-button__tooltip" aria-hidden="true">
        ${s._text}
      </${d}>
    </div>
  `;
};
export {
  _ as splitButtonTemplate
};
//# sourceMappingURL=split-button.template.js.map
