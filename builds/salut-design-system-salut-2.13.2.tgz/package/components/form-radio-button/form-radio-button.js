import { LitElement as c, unsafeCSS as h } from "lit";
import { query as u, property as s } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as y, booleanConverter as a } from "../../utils/property-types.js";
import m from "./form-radio-button.style.css.js";
import { template as b } from "./form-radio-button.template.js";
var v = Object.defineProperty, r = (n, e, p, _) => {
  for (var i = void 0, o = n.length - 1, d; o >= 0; o--)
    (d = n[o]) && (i = d(e, p, i) || i);
  return i && v(e, p, i), i;
};
const l = class l extends c {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.checked = !1, this.tabIndex = 0, this._defaultId = `dss-radio-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [h(f), h(m)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  updated(e) {
    e.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    this._input.checked = !1, this.checked = !1;
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "";
  }
  focusInput() {
    var e;
    (e = this._input) == null || e.focus();
  }
  render() {
    return b(this);
  }
  _handleChange(e) {
    this.checked = e.target.checked, this._emitChange();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
};
l.formAssociated = !0;
let t = l;
r([
  u("input.dss-radio-input")
], t.prototype, "_input");
r([
  s({ type: String })
], t.prototype, "label");
r([
  s(y)
], t.prototype, "hideLabel");
r([
  s({ type: String })
], t.prototype, "name");
r([
  s({ type: String })
], t.prototype, "id");
r([
  s({ type: String })
], t.prototype, "value");
r([
  s({ converter: a, reflect: !0 })
], t.prototype, "disabled");
r([
  s({ converter: a, reflect: !0 })
], t.prototype, "readonly");
r([
  s({ converter: a, reflect: !0 })
], t.prototype, "required");
r([
  s({ converter: a, reflect: !0 })
], t.prototype, "checked");
r([
  s({ type: Number })
], t.prototype, "tabIndex");
export {
  t as FormRadioButton
};
//# sourceMappingURL=form-radio-button.js.map
