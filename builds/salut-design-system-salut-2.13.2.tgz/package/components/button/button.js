import { LitElement as f, unsafeCSS as y } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as s } from "../../utils/property-types.js";
import c from "./button.style.css.js";
import { template as u } from "./button.template.js";
var m = Object.defineProperty, e = (p, i, n, l) => {
  for (var r = void 0, a = p.length - 1, d; a >= 0; a--)
    (d = p[a]) && (r = d(i, n, r) || r);
  return r && m(i, n, r), r;
};
class o extends f {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.label = "", this.icon = void 0, this.iconPosition = "left", this.disabled = !1, this.hidden = !1, this.onlyIcon = !1, this.fullWidth = !1, this.size = "md", this.tooltipFixed = !1, this.loading = !1, this.forceViewport = !1, this.loadingIcon = "progress_activity";
  }
  static get styles() {
    return [y(h), y(c)];
  }
  _handleClick() {
    if (this.disabled || this.loading) return;
    const i = this.closest("form");
    this.type === "submit" && i ? i.requestSubmit() : this.type === "reset" && i && i.reset(), this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  checkTextTruncate(i) {
    if (!i) return;
    const n = i.target, l = n.querySelector(".dss-button-text"), r = l.scrollWidth > l.offsetWidth;
    n.setAttribute("data-truncated", r.toString());
  }
  render() {
    return u(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "variant");
e([
  t({ type: String })
], o.prototype, "label");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "iconPosition");
e([
  t(s)
], o.prototype, "disabled");
e([
  t(s)
], o.prototype, "hidden");
e([
  t(s)
], o.prototype, "onlyIcon");
e([
  t(s)
], o.prototype, "fullWidth");
e([
  t({ type: String })
], o.prototype, "size");
e([
  t(s)
], o.prototype, "tooltipFixed");
e([
  t(s)
], o.prototype, "loading");
e([
  t(s)
], o.prototype, "forceViewport");
export {
  o as Button
};
//# sourceMappingURL=button.js.map
