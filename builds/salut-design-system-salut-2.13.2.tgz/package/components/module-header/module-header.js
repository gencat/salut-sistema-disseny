import { LitElement as m, unsafeCSS as l } from "lit";
import { property as r } from "lit/decorators.js";
import u from "../../foundations/typography/typography.css.js";
import y from "../../shared/reset.style.css.js";
import f from "./module-header.style.css.js";
import { template as d } from "./module-header.template.js";
var h = Object.defineProperty, i = (o, e, n, g) => {
  for (var t = void 0, s = o.length - 1, a; s >= 0; s--)
    (a = o[s]) && (t = a(e, n, t) || t);
  return t && h(e, n, t), t;
};
class p extends m {
  constructor() {
    super(...arguments), this.title = "", this.titleText = "", this.legend = "", this.tag = "h2";
  }
  static get styles() {
    return [l(y), l(f), l(u)];
  }
  updated(e) {
    super.updated(e), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return d(this);
  }
}
i([
  r({ type: String })
], p.prototype, "title");
i([
  r({ type: String })
], p.prototype, "titleText");
i([
  r({ type: String })
], p.prototype, "legend");
i([
  r({ type: String })
], p.prototype, "tag");
export {
  p as ModuleHeader
};
//# sourceMappingURL=module-header.js.map
