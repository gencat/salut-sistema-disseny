import { unsafeStatic as l, literal as a, html as d } from "lit/static-html.js";
const r = (e) => {
  const s = a`${l(e.tag)}`;
  return d`
    <header class='dss-module-header'>
      <${s} class='dss-headline--sm'>${e.titleText}</${s}>
      <div class='dss-module-header__child-container'>
        <p class='dss-legend--sm'>${e.legend}</p>
        <slot></slot>
      </div>
    </header>
`;
};
export {
  r as template
};
//# sourceMappingURL=module-header.template.js.map
