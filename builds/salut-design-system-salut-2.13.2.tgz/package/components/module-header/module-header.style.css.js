const e = ":host{width:100%}.dss-module-header{display:flex;align-items:center;justify-content:space-between;gap:var(--dss-spacing-md)}.dss-module-header :first-child{flex:1}.dss-module-header .dss-module-header__child-container{display:inline-flex;align-items:center;flex-wrap:wrap;flex-shrink:0;gap:var(--dss-spacing-md)}";
export {
  e as default
};
//# sourceMappingURL=module-header.style.css.js.map
