import { classMap as d } from "lit/directives/class-map.js";
import { ifDefined as f } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as o, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const a = o`dss-icon${e(t())}`, i = o`dss-icon-button${e(t())}`, v = (s) => {
  const r = {
    "dss-dialog--has-header-slot": !!s._headerSlot,
    "dss-dialog--footer-empty": !s._footerSlot,
    "dss-dialog--has-scroll": s._hasScroll,
    "dss-dialog--full-width": s.fullWidth,
    "dss-dialog--full-height": s.fullHeight,
    "dss-dialog--flex-body": s.flexBody,
    "dss-dialog--no-body-padding": s.removeBodyPadding,
    "dss-dialog--jcef": s.jcef
  }, g = {
    [`dss-dialog-header-state--${s._state}`]: !!s._state
  };
  return l`
    <div
      class="dss-dialog ${d(r)}"
      role="dialog"
      aria-labelledby="dss-dialog-title"
      aria-modal="true"
      style="${f(s._modalStyle)}"
    >
      <div class="dss-dialog-header">
        ${s._hideCloseIcon ? null : l`
              <${i} 
                class="dss-dialog-header-close" 
                icon="close"
                size="lg" 
                variant="default" 
                label="Tancar modal"
                hideTooltip
                @click="${s._close}">
              </${i}>
            `}
        
        <div id="dss-dialog-title" class="dss-dialog-header-title">
          ${s._isStateValid() ? l`
                <${a} 
                  class="dss-dialog-header-state ${d(g)}"
                  size="xl" 
                  icon="${s._getStateIcon()}" 
                  fill>
                </${a}>
              ` : null}
          ${s._modalTitle}
        </div>

        <div class="dss-dialog-header--extra">
          <slot name="header"></slot>
        </div>
      </div>

      <div class="dss-dialog-body">
        <slot name="body"></slot>
      </div>

      <div class="dss-dialog-footer">
        <slot name="footer"></slot>
      </div>
    </div>
  `;
};
export {
  v as modalTemplate
};
//# sourceMappingURL=modal.template.js.map
