import { html as a } from "lit/static-html.js";
const n = (t) => a`
  <div class="pagination__container pagination__container--${t.size}">
        <button
          type="button"
          class="pagination__button"
          @click=${t._prev}
          ?disabled=${+t.currentIndex == 1}
        >
          <span>keyboard_arrow_left</span>
        </button>
        ${t._buttons}
        <button
          type="button"
          class="pagination__button"
          @click=${t._next}
          ?disabled=${+t.currentIndex === t._totalPages}
        >
          <span>keyboard_arrow_right</span>
        </button>
      </div>

  
`;
export {
  n as template
};
//# sourceMappingURL=pagination.template.js.map
