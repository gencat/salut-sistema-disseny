import { LitElement as _, unsafeCSS as u } from "lit";
import { property as l, state as f } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import v from "../../shared/scrollbar.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import T from "./tabs-list.style.css.js";
import { tabsListTemplate as E } from "./tabs-list.template.js";
var y = Object.defineProperty, w = Object.getOwnPropertyDescriptor, o = (b, t, e, s) => {
  for (var i = s > 1 ? void 0 : s ? w(t, e) : t, a = b.length - 1, r; a >= 0; a--)
    (r = b[a]) && (i = (s ? r(t, e, i) : r(i)) || i);
  return s && i && y(t, e, i), i;
};
class n extends _ {
  constructor() {
    super(), this.canOrder = !1, this.canEdit = !1, this.canDelete = !1, this.fullHeight = !1, this._isEditing = !1, this._focusedIndex = null, this._dssTabsId = "", this._label = "Tabs component name", this._tabs = [], this._tabsElements = window.document.querySelectorAll("[role='tab']"), this._firstTab = document.createElement("div"), this._lastTab = document.createElement("div"), this._addTabEnabled = !1, this._addTabText = "Afegir Tab", this._ignoreInputFocusout = !1, this.draggedIndex = null, this._lastOverEl = null, this._handleUpdateArrowsBound = this._updateArrows.bind(this);
  }
  static get styles() {
    return [u(g), u(v), u(m), u(T)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleUpdateArrowsBound);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._menu) == null || t.removeEventListener("scroll", this._handleUpdateArrowsBound), window.removeEventListener("resize", this._handleUpdateArrowsBound);
  }
  set dssTabsId(t) {
    const e = this._dssTabsId;
    this._dssTabsId = t, this.requestUpdate("dssTabsId", e);
  }
  get dssTabsId() {
    return this._dssTabsId;
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set tabs(t) {
    const e = this._tabs;
    this._tabs = t, this.requestUpdate("tabs", e);
  }
  get tabs() {
    return this._tabs;
  }
  set addTabText(t) {
    const e = this._addTabText;
    this._addTabText = t, this.requestUpdate("addTabText", e);
  }
  get addTabText() {
    return this._addTabText;
  }
  set addTabEnabled(t) {
    const e = this._addTabEnabled;
    this._addTabEnabled = t, this.requestUpdate("addTabEnabled", e);
  }
  get addTabEnabled() {
    return this._addTabEnabled;
  }
  // menuContainer
  get _wrapper() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-tabs")) || void 0;
  }
  get _header() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-tabs-header")) || void 0;
  }
  // menu
  get _menu() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-tabs-menu")) || void 0;
  }
  // leftArrow
  get _prevScroll() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-tabs-scroll-button--prev")) || void 0;
  }
  // rightArrow
  get _nextScroll() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-tabs-scroll-button--next")) || void 0;
  }
  updated(t) {
    var e, s;
    t.has("tabs") && this.changeTabWatch(), t.has("fullHeight") && (this.fullHeight ? (this.classList.add("full-height"), (e = this._wrapper) == null || e.classList.add("dss-tabs--full-height")) : (this.classList.remove("full-height"), (s = this._wrapper) == null || s.classList.remove("dss-tabs--full-height")));
  }
  async changeTabWatch() {
    this._tabsElements = this.renderRoot.querySelectorAll("[role='tab']"), this._tabsElements.forEach((t) => {
      t.addEventListener("keydown", (e) => {
        this._handleKeydown(e);
      }), t.addEventListener("mousedown", (e) => {
        this.setSelectedTab(e.currentTarget);
      });
    }), this.setFirstAndLastTabs();
  }
  setFirstAndLastTabs() {
    let t = !1;
    this._tabsElements.forEach((e) => {
      t || (this._firstTab = e, t = !0), this._lastTab = e;
    });
  }
  changeTab(t) {
    const e = {
      detail: { selectedPanel: t.panel },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onChangeDssTab", e)), this.dispatchEvent(new CustomEvent("onChange", e)), this.updateTabs(t.id), this.updatePanels(t.panel);
  }
  updateTabs(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t ? { ...e, selected: !0 } : { ...e, selected: !1 }
    );
  }
  updatePanels(t) {
    window.document.querySelectorAll("dss-tabs-panel").forEach((s) => {
      const i = s.getAttribute("panelId");
      s.getAttribute("linkedTo") === this._dssTabsId && (i === t ? s.setAttribute("selected", "true") : s.removeAttribute("selected"));
    });
  }
  _handleKeydown(t) {
    const e = t, s = t.currentTarget;
    let i = !1;
    switch (e.key) {
      case "ArrowLeft":
        this.moveFocusToPreviousTab(s), i = !0;
        break;
      case "ArrowRight":
        this.moveFocusToNextTab(s), i = !0;
        break;
      case "Home":
        this.moveFocusToTab(this._firstTab), i = !0;
        break;
      case "End":
        this.moveFocusToTab(this._lastTab), i = !0;
        break;
    }
    i && (t.stopPropagation(), t.preventDefault());
  }
  moveFocusToTab(t) {
    t && t.focus();
  }
  moveFocusToPreviousTab(t) {
    let e = 0;
    t === this._firstTab ? this.moveFocusToTab(this._lastTab) : (this._tabsElements.forEach((s, i) => {
      s === t && (e = i);
    }), this.moveFocusToTab(this._tabsElements[e - 1]));
  }
  moveFocusToNextTab(t) {
    let e = 0;
    t === this._lastTab ? this.moveFocusToTab(this._firstTab) : (this._tabsElements.forEach((s, i) => {
      s === t && (e = i);
    }), this.moveFocusToTab(this._tabsElements[e + 1]));
  }
  setSelectedTab(t) {
    for (let e = 0; e < this._tabsElements.length; e += 1) {
      const s = this._tabsElements[e];
      t === s ? (s.setAttribute("aria-selected", "true"), s.removeAttribute("tabindex"), s.classList.add("dss-tabs-item--selected"), this._centerTabIntoScroll(s)) : (s.setAttribute("aria-selected", "false"), s.setAttribute("tabindex", "-1"), s.classList.remove("dss-tabs-item--selected"));
    }
  }
  selectTab(t) {
    const e = this.renderRoot.querySelector(`[role='tab'][id='${t}']`);
    e && this.setSelectedTab(e);
  }
  _centerTabIntoScroll(t) {
    if (!t || !this._menu) return;
    const e = t.getBoundingClientRect(), s = this._menu.getBoundingClientRect(), i = e.left + e.width / 2, a = s.left + s.width / 2, r = i - a;
    this._menu.scrollBy({ left: r, behavior: "smooth" });
  }
  addNewTab() {
    const t = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onAddDssTab", t));
  }
  // Scroll behavior
  _updateArrows() {
    if (this._menu && this._prevScroll && this._nextScroll) {
      const t = Math.ceil(this._menu.scrollLeft), e = Math.ceil(this._menu.scrollWidth - this._menu.clientWidth);
      this._prevScroll.style.display = t > 0 ? "block" : "none", this._nextScroll.style.display = t < e ? "block" : "none";
    }
  }
  _scrollMenu(t) {
    this._menu && this._menu.scrollBy({
      left: t * 160,
      behavior: "smooth"
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._menu && this._menu.addEventListener("scroll", this._handleUpdateArrowsBound), this._updateArrows();
  }
  render() {
    return E(this);
  }
  /* Edit and Delete handlers */
  _handleEdit(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t.id ? { ...e, isEditing: !0 } : { ...e, isEditing: !1 }
    ), setTimeout(() => {
      var i;
      this._ignoreInputFocusout = !1;
      const e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(`#${t.id}-edit`);
      e.focus();
      const s = e.value.length;
      e.setSelectionRange(s, s);
    }, 50);
  }
  _handleDelete(t) {
    const e = {
      detail: { tab: t },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onDelete", e));
  }
  _closeInputEdit(t) {
    this.tabs = this.tabs.map((e) => e.id === t.id ? { ...e, isEditing: !1 } : e);
  }
  _handleEditSave(t) {
    var s;
    this._ignoreInputFocusout = !0;
    const e = ((s = this.shadowRoot) == null ? void 0 : s.querySelector(`#${t.id}-edit`)).value;
    this._closeInputEdit(t), e && e.trim() !== "" && e !== t.text && (this.tabs = this.tabs.map((i) => i.id === t.id ? { ...i, text: e } : i), this._dispatchEditTabs());
  }
  _handleEditCancel(t, e) {
    t.preventDefault(), t.stopPropagation(), this._ignoreInputFocusout = !0, this._closeInputEdit(e);
  }
  _handleInputFocusout(t, e) {
    if (this._ignoreInputFocusout) {
      this._ignoreInputFocusout = !1;
      return;
    }
    const s = t.relatedTarget;
    s != null && s.classList.contains("save-edit") || s != null && s.classList.contains("cancel-edit") || this._handleEditSave(e);
  }
  _handleEditCancelFocusout(t, e) {
    var a;
    const s = t.relatedTarget;
    if (s != null && s.classList.contains("save-edit") || s != null && s.classList.contains("cancel-edit")) return;
    const i = (a = t.currentTarget) == null ? void 0 : a.closest(".dss-tabs-item");
    (!s || !(i != null && i.contains(s))) && this._handleEditSave(e);
  }
  _handleEditCancelKeydown(t, e) {
    t.key === "Enter" && this._handleEditCancel(t, e);
  }
  _handleEditKeydown(t, e) {
    (t.key === "Enter" || t.key === "Escape") && this._handleEditSave(e);
  }
  _dispatchEditTabs() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onEdit", t));
  }
  onDragStart(t, e) {
    var i;
    this.draggedIndex = e, t.currentTarget.classList.add("dragging");
    try {
      (i = t.dataTransfer) == null || i.setData("text/plain", "");
    } catch {
    }
    t.dataTransfer && (t.dataTransfer.effectAllowed = "move", t.dataTransfer.dropEffect = "move");
  }
  onDragEnd(t) {
    t.currentTarget.classList.remove("dragging"), this._lastOverEl && (this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = null), this.draggedIndex = null;
  }
  onDragOver(t) {
    t.preventDefault();
    const e = t.currentTarget;
    this._lastOverEl && this._lastOverEl !== e && this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = e;
    const s = e.getBoundingClientRect(), i = s.left + s.width / 2, a = (t.clientX ?? 0) < i;
    e.classList.toggle("over-left", a), e.classList.toggle("over-right", !a), t.dataTransfer && (t.dataTransfer.dropEffect = "move");
  }
  onDragLeave(t) {
    const e = t.currentTarget;
    e.classList.remove("over-left", "over-right"), this._lastOverEl === e && (this._lastOverEl = null);
  }
  onDrop(t, e) {
    t.preventDefault();
    const s = t.currentTarget;
    if (s.classList.remove("over-left", "over-right"), this._lastOverEl === s && (this._lastOverEl = null), this.draggedIndex === null) return;
    const i = s.getBoundingClientRect(), a = i.left + i.width / 2, r = (t.clientX ?? 0) >= a;
    let d = e + (r ? 1 : 0);
    const h = [...this.tabs], [p] = h.splice(this.draggedIndex, 1);
    this.draggedIndex < d && d--, d < 0 && (d = 0), d > h.length && (d = h.length), h.splice(d, 0, p), this.tabs = h, this.draggedIndex = null, this.dispatchOrder();
  }
  dispatchOrder() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onOrder", t));
  }
  onItemFocus(t) {
    var s;
    const e = (s = this.shadowRoot) == null ? void 0 : s.activeElement;
    e != null && e.matches(":focus-visible") && (this._focusedIndex = t);
  }
  onItemBlur(t) {
    this._focusedIndex === t && (this._focusedIndex = null);
  }
}
o([
  l({ type: String })
], n.prototype, "dssTabsId", 1);
o([
  l({ type: String })
], n.prototype, "label", 1);
o([
  l({ type: Array })
], n.prototype, "tabs", 1);
o([
  l({ type: String })
], n.prototype, "addTabText", 1);
o([
  l(c)
], n.prototype, "addTabEnabled", 1);
o([
  l(c)
], n.prototype, "canOrder", 2);
o([
  l(c)
], n.prototype, "canEdit", 2);
o([
  l(c)
], n.prototype, "canDelete", 2);
o([
  l(c)
], n.prototype, "fullHeight", 2);
o([
  f()
], n.prototype, "_isEditing", 2);
o([
  f()
], n.prototype, "_focusedIndex", 2);
o([
  f()
], n.prototype, "draggedIndex", 2);
export {
  n as TabsList
};
//# sourceMappingURL=tabs-list.js.map
