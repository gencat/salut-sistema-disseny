import { LitElement as y, unsafeCSS as a } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import u from "./user-feedback.style.css.js";
import { userFeedbackTemplate as f } from "./user-feedback.template.js";
var S = Object.defineProperty, e = (p, s, l, g) => {
  for (var r = void 0, o = p.length - 1, n; o >= 0; o--)
    (n = p[o]) && (r = n(s, l, r) || r);
  return r && S(s, l, r), r;
};
class i extends y {
  constructor() {
    super(...arguments), this.variant = "default", this.size = "lg", this.imageSrc = "", this.imageAlt = "", this.title = "", this.titleText = "", this.description = "", this.hasDetails = !1, this.detailsLabel = "Veure detalls", this.hideFooter = !1, this.status = "error", this._detailsExpanded = !1;
  }
  static get styles() {
    return [a(m), a(h), a(u)];
  }
  _handleDetailsClick() {
    this._detailsExpanded = !this._detailsExpanded, this.requestUpdate();
  }
  updated(s) {
    super.updated(s), s.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return f(this);
  }
}
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "size");
e([
  t({ type: String })
], i.prototype, "imageSrc");
e([
  t({ type: String })
], i.prototype, "imageAlt");
e([
  t({ type: String })
], i.prototype, "title");
e([
  t({ type: String })
], i.prototype, "titleText");
e([
  t({ type: String })
], i.prototype, "description");
e([
  t(d)
], i.prototype, "hasDetails");
e([
  t({ type: String })
], i.prototype, "detailsLabel");
e([
  t(d)
], i.prototype, "hideFooter");
e([
  t({ type: String })
], i.prototype, "status");
export {
  i as UserFeedback
};
//# sourceMappingURL=user-feedback.js.map
