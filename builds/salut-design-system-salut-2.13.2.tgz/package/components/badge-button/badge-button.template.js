import { nothing as $ } from "lit";
import { classMap as b } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as l, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const t = l`dss-icon${d(e())}`, a = l`dss-tooltip${d(e())}`, f = (s) => i`
  <button
    type=${s.type}
    class=${b({
  "dss-badge-button": !0,
  [`dss-badge-button--${s._size}`]: !!s._size,
  [`dss-badge-button--${s._size}`]: !!s._size,
  [`dss-badge-button--${s.state}`]: !!s.state,
  [`dss-badge-button--${s.state}-outlined`]: !!s.state && s.outlined
})}
    ?disabled=${s.disabled}
    ?hidden=${s.hidden}
    @click=${s._handleClick}
  >
		${s.hideIcon && s._isInformativeState() ? $ : i`
				<${t} 
					class="dss-badge-button__icon" 
					icon="${s._icon}" 
					size="${s._iconSize}" 
					?fill="${s._iconFill}">
				</${t}>
			`}
		<span class="dss-badge-button__label">${s.label}</span>
		<div class="dss-badge-button__action">
			<${t} class="dss-badge-button__icon" icon="${s._actionIcon}" size="${s._iconSize}"></${t}>
		</div>
		${s._isTextTruncated ? i`<${a} ?forceViewport="${s.forceViewport}">${s.label}</${a}>` : i`<slot name="tooltip"></slot>`}
  </button>
`;
export {
  f as template
};
//# sourceMappingURL=badge-button.template.js.map
