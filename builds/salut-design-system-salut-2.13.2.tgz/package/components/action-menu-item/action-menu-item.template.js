import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as a, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const s = a`dss-icon${t(e())}`, d = a`dss-icon-button${t(e())}`, $ = a`dss-notification-badge${t(e())}`, c = (i) => l`
  <li
    class=${o({
  "dss-action-menu-item": !0,
  "dss-action-menu-item--selected": !!i._selected,
  "dss-action-menu-item--disabled": !!i._disabled,
  "dss-action-menu-item--first": !!i._first,
  "dss-action-menu-item--last": !!i._last,
  [`dss-action-menu-item--${i._state}`]: !!i._state
})}
    tabindex="${i._disabled ? -1 : 0}"
    role="menuitem"
    aria-disabled=${i._disabled ? "true" : "false"}
    @click=${i._handleItemClick}
    @keydown=${i._handleKeydown}
  >
    ${i._leftIcon ? l`<${s} role="none" size="md" icon="${i._leftIcon}" ?fill="${i.leftIconFill}"></${s}>` : null}
    <p role="none" class="dss-action-menu-item-label">${i._label}</p>
    ${!i._selected && i._notifications > 0 ? l`
          <${$}
            state="${i._notificationsState}"
            value="${i._notifications}"
          ></${$}>
        ` : null}
    ${i._rightIcon ? l`<${s} size="md" icon="${i._rightIcon}" ?fill="${i.rightIconFill}"></${s}>` : null}
    ${i._actionIcon ? l`
          <${d}
            icon="${i._actionIcon}"
            label="${i.actionLabel}"
            variant="${i._actionState}"
            @click="${i._handleAction}"
            ?disabled=${i._disabled}
            ?tooltipFixed=${i.tooltipFixed}
            tooltipPosition="${i.tooltipPosition}"
            ?hideTooltip=${i.hideTooltip}
          ></${d}>
        ` : null}
    ${i._hasNestedMenu ? l`
          <${s} size="md" icon="chevron_right"></${s}>
          <slot></slot>
        ` : null}
  </li>
`;
export {
  c as actionMenuItemTemplate
};
//# sourceMappingURL=action-menu-item.template.js.map
