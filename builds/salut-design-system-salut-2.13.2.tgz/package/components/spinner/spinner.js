import { LitElement as o, unsafeCSS as p } from "lit";
import { property as m } from "lit/decorators.js";
import f from "./spinner.style.css.js";
import { template as a } from "./spinner.template.js";
var l = Object.defineProperty, u = (e, s, i, v) => {
  for (var r = void 0, t = e.length - 1, n; t >= 0; t--)
    (n = e[t]) && (r = n(s, i, r) || r);
  return r && l(s, i, r), r;
};
class d extends o {
  constructor() {
    super(...arguments), this.size = "md";
  }
  static get styles() {
    return p(f);
  }
  render() {
    return a(this);
  }
}
u([
  m({ type: String })
], d.prototype, "size");
export {
  d as Spinner
};
//# sourceMappingURL=spinner.js.map
