import { html as c } from "lit/static-html.js";
const i = (s) => c`
  <div class="dss-spinner dss-spinner--${s.size}">
      <svg
        viewBox="0 0 66 66"
        xmlns="http://www.w3.org/2000/svg"
        class="dss-spinner__item"
      >
        <circle cx="33" cy="33" r="28"></circle>
      </svg>
      <svg
        viewBox="0 0 66 66"
        xmlns="http://www.w3.org/2000/svg"
        class="dss-spinner__item"
      >
        <circle cx="33" cy="33" r="28"></circle>
      </svg>
      <svg
        viewBox="0 0 66 66"
        xmlns="http://www.w3.org/2000/svg"
        class="dss-spinner__item"
      >
        <circle cx="33" cy="33" r="28"></circle>
      </svg>
      <svg
        viewBox="0 0 66 66"
        xmlns="http://www.w3.org/2000/svg"
        class="dss-spinner__item"
      >
        <circle cx="33" cy="33" r="28"></circle>
      </svg>
    </div>
`;
export {
  i as template
};
//# sourceMappingURL=spinner.template.js.map
