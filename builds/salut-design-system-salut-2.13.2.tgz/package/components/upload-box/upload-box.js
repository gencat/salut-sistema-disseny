import { LitElement as p, unsafeCSS as l } from "lit";
import { property as r } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import _ from "../../shared/reset.style.css.js";
import f from "../button/button.style.css.js";
import m from "../decorative-icon/decorative-icon.style.css.js";
import c from "./upload-box.style.css.js";
import { booleanType as F } from "../../utils/property-types.js";
import { template as g } from "./upload-box.template.js";
var b = Object.defineProperty, a = (d, e, t, i) => {
  for (var s = void 0, n = d.length - 1, h; n >= 0; n--)
    (h = d[n]) && (s = h(e, t, s) || s);
  return s && b(e, t, s), s;
};
class o extends p {
  constructor() {
    super(...arguments), this.fileExplorerMessage = "Clica per pujar", this.dragAndDropMessage = "o arrossega arxius aquí", this.dragAndDropIcon = "file_upload", this.filesFormatMessage = "PDF, JPEG o PNG de menys de 5MB", this.buttonLabel = "Buscar arxius", this.filesFormat = ["pdf", "jpeg", "png"], this.maxFileSize = 5242880, this.disableOpenFile = !1, this.helpText = void 0, this.maxUploadFiles = void 0, this.maxUploadFilesMessage = "", this._dragOver = !1, this._files = [], this._disabled = !1, this._hasMaxUploadFilesError = !1, this._fileFormatErrorMessage = "Format d’arxiu incorrecte", this._fileSizeErrorMessage = "Mida d’arxiu incorrecte", this._fileFormatAndSizeErrorMessage = "Format i mida d’arxiu incorrecte", this._fileErrors = {}, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._input && this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [
      l(_),
      l(u),
      l(f),
      l(m),
      l(c)
    ];
  }
  get _input() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  _checkInputAttributes() {
    var t;
    const e = (t = this._input) == null ? void 0 : t.getAttribute("disabled");
    this._disabled = e !== null, this.requestUpdate();
  }
  /* METHODS */
  _onDragOver(e) {
    e.preventDefault(), !this._dragOver && !this._disabled && (this._dragOver = !0, this.requestUpdate());
  }
  _onDragLeave(e) {
    e.preventDefault(), this._dragOver && !this._disabled && (this._dragOver = !1, this.requestUpdate());
  }
  _onDrop(e) {
    var t;
    if (e.preventDefault(), !this._disabled) {
      this._dragOver && (this._dragOver = !1, this.requestUpdate());
      const i = (t = e.dataTransfer) == null ? void 0 : t.files;
      if (!i) return;
      this._handleUploadedFiles(i);
    }
  }
  _onClick() {
    this._input && !this._disabled && this._input.click();
  }
  _onSlotInputChange() {
    this._input && this._input.addEventListener("change", this._handleInputFileChange.bind(this));
  }
  _checkMaxUploadFiles(e) {
    if (!this.maxUploadFiles)
      return this._hasMaxUploadFilesError = !1, !0;
    const t = this._files.length + e;
    this._hasMaxUploadFilesError = t > this.maxUploadFiles, this.requestUpdate();
  }
  _isValidFileFormat(e) {
    var i;
    const t = (i = e.name.split(".").pop()) == null ? void 0 : i.toLowerCase();
    return this.filesFormat.includes(t || "");
  }
  _isValidFileSize(e) {
    return e.size <= this.maxFileSize;
  }
  _validateFile(e) {
    let t = !0, i = "";
    return !this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (t = !1, i = this._fileFormatAndSizeErrorMessage) : this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (t = !1, i = this._fileFormatErrorMessage) : !this._isValidFileSize(e) && this._isValidFileFormat(e) && (t = !1, i = this._fileSizeErrorMessage), t || (this._fileErrors[e.name] = i), t;
  }
  _isAlreadyUploaded(e) {
    return this._files.some((t) => t.name === e.name);
  }
  _handleInputFileChange(e) {
    const t = e.target;
    t.files && this._handleUploadedFiles(t.files);
  }
  _handleUploadedFiles(e) {
    if (e && e.length > 0) {
      if (this._checkMaxUploadFiles(e.length), this._hasMaxUploadFilesError) return;
      for (const t of Array.from(e))
        if (!this._isAlreadyUploaded(t)) {
          const i = this._validateFile(t), s = t;
          s.status = i ? "loading" : "invalid", this._files.push(s), this.requestUpdate(), this._readFile(t, i);
        }
    }
  }
  _readFile(e, t) {
    const i = new FileReader();
    i.onload = () => {
      this._files.find((s) => s.name === e.name).status = t ? "ready" : "invalid", this.requestUpdate(), this._dispatchUploadFiles();
    }, i.onerror = () => {
      this._files.find((s) => s.name === e.name).status = "error", i.error && (this._fileErrors[e.name] = i.error.message), this.requestUpdate();
    }, i.readAsDataURL(e);
  }
  _removeFile(e) {
    this._files.splice(e, 1), this._dispatchUploadFiles(), this._input && (this._input.value = ""), this._checkMaxUploadFiles(0), this.requestUpdate();
  }
  _reloadFile(e) {
    this._files.find((t) => t.name === e.name).status = "loading", this._fileErrors[e.name] = "", this.requestUpdate(), this._readFile(e);
  }
  /* PUBLIC METHODS */
  resetFiles() {
    this._files = [], this.requestUpdate();
  }
  /* EVENTS */
  _dispatchUploadFiles() {
    const e = {
      detail: this._files,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onUploadFiles", e));
  }
  _dispatchOpenFile(e) {
    const t = {
      detail: { file: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenFile", t));
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    try {
      await this.updateComplete, this.maxUploadFiles && this.maxUploadFilesMessage === "" && (this.maxUploadFilesMessage = `S'ha superat el límit d'arxius. S'hi admet un màxim de ${this.maxUploadFiles} arxius`), this._input && (this.observer.observe(this._input, this.observerConfig), this._checkInputAttributes(), this._onSlotInputChange());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return g(this);
  }
}
a([
  r({ type: String })
], o.prototype, "fileExplorerMessage");
a([
  r({ type: String })
], o.prototype, "dragAndDropMessage");
a([
  r({ type: String })
], o.prototype, "dragAndDropIcon");
a([
  r({ type: String })
], o.prototype, "filesFormatMessage");
a([
  r({ type: String })
], o.prototype, "buttonLabel");
a([
  r({ type: Array })
], o.prototype, "filesFormat");
a([
  r({ type: Number })
], o.prototype, "maxFileSize");
a([
  r(F)
], o.prototype, "disableOpenFile");
a([
  r({ type: String })
], o.prototype, "helpText");
a([
  r({ type: Number })
], o.prototype, "maxUploadFiles");
a([
  r({ type: String })
], o.prototype, "maxUploadFilesMessage");
export {
  o as UploadBox
};
//# sourceMappingURL=upload-box.js.map
