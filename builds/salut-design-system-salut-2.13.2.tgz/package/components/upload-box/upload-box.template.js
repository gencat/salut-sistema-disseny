import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as o, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
const r = o`dss-decorative-icon${d($())}`, i = o`dss-icon-button${d($())}`, g = (a) => {
  const t = {
    dragover: a._dragOver,
    "upload-box--disabled": a._disabled,
    "upload-box--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  }, p = {
    dragover: a._dragOver,
    "upload-box-help--disabled": a._disabled,
    "upload-box-help--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  };
  return s`
    <!-- Drag and drop -->
      <div class="upload-box-wrapper">
        <div
          class="upload-box ${e(t)}"
          @dragover="${a._onDragOver}"
          @dragleave="${a._onDragLeave}"
          @drop="${a._onDrop}"
        >
          <${r} icon=${a.dragAndDropIcon} size="lg" state="${a._hasMaxUploadFilesError ? "error" : "default"}" disabled=${a._disabled}></${r}>
          <div class="upload-box-cta">
            <div class="upload-box-cta__message">
              <span class="action" @click=${a._onClick}>
                ${a.fileExplorerMessage}
              </span>
              ${a.dragAndDropMessage}
            </div>
            <div class="upload-box-cta__requirements">
              ${a.filesFormatMessage}
            </div>
          </div>
          <slot name="input"></slot>
        </div>

        ${a.helpText || a._hasMaxUploadFilesError ? s`
            <div class="upload-box-help ${e(p)}">
              ${a._hasMaxUploadFilesError ? s`${a.maxUploadFilesMessage}` : s`${a.helpText}`}
            </div>
          ` : null}
        
      </div>

      <!--Uploaded files -->
      <div class="upload-box-files">
        <ul class="file-list">
          ${a._files.map(
    (l, _) => s`
              <li class="file">
                ${a._fileErrors[l.name] ? s`
                      <${r} icon="error_outline" size="sm" state="error"></${r}>
                    ` : l.status === "loading" ? s`
                      <${r} icon="downloading" size="sm" state="info"></${r}>
                    ` : s`
                      <${r} icon="check" size="sm" state="success"></${r}>
                    `}
                <div class="file-description">
                  <p class="file-description__name">

                    ${a._fileErrors[l.name] ? s`
                        ${l.name}
                      ` : l.status === "loading" ? s`${l.name} <span class="dot-flashing"></span>` : a.disableOpenFile ? s`
                            ${l.name}
                          ` : s`
                            <span class="upload-box__file-link" @click="${() => a._dispatchOpenFile(l)}">
                              ${l.name}
                            </span>
                          `}

                   
                  </p>
                  ${a._fileErrors[l.name] ? s`
                        <p class="file-description__error">
                          ${a._fileErrors[l.name]}
                        </p>
                      ` : ""}
                </div>
                <div class="file-actions">
                  ${l.status === "loading" ? s`
                        <${i}
                        size="sm"
                        icon="block"
                        variant="danger"
                        label="Cancel·lar"
                        hideTooltip
                        ></${i}>
                      ` : s`
                        ${l.status === "error" ? s`
                              <${i}
                              size="sm"
                              label="Recarregar"
                              icon="restart_alt"
                              variant="primary"
                              hideTooltip
                              @click="${() => a._reloadFile(l)}"
                              ></${i}>
                            ` : s``}
                        <${i}
                        size="sm"
                        icon="delete"
                        label="Eliminar"
                        variant="danger"
                        hideTooltip
                        @click="${() => a._removeFile(_)}"
                        ></${i}>
                      `}
                </div>
              </li>
            `
  )}
        </ul>
      </div>
  `;
};
export {
  g as template
};
//# sourceMappingURL=upload-box.template.js.map
