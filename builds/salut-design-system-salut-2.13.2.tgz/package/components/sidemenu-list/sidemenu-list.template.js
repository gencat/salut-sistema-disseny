import { html as s } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
const d = (e) => s`
  <ul
    role="menu"
    class=${t({
  "dss-sidemenu-list": !0,
  "dss-sidemenu-list--expanded": !!e._expanded
})}
    @navigate=${e._handleNavigate}
    @updateItemFocus=${e._handleItemFocus}
  >
    <slot></slot>
  </ul>
`;
export {
  d as sidemenuListTemplate
};
//# sourceMappingURL=sidemenu-list.template.js.map
