const s = ":host{display:block;width:100%}.dss-sidemenu-list{display:flex;align-items:center;flex-direction:column;gap:var(--dss-spacing-xxs)}.dss-sidemenu-list--expanded{width:100%}";
export {
  s as default
};
//# sourceMappingURL=sidemenu-list.style.css.js.map
