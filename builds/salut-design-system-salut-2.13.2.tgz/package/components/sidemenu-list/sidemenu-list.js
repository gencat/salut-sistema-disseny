import { LitElement as p, unsafeCSS as d } from "lit";
import { property as u } from "lit/decorators.js";
import "../../index.js";
import h from "../../foundations/icon/icon.style.css.js";
import b from "../../shared/reset.style.css.js";
import { booleanType as f } from "../../utils/property-types.js";
import C from "./sidemenu-list.style.css.js";
import { sidemenuListTemplate as _ } from "./sidemenu-list.template.js";
import { getCustomElementSuffix as g } from "../../api/custom-element-scope.js";
var x = Object.defineProperty, E = Object.getOwnPropertyDescriptor, c = (l, e, s, r) => {
  for (var n = E(e, s), t = l.length - 1, o; t >= 0; t--)
    (o = l[t]) && (n = o(e, s, n) || n);
  return n && x(e, s, n), n;
};
class m extends p {
  constructor() {
    super(...arguments), this._disabled = !1, this._expanded = !1, this._scrollContainerClass = "dss-layout-sidebar";
  }
  static get styles() {
    return [d(b), d(h), d(C)];
  }
  set expanded(e) {
    const s = this._expanded;
    this._expanded = e, this.requestUpdate("expanded", s);
  }
  get expanded() {
    return this._expanded;
  }
  set disabled(e) {
    const s = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", s);
  }
  get disabled() {
    return this._disabled;
  }
  set scrollContainerClass(e) {
    const s = this._scrollContainerClass;
    this._scrollContainerClass = e, this.requestUpdate("scrollContainerClass", s);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  _propagateProperties() {
    var s;
    const e = (s = this.shadowRoot) == null ? void 0 : s.querySelectorAll("slot");
    e && e.forEach((r) => {
      r.assignedElements().forEach((t) => {
        this._expanded ? t.setAttribute("expanded", "true") : t.removeAttribute("expanded"), this._scrollContainerClass ? t.setAttribute("scrollContainerClass", this._scrollContainerClass) : t.removeAttribute("scrollContainerClass");
      });
    });
  }
  _handleItemFocus(e) {
    var n;
    const s = e.target, r = (n = this.shadowRoot) == null ? void 0 : n.querySelector("slot");
    if (r) {
      const t = r.assignedElements({ flatten: !0 }).filter((i) => !i._disabled), o = t.findIndex((i) => i._focusEnabled);
      t[o] !== s && (s.setAttribute("focusEnabled", "true"), t[o].removeAttribute("focusEnabled"));
    }
  }
  _handleNavigate(e) {
    var r;
    const s = (r = this.shadowRoot) == null ? void 0 : r.querySelector("slot");
    if (s) {
      const t = s.assignedElements({ flatten: !0 }).filter((a) => !a._disabled).filter((a) => !a.classList.contains("hidden")), o = t.findIndex((a) => a._focusEnabled);
      let i = o;
      e.detail.direction === "next" ? i = (o + 1) % t.length : e.detail.direction === "previous" && (i = (o - 1 + t.length) % t.length), o !== i && (this._checkActionMenuClose(t[o]), t[o].blurItem(), t[o].removeAttribute("focusEnabled"), t[i].focusItem(), t[i].setAttribute("focusEnabled", "true"), this.dispatchEvent(new CustomEvent("onSlotFocus", { bubbles: !0, composed: !0 })));
    }
  }
  _checkActionMenuClose(e) {
    var i;
    const s = (i = e.shadowRoot) == null ? void 0 : i.querySelector("slot");
    if (!s) return;
    const n = `dss-action-menu${g()}`, o = s.assignedElements({ flatten: !0 }).find((a) => a.tagName.toLowerCase() === n);
    o && o.classList.contains("visible") && o._closeMenu();
  }
  async firstUpdated() {
    var s;
    await this.updateComplete;
    const e = (s = this.shadowRoot) == null ? void 0 : s.querySelector("slot");
    if (e) {
      const n = e.assignedElements({ flatten: !0 }).find((t) => t.tagName.toLowerCase() === "dss-sidemenu-list-item");
      n && n.setAttribute("focusEnabled", "true"), this._propagateProperties();
    }
  }
  updated(e) {
    super.updated(e), (e.has("expanded") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    return _(this);
  }
}
c([
  u(f)
], m.prototype, "expanded");
c([
  u(f)
], m.prototype, "disabled");
c([
  u({ type: String })
], m.prototype, "scrollContainerClass");
export {
  m as SidemenuList
};
//# sourceMappingURL=sidemenu-list.js.map
