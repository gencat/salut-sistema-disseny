import { LitElement as p, unsafeCSS as h } from "lit";
import { property as l, state as m } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import f from "./list-menu.style.css.js";
import { template as y } from "./list-menu.template.js";
var _ = Object.defineProperty, n = (c, e, t, s) => {
  for (var i = void 0, r = c.length - 1, d; r >= 0; r--)
    (d = c[r]) && (i = d(e, t, i) || i);
  return i && _(e, t, i), i;
};
class o extends p {
  constructor() {
    super(), this.title = "", this.titleText = "", this.description = "", this.icon = null, this.items = [], this.disabled = !1, this.selectedItemIndex = null, this._isFirstUpdate = !0, this._resizeTimer = null, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [h(u), h(f)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("keydown", this.onKeyDown), window.addEventListener("resize", this._handleResizeBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("keydown", this.onKeyDown), window.removeEventListener("resize", this._handleResizeBound);
  }
  _handleResize() {
    this._isFirstUpdate || (this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._checkTextsToTruncated();
    }, 500));
  }
  handleItemClick(e) {
    const t = this.items[e];
    t.disabled || (this.selectedItemIndex = e, this.dispatchEvent(
      new CustomEvent("item-clicked", {
        detail: { label: t.label },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  onKeyDown(e) {
    e.code === "ArrowDown" ? (e.preventDefault(), this.moveFocus(1)) : e.code === "ArrowUp" ? (e.preventDefault(), this.moveFocus(-1)) : (e.code === "Enter" || e.code === "Space" || e.code === "NumpadEnter") && (e.preventDefault(), this.selectedItemIndex !== null && this.handleItemClick(this.selectedItemIndex));
  }
  moveFocus(e) {
    var i, r;
    const t = ((i = this.shadowRoot) == null ? void 0 : i.querySelectorAll(".dss-list-menu-item:not(.disabled)")) || [];
    if (t.length === 0) return;
    let s = (this.selectedItemIndex ?? -1) + e;
    s < 0 && (s = t.length - 1), s >= t.length && (s = 0), this.selectedItemIndex = Array.from(t).findIndex((d, a) => a === s), (r = t[s]) == null || r.focus();
  }
  _checkTextsToTruncated() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelectorAll(".dss-list-menu-item__content-text")) || [];
    for (const [s, i] of e.entries()) {
      const r = i.clientWidth, d = i.scrollWidth;
      this.items[s].isTruncated = r < d;
    }
    this.requestUpdate();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._checkTextsToTruncated(), this._isFirstUpdate = !1;
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(e) {
    super.updated(e), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return y(this);
  }
}
n([
  l({ type: String })
], o.prototype, "title");
n([
  l({ type: String })
], o.prototype, "titleText");
n([
  l({ type: String })
], o.prototype, "description");
n([
  l({ type: String })
], o.prototype, "icon");
n([
  l({ type: Array })
], o.prototype, "items");
n([
  l({ type: String })
], o.prototype, "disabled");
n([
  m()
], o.prototype, "selectedItemIndex");
export {
  o as ListMenu
};
//# sourceMappingURL=list-menu.js.map
