import { LitElement as n, unsafeCSS as a } from "lit";
import { property as t } from "lit/decorators.js";
import { itemListBaseTemplate as y } from "./item-list-base.template.js";
import f from "../../api/marker/marker.style.css.js";
import v from "../../foundations/icon/icon.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import g from "../decorative-icon/decorative-icon.style.css.js";
import m from "./item-list-base.style.css.js";
var u = Object.defineProperty, e = (l, o, s, h) => {
  for (var p = void 0, c = l.length - 1, d; c >= 0; c--)
    (d = l[c]) && (p = d(o, s, p) || p);
  return p && u(o, s, p), p;
};
class i extends n {
  constructor() {
    super(...arguments), this.disabled = !1, this.value = void 0, this.title = "", this.titleText = "", this.subtitle = void 0, this.date = void 0, this.decorativeIcon = void 0, this.decorativeIconState = void 0, this.decorativeIconDisabled = !1, this.decorativeIconFill = !1, this.criticity = void 0, this.criticityLabel = void 0, this.criticityDisabled = !1, this.first = !1, this.tooltipFixed = !1, this.tooltipPosition = "top", this.interactive = !1, this.selectable = !1, this.forceViewport = !1, this.highlight = void 0, this.highlightThreshold = 2, this.advancedHighlight = !1;
  }
  static get styles() {
    return [
      a(v),
      a(g),
      a(m),
      a(f)
    ];
  }
  /* METHODS */
  _checkTextTruncate(o) {
    const s = o.target, h = s.scrollWidth > s.offsetWidth;
    s.setAttribute("data-truncated", h.toString());
  }
  _dispatchClickEvent(o) {
    o.stopPropagation(), o.preventDefault(), this.dispatchEvent(
      new CustomEvent("item-click", {
        detail: { originalEvent: o },
        bubbles: !1,
        composed: !1
      })
    );
  }
  /* LIT LIFECYCLE */
  updated(o) {
    super.updated(o), o.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return y(this);
  }
}
e([
  t(r)
], i.prototype, "disabled");
e([
  t({ type: String })
], i.prototype, "value");
e([
  t({ type: String })
], i.prototype, "title");
e([
  t({ type: String })
], i.prototype, "titleText");
e([
  t({ type: String })
], i.prototype, "subtitle");
e([
  t({ type: String })
], i.prototype, "date");
e([
  t({ type: String })
], i.prototype, "decorativeIcon");
e([
  t({ type: String })
], i.prototype, "decorativeIconState");
e([
  t(r)
], i.prototype, "decorativeIconDisabled");
e([
  t(r)
], i.prototype, "decorativeIconFill");
e([
  t({ type: String })
], i.prototype, "criticity");
e([
  t({ type: String })
], i.prototype, "criticityLabel");
e([
  t(r)
], i.prototype, "criticityDisabled");
e([
  t(r)
], i.prototype, "first");
e([
  t(r)
], i.prototype, "tooltipFixed");
e([
  t({ type: String })
], i.prototype, "tooltipPosition");
e([
  t(r)
], i.prototype, "interactive");
e([
  t(r)
], i.prototype, "selectable");
e([
  t(r)
], i.prototype, "forceViewport");
e([
  t({ type: String })
], i.prototype, "highlight");
e([
  t({ type: Number })
], i.prototype, "highlightThreshold");
e([
  t(r)
], i.prototype, "advancedHighlight");
export {
  i as ItemListBase
};
//# sourceMappingURL=item-list-base.js.map
