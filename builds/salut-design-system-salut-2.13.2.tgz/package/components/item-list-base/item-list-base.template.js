import { unsafeHTML as l } from "lit/directives/unsafe-html.js";
import { unsafeStatic as a, literal as r, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as h, highlightText as d } from "../../api/marker/marker.js";
import { nothing as s } from "lit";
import { classMap as T } from "lit/directives/class-map.js";
import { ifDefined as b } from "lit/directives/if-defined.js";
const g = r`dss-decorative-icon${a($())}`, v = r`dss-icon-badge${a($())}`, e = r`dss-tooltip${a($())}`, V = (i) => t`
  <div
    class=${T({
  "dss-item-list-base": !0,
  "dss-item-list-base--first": i.first
})}
  >
    ${i.selectable ? t`
        <slot name="selector"></slot>
      ` : s}

    ${i.criticity ? t`
          <${v} size="sm"
            state="${i.criticity}"
            label="${i.criticityLabel}"
            ?disabled="${i.disabled || i.criticityDisabled}"
          >
            ${i.criticityLabel ? t`
              <${e} 
                slot="tooltip" 
                ?tooltipFixed="${i.tooltipFixed}" 
                ?forceViewport="${i.forceViewport}"
              >
                ${i.criticityLabel}
              </${e}>` : s}
          </${v}>  
        ` : s}

    <div class="item-details">
      ${i.date ? t`
          <div class="item-details__date"> 
            <span>
              ${i.advancedHighlight ? l(
  h(i.date, i.highlight || "", i.highlightThreshold)
) : l(d(i.date, i.highlight || "", i.highlightThreshold))}
            </span>
          </div>
        ` : s}
      <div class="item-details__title">
        ${i.decorativeIcon ? t`
              <${g} 
                icon=${i.decorativeIcon} 
                size="sm" 
                state=${b(i.decorativeIconState)}
                ?disabled="${i.disabled || i.decorativeIconDisabled}"
                ?fill="${i.decorativeIconFill}"
              >
              </${g}>
            ` : s}
        ${i.interactive ? t`
            <button 
              class="item-details__title-button" 
              @mouseenter=${i._checkTextTruncate} 
              @click=${i._dispatchClickEvent}
              ?disabled="${i.disabled}"
            >
              ${i.advancedHighlight ? l(
  h(
    i.titleText,
    i.highlight || "",
    i.highlightThreshold
  )
) : l(
  d(i.titleText, i.highlight || "", i.highlightThreshold)
)}
              <${e} 
                ?tooltipFixed="${i.tooltipFixed}" 
                ?forceViewport="${i.forceViewport}"
                class="title-tooltip" 
                aria-hidden="true"
                >${i.titleText}</${e}>
            </button>
          ` : t`
            <div class="item-details__title-text" @mouseenter=${i._checkTextTruncate}>
              ${i.advancedHighlight ? l(
  h(
    i.titleText,
    i.highlight || "",
    i.highlightThreshold
  )
) : l(
  d(i.titleText, i.highlight || "", i.highlightThreshold)
)}
              <${e} 
                ?tooltipFixed="${i.tooltipFixed}"
                ?forceViewport="${i.forceViewport}"
                class="title-tooltip" 
                aria-hidden="true"
                >${i.titleText}</${e}>
            </div>
          `}
      </div>
      
      ${i.subtitle ? t`
          <div class="item-details__subtitle" @mouseenter=${i._checkTextTruncate}>
            ${i.advancedHighlight ? l(
  h(i.subtitle, i.highlight || "", i.highlightThreshold)
) : l(d(i.subtitle, i.highlight || "", i.highlightThreshold))}
            <${e} 
              ?tooltipFixed="${i.tooltipFixed}" 
              ?forceViewport="${i.forceViewport}"
              class="title-tooltip" 
              aria-hidden="true"
              >${i.subtitle}</${e}>
          </div>
        ` : s}
    </div>

    <div class="item-actions">
      <slot/>
    </div>
  </div>
`;
export {
  V as itemListBaseTemplate
};
//# sourceMappingURL=item-list-base.template.js.map
