import { LitElement as c, unsafeCSS as p } from "lit";
import { query as f, property as s, state as v } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as d, booleanConverter as l } from "../../utils/property-types.js";
import m from "./form-checkbox.style.css.js";
import { template as b } from "./form-checkbox.template.js";
var k = Object.defineProperty, i = (n, e, o, _) => {
  for (var a = void 0, r = n.length - 1, u; r >= 0; r--)
    (u = n[r]) && (a = u(e, o, a) || a);
  return a && k(e, o, a), a;
};
const h = class h extends c {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.id = "", this.name = "", this.value = !1, this.disabled = !1, this.readonly = !1, this.required = !1, this.checked = !1, this.tabIndex = 0, this.variant = "default", this.indeterminate = !1, this.defaultValue = this.value, this._defaultId = `dss-checkbox-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [p(y), p(m)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  updated(e) {
    e.has("value") && typeof this.value == "string" && ((this.value === "" || this.value === "false") && (this._input.checked = !1), this.internals.setFormValue(this._input.checked ? this.value : null)), !e.has("checked") && e.has("value") && typeof this.value == "boolean" && (this._input.checked = this.value, this.internals.setFormValue(this._input.checked ? "on" : null)), e.has("checked") && typeof this.value == "boolean" && this.internals.setFormValue(this._input.checked ? "on" : null), e.has("indeterminate") && (this._input.indeterminate = this.indeterminate);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    const e = typeof this.defaultValue == "boolean";
    this.value = e ? !1 : this.defaultValue, this._input.checked = !1, this.checked = !1;
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "";
  }
  focusInput() {
    var e;
    (e = this._input) == null || e.focus();
  }
  async firstUpdated() {
    await this.updateComplete, this.defaultValue = this.value, (this.checked || this.value === !0 || this.value === "true") && (this.checked = !0, this._input.checked = !0, this.internals.setFormValue(this._input.checked ? typeof this.value == "string" ? this.value : "on" : null));
  }
  render() {
    return b(this);
  }
  _handleChange(e) {
    this.checked = e.target.checked, typeof this.value == "boolean" && (this.value = this.checked), this.internals.setFormValue(this.checked ? typeof this.value == "string" ? this.value : "on" : null), this._emitChange();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
};
h.formAssociated = !0;
let t = h;
i([
  f("input.dss-checkbox-input")
], t.prototype, "_input");
i([
  s({ type: String })
], t.prototype, "label");
i([
  s(d)
], t.prototype, "hideLabel");
i([
  s({ type: String })
], t.prototype, "id");
i([
  s({ type: String })
], t.prototype, "name");
i([
  s({ type: String })
], t.prototype, "value");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "disabled");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "readonly");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "required");
i([
  s({ converter: l, reflect: !0 })
], t.prototype, "checked");
i([
  s({ type: Number })
], t.prototype, "tabIndex");
i([
  s({ type: String })
], t.prototype, "variant");
i([
  s(d)
], t.prototype, "indeterminate");
i([
  v()
], t.prototype, "defaultValue");
export {
  t as FormCheckbox
};
//# sourceMappingURL=form-checkbox.js.map
