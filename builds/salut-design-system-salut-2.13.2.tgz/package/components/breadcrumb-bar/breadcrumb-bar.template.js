import { html as a } from "lit";
import { map as d } from "lit/directives/map.js";
const i = (r) => a`
    <div class="dss-breadcrumb-bar">

      <nav class="dss-breadcrumb" aria-label="Ruta de pàgina">
        <ol class="dss-breadcrumb__list">
        ${d(r.items, (s, l) => {
  const e = l === r.items.length - 1;
  return a`
              <li class="dss-breadcrumb__item">
              ${e ? a`
                  <span
                    class="dss-breadcrumb__current"
                    aria-current="page"
                  >
                    ${s.label}
                  </span>
                ` : a`
                  <a
                    class="dss-breadcrumb__link"
                    href="${s.href || "#"}"
                    @click="${(c) => r.handleItemClick(c, s)}"
                    title="${s.label}"
                  >
                    ${s.label}
                  </a>
                `}
              </li>
            `;
})}
        </ol>
      </nav>

      <div class="dss-breadcrumb__actions">
        <slot></slot>  
      </div>
    </div>
  `;
export {
  i as template
};
//# sourceMappingURL=breadcrumb-bar.template.js.map
