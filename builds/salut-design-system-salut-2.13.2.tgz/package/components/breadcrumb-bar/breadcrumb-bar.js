import { LitElement as p, unsafeCSS as n } from "lit";
import { property as a } from "lit/decorators.js";
import l from "../../shared/reset.style.css.js";
import u from "./breadcrumb-bar.style.css.js";
import { template as f } from "./breadcrumb-bar.template.js";
var c = Object.defineProperty, d = (s, t, r, o) => {
  for (var e = void 0, m = s.length - 1, i; m >= 0; m--)
    (i = s[m]) && (e = i(t, r, e) || e);
  return e && c(t, r, e), e;
};
class v extends p {
  constructor() {
    super(...arguments), this.items = [];
  }
  static get styles() {
    return [n(l), n(u)];
  }
  handleItemClick(t, r) {
    var o;
    t.preventDefault(), (o = t.currentTarget) == null || o.blur(), this.dispatchEvent(new CustomEvent("onItemClick", { detail: r.href, bubbles: !0, composed: !0 }));
  }
  render() {
    return f(this);
  }
}
d([
  a({ type: Array })
], v.prototype, "items");
export {
  v as BreadcrumbBar
};
//# sourceMappingURL=breadcrumb-bar.js.map
