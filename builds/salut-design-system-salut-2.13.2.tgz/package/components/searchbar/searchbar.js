import { LitElement as z, unsafeCSS as F } from "lit";
import { query as L, property as i, state as y } from "lit/decorators.js";
import { classMap as k } from "lit/directives/class-map.js";
import { unsafeHTML as x } from "lit/directives/unsafe-html.js";
import { unsafeStatic as A, literal as I, html as b } from "lit/static-html.js";
import { getCustomElementSuffix as R } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as O, highlightText as q } from "../../api/marker/marker.js";
import B from "../../api/marker/marker.style.css.js";
import { normalizeText as m } from "../../utils/helpers.js";
import { booleanType as d, booleanConverter as v } from "../../utils/property-types.js";
import V from "./searchbar.style.css.js";
import { template as U } from "./searchbar.template.js";
var M = Object.defineProperty, s = (D, t, o, a) => {
  for (var h = void 0, p = D.length - 1, u; p >= 0; p--)
    (u = D[p]) && (h = u(t, o, h) || h);
  return h && M(t, o, h), h;
};
const $ = I`dss-icon${A(R())}`, E = I`dss-chip${A(R())}`, T = class T extends z {
  constructor() {
    super(), this.value = "", this.multiple = !1, this.icon = "search", this.size = "lg", this.helpText = void 0, this.innerFocus = !1, this.threshold = 3, this.searchTerms = [], this.catalog = [], this.emptyDropdownText = "Sense resultats per", this.recentSearchesLabel = "Últimes cerques", this.recentSearches = !1, this.isCatalogLoading = !1, this.dropdownStyle = "", this.catalogStyle = "", this.advancedFilter = !1, this.placeholder = "Escriu per cercar", this._filter = "", this._isFocused = !1, this._showClearButton = !1, this._filteredCatalog = [], this._showAllChips = !1, this._showDropdown = !1, this._dropdownStyle = "", this.id = "", this.name = "", this.label = "Cercador", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this._defaultId = `dss-input-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [F(B), F(V)];
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value);
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _getSearchStyle() {
    return `top: ${this.renderRoot.querySelectorAll(".dss-search-bar")[0].offsetHeight + 4}px; ${this.dropdownStyle}`;
  }
  get _inputValidity() {
    var t;
    return this._input && this._input.value !== "" ? (t = this._input) == null ? void 0 : t.checkValidity() : !0;
  }
  _handleInput() {
    this.multiple || this._handleValidity(), this.value = this._input.value, this._filter = this._input.value;
    let t = this._input.value;
    t.length >= this.threshold ? (this._showDropdown = !0, this._filteredCatalog = this._getFilterCatalog(t), this.multiple && t.endsWith(",") && (t = t.slice(0, -1), this.searchTerms.push(t), this._input.value = "", this.searchTerms.length && this._dispatchSearchChange()), this._dropdownStyle = this._getSearchStyle()) : this._hideDropdown(), this._emitInput();
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0;
  }
  _handleFocusOut() {
    this._isFocused = !1, this._showClearButton = !1;
  }
  _handleKeyDown(t) {
    (t == null ? void 0 : t.key) === "Enter" ? (this._showDropdown = !0, !this.multiple && this._input.value !== "" && (this.searchTerms = [], this.searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1), this._dropdownStyle = this._getSearchStyle()) : (t == null ? void 0 : t.key) === "Escape" && (this._showDropdown = !1);
  }
  _focusInput() {
    var t;
    (t = this._input) == null || t.focus();
  }
  _handleValidity() {
    var o;
    const t = (o = this._input) == null ? void 0 : o.checkValidity();
    this.invalid = !t, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus()), this.searchTerms = [], this._dispatchSearchChange(), this._hideDropdown();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedFilter(t) : this._applyDefaultFilter(t);
  }
  _applyDefaultFilter(t) {
    const o = m(t);
    return this.catalog.filter((a) => m(a.value).includes(o));
  }
  _applyAdvancedFilter(t) {
    if (!m(t.trim())) return this.catalog;
    const a = m(t).split(/\s+/).filter((h) => h.length >= this.threshold);
    return a.length === 0 ? this.catalog : this.catalog.filter((h) => {
      const p = m(h.value);
      return a.every((u) => p.includes(u));
    });
  }
  _generateSearchChips() {
    let t = 0;
    return this.searchTerms.map((a) => {
      var g;
      const h = (S) => {
        const w = S.detail.text;
        this.searchTerms = this.searchTerms.filter((C) => C !== w), this._dispatchSearchChange();
      };
      t += 1;
      const p = {
        disabled: this.disabled || this.readonly,
        "dss-chip--selected": !this.disabled && !this.readonly,
        "dss-chip--hide": t > 5
      };
      return b`
				<${E}
 					class="${k(p)}"
					size="sm" 
					label="${a}" 
					selected 
					disableSelect
					hasdelete 
					?disabled=${(g = this._input) == null ? void 0 : g.disabled}
					@onDelete="${h}">
				</${E}>
      `;
    });
  }
  _generateFilterCatalog() {
    let t = !0;
    return this._filteredCatalog.map((a) => {
      const h = (r) => {
        const l = r.target.getAttribute("value");
        l && (this.multiple ? this.searchTerms.includes(l) ? this.searchTerms = this.searchTerms.filter((c) => c !== l) : this.searchTerms.push(l) : (this._input.value = l, this._showDropdown = !1, this.searchTerms = [], this.searchTerms.push(l)), this._dispatchSearchChange());
      }, p = (r) => {
        r && r.focus();
      }, u = (r) => {
        let l = 0;
        const n = this.renderRoot.querySelectorAll(".dss-catalog-item"), c = n.length - 1;
        r === n[0] ? p(n[c]) : (n.forEach((_, f) => {
          _ === r && (l = f);
        }), p(n[l - 1]));
      }, g = (r) => {
        let l = 0;
        const n = this.renderRoot.querySelectorAll(".dss-catalog-item"), c = n.length - 1;
        r === n[c] ? p(n[0]) : (n.forEach((_, f) => {
          _ === r && (l = f);
        }), p(n[l + 1]));
      }, S = (r) => {
        const l = r.currentTarget, n = r;
        let c = !1;
        switch (n.key) {
          case "ArrowUp":
            u(l), c = !0;
            break;
          case "ArrowDown":
            g(l), c = !0;
            break;
          case "Enter": {
            const _ = r.target, f = this.renderRoot.querySelector('.dss-catalog-item[tabindex="0"]');
            f == null || f.setAttribute("tabindex", "-1"), r.target.setAttribute("tabindex", "0"), _.click(), c = !0;
            break;
          }
        }
        c && (r.stopPropagation(), r.preventDefault());
      }, w = {
        "dss-catalog-item--selected": this.searchTerms.includes(a.value)
        // 'disabled': this._input?.disabled,
        // 'dss-chip--selected': !this._input?.disabled,
      }, C = b`
        <div
					role="option"
          class="dss-catalog-item ${k(w)}"
          value="${a.value}"
          tabindex="${t ? 0 : -1}"
          @click="${h}"
          @keydown=${S}
        >
          ${a.icon ? b`
								<${$}
									class="dss-catalog-item__icon"
									icon="${a.icon}"
									size="md"
									value="${a.value}"
								></${$}>
              ` : null}
          <div class="dss-catalog-item__text" value="${a.value}">
            ${this.advancedFilter ? x(O(a.value, this._filter, this.threshold)) : x(q(a.value, this._filter))}
					</div>
        </div>
      `;
      return t = !1, C;
    });
  }
  _dispatchSearchChange() {
    const t = {
      detail: this.searchTerms,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("search", t)), this.multiple ? this.value = this.searchTerms.toString() : this.value = this.searchTerms[0] || "", this._emitChange();
  }
  _emitInput() {
    !this._input || this.multiple || (this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 })), this._handleChange());
  }
  _handleChange() {
    !this._input || this.multiple || this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _closeDropdown() {
    document.addEventListener("mousedown", (t) => {
      t.target !== this && t.target !== this._input && (this._showDropdown = !1);
    }), document.addEventListener("focusout", (t) => {
      const o = t.relatedTarget;
      o !== null && o !== this && o !== this._input && (this._showDropdown = !1);
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._closeDropdown(), this._dropdownStyle = this._getSearchStyle());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return U(this);
  }
};
T.formAssociated = !0;
let e = T;
s([
  L("input.dss-input")
], e.prototype, "_input");
s([
  i({ type: String })
], e.prototype, "value");
s([
  i(d)
], e.prototype, "multiple");
s([
  i({ type: String })
], e.prototype, "icon");
s([
  i({ type: String })
], e.prototype, "size");
s([
  i({ type: String })
], e.prototype, "helpText");
s([
  i(d)
], e.prototype, "innerFocus");
s([
  i({ type: Number })
], e.prototype, "threshold");
s([
  i({ type: Array })
], e.prototype, "searchTerms");
s([
  i({ type: Array })
], e.prototype, "catalog");
s([
  i({ type: String })
], e.prototype, "emptyDropdownText");
s([
  i({ type: String })
], e.prototype, "recentSearchesLabel");
s([
  i(d)
], e.prototype, "recentSearches");
s([
  i(d)
], e.prototype, "isCatalogLoading");
s([
  i({ type: String })
], e.prototype, "dropdownStyle");
s([
  i({ type: String })
], e.prototype, "catalogStyle");
s([
  i(d)
], e.prototype, "advancedFilter");
s([
  i({ type: String })
], e.prototype, "placeholder");
s([
  y()
], e.prototype, "_filter");
s([
  y()
], e.prototype, "_isFocused");
s([
  y()
], e.prototype, "_showClearButton");
s([
  y()
], e.prototype, "_filteredCatalog");
s([
  y()
], e.prototype, "_showAllChips");
s([
  y()
], e.prototype, "_showDropdown");
s([
  y()
], e.prototype, "_dropdownStyle");
s([
  i({ type: String })
], e.prototype, "id");
s([
  i({ type: String })
], e.prototype, "name");
s([
  i({ type: String })
], e.prototype, "label");
s([
  i({ converter: v, reflect: !0 })
], e.prototype, "disabled");
s([
  i({ converter: v, reflect: !0 })
], e.prototype, "readonly");
s([
  i({ converter: v, reflect: !0 })
], e.prototype, "required");
s([
  i({ converter: v, reflect: !0 })
], e.prototype, "invalid");
s([
  i({ type: String })
], e.prototype, "pattern");
s([
  i({ type: String })
], e.prototype, "inputmode");
s([
  i({ type: String })
], e.prototype, "autocapitalize");
s([
  i({ type: String })
], e.prototype, "autocomplete");
s([
  i(d)
], e.prototype, "autocorrect");
s([
  i(d)
], e.prototype, "autofocus");
s([
  i(d)
], e.prototype, "spellcheck");
export {
  e as SearchBar_
};
//# sourceMappingURL=searchbar.js.map
