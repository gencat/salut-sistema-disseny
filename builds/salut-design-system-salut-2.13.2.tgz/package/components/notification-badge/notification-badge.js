import { LitElement as y, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import { booleanType as i } from "../../utils/property-types.js";
import u from "./notification-badge.style.css.js";
import { template as d } from "./notification-badge.template.js";
var m = Object.defineProperty, e = (p, n, a, h) => {
  for (var o = void 0, s = p.length - 1, f; s >= 0; s--)
    (f = p[s]) && (o = f(n, a, o) || o);
  return o && m(n, a, o), o;
};
class r extends y {
  constructor() {
    super(...arguments), this.icon = void 0, this.value = "", this.state = "default", this.type = "default", this.dot = !1, this.menu = !1, this.borderMenu = !1, this.borderWhite = !1, this.isHover = !1, this.isActive = !1;
  }
  static get styles() {
    return [l(u)];
  }
  render() {
    return d(this);
  }
}
e([
  t({ type: String })
], r.prototype, "icon");
e([
  t({ type: String })
], r.prototype, "value");
e([
  t({ type: String })
], r.prototype, "state");
e([
  t({ type: String })
], r.prototype, "type");
e([
  t(i)
], r.prototype, "dot");
e([
  t(i)
], r.prototype, "menu");
e([
  t(i)
], r.prototype, "borderMenu");
e([
  t(i)
], r.prototype, "borderWhite");
e([
  t(i)
], r.prototype, "isHover");
e([
  t(i)
], r.prototype, "isActive");
export {
  r as NotificationBadge
};
//# sourceMappingURL=notification-badge.js.map
