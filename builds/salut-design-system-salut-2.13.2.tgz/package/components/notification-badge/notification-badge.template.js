import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as r, literal as b, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as f } from "../../api/custom-element-scope.js";
const t = b`dss-icon${r(f())}`, u = (i) => {
  const e = {
    "dss-notification-badge--border-white": i.borderWhite,
    "dss-notification-badge--dot": i.dot,
    "dss-notification-badge--info": i.state === "info",
    "dss-notification-badge--error": i.state === "error",
    "dss-notification-badge--alert": i.state === "alert",
    "dss-notification-badge--success": i.state === "success",
    "dss-notification-badge--border-menu": i.borderMenu,
    "dss-notification-badge--hover": (i.borderMenu || i.borderWhite) && i.isHover,
    "dss-notification-badge--active": (i.borderMenu || i.borderWhite) && i.isActive,
    "dss-notification-badge--brand": i.type === "brand"
  };
  let s;
  return !i.dot && i.icon ? s = a`<${t} size="sm" icon="${i.icon}"></${t}>` : !i.dot && i.value ? s = a`<span class="dss-notification-badge-value"
      >${i.value}</span
    >` : s = null, a`
    <div class="dss-notification-badge ${d(e)}">
      ${s}
    </div>
  `;
};
export {
  u as template
};
//# sourceMappingURL=notification-badge.template.js.map
