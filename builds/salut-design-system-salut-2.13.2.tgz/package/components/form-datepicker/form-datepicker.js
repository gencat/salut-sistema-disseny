import { createPopper as S } from "@popperjs/core";
import { LitElement as T, unsafeCSS as c } from "lit";
import { query as v, property as a, state as _ } from "lit/decorators.js";
import D from "../../shared/reset.style.css.js";
import { booleanType as l, booleanConverter as u } from "../../utils/property-types.js";
import k from "../form-input/form-input.style.css.js";
import O from "./form-datepicker.style.css.js";
import { template as L } from "./form-datepicker.template.js";
var V = Object.defineProperty, i = (f, t, s, r) => {
  for (var o = void 0, n = f.length - 1, h; n >= 0; n--)
    (h = f[n]) && (o = h(t, s, o) || o);
  return o && V(t, s, o), o;
};
const y = class y extends T {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "calendar_today", this.showCalendar = !1, this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.showTime = !1, this.showButtons = !1, this.leftLabel = "Cancel·lar", this.rightLabel = "Seleccionar", this.minDate = "", this.maxDate = "", this.timepicker = "", this.timepickerLabel = "Selecciona una hora", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this.customCalendar = void 0, this.customTimeListOptions = [], this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this.tooltipFixed = !1, this.forceViewport = !1, this._defaultId = `dss-datepicker-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._externalPlaceholder = "", this._previousDate = "", this._inputValidity = !0, this._popperInstance = null, this._placeholder = "", this._helpText = "", this._helpTextBackup = "", this._oldHelpText = "", this._isFirstUpdated = !0, this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [c(D), c(k), c(O)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeCalendarListener();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._helpTextBackup = this.helpText ?? "", this._createPopperCalendar(), this._input.classList.add("dss-input-skip-native"), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value), t.has("placeholder") && (this._placeholder = this.placeholder, this._externalPlaceholder = this.placeholder), t.has("showTime") && this.showTime && (this.showButtons = !0), t.has("helpText") && queueMicrotask(() => {
      this._helpText = this.helpText ?? "", this._oldHelpText = this.helpText ?? "";
    });
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  render() {
    return L(this);
  }
  /* Handle Input Events */
  _handleInput(t) {
    var r;
    const s = (r = t.target.value) == null ? void 0 : r.replace(/\D/g, "");
    this._input && (this._input.value = this._formatDate(s), this.value = this._formatDate(s), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _handleFocusin() {
    var t;
    this._isFocused || this.readonly || (this._externalPlaceholder !== "" ? this._placeholder = this._externalPlaceholder : this._placeholder = this.showTime ? "DD/MM/AAAA HH:MM" : "DD/MM/AAAA", (t = this._input) == null || t.setAttribute("placeholder", this._placeholder), this.showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this._isFocused = !0);
  }
  _focusInput() {
    var t;
    !this.disabled && !this.readonly && ((t = this._input) == null || t.focus());
  }
  _handleKeydown(t) {
    var s, r, o, n, h;
    if ((t == null ? void 0 : t.key) === "Tab" ? (this._isFocused = !0, this._checkInputOverflow()) : (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this.showCalendar = !0, this._popperInstance.update(), this._checkInputOverflow(), this._addCalendarListener()) : (t == null ? void 0 : t.key) === "Escape" && this._closeCalendar(), t.key === "Enter" && this._input && ((s = this._input.value) == null ? void 0 : s.length) > 7 && this._input) {
      const d = (r = this._input.value) == null ? void 0 : r.replace(/(\d+[/])(\d+[/])/, "$2$1"), p = new Date(d), g = (o = p.getDate()) == null ? void 0 : o.toString().padStart(2, "0"), b = (p.getMonth() + 1).toString().padStart(2, "0"), C = p.getFullYear(), x = (n = p.getHours()) == null ? void 0 : n.toString().padStart(2, "0"), w = (h = p.getMinutes()) == null ? void 0 : h.toString().padStart(2, "0");
      let m = `${g}/${b}/${C}`;
      this.showTime && (m += ` ${x}:${w}`, this._handleValidity()), this._input && (this._input.value = m), this._dispatchValueChange(), this.showCalendar ? this._closeCalendar() : this.requestUpdate();
    }
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), s = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, o = document.createElement("canvas").getContext("2d");
    if (!o) return;
    o.font = s;
    const n = o.measureText(this._input.value).width;
    this._isTruncated = n > this._input.offsetWidth;
  }
  /* Hamdle Datepicker Validations */
  _handleValidity() {
    var s;
    const t = (s = this._input) == null ? void 0 : s.checkValidity();
    t !== void 0 && (this._inputValidity = t), this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _validateDate() {
    var s;
    const t = this._checkDateFormat((s = this._input) == null ? void 0 : s.value);
    t ? (this._input.setCustomValidity(this._helpText), this.internals.setValidity({ customError: !0 }, this._helpText, this._input)) : (this._input.setCustomValidity(""), this.internals.setValidity({})), this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    const s = this.showTime ? 16 : 10;
    if (t === "")
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t.length < s)
      return this._helpText = this.errorMessageFormat, this.invalid = !0, !0;
    if (this.minDate || this.maxDate) {
      const r = this.showTime ? t.substring(0, 10) : t, o = new Date(this._convertToISO(r)), n = new Date(this._convertToISO(this.minDate)), h = new Date(this._convertToISO(this.maxDate));
      if (n && o < n)
        return this._helpText = this.errorMessageMinDate, this.invalid = !0, !0;
      if (h && o > h)
        return this._helpText = this.errorMessageMaxDate, this.invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
  }
  _convertToISO(t) {
    const [s, r, o] = t.split("/");
    return `${o}-${r}-${s}`;
  }
  _dispatchOnValidate(t) {
    var r;
    const s = {
      detail: {
        date: (r = this._input) == null ? void 0 : r.value,
        invalid: t,
        status: this.invalid ? "INVALID" : "VALID"
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("value-changed", s));
  }
  // Datepicker specific methods
  _formatDate(t) {
    let s = t.substring(0, 2), r = t.substring(2, 4);
    const o = t.substring(4, 8);
    let n = t.substring(8, 10), h = t.substring(10, 12);
    Number(s) > 3 && (s = s == null ? void 0 : s.padStart(2, "0")), Number(r) > 1 && (r = r == null ? void 0 : r.padStart(2, "0")), Number(s) > 31 && (s = "31"), Number(r) > 12 && (r = "12"), r === "02" && Number(s) > 28 && (o == null ? void 0 : o.length) === 4 && (s = new Date(Number(o), 1, 29).getMonth() === 1 ? "29" : "28");
    let d = `${s}${r ? `/${r}` : ""}${o ? `/${o}` : ""}`;
    return this.showTime && (Number(n) > 2 && (n = n == null ? void 0 : n.padStart(2, "0")), Number(n) > 23 && (n = "23"), Number(h) > 5 && (h = h == null ? void 0 : h.padStart(2, "0")), d = `${d}${n ? ` ${n}` : ""}${h ? `:${h}` : ""}`), d;
  }
  _onDateChange(t) {
    const s = t.detail;
    this._input && (this._input.value = s, this.value = s, this._handleValidity()), this._closeCalendar(), this._dispatchValueChange();
  }
  _onCancel() {
    this._closeCalendar(), this._input && (this._input.value = this._previousDate || "", this._handleValidity()), this.requestUpdate();
  }
  _dispatchValueChange() {
    this._emitInput(), this._emitChange();
  }
  _clearDate() {
    this._input && (this._input.value = "", this._input.setCustomValidity(""), this.internals.setValidity({}), this.value = "", this._handleValidity(), this._helpText = this._helpTextBackup, this.invalid = this._input ? !this._input.checkValidity() : !1, this._dispatchValueChange(), this.requestUpdate());
  }
  /* Handle Popper */
  _createPopperCalendar() {
    var r, o;
    const t = (r = this.shadowRoot) == null ? void 0 : r.querySelector(".dss-input-group"), s = (o = this.shadowRoot) == null ? void 0 : o.querySelector(".dss-calendar");
    t && s && (this._popperInstance = S(t, s, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  _closeCalendar() {
    var t, s;
    this._removeCalendarListener(), (t = this._input) == null || t.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this.showCalendar = !1, (s = this._input) == null || s.blur(), this.validate && this._validateDate(), this._checkInputOverflow(), this.requestUpdate();
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this.showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const s = t.relatedTarget;
    s !== null && s !== this && s !== this._input && s !== this._label && this.showCalendar && this._closeCalendar();
  }
};
y.formAssociated = !0;
let e = y;
i([
  v("input.dss-input")
], e.prototype, "_input");
i([
  v("label.dss-label")
], e.prototype, "_label");
i([
  a({ type: String })
], e.prototype, "label");
i([
  a(l)
], e.prototype, "hideLabel");
i([
  a({ type: String })
], e.prototype, "name");
i([
  a({ type: String })
], e.prototype, "id");
i([
  a({ type: String })
], e.prototype, "type");
i([
  a({ type: String })
], e.prototype, "placeholder");
i([
  a({ type: String })
], e.prototype, "value");
i([
  a({ converter: u, reflect: !0 })
], e.prototype, "disabled");
i([
  a({ converter: u, reflect: !0 })
], e.prototype, "readonly");
i([
  a({ converter: u, reflect: !0 })
], e.prototype, "required");
i([
  a({ converter: u, reflect: !0 })
], e.prototype, "invalid");
i([
  a({ type: Number })
], e.prototype, "step");
i([
  a({ type: Number })
], e.prototype, "min");
i([
  a({ type: Number })
], e.prototype, "max");
i([
  a({ type: Number })
], e.prototype, "minLength");
i([
  a({ type: String })
], e.prototype, "pattern");
i([
  a({ type: String })
], e.prototype, "inputmode");
i([
  a({ type: String })
], e.prototype, "autocapitalize");
i([
  a({ type: String })
], e.prototype, "autocomplete");
i([
  a(l)
], e.prototype, "autocorrect");
i([
  a(l)
], e.prototype, "autofocus");
i([
  a(l)
], e.prototype, "spellcheck");
i([
  a({ type: String })
], e.prototype, "size");
i([
  a({ type: String })
], e.prototype, "icon");
i([
  a({ type: String })
], e.prototype, "helpText");
i([
  a(l)
], e.prototype, "showCalendar");
i([
  a({ type: String })
], e.prototype, "dropdownPlacement");
i([
  a(l)
], e.prototype, "dropdownFixed");
i([
  a(l)
], e.prototype, "showTime");
i([
  a(l)
], e.prototype, "showButtons");
i([
  a({ type: String })
], e.prototype, "leftLabel");
i([
  a({ type: String })
], e.prototype, "rightLabel");
i([
  a({ type: String })
], e.prototype, "minDate");
i([
  a({ type: String })
], e.prototype, "maxDate");
i([
  a({ type: String })
], e.prototype, "timepicker");
i([
  a({ type: String })
], e.prototype, "timepickerLabel");
i([
  a({ type: Number })
], e.prototype, "minHour");
i([
  a({ type: Number })
], e.prototype, "maxHour");
i([
  a({ type: Number })
], e.prototype, "minutesRange");
i([
  a({ type: Array })
], e.prototype, "customCalendar");
i([
  a({ type: Array })
], e.prototype, "customTimeListOptions");
i([
  a(l)
], e.prototype, "validate");
i([
  a(l)
], e.prototype, "errorMessageFormat");
i([
  a(l)
], e.prototype, "errorMessageMinDate");
i([
  a(l)
], e.prototype, "errorMessageMaxDate");
i([
  a(l)
], e.prototype, "tooltipFixed");
i([
  a(l)
], e.prototype, "forceViewport");
i([
  _()
], e.prototype, "_isFocused");
i([
  _()
], e.prototype, "_isTruncated");
i([
  _()
], e.prototype, "_helpText");
export {
  e as FormDatepicker
};
//# sourceMappingURL=form-datepicker.js.map
