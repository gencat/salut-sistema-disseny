import { LitElement as p, unsafeCSS as l } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as n } from "../../utils/property-types.js";
import u from "./accordion.style.css.js";
import { template as y } from "./accordion.template.js";
var g = Object.defineProperty, _ = Object.getOwnPropertyDescriptor, o = (c, t, e, a) => {
  for (var r = a > 1 ? void 0 : a ? _(t, e) : t, d = c.length - 1, h; d >= 0; d--)
    (h = c[d]) && (r = (a ? h(t, e, r) : h(r)) || r);
  return a && r && g(t, e, r), r;
};
class s extends p {
  constructor() {
    super(...arguments), this.hideTooltip = !1, this.info = void 0, this.infoBadgeState = "critic", this.infoBadgeIcon = "", this.infoBadgeOutlined = !0, this.tooltipFixed = !1, this.tooltipPosition = "top", this.secondaryActionLabel = "", this.secondaryActionFill = !1, this.hasPrimaryAction = !1, this.primaryActionLabel = "", this.primaryActionIcon = "", this.primaryActionStatus = "neutral", this.primaryActionDisabled = !1, this.primaryActionFill = !1, this.forceViewport = !1, this.helpText = null, this._icon = "", this._iconStatus = "default", this._type = "", this._title = "", this._index = void 0, this._isOpen = !1, this._results = void 0, this._resultsText = "Resultats", this._resultsState = "neutral", this._accordionStyle = "box", this._hasCheckbox = !1, this._hasSecondaryAction = !1, this._secondaryActionIcon = "add_box", this._secondaryActionStatus = "primary", this._secondaryActionDisabled = !1, this._notificationsState = "default", this._notifications = void 0, this._widget = !1, this._widgetBadgeState = "neutral", this._widgetBadgeText = void 0, this._widgetShowNext = !1, this._widgetShowClose = !1;
  }
  static get styles() {
    return [l(u)];
  }
  get _checkbox() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="checkbox"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set iconStatus(t) {
    const e = this._iconStatus;
    this._iconStatus = t, this.requestUpdate("iconStatus", e);
  }
  get iconStatus() {
    return this._iconStatus;
  }
  set titleText(t) {
    const e = this._title;
    this._title = t, this.requestUpdate("title", e);
  }
  get titleText() {
    return this._title;
  }
  set type(t) {
    const e = this._type;
    this._type = t, this.requestUpdate("type", e);
  }
  get type() {
    return this._type;
  }
  set index(t) {
    const e = this._index;
    this._index = t, this.requestUpdate("index", e);
  }
  get index() {
    return this._index || 0;
  }
  set isOpen(t) {
    const e = this._isOpen;
    this._isOpen = t, this.requestUpdate("disabled", e);
  }
  get isOpen() {
    return this._isOpen;
  }
  set accordionStyle(t) {
    const e = this._accordionStyle;
    t === "inner" ? this._accordionStyle = t : this._accordionStyle = "box", this.requestUpdate("accordionStyle", e);
  }
  get accordionStyle() {
    return this._accordionStyle;
  }
  set results(t) {
    const e = this._results;
    this._results = t, this.requestUpdate("results", e);
  }
  get results() {
    return this._results || 0;
  }
  set resultsText(t) {
    const e = this._resultsText;
    this._resultsText = t, this.requestUpdate("resultsText", e);
  }
  get resultsText() {
    return this._resultsText;
  }
  set hasCheckbox(t) {
    const e = this._hasCheckbox;
    this._hasCheckbox = t, this.requestUpdate("hasCheckbox", e);
  }
  get hasCheckbox() {
    return this._hasCheckbox;
  }
  set hasSecondaryAction(t) {
    const e = this._hasSecondaryAction;
    this._hasSecondaryAction = t, this.requestUpdate("hasSecondaryAction", e);
  }
  get hasSecondaryAction() {
    return this._hasSecondaryAction;
  }
  set secondaryActionIcon(t) {
    const e = this._secondaryActionIcon;
    this._secondaryActionIcon = t, this.requestUpdate("secondaryActionIcon", e);
  }
  get secondaryActionIcon() {
    return this._secondaryActionIcon;
  }
  set secondaryActionStatus(t) {
    const e = this._secondaryActionStatus;
    this._secondaryActionStatus = t, this.requestUpdate("secondaryActionStatus", e);
  }
  get secondaryActionStatus() {
    return this._secondaryActionStatus;
  }
  set secondaryActionDisabled(t) {
    const e = this._secondaryActionDisabled;
    this._secondaryActionDisabled = t, this.requestUpdate("secondaryActionDisabled", e);
  }
  get secondaryActionDisabled() {
    return this._secondaryActionDisabled;
  }
  set resultsState(t) {
    const e = this._resultsState;
    this._resultsState = t, this.requestUpdate("resultsState", e);
  }
  get resultsState() {
    return this._resultsState;
  }
  set notificationsState(t) {
    const e = this._notificationsState;
    this._notificationsState = t, this.requestUpdate("notificationsState", e);
  }
  get notificationsState() {
    return this._notificationsState;
  }
  set notifications(t) {
    const e = this._notificationsState;
    this._notifications = t, this.requestUpdate("notifications", e);
  }
  get notifications() {
    return this._notifications || 0;
  }
  set widget(t) {
    const e = this._widget;
    this._widget = t, this.requestUpdate("widget", e);
  }
  get widget() {
    return this._widget;
  }
  set widgetBadgeState(t) {
    const e = this._widgetBadgeState;
    this._widgetBadgeState = t, this.requestUpdate("widgetBadgeState", e);
  }
  get widgetBadgeState() {
    return this._widgetBadgeState;
  }
  set widgetBadgeText(t) {
    const e = this._widgetBadgeText;
    this._widgetBadgeText = t, this.requestUpdate("widgetBadgeText", e);
  }
  get widgetBadgeText() {
    return this._widgetBadgeText || "";
  }
  set widgetShowNext(t) {
    const e = this._widgetShowNext;
    this._widgetShowNext = t, this.requestUpdate("widgetShowNext", e);
  }
  get widgetShowNext() {
    return this._widgetShowNext;
  }
  set widgetShowClose(t) {
    const e = this._widgetShowClose;
    this._widgetShowClose = t, this.requestUpdate("widgetShowClose", e);
  }
  get widgetShowClose() {
    return this._widgetShowClose;
  }
  _toggleAccordion() {
    this._isOpen = !this._isOpen, this._dispatchToggleAccordion(), this.requestUpdate();
  }
  _dispatchCheckboxChange() {
    const t = {
      detail: this._checkbox.checked,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onAccordionCheckboxChange", t));
  }
  _dispatchSecondaryAction() {
    const t = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onAccordionSecondaryAction", t));
  }
  _dispatchPrimaryAction() {
    this.dispatchEvent(new Event("onPrimaryAction"));
  }
  _dispatchToggleAccordion() {
    const t = {
      detail: this._isOpen,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onToggleAccordion", t));
  }
  _dispatchWidgetNext() {
    const t = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onWidgetNext", t));
  }
  _dispatchWidgetClose() {
    const t = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onWidgetClose", t));
  }
  // checkTextTruncate(event: MouseEvent) {
  // 	if (!event) return;
  // 	const target = event.target as HTMLElement;
  // 	const isTruncated = target.scrollWidth > target.offsetWidth;
  // 	target.setAttribute('data-truncated', isTruncated.toString());
  // }
  render() {
    return y(this);
  }
}
o([
  i(n)
], s.prototype, "hideTooltip", 2);
o([
  i({ type: String })
], s.prototype, "info", 2);
o([
  i({ type: String })
], s.prototype, "infoBadgeState", 2);
o([
  i({ type: String })
], s.prototype, "infoBadgeIcon", 2);
o([
  i(n)
], s.prototype, "infoBadgeOutlined", 2);
o([
  i(n)
], s.prototype, "tooltipFixed", 2);
o([
  i({ type: String })
], s.prototype, "tooltipPosition", 2);
o([
  i({ type: String })
], s.prototype, "secondaryActionLabel", 2);
o([
  i(n)
], s.prototype, "secondaryActionFill", 2);
o([
  i(n)
], s.prototype, "hasPrimaryAction", 2);
o([
  i({ type: String })
], s.prototype, "primaryActionLabel", 2);
o([
  i({ type: String })
], s.prototype, "primaryActionIcon", 2);
o([
  i({ type: String })
], s.prototype, "primaryActionStatus", 2);
o([
  i(n)
], s.prototype, "primaryActionDisabled", 2);
o([
  i(n)
], s.prototype, "primaryActionFill", 2);
o([
  i(n)
], s.prototype, "forceViewport", 2);
o([
  i({ type: String })
], s.prototype, "helpText", 2);
o([
  i({ type: String })
], s.prototype, "icon", 1);
o([
  i({ type: String })
], s.prototype, "iconStatus", 1);
o([
  i({ type: String })
], s.prototype, "titleText", 1);
o([
  i({ type: String })
], s.prototype, "type", 1);
o([
  i({ type: Number })
], s.prototype, "index", 1);
o([
  i(n)
], s.prototype, "isOpen", 1);
o([
  i({ type: String })
], s.prototype, "accordionStyle", 1);
o([
  i({ type: Number })
], s.prototype, "results", 1);
o([
  i({ type: String })
], s.prototype, "resultsText", 1);
o([
  i(n)
], s.prototype, "hasCheckbox", 1);
o([
  i(n)
], s.prototype, "hasSecondaryAction", 1);
o([
  i({ type: String })
], s.prototype, "secondaryActionIcon", 1);
o([
  i({ type: String })
], s.prototype, "secondaryActionStatus", 1);
o([
  i(n)
], s.prototype, "secondaryActionDisabled", 1);
o([
  i({ type: String })
], s.prototype, "resultsState", 1);
o([
  i({ type: String })
], s.prototype, "notificationsState", 1);
o([
  i({ type: Number })
], s.prototype, "notifications", 1);
o([
  i({ type: Boolean })
], s.prototype, "widget", 1);
o([
  i({ type: String })
], s.prototype, "widgetBadgeState", 1);
o([
  i({ type: String })
], s.prototype, "widgetBadgeText", 1);
o([
  i({ type: Boolean })
], s.prototype, "widgetShowNext", 1);
o([
  i({ type: Boolean })
], s.prototype, "widgetShowClose", 1);
export {
  s as Accordion
};
//# sourceMappingURL=accordion.js.map
