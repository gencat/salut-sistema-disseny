import { createPopper as d } from "@popperjs/core";
import { LitElement as f, unsafeCSS as h } from "lit";
import { property as o } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./tooltip.style.css.js";
import { template as b } from "./tooltip.template.js";
var v = Object.defineProperty, i = (n, t, e, a) => {
  for (var p = void 0, l = n.length - 1, c; l >= 0; l--)
    (c = n[l]) && (p = c(t, e, p) || p);
  return p && v(t, e, p), p;
};
class s extends f {
  constructor() {
    super(...arguments), this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        if (e.type === "attributes" && e.attributeName === "data-popper-placement") {
          const a = this.getAttribute("data-popper-placement");
          a && this._propagatePlacement(a);
        }
    }, this.observer = new MutationObserver(this.callback), this.position = "top", this.align = "left", this.hide = !1, this.noHeightLimit = !1, this.tooltipFixed = !1, this.interactive = !1, this.forceViewport = !1, this._popperInstance = null;
  }
  static get styles() {
    return [h(u), h(m)];
  }
  connectedCallback() {
    super.connectedCallback();
    const t = this.parentElement;
    t && this.createPopperInstance(t);
  }
  disconnectedCallback() {
    this.observer.disconnect(), this._popperInstance && (this._popperInstance.destroy(), this._popperInstance = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.observer.observe(this, this.observerConfig);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    super.updated(t), t.has("position") && this._popperInstance && this._popperInstance.setOptions({
      placement: this.position
    });
  }
  _getPopperStrategy() {
    return this.tooltipFixed ? "fixed" : "absolute";
  }
  _getPopperModifiers() {
    const t = [
      {
        name: "offset",
        options: {
          offset: [0, 8]
        }
      }
    ];
    return this.forceViewport ? [
      ...t,
      {
        name: "preventOverflow",
        options: {
          boundary: "viewport",
          rootBoundary: "viewport",
          altBoundary: !0,
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        }
      },
      {
        name: "flip",
        options: {
          boundary: "viewport",
          rootBoundary: "viewport",
          altBoundary: !0
        }
      }
    ] : [
      ...t,
      {
        name: "preventOverflow",
        options: {
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        }
      }
    ];
  }
  createPopperInstance(t) {
    this._popperInstance = d(t, this, {
      placement: this.position,
      strategy: this._getPopperStrategy(),
      modifiers: this._getPopperModifiers(),
      onFirstUpdate: (e) => {
        this._propagatePlacement(e.placement);
      }
    }), t.addEventListener("mouseenter", () => {
      this._openTooltip();
    }), t.addEventListener("mouseleave", () => {
      this._closeTooltip();
    }), t.addEventListener("focusin", () => {
      this.classList.contains("visible") || this._openTooltip();
    }), t.addEventListener("focusout", () => {
      this.classList.contains("visible") && this._closeTooltip();
    });
  }
  _onMouseEnter(t) {
    this.interactive || (t.stopPropagation(), t.preventDefault(), this._closeTooltip(), this.style.pointerEvents = "none");
  }
  _openTooltip() {
    var t;
    (t = this._popperInstance) == null || t.update(), this.classList.add("visible");
  }
  _closeTooltip() {
    this.classList.remove("visible");
  }
  _propagatePlacement(t) {
    const e = this.renderRoot.querySelector(".dss-tooltip-box");
    e && e.setAttribute("data-popper-placement", t);
  }
  updateTooltip() {
    this._popperInstance.update();
  }
  render() {
    return b(this);
  }
}
i([
  o({ type: String })
], s.prototype, "position");
i([
  o({ type: String })
], s.prototype, "align");
i([
  o(r)
], s.prototype, "hide");
i([
  o(r)
], s.prototype, "noHeightLimit");
i([
  o(r)
], s.prototype, "tooltipFixed");
i([
  o(r)
], s.prototype, "interactive");
i([
  o(r)
], s.prototype, "forceViewport");
export {
  s as Tooltip
};
//# sourceMappingURL=tooltip.js.map
