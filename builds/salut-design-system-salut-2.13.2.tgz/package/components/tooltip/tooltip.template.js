import { classMap as s } from "lit/directives/class-map.js";
import { html as o } from "lit/static-html.js";
const d = (t) => {
  const i = {
    "dss-tooltip": !0,
    [`dss-tooltip--${t.position}`]: !!t.position,
    [`dss-tooltip--align-${t.align}`]: !!t.align,
    "dss-tooltip--hidden": t.hide,
    "dss-tooltip--no-height-limit": t.noHeightLimit
  };
  return o`
    <div 
			class="${s(i)}"
			@mouseenter="${t._onMouseEnter}"
		>
      <slot></slot>
    </div>
  `;
};
export {
  d as template
};
//# sourceMappingURL=tooltip.template.js.map
