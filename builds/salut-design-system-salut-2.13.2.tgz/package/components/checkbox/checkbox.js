import { LitElement as p, unsafeCSS as o } from "lit";
import { property as c } from "lit/decorators.js";
import l from "../../foundations/icon/icon.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import _ from "./checkbox.style.css.js";
import { template as f } from "./checkbox.template.js";
var b = Object.defineProperty, m = Object.getOwnPropertyDescriptor, a = (n, e, t, s) => {
  for (var i = s > 1 ? void 0 : s ? m(e, t) : e, h = n.length - 1, r; h >= 0; h--)
    (r = n[h]) && (i = (s ? r(e, t, i) : r(i)) || i);
  return s && i && b(e, t, i), i;
};
class d extends p {
  constructor() {
    super(...arguments), this.variant = "default", this.indeterminate = !1, this._checked = !1, this._isCheckedPropDefined = !1, this._isFirstUpdate = !0, this._disabled = !1, this._readonly = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [o(l), o(_)];
  }
  get _input() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  get _label() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="label"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  set checked(e) {
    const t = this._checked;
    this._checked = e, this._isCheckedPropDefined = !0, this._isFirstUpdate || this._dispatchChange(), this.requestUpdate("checked", t);
  }
  get checked() {
    return this._checked;
  }
  disconnectedCallback() {
    this.observer.disconnect(), this._input.removeEventListener("change", this._handleChange.bind(this));
  }
  /* END Input Observer */
  _checkInputAttributes() {
    var s, i, h;
    if (!this._isCheckedPropDefined) {
      const r = (s = this._input) == null ? void 0 : s.getAttribute("checked");
      this._checked = r !== null;
    }
    const e = (i = this._input) == null ? void 0 : i.getAttribute("disabled");
    this._disabled = e !== null;
    const t = (h = this._input) == null ? void 0 : h.getAttribute("readonly");
    this._readonly = t !== null;
  }
  _handleChange() {
    var e;
    this._checked = (e = this._input) == null ? void 0 : e.checked, this._dispatchChange();
  }
  _dispatchChange() {
    this.dispatchEvent(
      new CustomEvent("onChange", {
        detail: this._checked,
        bubbles: !0,
        composed: !0
      })
    );
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._checked && (this._input.checked = !0), this.indeterminate && (this._input.indeterminate = !0), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this._input.addEventListener("change", this._handleChange.bind(this))), this._isFirstUpdate = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(e) {
    const t = e.has("indeterminate"), s = e.has("checked");
    this._input && t && (this._input.indeterminate = this.indeterminate), this._input && s && (this._input.checked = this.checked);
  }
  render() {
    return f(this);
  }
}
a([
  c({ type: String })
], d.prototype, "variant", 2);
a([
  c(u)
], d.prototype, "indeterminate", 2);
a([
  c(u)
], d.prototype, "checked", 1);
export {
  d as Checkbox
};
//# sourceMappingURL=checkbox.js.map
