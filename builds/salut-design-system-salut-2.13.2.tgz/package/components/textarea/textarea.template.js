import { nothing as e } from "lit";
import { classMap as $ } from "lit/directives/class-map.js";
import { unsafeStatic as y, literal as c, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as q } from "../../api/custom-element-scope.js";
const f = c`dss-icon${y(q())}`, o = (a) => {
  var t, r, d, i, l, _, x, u, g, h, v;
  const b = {
    "dss-textarea--invalid": a._showError,
    "dss-textarea--auto-height": a.autoHeight,
    "dss-textarea--disabled": (t = a._textarea) == null ? void 0 : t.disabled,
    "dss-textarea--gap": a._maxLength || !!a._description || a.size !== "sm",
    "dss-textarea--gap-sm": a.size === "sm",
    "dss-textarea--required": (r = a._textarea) == null ? void 0 : r.required,
    "dss-textarea--empty-description": !a._maxLength && !a._description,
    [`dss-textarea--${a.size}`]: !!a.size
  }, z = {
    "dss-textarea__group--focused": ((d = a._textarea) == null ? void 0 : d.value) || a._isTextareaFocused || ((i = a._textarea) == null ? void 0 : i.placeholder),
    // 'dss-textarea__group--focused-visible': true,
    "dss-textarea__group--focused-visible": a._isGroupFocusedVisible,
    [`dss-textarea__group--${a.size}`]: !!a.size,
    "dss-textarea__group--has-label": !!a._label,
    "dss-textarea__group--required": (l = a._textarea) == null ? void 0 : l.required,
    "dss-textarea__group--readOnly": (_ = a._textarea) == null ? void 0 : _.readOnly,
    "dss-textarea__group--read-only-empty": ((x = a._textarea) == null ? void 0 : x.readOnly) && ((u = a._textarea) == null ? void 0 : u.placeholder) === "" && !((g = a._textarea) != null && g.value)
  };
  return s`
     
    <div class="dss-textarea ${$(b)}">
      ${a.size === "sm" ? s`
          <div class="dss-textarea-label">
            <slot name="label"></slot>
          </div>
        ` : e}

      <div class="dss-textarea__group ${$(z)}">
        ${a.icon ? s`
            <${f} icon="${a.icon}" class="dss-textarea-icon"></${f}>
          ` : e}
        <div class="dss-textarea__content">
          ${a.size !== "sm" ? s`
            <slot name="label"></slot>
            ` : e}
          <slot
            name="textarea"
            @focusin=${a._handleFocus}
            @focusout=${a._handleFocusOut}
          ></slot>
        </div>
      </div>
      <div class="dss-textarea__help">
        <div class="dss-textarea__description">
          <slot
            name="description"
            @slotchange=${a._handleSlotChange}
          ></slot>
        </div>
        ${a._maxLength ? s`<span
              >${(v = (h = a._textarea) == null ? void 0 : h.value) == null ? void 0 : v.length}/${a._maxLength}</span
            >` : null}
      </div>
    </div>
  `;
};
export {
  o as template
};
//# sourceMappingURL=textarea.template.js.map
