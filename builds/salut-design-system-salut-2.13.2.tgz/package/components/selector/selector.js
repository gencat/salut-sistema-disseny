import { LitElement as C, unsafeCSS as k } from "lit";
import { property as r } from "lit/decorators.js";
import { classMap as $ } from "lit/directives/class-map.js";
import { ifDefined as T } from "lit/directives/if-defined.js";
import { unsafeStatic as x, literal as I, html as n } from "lit/static-html.js";
import { getCustomElementSuffix as O } from "../../api/custom-element-scope.js";
import R from "../../foundations/icon/icon.style.css.js";
import N from "../../shared/scrollbar.style.css.js";
import { booleanType as p, selectedType as P } from "../../utils/property-types.js";
import F from "./selector.style.css.js";
import { unsafeHTML as D } from "lit/directives/unsafe-html.js";
import { highlightTextMultiple as M, highlightText as j } from "../../api/marker/marker.js";
import z from "../../api/marker/marker.style.css.js";
var H = Object.defineProperty, B = Object.getOwnPropertyDescriptor, a = (E, e, t, l) => {
  for (var s = l > 1 ? void 0 : l ? B(e, t) : e, i = E.length - 1, o; i >= 0; i--)
    (o = E[i]) && (s = (l ? o(e, t, s) : o(s)) || s);
  return l && s && H(e, t, s), s;
};
const G = I`dss-spinner${x(O())}`;
class c extends C {
  constructor() {
    super(...arguments), this.isOpen = !1, this.readonly = !1, this.boxShadow = !1, this.advancedFilter = !1, this.searchThreshold = 1, this.isDisplayed = void 0, this._elementId = `dss-selector-${(/* @__PURE__ */ new Date()).getTime()}`, this._elements = null, this._elementSelectAll = [], this._selectedValue = null, this._multiple = !1, this._deselectable = !1, this._disabled = !1, this._tick = !0, this._type = "default", this._style = null, this._filtre = null, this._labelSelectAll = "Seleccionar-ho tot", this._labelDeselectAll = "Deseleccionar-ho tot", this._selectAll = !1, this._isAllSelected = !1, this._elementsSelected = 0, this._emptySelectorLabel = "Sense resultats per", this._emptyFilterLabel = "Escriu per cercar.", this._filterThreshold = 1, this._ariaLabel = void 0;
  }
  static get styles() {
    return [k(R), k(N), k(z), k(F)];
  }
  set multiple(e) {
    const t = this._multiple;
    this._multiple = e, this.requestUpdate("multiple", t);
  }
  get multiple() {
    return this._multiple;
  }
  set tick(e) {
    const t = this._tick;
    this._tick = e, this.requestUpdate("tick", t);
  }
  get tick() {
    return this._tick;
  }
  set deselectable(e) {
    const t = this._deselectable;
    this._deselectable = e, this.requestUpdate("deselectable", t);
  }
  get deselectable() {
    return this._deselectable;
  }
  set disabled(e) {
    const t = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", t);
  }
  get disabled() {
    return this._disabled;
  }
  set elements(e) {
    const t = this._elements;
    this._elements = e, this.requestUpdate("elements", t);
  }
  get elements() {
    return this._elements || [];
  }
  set selectedValue(e) {
    var s, i;
    const t = this._selectedValue;
    if (!e || e.length === 0) {
      this._selectedValue = null, this.requestUpdate("selectedValue", t);
      return;
    }
    if (this._multiple) {
      this._selectedValue = ((s = this._elements) == null ? void 0 : s.filter((o) => e.includes(o.value))) || null, this.requestUpdate("selectedValue", t);
      return;
    }
    const l = (i = this._elements) == null ? void 0 : i.find((o) => o.value === e[0]);
    this._selectedValue = l ? [l] : null, this.requestUpdate("selectedValue", t);
  }
  get selectedValue() {
    var e;
    return ((e = this._selectedValue) == null ? void 0 : e.map((t) => t.value)) || [];
  }
  set type(e) {
    const t = this._type;
    e === "default" || e === "green" ? this._type = e : this._type = "default", this.requestUpdate("type", t);
  }
  get type() {
    return this._type;
  }
  set boxStyle(e) {
    const t = this._style;
    this._style = e, this.requestUpdate("style", t);
  }
  get boxStyle() {
    return this._style || "";
  }
  set filtre(e) {
    if (e) {
      const t = this._filtre;
      this._filtre = e.toLowerCase(), this.requestUpdate("filtre", t);
    } else e === "" && (this._filtre = null);
    this._selectAll && this._areAllElementsSelected();
  }
  get filtre() {
    return this._filtre || "";
  }
  set labelSelectAll(e) {
    const t = this._labelSelectAll;
    e !== "" && (this._labelSelectAll = e), this.requestUpdate("labelSelectAll", t);
  }
  get labelSelectAll() {
    return this._labelSelectAll;
  }
  set labelDeselectAll(e) {
    const t = this._labelDeselectAll;
    e !== "" && (this._labelDeselectAll = e), this.requestUpdate("labelDeselectAll", t);
  }
  get labelDeselectAll() {
    return this._labelDeselectAll;
  }
  set selectAll(e) {
    const t = this._selectAll;
    this._selectAll = e, this.requestUpdate("selectAll", t);
  }
  get selectAll() {
    return this._selectAll;
  }
  set filterThreshold(e) {
    const t = this._filterThreshold;
    this._filterThreshold = e, this.requestUpdate("filterThreshold", t);
  }
  get filterThreshold() {
    return this._filterThreshold;
  }
  set elementsSelected(e) {
    const t = this._elementsSelected;
    this._elementsSelected = e, this.requestUpdate("elementsSelected", t);
  }
  get elementsSelected() {
    return this._elementsSelected;
  }
  set ariaLabel(e) {
    const t = this._ariaLabel;
    this._ariaLabel = e, this.requestUpdate("ariaLabel", t);
  }
  get ariaLabel() {
    return this._ariaLabel || "";
  }
  _valueIsSelected(e) {
    var t;
    return ((t = this._selectedValue) == null ? void 0 : t.some((l) => l.value === e)) || !1;
  }
  _manuallySelect(e, t) {
    if (e.preventDefault(), e.stopPropagation(), this._disabled || this.readonly) return;
    const l = this._valueIsSelected(t);
    if (!this._multiple && !this._deselectable && l) return;
    const s = e.target, i = s.className.includes("dss-mark") ? s.parentElement : s;
    i && i.className.includes("dss-form-field") ? i.querySelector("input").checked = !l : i && (i.parentElement.querySelector("input").checked = !l), this._returnSelectedValues(t), this._areAllElementsSelected();
  }
  _manuallySelectAll(e) {
    if (e.preventDefault(), e.stopPropagation(), this._disabled || this.readonly || !this._multiple && !this._deselectable && this._isAllSelected) return;
    const t = e.target;
    t.className.includes("dss-form-field") ? (t.querySelector("input").checked = !t.querySelector("input").checked, this._returnSelecteAllValues(t.querySelector("input").checked)) : (t.parentElement.querySelector("input").checked = !t.parentElement.querySelector("input").checked, this._returnSelecteAllValues(t.parentElement.querySelector("input").checked)), this._areAllElementsSelected();
  }
  _returnSelecteAllValues(e) {
    var s, i;
    e ? this._selectedValue = ((s = this._elements) == null ? void 0 : s.filter((o) => o.value)) || [] : this._selectedValue = [];
    const l = {
      detail: ((i = this._selectedValue) == null ? void 0 : i.map((o) => o.value)) || null,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", l)), this.requestUpdate();
  }
  _returnSelectedValues(e) {
    var o, m;
    const t = Array.from(((o = this.shadowRoot) == null ? void 0 : o.querySelectorAll("input:checked")) || []).map((d) => d.getAttribute("value")).filter((d) => d == null ? !1 : this._multiple ? !0 : d === e), l = t.indexOf(this._elementSelectAll[0]);
    l !== -1 && t.splice(l, 1), this._selectedValue = ((m = this._elements) == null ? void 0 : m.filter((d) => t.includes(d.value))) || [];
    let s;
    this._multiple ? s = t : s = t[0] || null;
    const i = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", i)), this.requestUpdate();
  }
  _focusEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.add("dss-form-field__focus");
  }
  _blurEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.remove("dss-form-field__focus");
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._elementSelectAll = [this._labelSelectAll], this._areAllElementsSelected(), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _areAllElementsSelected() {
    if (!this._elements || !this._selectedValue) {
      this._elementSelectAll = [this._labelSelectAll], this._isAllSelected = !1;
      return;
    }
    const e = this._selectedValue.map((l) => l.value), t = this._elements.map((l) => l.value);
    this._isAllSelected = e.length === t.length && e.every((l) => t.includes(l)), this._isAllSelected ? this._elementSelectAll = [this._labelDeselectAll] : this._elementSelectAll = [this._labelSelectAll], this.requestUpdate();
  }
  selectFirstMatch() {
    var l;
    const e = (l = this.shadowRoot) == null ? void 0 : l.querySelectorAll(".dss-form-field");
    let t = null;
    for (const s of e || []) {
      const i = s.getAttribute("data-label");
      if (i && this._filtre && i.toLowerCase() === this._filtre.toLowerCase()) {
        t = s;
        break;
      }
    }
    t && t.click();
  }
  moveFocus() {
    var s;
    const e = (s = this.shadowRoot) == null ? void 0 : s.querySelectorAll(".dss-form-field");
    if (!e || e.length === 0) return;
    const l = e[0].querySelector("input");
    l && l.focus();
  }
  generateListInputsElements() {
    var t;
    return (t = this._elements) == null ? void 0 : t.map((l, s) => {
      var u;
      const i = l.label.trim().replace(/\s+/g, "-"), o = l.value.trim().replace(/\s+/g, "-"), m = `selector-${i}-${o}`, d = this._valueIsSelected(l.value), y = this._tick && !this._multiple, h = $({
        disabled: this._disabled,
        "dss-disabled": this._disabled,
        "dss-form-field": !0,
        "dss-form-field--simple": this._tick && !this._multiple,
        "dss-form-field--multiple": this._multiple,
        "dss-form-field--readonly": this.readonly,
        "dss-form-field--no-tick": !this._tick,
        "dss-type--default": this._type === "default",
        "dss-type--green": this._type === "green",
        "dss-ticked": y,
        "dss-selected": d && y,
        "dss-form-field--selected": d,
        "dss-first-unselected": s && s > 0 && s === this._elementsSelected,
        "dss-form-field--match": l.label.toLowerCase() === ((u = this._filtre) == null ? void 0 : u.toLowerCase())
      }), v = $({
        "dss-checkbox": this._multiple,
        "dss-radio": !this._multiple,
        "dss-disabled": this._disabled,
        hidden: y
      }), A = n`
        <input
          id="${m}"
          name="${m}"
          type="checkbox"
          class="${v}"
          .value="${l.value}"
          .checked="${d}"
          @focus="${this._focusEvent}"
          @blur="${this._blurEvent}"
				 ?disabled="${this._disabled || this.readonly}"
        />
        <div class="dss-check-overlay"></div>
      `, g = n`<span
        class="dss-icon--checked"
        style="visibility: ${this.isOpen && y && d ? "visible" : "hidden"}"
      ></span>`;
      return n`
        <div
          class="${h}"
          @keydown="${(_) => {
        var q, w, L, U;
        if (_.key === "Enter" || _.key === " ")
          this._manuallySelect(_, l.value);
        else if (_.key === "ArrowUp") {
          const b = _.target, S = (w = (q = b == null ? void 0 : b.closest(".dss-form-field")) == null ? void 0 : q.previousElementSibling) == null ? void 0 : w.querySelector("input");
          S == null || S.focus();
        } else if (_.key === "ArrowDown") {
          const b = _.target, S = (U = (L = b == null ? void 0 : b.closest(".dss-form-field")) == null ? void 0 : L.nextElementSibling) == null ? void 0 : U.querySelector("input");
          S == null || S.focus();
        }
      }}"
          @click="${(_) => {
        this._manuallySelect(_, l.value);
      }}"
          data-label="${l.label}"
        >
          ${A}
          <label for=${m}>
						${this.advancedFilter ? D(M(l.label, this._filtre || "", this.searchThreshold)) : D(j(l.label, this._filtre || ""))}
          </label>
          ${g}
        </div>
      `;
    });
  }
  generatElementSelectAll() {
    var t;
    return (t = this._elementSelectAll) == null ? void 0 : t.map((l) => {
      var y;
      const s = $({
        disabled: this._disabled || this.readonly,
        "dss-form-field": !0,
        "dss-type--default": this._type === "default",
        "dss-type--green": this._type === "green",
        "dss-selectAll": !0,
        "dss-disabled": this._disabled || this.readonly,
        "dss-form-field--match": l.toLowerCase() === ((y = this._filtre) == null ? void 0 : y.toLowerCase())
      }), i = $({
        "dss-checkbox": this._multiple
      }), o = n`
        <input
          id="${this._elementId}"
          name="${this._elementId}"
          type="checkbox"
          class="${i}"
          .value="${l}"
          .checked="${this._isAllSelected}"
          @focus="${this._focusEvent}"
          @blur="${this._blurEvent}"
					?disabled="${this._disabled || this.readonly}"
        />
        <div class="dss-check-overlay"></div>
      `;
      return n`
        <div
          class="${s}"
          @keydown="${(h) => {
        var v, A, g, V;
        if (h.key === "Enter" || h.key === " ")
          this._manuallySelectAll(h);
        else if (h.key === "ArrowUp") {
          const f = h.target, u = (A = (v = f == null ? void 0 : f.closest(".dss-form-field")) == null ? void 0 : v.previousElementSibling) == null ? void 0 : A.querySelector("input");
          u == null || u.focus();
        } else if (h.key === "ArrowDown") {
          const f = h.target, u = (V = (g = f == null ? void 0 : f.closest(".dss-form-field")) == null ? void 0 : g.nextElementSibling) == null ? void 0 : V.querySelector("input");
          u == null || u.focus();
        }
      }}"
          @click="${(h) => {
        this._manuallySelectAll(h);
      }}"
          data-label="${l}"
        >
          ${o}
          <label for="${this._elementId}">${l}</label>
        </div>
      `;
    });
  }
  render() {
    let e = this.generateListInputsElements();
    const t = this.generatElementSelectAll();
    this._multiple && this._selectAll && (e == null || e.unshift(t[0]), e = (e == null ? void 0 : e.length) === 1 ? [] : e);
    const l = (s) => {
      (s.key === "ArrowDown" || s.key === "ArrowUp") && s.preventDefault();
    };
    return n`
      ${this._elements && this._elements.length > 0 ? n`
            <div
              aria-label="${T(this._ariaLabel)}"
              part="selector"
              class="list dss-selector-list-wrapper ${this.boxShadow ? "dss-selector-list-wrapper--box-shadow" : ""}"
              @keydown=${l}
              style="${this._style}"
            >
              ${e}
            </div>
          ` : n`
            <div
              part="selector"
              class="list dss-selector-list-wrapper"
              @keydown=${l}
              style="${this._style}"
            >
              ${this._filtre && this._filtre.length >= this._filterThreshold ? n`
                    <div class="dss-selector-empty">
                      <span class="dss-icon dss-icon--sm">info</span>
                      <span class="text">
                        ${this._filtre || this._filtre === "" ? n` ${this._emptySelectorLabel}: ${this._filtre} ` : n`${this._emptyFilterLabel}`}
                      </span>
                    </div>
                  ` : n`
                    <div class="dss-selector-empty">
											<${G} size="md"/>
                    </div>
                  `}
            </div>
          `}
    `;
  }
}
a([
  r(p)
], c.prototype, "isOpen", 2);
a([
  r(p)
], c.prototype, "readonly", 2);
a([
  r(p)
], c.prototype, "boxShadow", 2);
a([
  r(p)
], c.prototype, "advancedFilter", 2);
a([
  r({ type: Number })
], c.prototype, "searchThreshold", 2);
a([
  r(p)
], c.prototype, "multiple", 1);
a([
  r(p)
], c.prototype, "tick", 1);
a([
  r(p)
], c.prototype, "deselectable", 1);
a([
  r(p)
], c.prototype, "disabled", 1);
a([
  r({ type: Array })
], c.prototype, "elements", 1);
a([
  r(P)
], c.prototype, "selectedValue", 1);
a([
  r({ type: String })
], c.prototype, "type", 1);
a([
  r({ type: String })
], c.prototype, "boxStyle", 1);
a([
  r({ type: String })
], c.prototype, "filtre", 1);
a([
  r({ type: String })
], c.prototype, "labelSelectAll", 1);
a([
  r({ type: String })
], c.prototype, "labelDeselectAll", 1);
a([
  r(p)
], c.prototype, "selectAll", 1);
a([
  r({ type: Number })
], c.prototype, "filterThreshold", 1);
a([
  r({ type: Number })
], c.prototype, "elementsSelected", 1);
a([
  r({ type: String })
], c.prototype, "ariaLabel", 1);
a([
  r(p)
], c.prototype, "isDisplayed", 2);
export {
  c as Selector
};
//# sourceMappingURL=selector.js.map
