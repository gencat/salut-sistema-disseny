import { LitElement as h, unsafeCSS as p } from "lit";
import { property as t } from "lit/decorators.js";
import d from "../../api/marker/marker.style.css.js";
import m from "../../foundations/icon/icon.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import c from "../decorative-icon/decorative-icon.style.css.js";
import f from "./tile.style.css.js";
import { template as g } from "./tile.template.js";
var u = Object.defineProperty, e = (l, s, y, S) => {
  for (var i = void 0, n = l.length - 1, a; n >= 0; n--)
    (a = l[n]) && (i = a(s, y, i) || i);
  return i && u(s, y, i), i;
};
class o extends h {
  constructor() {
    super(...arguments), this.type = "default", this.icon = "", this.tileTitle = "", this.description = "", this.selected = !1, this.disabled = !1, this.hasLogo = !1, this.logoURL = "", this.heightAuto = !1, this.widget = !1, this.marker = void 0;
  }
  static get styles() {
    return [p(m), p(c), p(d), p(f)];
  }
  _onClick() {
    this.type === "selector" && (this.selected = !this.selected, this.requestUpdate());
    const s = {
      detail: { title: this.tileTitle },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onTileClick", s));
  }
  render() {
    return g(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "tileTitle");
e([
  t({ type: String })
], o.prototype, "description");
e([
  t(r)
], o.prototype, "selected");
e([
  t(r)
], o.prototype, "disabled");
e([
  t(r)
], o.prototype, "hasLogo");
e([
  t({ type: String })
], o.prototype, "logoURL");
e([
  t(r)
], o.prototype, "heightAuto");
e([
  t(r)
], o.prototype, "widget");
e([
  t({ type: String })
], o.prototype, "marker");
export {
  o as Tile
};
//# sourceMappingURL=tile.js.map
