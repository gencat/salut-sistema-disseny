import { classMap as r } from "lit/directives/class-map.js";
import { unsafeHTML as g } from "lit/directives/unsafe-html.js";
import { unsafeStatic as c, literal as o, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as h } from "../../api/custom-element-scope.js";
import { highlightText as u } from "../../api/marker/marker.js";
const $ = o`dss-decorative-icon${c(h())}`, _ = (s) => {
  const e = {
    "dss-tile--button": s.type === "button",
    "dss-tile--selector": s.type === "selector",
    "dss-tile--selected": s.type === "selector" && s.selected,
    "dss-tile--action": s.type === "action",
    "dss-tile--disabled": s.disabled,
    "dss-tile--height-auto": s.heightAuto,
    "dss-tile--widget": s.widget
  }, l = () => t`
      <${$} 
        icon="${s.icon}" 
        state="default" 
        size="xl"
        ?disabled=${s.disabled}
      ></${$}>
    `, d = () => t`
      <div class="dss-tile-logo">
        <img
          class="dss-tile-logo__image"
          src="${s.logoURL}"
          alt="Tile Logo"
        />
      </div>
    `, a = () => t`
      <div class="dss-tile-content">
        <div class="dss-tile-content__text">
          <h4 class="dss-tile-title">
            ${g(u(s.tileTitle, s.marker))}
          </h4>
          <p class="dss-tile-description">
            ${g(u(s.description, s.marker))}
          </p>
        </div>
        ${s.type === "action" ? t` <slot name="action"></slot> ` : null}
      </div>
    `;
  let i = t``;
  return s.type === "button" || s.type === "selector" ? i = t`
      <div
        class="dss-tile ${r(e)}"
        tabindex="${s.disabled ? -1 : 0}"
        role="button"
        @click=${s._onClick}
      >
        ${s.icon && !s.hasLogo ? l() : null}
        ${s.hasLogo ? d() : null}
        ${a()}
      </div>
    ` : i = t`
      <div class="dss-tile ${r(e)}">
        ${s.icon && !s.hasLogo ? l() : null}
        ${s.hasLogo ? d() : null}
        ${a()}
      </div>
    `, i;
};
export {
  _ as template
};
//# sourceMappingURL=tile.template.js.map
