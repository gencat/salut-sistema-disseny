import { classMap as d } from "lit/directives/class-map.js";
import { html as a } from "lit/static-html.js";
const v = (s) => {
  var i;
  const l = {
    "dss-slider--vertical": s._vertical
  }, r = {
    "dss-slider-tooltip--active": s._isTooltipTouched
  };
  return a`
    <div class="dss-slider-wrapper ${d(l)}">
      <input
        id="dss-slider-input"
        aria-label="${s._label}"
        type="range"
        class="dss-slider"
        min=${s._min}
        max=${s._max}
        .value=${(i = s._value) == null ? void 0 : i.toString()}
        step=${s._step}
        direction="${s._orient}"
        @input="${s._handleInput}"
        style="--progress: ${`${s._progress}%`}"
        ?disabled="${s._disabled}"
      />
      <div
        class="dss-slider-tooltip ${d(r)}"
        id="dss-slider-tooltip"
      ></div>
      <div class="dss-slider-info dss-slider-info--min">${s._min}</div>
      <div class="dss-slider-info dss-slider-info--medium">
        ${Math.round((s._max + s._min) / 2)}
      </div>
      <div class="dss-slider-info dss-slider-info--max">${s._max}</div>
      <div></div>
    </div>
  `;
};
export {
  v as template
};
//# sourceMappingURL=slider.template.js.map
