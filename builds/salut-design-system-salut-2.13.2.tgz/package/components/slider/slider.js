import { LitElement as d, unsafeCSS as _ } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as c } from "../../utils/property-types.js";
import m from "./slider.style.css.js";
import { template as v } from "./slider.template.js";
var b = Object.defineProperty, g = Object.getOwnPropertyDescriptor, r = (h, t, e, l) => {
  for (var s = g(t, e), a = h.length - 1, o; a >= 0; a--)
    (o = h[a]) && (s = o(t, e, s) || s);
  return s && b(t, e, s), s;
};
class n extends d {
  constructor() {
    super(...arguments), this._label = "Input range", this._min = 0, this._max = 0, this._step = 1, this._orient = "horizontal", this._vertical = !1, this._value = 0, this._progress = 0, this._disabled = !1, this._isTooltipTouched = !1;
  }
  static get styles() {
    return _(m);
  }
  get _input() {
    var t;
    return (t = this.shadowRoot) == null ? void 0 : t.querySelector("input");
  }
  get _tooltip() {
    var t;
    return (t = this.shadowRoot) == null ? void 0 : t.querySelector("#dss-slider-tooltip");
  }
  set min(t) {
    const e = this._min;
    this._min = t, this.requestUpdate("min", e);
  }
  get min() {
    return this._min;
  }
  set max(t) {
    const e = this._max;
    t >= this._value && (this._max = t, this._setProgress(), this.requestUpdate("max", e));
  }
  get max() {
    return this._max;
  }
  set step(t) {
    const e = this._step;
    this._step = t, this.requestUpdate("step", e);
  }
  get step() {
    return this._step;
  }
  set orient(t) {
    const e = this._orient;
    this._orient = t, t === "vertical" ? this._vertical = !0 : this._vertical = !1, this.requestUpdate("orient", e);
  }
  get orient() {
    return this._orient;
  }
  set value(t) {
    const e = this._value;
    this._max >= t && (this._value = t, this._setProgress(), this.requestUpdate("value", e));
  }
  get value() {
    return this._value;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  // _bubble = this.renderRoot.querySelector('#dssSliderValue')
  async firstUpdated() {
    try {
      await this.updateComplete, this._setProgress(), this.requestUpdate(), document.addEventListener("DOMContentLoaded", this._updateTooltip.bind(this)), this._input.addEventListener("input", this._updateTooltip.bind(this)), this._input.addEventListener("mouseup", this._dispatchValue.bind(this)), this._input.addEventListener("keyup", this._dispatchValue.bind(this)), this._input.addEventListener("touchstart", this._handleTouchStart.bind(this)), this._input.addEventListener("touchmove", this._handleTouchMove.bind(this)), this._input.addEventListener("touchend", this._handleTouchEnd.bind(this));
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _handleTouchStart(t) {
    this._vertical && t.preventDefault(), this._isTooltipTouched = !0;
  }
  _handleTouchEnd(t) {
    this._vertical && t.preventDefault(), this._isTooltipTouched = !1, this.requestUpdate(), this._dispatchValue();
  }
  _handleTouchMove(t) {
    if (this._vertical) {
      if (!t.target) return;
      const e = t.target, l = Number.parseInt(e.max, 10), s = Number.parseInt(e.min, 10), a = t.touches[0], o = e.getBoundingClientRect(), u = (a.clientY - o.top) / o.height, p = Math.round(u * (l - s) + s);
      e.value = String(l - p + s), e.dispatchEvent(new Event("input"));
    }
  }
  _handleInput() {
    if (this._input) {
      const t = Number.parseFloat(this._input.value);
      this._progress = Math.round((t - this._min) / (this._max - this._min) * 100), this.requestUpdate();
    }
  }
  _setProgress() {
    this._input && (this._input.value = this._value.toString()), this._progress = Math.round((this._value - this._min) / (this._max - this._min) * 100), this.requestUpdate();
  }
  _updateTooltip() {
    if (this._tooltip) {
      const t = Number((+this._input.value - +this._min) * 100 / (+this._max - +this._min)), e = 10 - t * 0.2;
      this._tooltip.innerHTML = `<span class="tooltip-wrapper"><span class="tooltip-value">${this._input.value}</span></span>`, this._tooltip.style.left = `calc(${t}% + (${e}px))`;
    }
  }
  _dispatchValue() {
    const t = {
      detail: this._input.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onDssSliderValueChange", t));
  }
  render() {
    return v(this);
  }
}
r([
  i({ type: Number })
], n.prototype, "min");
r([
  i({ type: Number })
], n.prototype, "max");
r([
  i({ type: Number })
], n.prototype, "step");
r([
  i({ type: String })
], n.prototype, "orient");
r([
  i({ type: Number })
], n.prototype, "value");
r([
  i(c)
], n.prototype, "disabled");
r([
  i({ type: String })
], n.prototype, "label");
export {
  n as Slider
};
//# sourceMappingURL=slider.js.map
