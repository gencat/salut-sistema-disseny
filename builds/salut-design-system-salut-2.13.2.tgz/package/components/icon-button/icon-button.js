import { LitElement as y, unsafeCSS as d } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as i } from "../../utils/property-types.js";
import f from "./icon-button.style.css.js";
import { template as m } from "./icon-button.template.js";
var b = Object.defineProperty, e = (p, a, l, c) => {
  for (var r = void 0, s = p.length - 1, n; s >= 0; s--)
    (n = p[s]) && (r = n(a, l, r) || r);
  return r && b(a, l, r), r;
};
class o extends y {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.size = "md", this.label = "", this.icon = void 0, this.fill = !1, this.disabled = !1, this.hidden = !1, this.disableTabindex = !1, this.ariaLabel = null, this.ariaExpanded = void 0, this.tooltipFixed = !1, this.tooltipInteractive = !1, this.tooltipPosition = "top", this.hideTooltip = !1, this.forceViewport = !1;
  }
  static get styles() {
    return [d(h), d(f)];
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  render() {
    return m(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "variant");
e([
  t({ type: String })
], o.prototype, "size");
e([
  t({ type: String })
], o.prototype, "label");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t(i)
], o.prototype, "fill");
e([
  t(i)
], o.prototype, "disabled");
e([
  t(i)
], o.prototype, "hidden");
e([
  t(i)
], o.prototype, "disableTabindex");
e([
  t({ type: String })
], o.prototype, "ariaLabel");
e([
  t(i)
], o.prototype, "ariaExpanded");
e([
  t(i)
], o.prototype, "tooltipFixed");
e([
  t(i)
], o.prototype, "tooltipInteractive");
e([
  t({ type: String })
], o.prototype, "tooltipPosition");
e([
  t(i)
], o.prototype, "hideTooltip");
e([
  t(i)
], o.prototype, "forceViewport");
export {
  o as IconButton
};
//# sourceMappingURL=icon-button.js.map
