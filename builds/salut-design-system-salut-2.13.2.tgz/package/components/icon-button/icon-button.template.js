import { classMap as s } from "lit/directives/class-map.js";
import { when as $ } from "lit/directives/when.js";
import { unsafeStatic as e, literal as r, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as b } from "../../api/custom-element-scope.js";
const l = r`dss-icon${e(b())}`, d = r`dss-tooltip${e(b())}`, t = (i) => a`
  ${$(
  i.label && !i.hideTooltip,
  () => a`
      <${d} 
        position="${i.tooltipPosition}"
        ?tooltipFixed=${i.tooltipFixed}
        ?forceViewport="${i.forceViewport}"
        ?interactive=${i.tooltipInteractive}
        aria-hidden="true">
        ${i.label}
      </${d}>
    `
)}
`, z = (i) => a`
  ${$(
  i.ariaExpanded !== void 0,
  () => a`
    <button
      type=${i.type}
      class=${s({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
      ?disabled=${i.disabled}
      ?hidden=${i.hidden}
      aria-expanded=${i.ariaExpanded}
      aria-label="${i.ariaLabel ?? i.label}"
      tabindex="${i.disableTabindex ? "-1" : "0"}"
      @click=${i._handleClick}
    >
      <${l} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}" ?fill=${i.fill}></${l}>
      ${t(i)}
    </button>
  `,
  () => a`
      <button
        type=${i.type}
        class=${s({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
        ?disabled=${i.disabled}
        ?hidden=${i.hidden}
        aria-label="${i.label}"
        tabindex="${i.disableTabindex ? "-1" : "0"}"
        @click=${i._handleClick}
      >
        <${l} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}" ?fill=${i.fill}></${l}>
        ${t(i)}
      </button>
    `
)}
`;
export {
  z as template
};
//# sourceMappingURL=icon-button.template.js.map
