import { LitElement as p, unsafeCSS as a } from "lit";
import { property as i } from "lit/decorators.js";
import _ from "../../foundations/icon/icon.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import u from "./badge.states.css.js";
import f from "./badge.style.css.js";
import { template as m } from "./badge.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, s = (l, t, e, c) => {
  for (var r = c > 1 ? void 0 : c ? g(t, e) : t, h = l.length - 1, d; h >= 0; h--)
    (d = l[h]) && (r = (c ? d(t, e, r) : d(r)) || r);
  return c && r && y(t, e, r), r;
};
class o extends p {
  constructor() {
    super(...arguments), this.text = "", this.disabled = !1, this.outlined = !1, this.dot = !1, this.hideIcon = !1, this.tooltipPosition = "top", this.width = void 0, this.forceViewport = !1, this._icon = "warning", this._iconSize = "sm", this._iconFill = !1, this._size = "sm", this._state = "", this._isIconDefined = !1, this._isFirstUpdated = !0, this._isTextTruncated = !1;
  }
  static get styles() {
    return [a(_), a(f), a(u)];
  }
  get _tooltip() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="tooltip"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this._isIconDefined = !0, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set size(t) {
    const e = this._size;
    this._size = t, t === "xl" ? this._iconSize = "md" : this._iconSize = "sm", this.requestUpdate("size", e);
  }
  get size() {
    return this._size;
  }
  set state(t) {
    const e = this._state;
    this._state = t, this._generateDefaultIcon(t), this.requestUpdate("state", e);
  }
  get state() {
    return this._state;
  }
  async firstUpdated() {
    var t;
    if (await this.updateComplete, this.width) {
      const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-badge");
      e && (e.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("text") && this._checkTextTruncated(), !this._isFirstUpdated && t.has("state") && (this._iconFill = !1, this._generateDefaultIcon(this.state));
  }
  _checkTextTruncated() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector(".dss-badge__text");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  _updateIconFill(t) {
    this._iconFill = !t.includes("low") || t === "correct";
  }
  _generateDefaultIcon(t) {
    t && !this._isIconDefined && (t.includes("danger") ? (this._icon = "warning", this._updateIconFill(t)) : t.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(t)) : t.includes("slight") ? (this._icon = "error", this._updateIconFill(t)) : t.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(t)) : t.includes("undeterminated") ? this._icon = "circle" : t.includes("undetermined") ? this._icon = "circle" : t.includes("critic") ? this._icon = "cancel" : t.includes("alert") ? this._icon = "report" : t.includes("ideal") ? this._icon = "check_circle" : t.includes("info") ? this._icon = "info" : t.includes("neutral") && (this._icon = "circle"));
  }
  _isInformativeState() {
    return ["ideal", "critical", "critic", "alert", "info", "info-alt", "neutral"].includes(this._state);
  }
  render() {
    return m(this);
  }
}
s([
  i({ type: String })
], o.prototype, "icon", 1);
s([
  i({ type: String })
], o.prototype, "size", 1);
s([
  i({ type: String })
], o.prototype, "text", 2);
s([
  i({ type: String })
], o.prototype, "state", 1);
s([
  i(n)
], o.prototype, "disabled", 2);
s([
  i(n)
], o.prototype, "outlined", 2);
s([
  i(n)
], o.prototype, "dot", 2);
s([
  i(n)
], o.prototype, "hideIcon", 2);
s([
  i({ type: String })
], o.prototype, "tooltipPosition", 2);
s([
  i({ type: String })
], o.prototype, "width", 2);
s([
  i(n)
], o.prototype, "forceViewport", 2);
export {
  o as Badge
};
//# sourceMappingURL=badge.js.map
