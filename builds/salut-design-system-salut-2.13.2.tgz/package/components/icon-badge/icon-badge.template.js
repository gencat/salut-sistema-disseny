import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as t, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as g } from "../../api/custom-element-scope.js";
const d = t`dss-icon${i(g())}`, u = (s) => {
  const a = {
    "dss-icon-badge--xl": s._size === "xl",
    "dss-icon-badge--lg": s._size === "lg",
    "dss-icon-badge--md": s._size === "md",
    "dss-icon-badge--sm": s._size === "sm",
    "dss-badge--danger": s._state === "danger",
    "dss-badge--danger-low": s._state === "danger-low",
    "dss-badge--danger-high": s._state === "danger-high",
    "dss-badge--moderate": s._state === "moderate",
    "dss-badge--moderate-low": s._state === "moderate-low",
    "dss-badge--moderate-high": s._state === "moderate-high",
    "dss-badge--slight": s._state === "slight",
    "dss-badge--slight-low": s._state === "slight-low",
    "dss-badge--slight-high": s._state === "slight-high",
    "dss-badge--correct": s._state === "correct",
    "dss-badge--undeterminated": s._state === "undeterminated",
    "dss-badge--critic": s._state === "critic" && !s._outlined,
    "dss-badge--critic-outlined": s._state === "critic" && s._outlined,
    "dss-badge--alert": s._state === "alert" && !s._outlined,
    "dss-badge--alert-outlined": s._state === "alert" && s._outlined,
    "dss-badge--ideal": s._state === "ideal" && !s._outlined,
    "dss-badge--ideal-outlined": s._state === "ideal" && s._outlined,
    "dss-badge--info": s._state === "info" && !s._outlined,
    "dss-badge--info-outlined": s._state === "info" && s._outlined,
    "dss-badge--info-alt": s._state === "info-alt" && !s._outlined,
    "dss-badge--info-alt-outlined": s._state === "info-alt" && s._outlined,
    "dss-badge--neutral": s._state === "neutral" && !s._outlined,
    "dss-badge--neutral-outlined": s._state === "neutral" && s._outlined,
    "dss-badge--above": s._state === "above",
    "dss-badge--above-low": s._state === "above-low",
    "dss-badge--above-high": s._state === "above-high",
    "dss-badge--below": s._state === "below",
    "dss-badge--below-low": s._state === "below-low",
    "dss-badge--below-high": s._state === "below-high",
    "dss-badge--disabled": s._disabled,
    "dss-icon-badge--bubble": s._bubble
  };
  return l`
		<div class="dss-wrapper">
      <div class="dss-icon-badge dss-icon ${e(a)}">
				<${d}
					size="${s._iconSize}"
					icon="${s._icon}"
					?fill="${s._iconFill}"
				></${d}>
			</div>
      <slot name="tooltip"></slot>
    </div>
  `;
};
export {
  u as template
};
//# sourceMappingURL=icon-badge.template.js.map
