const s = ".dss-icon-badge{cursor:default;box-sizing:border-box;display:flex;justify-content:center;align-items:center;height:20px;width:20px;border:var(--dss-border-width-sm) solid var(--color-neutral-500);padding:var(--dss-spacing-tiny);border-radius:var(--dss-radius-xs);font-size:16px;color:var(--color-neutral-500);background-color:var(--color-white)}.dss-icon-badge--bubble{border-radius:var(--dss-radius-full)!important}.dss-icon-badge--md{height:24px;width:32px;padding:var(--dss-spacing-xxs) var(--dss-spacing-xs)}.dss-icon-badge--lg{height:32px;width:40px;padding:var(--dss-spacing-xxs) var(--dss-spacing-xs);border-radius:var(--dss-radius-sm);font-size:24px}.dss-icon-badge--xl{height:40px;width:40px;padding:var(--dss-spacing-xxs) var(--dss-spacing-xs);border-radius:var(--dss-radius-sm);font-size:24px}";
export {
  s as default
};
//# sourceMappingURL=icon.badge.style.css.js.map
