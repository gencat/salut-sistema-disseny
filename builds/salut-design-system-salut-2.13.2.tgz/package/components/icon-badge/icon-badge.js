import { LitElement as h, unsafeCSS as c } from "lit";
import { property as s } from "lit/decorators.js";
import _ from "../../foundations/icon/icon.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import a from "../badge/badge.states.css.js";
import { template as p } from "./icon-badge.template.js";
import b from "./icon.badge.style.css.js";
var f = Object.defineProperty, m = Object.getOwnPropertyDescriptor, l = (o, e, i, g) => {
  for (var t = m(e, i), r = o.length - 1, u; r >= 0; r--)
    (u = o[r]) && (t = u(e, i, t) || t);
  return t && f(e, i, t), t;
};
class n extends h {
  constructor() {
    super(...arguments), this._icon = "warning", this._size = "sm", this._state = "", this._disabled = !1, this._isIconDefined = !1, this._outlined = !1, this._bubble = !1, this._iconSize = "sm", this._iconFill = !1;
  }
  static get styles() {
    return [c(_), c(b), c(a)];
  }
  set icon(e) {
    const i = this._icon;
    this._icon = e, this._isIconDefined = !0, this.requestUpdate("icon", i);
  }
  get icon() {
    return this._icon;
  }
  set size(e) {
    const i = this._size;
    this._size = e, this.requestUpdate("size", i);
  }
  get size() {
    return this._size;
  }
  set state(e) {
    const i = this._state;
    this._state = e, e && !this._isIconDefined && (e.includes("danger") ? (this._icon = "warning", this._updateIconFill(e)) : e.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(e)) : e.includes("slight") ? (this._icon = "error", this._updateIconFill(e)) : e.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(e)) : e.includes("undeterminated") ? this._icon = "circle" : e.includes("undetermined") ? this._icon = "circle" : e.includes("critic") ? this._icon = "cancel" : e.includes("alert") ? this._icon = "report" : e.includes("ideal") ? this._icon = "check_circle" : e.includes("info") ? this._icon = "info" : e.includes("neutral") ? this._icon = "circle" : e.includes("above") ? (this._bubble = !0, this._icon = "arrow_upward") : e.includes("below") && (this._icon = "arrow_downward", this._bubble = !0)), this.requestUpdate("state", i);
  }
  get state() {
    return this._state;
  }
  set disabled(e) {
    const i = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", i);
  }
  get disabled() {
    return this._disabled;
  }
  set outlined(e) {
    const i = this._outlined;
    this._outlined = e, this.requestUpdate("outlined", i);
  }
  get outlined() {
    return this._outlined;
  }
  set bubble(e) {
    const i = this._bubble;
    this._bubble = e, this.requestUpdate("bubble", i);
  }
  get bubble() {
    return this._bubble;
  }
  firstUpdated() {
    (this._size === "lg" || this._size === "xl") && (this._iconSize = "md", this.requestUpdate());
  }
  _updateIconFill(e) {
    this._iconFill = !e.includes("low");
  }
  render() {
    return p(this);
  }
}
l([
  s({ type: String })
], n.prototype, "icon");
l([
  s({ type: String })
], n.prototype, "size");
l([
  s({ type: String })
], n.prototype, "state");
l([
  s(d)
], n.prototype, "disabled");
l([
  s(d)
], n.prototype, "outlined");
l([
  s(d)
], n.prototype, "bubble");
export {
  n as IconBadge
};
//# sourceMappingURL=icon-badge.js.map
