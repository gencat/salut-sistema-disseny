import { LitElement as u, unsafeCSS as h } from "lit";
import { property as i } from "lit/decorators.js";
import { getCustomElementSuffix as p } from "../../api/custom-element-scope.js";
import _ from "../../foundations/icon/icon.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import m from "./sidemenu-list-item.style.css.js";
import { sidemenuListItemTemplate as b } from "./sidemenu-list-item.template.js";
var g = Object.defineProperty, w = Object.getOwnPropertyDescriptor, o = (a, t, e, l) => {
  for (var s = w(t, e), r = a.length - 1, c; r >= 0; r--)
    (c = a[r]) && (s = c(t, e, s) || s);
  return s && g(t, e, s), s;
};
class n extends u {
  constructor() {
    super(), this._label = "Menu", this._icon = "add_box", this._selected = !1, this._disabled = !1, this._expanded = !1, this._hasNestedMenu = !1, this._nestedMenuPosition = "top", this._notifications = 0, this._notificationsState = "error", this._isHover = !1, this._isActive = !1, this._showItemDropdown = !1, this._isFocused = !1, this._focusEnabled = !1, this._scrollContainerClass = "dss-layout-sidebar", this._tooltip = null, this._dropdown = null, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleContainerScrollBound = this._handleContainerScroll.bind(this);
  }
  static get styles() {
    return [h(f), h(_), h(m)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound), this._scrollContainer && this._scrollContainer.removeEventListener("scroll", this._handleContainerScrollBound);
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon || "";
  }
  set selected(t) {
    const e = this._selected;
    this._selected = t, this.requestUpdate("selected", e);
  }
  get selected() {
    return this._selected;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set hasNestedMenu(t) {
    const e = this._hasNestedMenu;
    this._hasNestedMenu = t, this.requestUpdate("hasNestedMenu", e);
  }
  get hasNestedMenu() {
    return this._hasNestedMenu;
  }
  set expanded(t) {
    const e = this._expanded;
    this._expanded = t, this.requestUpdate("expanded", e);
  }
  get expanded() {
    return this._expanded;
  }
  set notifications(t) {
    const e = this._notifications;
    this._notifications = t, this.requestUpdate("notifications", e);
  }
  get notifications() {
    return this._notifications;
  }
  set notificationsState(t) {
    const e = this._notificationsState;
    this._notificationsState = t, this.requestUpdate("notificationsState", e);
  }
  get notificationsState() {
    return this._notificationsState;
  }
  set nestedMenuPosition(t) {
    const e = this._nestedMenuPosition;
    this._nestedMenuPosition = t, this.requestUpdate("nestedMenuPosition", e);
  }
  get nestedMenuPosition() {
    return this._nestedMenuPosition;
  }
  set focusEnabled(t) {
    const e = this._focusEnabled;
    this._focusEnabled = t, this.requestUpdate("focusEnabled", e);
  }
  get focusEnabled() {
    return this._focusEnabled;
  }
  set scrollContainerClass(t) {
    const e = this._scrollContainerClass;
    this._scrollContainerClass = t, this.requestUpdate("scrollContainerClass", e);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  get _notificationBadge() {
    var t;
    return ((t = this.shadowRoot) == null ? void 0 : t.querySelector("dss-notification-badge")) || void 0;
  }
  _clickedOutsideItem(t, e) {
    e.composedPath().includes(t) || this._showItemDropdown && (this._showItemDropdown = !1, this.requestUpdate());
  }
  _handleDocumentClick(t) {
    this._clickedOutsideItem(this, t);
  }
  _handleContainerScroll() {
  }
  _handleClick() {
    this._disabled || (this._hasNestedMenu ? (this._showItemDropdown = !0, this._toggleTooltip(), this.requestUpdate()) : this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 })), this.dispatchEvent(
      new CustomEvent("updateItemFocus", {
        detail: !0,
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _handleMouseEnter() {
    this._notificationBadge && !this._disabled && this._notificationBadge.setAttribute("isHover", "true");
  }
  _handleMouseLeave() {
    this._notificationBadge && !this._disabled && this._notificationBadge.removeAttribute("isHover");
  }
  _handleMouseDown() {
    this._notificationBadge && !this._disabled && this._notificationBadge.setAttribute("isActive", "true");
  }
  _handleMouseUp() {
    this._notificationBadge && !this._disabled && this._notificationBadge.removeAttribute("isActive");
  }
  _handleKeyDown(t) {
    if (t.key === "ArrowDown" || t.key === "ArrowUp") {
      const e = t.target, s = `dss-action-menu-item${p()}`;
      if (e.tagName.toLowerCase() === s) return;
      t.preventDefault(), this.dispatchEvent(
        new CustomEvent("navigate", {
          detail: {
            direction: t.key === "ArrowDown" ? "next" : "previous"
          },
          bubbles: !0,
          composed: !0
        })
      );
    }
    if (t.key === "Enter" && t.target.click(), t.key === "Escape") {
      this._closeItemDropdown();
      const e = {
        detail: this,
        bubbles: !1,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("keydownEscape", e));
    }
  }
  _handleFocusout(t) {
    const e = t.relatedTarget;
    e === null && this._closeItemDropdown(), e && !this.contains(e) && this._closeItemDropdown();
  }
  _toggleTooltip() {
    var t, e;
    this._showItemDropdown ? (t = this._tooltip) == null || t.classList.add("force-hidden") : (e = this._tooltip) == null || e.classList.remove("force-hidden");
  }
  _closeItemDropdown() {
    this._showItemDropdown && setTimeout(() => {
      this._showItemDropdown = !1, this._toggleTooltip(), this.requestUpdate();
    }, 0);
  }
  focusItem() {
    var t, e;
    this._isFocused = !0, (e = (t = this.shadowRoot) == null ? void 0 : t.querySelector("li")) == null || e.focus();
  }
  blurItem() {
    var t, e;
    this._isFocused = !1, (e = (t = this.shadowRoot) == null ? void 0 : t.querySelector("li")) == null || e.blur();
  }
  get _scrollContainer() {
    return document.querySelector(`.${this._scrollContainerClass}`);
  }
  _getDropdownFixedPosition() {
    const t = this.getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-list-item__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _getTooltipFixedPosition() {
    if (this._tooltip) {
      const t = this.getBoundingClientRect();
      this._tooltip.style.top = `${t.top + t.height / 2}px`, this._tooltip.style.left = `${t.right - 4}px`;
    }
  }
  async firstUpdated() {
    var e, l;
    await this.updateComplete;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector(".dss-sidemenu-list-item__tooltip");
    if (t && (this._tooltip = t), this._hasNestedMenu) {
      const s = (l = this.shadowRoot) == null ? void 0 : l.querySelector(".dss-sidemenu-list-item__dropdown");
      s && (this._dropdown = s);
    }
    this._scrollContainer && this._scrollContainer.addEventListener("scroll", this._handleContainerScrollBound);
  }
  updated(t) {
    super.updated(t), t.has("expanded");
  }
  render() {
    return b(this);
  }
}
o([
  i({ type: String })
], n.prototype, "label");
o([
  i({ type: String })
], n.prototype, "icon");
o([
  i(d)
], n.prototype, "selected");
o([
  i(d)
], n.prototype, "disabled");
o([
  i(d)
], n.prototype, "hasNestedMenu");
o([
  i(d)
], n.prototype, "expanded");
o([
  i({ type: Number })
], n.prototype, "notifications");
o([
  i({ type: String })
], n.prototype, "notificationsState");
o([
  i({ type: String })
], n.prototype, "nestedMenuPosition");
o([
  i(d)
], n.prototype, "focusEnabled");
o([
  i({ type: String })
], n.prototype, "scrollContainerClass");
export {
  n as SidemenuListItem
};
//# sourceMappingURL=sidemenu-list-item.js.map
