import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as d, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as a } from "../../api/custom-element-scope.js";
const i = d`dss-icon${l(a())}`, u = d`dss-tooltip${l(a())}`, _ = d`dss-notification-badge${l(a())}`, r = (s) => e`
  <li
    role="menuitem"
    aria-label="${s._label}"
    class=${t({
  "dss-sidemenu-list-item": !0,
  "dss-sidemenu-list-item--expanded": !!s._expanded,
  "dss-sidemenu-list-item--collapsed": !s._expanded,
  "dss-sidemenu-list-item--selected": !!s._selected,
  "dss-sidemenu-list-item--disabled": !!s._disabled
})}
    tabindex="${s._focusEnabled ? "0" : "-1"}"
    ?disabled=${s._disabled}
    @click="${s._handleClick}"
    @mouseenter="${s._handleMouseEnter}"
    @mouseleave="${s._handleMouseLeave}"
    @mousedown="${s._handleMouseDown}"
    @mouseup="${s._handleMouseUp}"
    @keydown="${s._handleKeyDown}"
    @focusout="${s._handleFocusout}"
  >
    <span class="dss-sidemenu-list-item__icon">
      <${i} icon="${s._icon}" size="md"></${i}>
      ${s._notifications && !s._showItemDropdown && !s._selected ? e`
            <${_}
              class=${t({
  "dss-sidemenu-list-item__notification": !0,
  "dss-sidemenu-list-item__notification--expanded": !0
})}
              value="${s._notifications}"
              state="succes"
              type="default"
              borderMenu
            >
            </${_}>
          ` : null}
    </span>

    ${s._expanded ? e`
      <span class="dss-sidemenu-list-item__label">
        ${s._label}
      </span>

      ${s._hasNestedMenu ? e`
        <${i} icon="chevron_right" size="md"></${i}>
      ` : null}
    ` : null}

    <${u} position="right" class="dss-sidemenu-list-item__tooltip">
      <span>${s._label}</span>
    </${u}>

    <slot></slot>
  </li>
`;
export {
  r as sidemenuListItemTemplate
};
//# sourceMappingURL=sidemenu-list-item.template.js.map
