import { LitElement, unsafeCSS, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { unsafeHTML } from "lit/directives/unsafe-html.js";
import { booleanType } from "../../utils/property-types.js";
import styles from "./stepper.style.css.js";
var __defProp = Object.defineProperty, __getOwnPropDesc = Object.getOwnPropertyDescriptor, __decorateClass = (t, s, r, l) => {
  for (var i = __getOwnPropDesc(s, r), e = t.length - 1, c; e >= 0; e--)
    (c = t[e]) && (i = c(s, r, i) || i);
  return i && __defProp(s, r, i), i;
};
class Stepper extends LitElement {
  constructor() {
    super(...arguments), this._steps = [], this._currentStep = 1, this._column = !1, this._circular = !1, this._hideLabel = !1, this._size = "md", this._activeBarWidth = "0", this._isFirstUpdate = !0;
  }
  static get styles() {
    return unsafeCSS(styles);
  }
  set steps(steps) {
    const oldValue = this._steps;
    this._steps = steps, typeof steps == "string" && (this._steps = eval(`(${steps})`)), this.requestUpdate("steps", oldValue);
  }
  get steps() {
    return this._steps;
  }
  set currentStep(t) {
    const s = this._currentStep;
    this._currentStep = t, this.requestUpdate("currentStep", s);
  }
  get currentStep() {
    return this._currentStep;
  }
  set column(t) {
    const s = this._column;
    this._column = t, this.requestUpdate("column", s);
  }
  get column() {
    return this._column;
  }
  set circular(t) {
    const s = this._circular;
    this._circular = t, this.requestUpdate("circular", s);
  }
  get circular() {
    return this._circular;
  }
  set hideLabel(t) {
    const s = this._hideLabel;
    this._hideLabel = t, this.requestUpdate("hideLabel", s);
  }
  get hideLabel() {
    return this._hideLabel;
  }
  set size(t) {
    const s = this._size;
    this._size = t, this.requestUpdate("size", s);
  }
  get size() {
    return this._size;
  }
  async firstUpdated() {
    await this.updateComplete, this._setActiveBarWidth(), this._isFirstUpdate = !1, this.requestUpdate();
  }
  willUpdate(t) {
    this._isFirstUpdate || (t.has("currentStep") || t.has("steps") || t.has("column")) && (this._setActiveBarWidth(), this.requestUpdate());
  }
  _setActiveBarWidth() {
    var i;
    const t = this._steps.length, s = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-stepper"), r = s == null ? void 0 : s.getBoundingClientRect(), l = this._column ? r == null ? void 0 : r.height : r == null ? void 0 : r.width;
    if (l) {
      const e = Math.floor(l / (t - 1));
      this._activeBarWidth = `${e}px`;
    }
  }
  _onStepClick(t, s) {
    if (!(t.state === "disabled")) {
      const l = {
        detail: { step: t, stepNumber: s },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onStepClick", l));
    }
  }
  render() {
    var l, i;
    const t = (l = this._steps) == null ? void 0 : l.length, s = Math.round(this._currentStep / t * 100), r = {
      "dss-stepper--vertical": this._column,
      "dss-stepper--sm": this._size === "sm",
      "dss-stepper--md": this._size === "md"
    };
    return html`
      ${this._circular ? html`
            <div class="dss-circular-stepper">
              <div class="dss-circular-stepper__item">
                <svg viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="33" cy="33" r="28" pathLength="100"></circle>
                  <circle
                    cx="33"
                    cy="33"
                    r="28"
                    style="--percent: ${s}"
                    pathLength="100"
                  ></circle>
                </svg>
                <span class="dss-circular-stepper__counter">
                  <b>${this._currentStep}</b>/${t}
                </span>
              </div>
              <span class="dss-circular-stepper__label">
                ${this._steps[this._currentStep - 1].label}
              </span>
            </div>
          ` : html`
            <style>
              :host {
                --active-bar-width: ${this._activeBarWidth};
              }
            </style>
            <ol class="dss-stepper ${classMap(r)}">
              ${(i = this._steps) == null ? void 0 : i.map((e, c) => {
      const a = c + 1, p = (d) => {
        d.key === "Enter" && this._onStepClick(e, a);
      }, o = e.state === "disabled", n = {
        "dss-bubble--active": a === this._currentStep,
        "dss-bubble--completed": a < this._currentStep,
        "dss-bubble--checked": e.state === "checked" && a !== this._currentStep,
        "dss-bubble--error": e.state === "error" && a !== this._currentStep,
        "dss-bubble--info": e.state === "info" && a !== this._currentStep,
        "dss-bubble--alert": e.state === "alert" && a !== this._currentStep,
        "dss-bubble--disabled": e.state === "disabled",
        "dss-bubble--icon": !!(e != null && e.icon) && this._size !== "sm"
      }, h = {
        "dss-bubble-label--disabled": e.state === "disabled",
        "hide-label": this._hideLabel
      };
      return html`
                  <li
                    class="dss-bubble ${classMap(n)}"
                    icon="${(e == null ? void 0 : e.icon) || ""}"
                    tabindex="${o ? -1 : 0}"
                    aria-label="Step ${e == null ? void 0 : e.state}"
                    @click=${() => this._onStepClick(e, a)}
                    @keydown=${p}
                  >
                    <span class="dss-bubble-label ${classMap(h)}"
                      >${unsafeHTML(e.label)}</span
                    >
                  </li>
                `;
    })}
            </ol>
          `}
    `;
  }
}
__decorateClass([
  property({ type: [] })
], Stepper.prototype, "steps");
__decorateClass([
  property({ type: Number })
], Stepper.prototype, "currentStep");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "column");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "circular");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "hideLabel");
__decorateClass([
  property({ type: String })
], Stepper.prototype, "size");
export {
  Stepper
};
//# sourceMappingURL=stepper.js.map
