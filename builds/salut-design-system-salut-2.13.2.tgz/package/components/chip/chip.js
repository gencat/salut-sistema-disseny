import { LitElement as c, unsafeCSS as h } from "lit";
import { property as t } from "lit/decorators.js";
import p from "../../shared/reset.style.css.js";
import { booleanType as o } from "../../utils/property-types.js";
import f from "./chip.style.css.js";
import { template as y } from "./chip.template.js";
var b = Object.defineProperty, s = (r, e, a, u) => {
  for (var l = void 0, d = r.length - 1, n; d >= 0; d--)
    (n = r[d]) && (l = n(e, a, l) || l);
  return l && b(e, a, l), l;
};
class i extends c {
  constructor() {
    super(...arguments), this.size = "lg", this.icon = "", this.label = "", this.hasDelete = !1, this.disabled = !1, this.selected = !1, this.disableSelect = !1, this._isLabelTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [h(p), h(f)];
  }
  handleToggle() {
    this.disableSelect || this.disabled || (this.selected = !this.selected, this.dispatchEvent(
      new CustomEvent("onToggle", {
        detail: {
          text: this.label,
          selected: this.selected
        }
      })
    ));
  }
  handleKeydown(e) {
    e.stopPropagation(), (e.key === "Enter" || e.key === "Space") && this.handleToggle();
  }
  handleDelete(e) {
    e.stopPropagation(), this.dispatchEvent(
      new CustomEvent("onDelete", {
        detail: {
          text: this.label
        }
      })
    );
  }
  async firstUpdated() {
    await this.updateComplete, this._checkLabelTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(e) {
    !this._isFirstUpdated && e.has("label") && this._checkLabelTruncated();
  }
  _checkLabelTruncated() {
    var a;
    const e = (a = this.shadowRoot) == null ? void 0 : a.querySelector(".dss-chip__label");
    e && (this._isLabelTruncated = e.scrollWidth > e.offsetWidth, this.requestUpdate());
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("keydown", this.onKeyDown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("keydown", this.onKeyDown);
  }
  onKeyDown(e) {
    (e.code === "Enter" || e.code === "NumpadEnter" || e.code === "Space") && this.handleToggle(), (e.code === "Backspace" && this.hasDelete || e.code === "Delete" && this.hasDelete) && this.handleDelete(e);
  }
  render() {
    return y(this);
  }
}
s([
  t({ type: String })
], i.prototype, "size");
s([
  t({ type: String })
], i.prototype, "icon");
s([
  t({ type: String })
], i.prototype, "label");
s([
  t(o)
], i.prototype, "hasDelete");
s([
  t(o)
], i.prototype, "disabled");
s([
  t(o)
], i.prototype, "selected");
s([
  t(o)
], i.prototype, "disableSelect");
export {
  i as Chip
};
//# sourceMappingURL=chip.js.map
