import { nothing as l } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { when as d } from "lit/directives/when.js";
import { unsafeStatic as e, literal as a, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
const c = a`dss-icon${e($())}`, h = a`dss-icon-button${e($())}`, t = a`dss-tooltip${e($())}`, o = (s) => i`
  <div
    class=${r({
  "dss-chip": !0,
  "dss-chip--disabled": s.disabled,
  "dss-chip--not-clickable": s.disableSelect,
  "dss-chip--selected": s.selected,
  "dss-chip--has-icons": !!s.icon || s.hasDelete,
  "dss-chip--only-icon": !!(s.icon && !s.label) && !s.hasDelete,
  [`dss-chip--${s.size}`]: !!s.size
})}
    role="button"
    aria-pressed=${s.selected}
    tabindex="0"
    @click=${s.handleToggle}
    @keydown=${s.handleKeydown}
    >

    ${d(
  s.icon,
  () => i`
      <div class="dss-chip__icon">
        <${c}
          icon="${s.icon}"
          size="${s.size === "lg" ? "md" : "sm"}">
        </${c}>
      </div>
    `,
  () => l
)}

    ${d(
  s.label,
  () => i`
        <div class="dss-chip__label">
          ${s.label}
        </div>
      `,
  () => l
)}

    ${d(
  s.hasDelete,
  () => i`
      <div class="dss-chip__delete">
        <${h}
          variant="info"
          icon="cancel"
          label="Eliminar"
          hideTooltip
          size="${s.size === "sm" ? "sm" : "md"}"
          ?disabled=${s.disabled}
          @click=${s.handleDelete}>
        </${h}>
      </div>
      `,
  () => l
)}

    ${d(
  s._isLabelTruncated,
  () => i`
        <${t}>
          ${s.label}
        </${t}>
      `,
  () => l
)}
  </div>
`;
export {
  o as template
};
//# sourceMappingURL=chip.template.js.map
