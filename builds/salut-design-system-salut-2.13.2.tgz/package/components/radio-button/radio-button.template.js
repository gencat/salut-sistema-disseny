import { classMap as l } from "lit/directives/class-map.js";
import { html as t } from "lit/static-html.js";
const r = (s) => {
  const a = {
    "dss-radio-wrapper--disabled": s.disabled
  };
  return t`
    <div class="dss-radio-wrapper ${l(a)}">
			<div class="dss-radio-container">
        <slot name="input" @click="${s.handleInput}"></slot>
      </div>
      <slot name="label"></slot>
    </div>
  `;
};
export {
  r as template
};
//# sourceMappingURL=radio-button.template.js.map
