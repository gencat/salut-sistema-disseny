import { LitElement as c, unsafeCSS as d } from "lit";
import { property as o } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import u from "./radio-button.style.css.js";
import { template as m } from "./radio-button.template.js";
var f = Object.defineProperty, s = (i, r, e, v) => {
  for (var t = void 0, l = i.length - 1, n; l >= 0; l--)
    (n = i[l]) && (t = n(r, e, t) || t);
  return t && f(r, e, t), t;
};
class a extends c {
  constructor() {
    super(...arguments), this.label = "", this.value = !1, this.checked = !1, this.disabled = !1;
  }
  static get styles() {
    return [d(h), d(u)];
  }
  handleInput(r) {
    const e = r.target;
    this.checked = e.checked, this.value = e.checked, this.dispatchEvent(
      new CustomEvent("onChange", {
        detail: { value: e.value, checked: this.checked },
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    return m(this);
  }
}
s([
  o({ type: String })
], a.prototype, "label");
s([
  o(p)
], a.prototype, "value");
s([
  o(p)
], a.prototype, "checked");
s([
  o(p)
], a.prototype, "disabled");
export {
  a as RadioButton
};
//# sourceMappingURL=radio-button.js.map
