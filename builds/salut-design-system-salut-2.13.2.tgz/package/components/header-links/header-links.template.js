import { unsafeStatic as a, literal as t, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
const s = t`dss-button${a(d())}`, $ = (l) => i`
  <ul class="dss-header-links" role="menu">
    ${l._items.map(
  (e) => i`
        <li class="dss-header-links__item" role="menuitem">
          <${s}
            variant="subtle"
            size="${l._buttonSize}"
            icon="${e.icon ? e.icon : void 0}"
            label="${e.label}"
            ?disabled=${e.disabled}
            @click=${() => l._dispatchItemAction(e)}
            ?onlyIcon="${l._isBreakpointSm}"
          >  
          </${s}>
        </li>
      `
)}
    ${l._hideHelp ? null : i`
          <li class="dss-header-links__item" role="menuitem">
            <${s}
              class="dss-header-links__button-default"
              variant="subtle"
              size="${l._buttonSize}"
              icon="help_outline"
              label="${l._helpLabel}"
              ?disabled=${l._disableHelp}
              @click=${l._handleHelp}
              ?onlyIcon="${l._isBreakpointSm}"
            >  
            </${s}>
          </li>
        `}
  </ul>
`;
export {
  $ as headerLinksTemplate
};
//# sourceMappingURL=header-links.template.js.map
