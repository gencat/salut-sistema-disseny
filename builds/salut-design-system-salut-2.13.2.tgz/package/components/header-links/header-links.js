import { LitElement as m, unsafeCSS as d } from "lit";
import { property as i } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import _ from "./header-links.style.css.js";
import { headerLinksTemplate as c } from "./header-links.template.js";
var b = Object.defineProperty, f = Object.getOwnPropertyDescriptor, l = (n, e, t, h) => {
  for (var s = h > 1 ? void 0 : h ? f(e, t) : e, o = n.length - 1, p; o >= 0; o--)
    (p = n[o]) && (s = (h ? p(e, t, s) : p(s)) || s);
  return h && s && b(e, t, s), s;
};
class r extends m {
  constructor() {
    super(), this.jcef = !1, this._hideHelp = !1, this._disableHelp = !1, this._helpLabel = "Ajuda", this._items = [], this._isBreakpointSm = !1, this._buttonSize = "md", this._resizeTimer = null, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [d(u), d(_)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound);
  }
  set hideHelp(e) {
    const t = this._hideHelp;
    this._hideHelp = e, this.requestUpdate("hideHelp", t);
  }
  get hideHelp() {
    return this._hideHelp;
  }
  set disableHelp(e) {
    const t = this._disableHelp;
    this._disableHelp = e, this.requestUpdate("disableHelp", t);
  }
  get disableHelp() {
    return this._disableHelp;
  }
  set helpLabel(e) {
    const t = this._helpLabel;
    this._helpLabel = e, this.requestUpdate("helpLabel", t);
  }
  get helpLabel() {
    return this._helpLabel;
  }
  set items(e) {
    const t = this._items;
    this._items = e, this.requestUpdate("items", t);
  }
  get items() {
    return this._items;
  }
  /* METHODS */
  _dispatchItemAction(e) {
    const t = {
      detail: e,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickLink", t));
  }
  _handleHelp() {
    this.dispatchEvent(new CustomEvent("onHelp", { bubbles: !0, composed: !0 }));
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      const e = window.innerWidth, t = this.jcef ? 1418 : 1439;
      this._isBreakpointSm = e <= t, this._buttonSize = this._isBreakpointSm ? "lg" : "md", this.requestUpdate();
    }, 250);
  }
  render() {
    return c(this);
  }
}
l([
  i(a)
], r.prototype, "jcef", 2);
l([
  i(a)
], r.prototype, "hideHelp", 1);
l([
  i(a)
], r.prototype, "disableHelp", 1);
l([
  i({ type: String })
], r.prototype, "helpLabel", 1);
l([
  i({ type: Array })
], r.prototype, "items", 1);
export {
  r as HeaderLinks
};
//# sourceMappingURL=header-links.js.map
