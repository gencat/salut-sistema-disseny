const s = ":host{display:block}.dss-header-links{display:flex;align-items:center;gap:var(--dss-spacing-xs)}";
export {
  s as default
};
//# sourceMappingURL=header-links.style.css.js.map
