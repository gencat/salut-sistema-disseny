import { html as o } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
const n = (l) => o`
  <ul
    class=${t({
  "dss-action-menu": !0,
  "dss-action-menu--full-width": !!l._fullWidth
})}
    aria-label="Menu d'accions"
    role="menu"
  >
    <slot></slot>
  </ul>
`;
export {
  n as actionMenuTemplate
};
//# sourceMappingURL=action-menu.template.js.map
