import { createPopper as p } from "@popperjs/core";
import { LitElement as c, unsafeCSS as u } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as h } from "../../utils/property-types.js";
import { template as _ } from "./datepicker-range.template.js";
import g from "../../shared/reset.style.css.js";
import f from "../input/input.style.css.js";
import m from "./datepicker-range.style.css.js";
var v = Object.defineProperty, R = Object.getOwnPropertyDescriptor, n = (d, t, e, a) => {
  for (var s = a > 1 ? void 0 : a ? R(t, e) : t, o = d.length - 1, l; o >= 0; o--)
    (l = d[o]) && (s = (a ? l(t, e, s) : l(s)) || s);
  return a && s && v(t, e, s), s;
};
class r extends c {
  constructor() {
    super(), this.inputSize = "lg", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.customCalendar = void 0, this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "El rang de dates és anterior a la permesa.", this.errorMessageMaxDate = "El rang de dates és posterior a la permesa.", this._iconRangeStart = "calendar_month", this._iconRangeEnd = "calendar_month", this._dateformatPlaceholder = "DD/MM/AAAA", this._isStartFocused = !1, this._isEndFocused = !1, this._invalid = !1, this._showCalendar = !1, this._helpText = "", this._minDate = "", this._maxDate = "", this._calendarShowButtons = !1, this._calendarLeftButtonLabel = "Cancel·lar", this._calendarRightButtonLabel = "Seleccionar", this._copyInputRangeStartPlaceholder = "", this._copyInputRangeEndPlaceholder = "", this._isFirstInputsCheck = !0, this._popperInstance = null, this._helpTextBackup = "", this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && this._checkInputAttributes();
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showCalendar && this._closeCalendar();
      },
      {
        root: null,
        // Usa el viewport como referencia
        threshold: 0
        // Llama al callback en cuanto cualquier parte del elemento deja de ser visible
      }
    ), this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [u(g), u(f), u(m)];
  }
  /* SLOTS */
  get _inputRangeStart() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input-range-start"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  get _inputRangeEnd() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input-range-end"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set iconRangeStart(t) {
    const e = this._iconRangeStart;
    this._iconRangeStart = t, this.requestUpdate("iconRangeStart", e);
  }
  get iconRangeStart() {
    return this._iconRangeStart;
  }
  set iconRangeEnd(t) {
    const e = this._iconRangeEnd;
    this._iconRangeEnd = t, this.requestUpdate("iconRangeEnd", e);
  }
  get iconRangeEnd() {
    return this._iconRangeEnd;
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = t, this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate;
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = t, this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set showButtons(t) {
    const e = this._calendarShowButtons;
    this._calendarShowButtons = t, this.requestUpdate("calendarShowButtons", e);
  }
  get showButtons() {
    return this._calendarShowButtons;
  }
  set calendarLeftButtonLabel(t) {
    const e = this._calendarLeftButtonLabel;
    this._calendarLeftButtonLabel = t, this.requestUpdate("calendarLeftButtonLabel", e);
  }
  get calendarLeftButtonLabel() {
    return this._calendarLeftButtonLabel;
  }
  set calendarRightButtonLabel(t) {
    const e = this._calendarRightButtonLabel;
    this._calendarRightButtonLabel = t, this.requestUpdate("calendarRightButtonLabel", e);
  }
  get calendarRightButtonLabel() {
    return this._calendarRightButtonLabel;
  }
  disconnectedCallback() {
    this._removeCalendarListener(), this.observer.disconnect(), this.visibleObserver.disconnect();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  /* METHODS */
  _checkInputAttributes() {
    this._isFirstInputsCheck && this._inputRangeStart && (this._copyInputRangeStartPlaceholder = this._inputRangeStart.placeholder), this._isFirstInputsCheck && this._inputRangeEnd && (this._copyInputRangeEndPlaceholder = this._inputRangeEnd.placeholder), this._isFirstInputsCheck = !1;
  }
  _updatePlaceholders() {
    this._isStartFocused && !this._copyInputRangeStartPlaceholder && (this._inputRangeStart.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate()), this._isEndFocused && !this._copyInputRangeEndPlaceholder && (this._inputRangeEnd.setAttribute("placeholder", this._dateformatPlaceholder), this.requestUpdate());
  }
  _removePlaceholders() {
    this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
  }
  // _handleValidity() {
  //   const startValidity = this._inputRangeStart?.checkValidity();
  //   if (startValidity !== undefined) this._inputStartValidity = startValidity;
  //   const endValidity = this._inputRangeEnd?.checkValidity();
  //   if (endValidity !== undefined) this._inputEndValidity = endValidity;
  // }
  _handleRangeStartInput(t) {
    if (t.target) {
      const a = t.target.value.replace(/\D/g, "");
      this._inputRangeStart.value = this._formatDate(a);
    }
  }
  _handleRangeEndInput(t) {
    if (t.target) {
      const a = t.target.value.replace(/\D/g, "");
      this._inputRangeEnd.value = this._formatDate(a);
    }
  }
  _handleRangeStartClick() {
    this._showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate();
  }
  _handleRangeEndClick() {
    this._showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate();
  }
  _handleRangeStartFocusIn() {
    this._isStartFocused || (this._isStartFocused = !0, this._isEndFocused = !1, this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder"), this._updatePlaceholders(), this.requestUpdate());
  }
  _handleRangeEndFocusIn() {
    this._isEndFocused || (this._isStartFocused = !1, this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder"), this._isEndFocused = !0, this._updatePlaceholders(), this.requestUpdate());
  }
  _handleRangeKeydown(t) {
    var e, a;
    (t == null ? void 0 : t.key) === "Tab" ? this._showCalendar && this._isStartFocused && (t.preventDefault(), this.dispatchEvent(
      new CustomEvent("range-focus-calendar", {
        bubbles: !0,
        composed: !0
      })
    )) : (t == null ? void 0 : t.key) === "Enter" && this._showCalendar && ((e = this._inputRangeStart.value) == null ? void 0 : e.length) > 7 && ((a = this._inputRangeEnd.value) == null ? void 0 : a.length) > 7 ? this._closeCalendar() : (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this._showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate()) : (t == null ? void 0 : t.key) === "Escape" && (this._showCalendar = !1, this._popperInstance.update(), this._removeCalendarListener(), this.requestUpdate());
  }
  _onCalendarChange(t) {
    const e = t.detail;
    if (e.rangeStart) {
      this._inputRangeStart.value = t.detail.rangeStart;
      const a = this._convertToISO(e.rangeStart), s = this._convertToISO(this._inputRangeEnd.value);
      this._inputRangeEnd.value && new Date(s) < new Date(a) && (this._inputRangeEnd.value = "", e.rangeEnd = null);
    }
    e.rangeEnd ? this._inputRangeEnd.value = t.detail.rangeEnd : this._inputRangeEnd.value = "", this._inputRangeEnd.value || (this._inputRangeEnd.focus(), this._isStartFocused = !1, this._isEndFocused = !0), this._inputRangeStart.value && this._inputRangeEnd.value && (this._showCalendar = !1, this._isStartFocused = !1, this._isEndFocused = !1, this._removeCalendarListener()), this.validate && this._validateDate(), this.requestUpdate();
  }
  _onCalendarCancel() {
    this._showCalendar = !1, this._removeCalendarListener(), this.requestUpdate();
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._inputRangeStart && e !== this._inputRangeEnd && this._showCalendar && this._closeCalendar();
  }
  _clearDate(t) {
    switch (t) {
      case "rangeStart":
        if (!this._inputRangeStart) return;
        this._inputRangeStart.value = "", this._copyInputRangeStartPlaceholder || this._inputRangeStart.removeAttribute("placeholder");
        break;
      case "rangeEnd":
        if (!this._inputRangeEnd) return;
        this._inputRangeEnd.value = "", this._copyInputRangeEndPlaceholder || this._inputRangeEnd.removeAttribute("placeholder");
        break;
    }
    this._validateDate(), this.requestUpdate();
  }
  _closeCalendar() {
    var t, e;
    this._removePlaceholders(), this._isStartFocused = !1, this._isEndFocused = !1, this._showCalendar = !1, (t = this._inputRangeStart) == null || t.blur(), (e = this._inputRangeEnd) == null || e.blur(), this._removeCalendarListener(), this.validate && this._validateDate(), this.requestUpdate();
  }
  _formatDate(t) {
    let e = t.substring(0, 2), a = t.substring(2, 4);
    const s = t.substring(4, 8);
    return Number(e) > 3 && (e = e == null ? void 0 : e.padStart(2, "0")), Number(a) > 1 && (a = a == null ? void 0 : a.padStart(2, "0")), Number(e) > 31 && (e = "31"), Number(a) > 12 && (a = "12"), a === "02" && Number(e) > 28 && (s == null ? void 0 : s.length) === 4 && (e = new Date(Number(s), 1, 29).getMonth() === 1 ? "29" : "28"), `${e}${a ? `/${a}` : ""}${s ? `/${s}` : ""}`;
  }
  _validateDate() {
    var e, a;
    let t = this._checkDateFormat((e = this._inputRangeStart) == null ? void 0 : e.value);
    t || (t = this._checkDateFormat((a = this._inputRangeEnd) == null ? void 0 : a.value)), this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    if (!t || t === void 0)
      return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
    if (t === "")
      return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
    if (t.length < 10)
      return this._helpText = this.errorMessageFormat, this._invalid = !0, !0;
    if (this._minDate || this._maxDate) {
      const a = new Date(this._convertToISO(t)), s = new Date(this._convertToISO(this._minDate)), o = new Date(this._convertToISO(this._maxDate));
      if (s && a < s)
        return this._helpText = this.errorMessageMinDate, this._invalid = !0, !0;
      if (o && a > o)
        return this._helpText = this.errorMessageMaxDate, this._invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
  }
  _convertToISO(t) {
    const [e, a, s] = t.split("/");
    return `${s}-${a}-${e}`;
  }
  _dispatchOnValidate(t) {
    var a, s;
    const e = {
      detail: {
        rangeStart: (a = this._inputRangeStart) == null ? void 0 : a.value,
        rangeEnd: (s = this._inputRangeEnd) == null ? void 0 : s.value,
        invalid: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onValidate", e));
  }
  _createPopperCalendar() {
    var a, s;
    const t = (a = this.shadowRoot) == null ? void 0 : a.querySelector(".dss-datepicker-range-inputs__start"), e = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-calendar");
    t && e && (this._popperInstance = p(t, e, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    try {
      await this.updateComplete, this._helpTextBackup = this.helpText, this._createPopperCalendar(), this._inputRangeStart && this._inputRangeEnd && (this._inputRangeStart.classList.add("dss-input-skip-native"), this._inputRangeEnd.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._inputRangeStart, this.observerConfig), this.observer.observe(this._inputRangeEnd, this.observerConfig), this.visibleObserver.observe(this._inputRangeStart));
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return _(this);
  }
}
n([
  i({ type: String })
], r.prototype, "iconRangeStart", 1);
n([
  i({ type: String })
], r.prototype, "iconRangeEnd", 1);
n([
  i({ type: String })
], r.prototype, "minDate", 1);
n([
  i({ type: String })
], r.prototype, "maxDate", 1);
n([
  i(h)
], r.prototype, "invalid", 1);
n([
  i({ type: String })
], r.prototype, "inputSize", 2);
n([
  i({ type: String })
], r.prototype, "helpText", 1);
n([
  i(h)
], r.prototype, "showButtons", 1);
n([
  i({ type: String })
], r.prototype, "calendarLeftButtonLabel", 1);
n([
  i({ type: String })
], r.prototype, "calendarRightButtonLabel", 1);
n([
  i({ type: String })
], r.prototype, "dropdownPlacement", 2);
n([
  i(h)
], r.prototype, "dropdownFixed", 2);
n([
  i({ type: Array })
], r.prototype, "customCalendar", 2);
n([
  i(h)
], r.prototype, "validate", 2);
n([
  i(h)
], r.prototype, "errorMessageFormat", 2);
n([
  i(h)
], r.prototype, "errorMessageMinDate", 2);
n([
  i(h)
], r.prototype, "errorMessageMaxDate", 2);
export {
  r as DatepickerRange
};
//# sourceMappingURL=datepicker-range.js.map
