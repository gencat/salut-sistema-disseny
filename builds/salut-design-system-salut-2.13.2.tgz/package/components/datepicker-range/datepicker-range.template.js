import { nothing as e } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { ifDefined as V } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as t, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const P = t`dss-calendar${l(u())}`, s = t`dss-icon${l(u())}`, r = t`dss-icon-button${l(u())}`, aa = (a) => {
  var n, g, p, _, $, R, v, S, b, h, E, C, k, f, w, y, c, z, D, I, x, B, q, F, O, L, T, j, G, K, N;
  const W = {
    "dss-datepicker-range--sm": a.inputSize !== "lg"
  }, M = {
    "dss-datepicker-range-help--invalid": a._invalid || !((n = a._inputRangeStart) != null && n.validity.valid) && ((g = a._inputRangeStart) == null ? void 0 : g.value) !== "" || !((p = a._inputRangeEnd) != null && p.validity.valid) && ((_ = a._inputRangeEnd) == null ? void 0 : _.value) !== "",
    "dss-datepicker-range-help--disabled": (($ = a._inputRangeStart) == null ? void 0 : $.disabled) && ((R = a._inputRangeEnd) == null ? void 0 : R.disabled)
  }, A = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": (v = a._inputRangeStart) == null ? void 0 : v.required,
    "dss-input-wrapper--disabled": (S = a._inputRangeStart) == null ? void 0 : S.disabled,
    [`dss-input-wrapper--${a.inputSize}`]: !!a.inputSize
  }, H = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": (b = a._inputRangeEnd) == null ? void 0 : b.required,
    "dss-input-wrapper--disabled": (h = a._inputRangeEnd) == null ? void 0 : h.disabled,
    [`dss-input-wrapper--${a.inputSize}`]: !!a.inputSize
  }, J = {
    "dss-input-group": !0,
    [`dss-input-group--${a.inputSize}`]: !!a.inputSize,
    "dss-input-group--invalid": a._invalid || !((E = a._inputRangeStart) != null && E.validity.valid) && ((C = a._inputRangeStart) == null ? void 0 : C.value) !== "",
    "dss-input-group--required": (k = a._inputRangeStart) == null ? void 0 : k.required,
    "dss-input-group--disabled": (f = a._inputRangeStart) == null ? void 0 : f.disabled,
    "dss-input-group--focused": ((w = a._inputRangeStart) == null ? void 0 : w.value) || a._isStartFocused || a._copyInputRangeStartPlaceholder,
    "dss-input-group--read-only": (y = a._inputRangeStart) == null ? void 0 : y.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, Q = {
    "dss-input-group": !0,
    [`dss-input-group--${a.inputSize}`]: !!a.inputSize,
    "dss-input-group--invalid": a._invalid || !((c = a._inputRangeEnd) != null && c.validity.valid) && ((z = a._inputRangeEnd) == null ? void 0 : z.value) !== "",
    "dss-input-group--required": (D = a._inputRangeEnd) == null ? void 0 : D.required,
    "dss-input-group--disabled": (I = a._inputRangeEnd) == null ? void 0 : I.disabled,
    "dss-input-group--focused": ((x = a._inputRangeEnd) == null ? void 0 : x.value) || a._isEndFocused || a._copyInputRangeEndPlaceholder,
    "dss-input-group--read-only": (B = a._inputRangeEnd) == null ? void 0 : B.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, U = {
    "dss-calendar": !0,
    "dss-calendar--visible": a._showCalendar && !((q = a._inputRangeStart) != null && q.readOnly) && !((F = a._inputRangeEnd) != null && F.readOnly),
    "dss-calendar--disabled": ((O = a._inputRangeStart) == null ? void 0 : O.disabled) && ((L = a._inputRangeEnd) == null ? void 0 : L.disabled),
    "dss-calendar--sm": a.inputSize !== "lg"
  };
  return i`
      <div class="dss-datepicker-range ${d(W)}">
        <div 
          class="dss-datepicker-range-inputs" 
          role="combobox"
          aria-controls="datepicker-range-calendar"
          aria-expanded=${V(a._showCalendar)}>

          <div class="dss-datepicker-range-inputs__start ${d(A)}">
            ${a.inputSize === "sm" ? i`
              <div class="dss-wrapper-label">
                <slot name="label-range-start"></slot>
              </div>
              ` : e}
            <div class="${d(J)}">
              ${a._iconRangeStart && a._iconRangeStart !== "" ? i`
                <${s} icon="${a._iconRangeStart}" class="dss-input-icon"></${s}>
                ` : e}
              <div class="dss-input-field">
                ${a.inputSize !== "sm" ? i`
                  <slot name="label-range-start"></slot>
                  ` : e}
                <slot name="input-range-start"
                  @click=${a._handleRangeStartClick}
                  @input=${a._handleRangeStartInput}
                  @focusin=${a._handleRangeStartFocusIn}
                  @keydown=${a._handleRangeKeydown}
                ></slot>
              </div>
							<${r}
								hideTooltip
							  label="Netejar data"
								size="md"
								icon="close"
								@onClick=${() => a._clearDate("rangeStart")}
								?hidden=${!((T = a._inputRangeStart) != null && T.value) || a._inputRangeStart.readOnly || a._inputRangeStart.disabled}
							></${r}>
            </div>
          </div>

          <div class="dss-datepicker-range-inputs__end ${d(H)}">
            ${a.inputSize === "sm" ? i`
              <div class="dss-wrapper-label">
                <slot name="label-range-end"></slot>
              </div>
              ` : e}
            <div class="${d(Q)}">
              ${a._iconRangeEnd && a._iconRangeEnd !== "" ? i`
                <${s} icon="${a._iconRangeEnd}" class="dss-input-icon"></${s}>
                ` : e}
              <div class="dss-input-field">
                ${a.inputSize !== "sm" ? i`
                  <slot name="label-range-end"></slot>
                  ` : e}
                <slot name="input-range-end"
                  @click=${a._handleRangeEndClick}
                  @input=${a._handleRangeEndInput}
                  @focusin=${a._handleRangeEndFocusIn}
                  @keydown=${a._handleRangeKeydown}
                ></slot>
              </div>
							<${r}
								hideTooltip
 								label="Netejar data"
								size="md"
								icon="close"
								@onClick=${() => a._clearDate("rangeEnd")}
								?hidden=${!((j = a._inputRangeEnd) != null && j.value) || a._inputRangeEnd.readOnly || a._inputRangeEnd.disabled}
							></${r}>
            </div>
          </div>
       
        </div>

        ${a._helpText ? i`
              <div class="dss-datepicker-range-help ${d(M)}">
                ${a._helpText}
              </div>
            ` : null}
       
        <${P}
          range
          .isRangeStartFocused=${a._isStartFocused}
          .isRangeEndFocused=${a._isEndFocused}
          role="listbox"
          aria-label="Datepicker Range Calendar"
          id="datepicker-range-calendar"
          class="${d(U)}"
          .selectedDate="${(G = a._inputRangeStart) == null ? void 0 : G.value}"
          .rangeStartDate="${(K = a._inputRangeStart) == null ? void 0 : K.value}"
          .rangeEndDate="${(N = a._inputRangeEnd) == null ? void 0 : N.value}"
					.customCalendar=${a.customCalendar}
          .showButtons=${a._calendarShowButtons}
          .leftLabel=${a._calendarLeftButtonLabel}
          .rightLabel=${a._calendarRightButtonLabel}
          .minDate=${a._minDate}
          .maxDate=${a._maxDate}
          @onRangeChange=${a._onCalendarChange}
          @onCancel=${a._onCalendarCancel}
        ></${P}>
      </div>
    `;
};
export {
  aa as template
};
//# sourceMappingURL=datepicker-range.template.js.map
