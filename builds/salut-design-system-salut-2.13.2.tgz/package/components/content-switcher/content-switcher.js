import { LitElement as p, unsafeCSS as d } from "lit";
import { property as o, state as c } from "lit/decorators.js";
import f from "../../shared/elevation.style.css.js";
import b from "../../shared/reset.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import m from "./content-switcher.style.css.js";
import { template as _ } from "./content-switcher.template.js";
var S = Object.defineProperty, i = (a, t, e, r) => {
  for (var s = void 0, h = a.length - 1, n; h >= 0; h--)
    (n = a[h]) && (s = n(t, e, s) || s);
  return s && S(t, e, s), s;
};
class l extends p {
  constructor() {
    super(...arguments), this.fullWidth = !1, this.size = "md", this.tabs = [], this._isFirstUpdate = !0, this._tabs = [];
  }
  connectedCallback() {
    super.connectedCallback(), this._initializeSelectedTab();
  }
  static get styles() {
    return [d(b), d(f), d(m)];
  }
  _onSelect(t) {
    t.selected = !0, this.tabSelected = t, this._tabs = this._tabs.map((e) => {
      var r;
      return { ...e, selected: e.label === ((r = this.tabSelected) == null ? void 0 : r.label) };
    }), this.dispatchEvent(new CustomEvent("onChange", { detail: this.tabSelected.label })), this.requestUpdate();
  }
  _checkFullWidth() {
    this.fullWidth ? this.classList.add("full-width") : this.classList.remove("full-width");
  }
  _initializeSelectedTab() {
    this._tabs = this.tabs.map((t) => ({ ...t })), this.tabSelected = this._tabs.find((t) => t.selected) || this._tabs.find((t) => !t.disabled);
  }
  willUpdate(t) {
    if (t.has("tabs")) {
      if (this._isFirstUpdate) {
        this._isFirstUpdate = !1;
        return;
      }
      const e = t.get("tabs");
      if (JSON.stringify(e) === JSON.stringify(this.tabs))
        return;
      this._initializeSelectedTab();
    }
  }
  updated(t) {
    t.has("fullWidth") && this._checkFullWidth();
  }
  render() {
    return _(this);
  }
}
i([
  o(u)
], l.prototype, "fullWidth");
i([
  o({ type: String })
], l.prototype, "size");
i([
  o({ type: Array })
], l.prototype, "tabs");
i([
  c()
], l.prototype, "tabSelected");
export {
  l as ContentSwitcher
};
//# sourceMappingURL=content-switcher.js.map
