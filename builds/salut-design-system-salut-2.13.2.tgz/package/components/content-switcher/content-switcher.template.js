import { nothing as r, html as i } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { repeat as n } from "lit/directives/repeat.js";
const m = (l) => i`
  <div class=${t({
  "dss-content-switcher": !0,
  "dss-content-switcher--full-width": l.fullWidth
})}
    role="radiogroup" 
    aria-orientation="horizontal">
    ${n(
  l._tabs,
  (e) => e.label,
  (e, s) => {
    var a, d;
    const c = {
      "dss-elevation--md": !!e.selected
    }, o = {
      "dss-content-switcher__item": !0,
      "dss-content-switcher__item--selected": !!e.selected,
      [`dss-content-switcher__item--${l.size}`]: !!l.size
    };
    return i`
          <div class=${t(o)}>
            <input
              id="radio-${s}"
              type="radio"
              tabindex=${e.selected || e.label === ((a = l.tabSelected) == null ? void 0 : a.label) ? "0" : "-1"}
              name="tab"
              ?checked=${e.selected || e.label === ((d = l.tabSelected) == null ? void 0 : d.label)}
              ?disabled=${e.disabled}
              @change=${() => l._onSelect(e)}
              aria-labelledby="label-${s}"
            />
            <label id="label-${s}" class=${t(c)}>
              ${e.icon ? i`
                <dss-icon icon="${e.icon}" size="${l.size === "lg" ? "md" : "sm"}" class="tab-icon"></dss-icon>
              ` : r}
              ${e.label}
            </label>
          </div>
        `;
  }
)}
  </div>
`;
export {
  m as template
};
//# sourceMappingURL=content-switcher.template.js.map
