import { LitElement as l, unsafeCSS as d, html as h } from "lit";
import { property as i } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import { booleanType as g } from "../../utils/property-types.js";
import c from "./table-pagination.style.css.js";
var x = Object.defineProperty, S = Object.getOwnPropertyDescriptor, n = (_, t, e, o) => {
  for (var s = S(t, e), r = _.length - 1, p; r >= 0; r--)
    (p = _[r]) && (s = p(t, e, s) || s);
  return s && x(t, e, s), s;
};
class a extends l {
  constructor() {
    super(...arguments), this._length = 0, this._pageSizeOptions = [], this._pageSize = 10, this._totalPages = 0, this._currentIndex = 1, this._startIndex = 1, this._endIndex = this._pageSize, this._rowsPerPageText = "Files per pàgina", this._resultsText = "Resultats", this._pageSizeOptionsDisabled = !1, this._hidePaginationResults = !1;
  }
  static get styles() {
    return [d(u), d(c)];
  }
  set length(t) {
    const e = this._length;
    this._length = t, this.requestUpdate("length", e);
  }
  get length() {
    return this._length;
  }
  set pageSize(t) {
    const e = this._pageSize;
    this._pageSize = t, this.requestUpdate("pageSize", e);
  }
  get pageSize() {
    return this._pageSize;
  }
  set pageSizeOptions(t) {
    const e = this._pageSizeOptions;
    this._pageSizeOptions = t, this.requestUpdate("pageSizeOptions", e);
  }
  get pageSizeOptions() {
    return this._pageSizeOptions;
  }
  set pageSizeOptionsDisabled(t) {
    const e = this._pageSizeOptionsDisabled;
    this._pageSizeOptionsDisabled = t, this.requestUpdate("pageSizeOptionsDisabled", e);
  }
  get pageSizeOptionsDisabled() {
    return this._pageSizeOptionsDisabled;
  }
  set currentIndex(t) {
    const e = this._currentIndex;
    this._currentIndex = t, this.requestUpdate("currentIndex", e);
  }
  get currentIndex() {
    return this._currentIndex;
  }
  set rowsPerPageText(t) {
    const e = this._rowsPerPageText;
    this._rowsPerPageText = t, this.requestUpdate("rowsPerPageText", e);
  }
  get rowsPerPageText() {
    return this._rowsPerPageText;
  }
  set resultsText(t) {
    const e = this._resultsText;
    this._resultsText = t, this.requestUpdate("resultsText", e);
  }
  get resultsText() {
    return this._resultsText;
  }
  set hidePaginationResults(t) {
    const e = this._hidePaginationResults;
    this._hidePaginationResults = t, this.requestUpdate("hidePaginationResults", e);
  }
  get hidePaginationResults() {
    return this._hidePaginationResults;
  }
  _next() {
    this._currentIndex++, this._startIndex += this._pageSize, this._endIndex += this._pageSize, this._currentIndex === this._totalPages && (this._endIndex = this._length), this._emitCurrentPage(), this.requestUpdate();
  }
  _prev() {
    const t = Math.abs(this._startIndex - this._endIndex) + 1;
    this._startIndex -= this._pageSize, this._endIndex -= this._currentIndex === this._totalPages ? t : this._pageSize, this._currentIndex--, this._emitCurrentPage(), this.requestUpdate();
  }
  _handleChange() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector("#pagination-select");
    this._pageSize = Number(t.value), this._reload(this._startIndex), this._emitCurrentPage(), this.requestUpdate();
  }
  _emitCurrentPage() {
    this.dispatchEvent(
      new CustomEvent("onChangePage", {
        detail: {
          currentIndex: this._currentIndex,
          startIndex: this._startIndex,
          endIndex: this._endIndex,
          pageSize: this._pageSize
        },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _reload(t) {
    this._currentIndex = Math.ceil(t / this._pageSize), this._reset(!0);
  }
  _reset(t) {
    this._totalPages = Math.ceil(this._length / this._pageSize), t || (this._currentIndex < 1 ? this._currentIndex = 1 : this._currentIndex > this._totalPages && (this._currentIndex = this._totalPages)), this._startIndex = (this._currentIndex - 1) * this._pageSize + 1, this._endIndex = this._startIndex - 1 + this._pageSize, this._endIndex > this._length && (this._endIndex = this._length);
  }
  _getDefaultPageSize() {
    var e;
    const t = this._pageSizeOptions.includes(this._pageSize);
    return (e = this._pageSizeOptions) != null && e.length ? t ? this._pageSize : this._pageSizeOptions[0] : this._pageSize;
  }
  _printStartIndex() {
    return this._startIndex <= 0 || this._length <= 0 ? "0" : this._startIndex.toString();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._pageSize = this._getDefaultPageSize(), this._reset(), this._emitCurrentPage(), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(t) {
    const e = t.has("length"), o = t.has("pageSize"), s = t.has("pageSizeOptions"), r = t.has("currentIndex");
    (e || o || s || r) && (this._pageSize = this._getDefaultPageSize(), this._reset(), r && this._emitCurrentPage(), this.requestUpdate());
  }
  render() {
    var t;
    return h`
      <div class="pagination__container">
        ${this._hidePaginationResults ? null : h`
              <span class="pagination__results"
                >${this._length} ${this._resultsText}</span
              >
              <div class="pagination__divider"></div>
            `}
        ${(t = this._pageSizeOptions) != null && t.length ? h`
              <div class="pagination__row-page">
                <span class="pagination__text">${this._rowsPerPageText}</span>
                <div class="pagination__select">
                  <select
                    id="pagination-select"
                    class="pagination-select-options"
                    @change=${this._handleChange}
                    aria-label="Seleccionar la mida de la pàgina"
                    ?disabled=${this._pageSizeOptionsDisabled}
                  >
                    ${this._pageSizeOptions.map(
      (e) => h`
                          <option
                            value="${e}"
                            .selected=${this._pageSize === e}
                          >
                            ${e}
                          </option>
                        `
    )}
                  </select>
                  <span class="material-symbols-rounded pagination__arrow-down">
                    keyboard_arrow_down
                  </span>
                </div>
              </div>
              <span class="pagination__text">
                ${this._printStartIndex()}-${this._endIndex.toString()} de
                ${this._length}
              </span>
              <div class="pagination__buttons">
                <button
                  type="button"
                  class="pagination__button ${this._currentIndex}"
                  @click=${this._prev}
                  ?disabled=${+this._currentIndex == 1 || +this._length <= 0}
                >
                  <span>keyboard_arrow_left</span>
                </button>
                <button
                  type="button"
                  class="pagination__button"
                  @click=${this._next}
                  ?disabled=${+this._currentIndex == +this._totalPages || +this._length <= 0}
                >
                  <span>keyboard_arrow_right</span>
                </button>
              </div>
            ` : h`
              <button
                type="button"
                class="pagination__button"
                @click=${this._prev}
                ?disabled=${+this._currentIndex == 1 || +this._length <= 0}
              >
                <span>keyboard_arrow_left</span>
              </button>
              <span class="pagination__text">
                ${this._printStartIndex()} - ${this._endIndex.toString()} de
                ${this._length.toString()}
              </span>
              <button
                type="button"
                class="pagination__button"
                @click=${this._next}
                ?disabled=${+this._currentIndex === this._totalPages || +this._length <= 0}
              >
                <span>keyboard_arrow_right</span>
              </button>
            `}
      </div>
    `;
  }
}
n([
  i({ type: Number })
], a.prototype, "length");
n([
  i({ type: Number })
], a.prototype, "pageSize");
n([
  i({ type: Array })
], a.prototype, "pageSizeOptions");
n([
  i(g)
], a.prototype, "pageSizeOptionsDisabled");
n([
  i({ type: Number })
], a.prototype, "currentIndex");
n([
  i({ type: String })
], a.prototype, "rowsPerPageText");
n([
  i({ type: String })
], a.prototype, "resultsText");
n([
  i(g)
], a.prototype, "hidePaginationResults");
export {
  a as TablePagination
};
//# sourceMappingURL=table-pagination.js.map
