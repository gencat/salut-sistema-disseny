import { LitElement as U, unsafeCSS as w, css as q, html as l } from "lit";
import { property as n } from "lit/decorators.js";
import { classMap as g } from "lit/directives/class-map.js";
import { ifDefined as S } from "lit/directives/if-defined.js";
import { booleanType as m } from "../../utils/property-types.js";
import { onKeyboardEnter as B, moveFocusToNextTarget as O, moveFocusToPreviousTarget as H } from "../../utils/keyboard-navigation.js";
import F from "../../components/button/button.style.css.js";
import z from "../../components/badge/badge.states.css.js";
import P from "../../components/icon-button/icon-button.style.css.js";
import E from "../../foundations/icon/icon.style.css.js";
import V from "../../components/checkbox/checkbox.style.css.js";
import I from "../../components/chip/chip.style.css.js";
import j from "../../components/radio-button/radio-button.style.css.js";
var M = Object.defineProperty, N = Object.getOwnPropertyDescriptor, d = (D, e, s, t) => {
  for (var o = N(e, s), c = D.length - 1, i; c >= 0; c--)
    (i = D[c]) && (o = i(e, s, o) || o);
  return o && M(e, s, o), o;
};
class r extends U {
  constructor() {
    super(...arguments), this._valueMaxLength = 60, this._data = [], this._customData = void 0, this._pipeData = [], this._customTableHeader = void 0, this._filters = [], this._tableHeader = [], this._tableHeaderSort = {}, this._hasPaginator = !1, this._currentIndex = 1, this._pageSize = 10, this._pageSizeOptions = "[5,10,20]", this._resultstext = "Resultats", this._rowsperpagetext = "Files per pàgina", this._textAlign = "left", this._headerTitle = "", this._hideHeader = !1, this._hideColumnHeader = !1, this._innerFilters = !1, this._expandTable = !1, this._expandLabel = "Ampliar", this._collapseLabel = "Reduir", this._rowsOnCollapsed = 5, this._filtersLabel = "Selecció", this._cleanFiltersLabel = "Netejar filtres", this._openFiltersLabel = "Filtres", this._selectedRowsLabel = "files seleccionades", this._selectAllRows = !0, this._noFiltersLabel = "No hi ha filtres seleccionats", this._footerButtons = 3, this._maxContentWidth = !1, this._stickyColumns = !1, this._multiselect = !1, this._radioselect = !1, this._hasRowButton = !1, this._rowButtonLabel = "Button", this._hasRowActions = !1, this._rowActionsIcons = ["add_box", "add_box", "add_box"], this._footerButtonPrimaryLabel = "Primary", this._footerButtonSecondaryLabel = "Secondary", this._footerButtonAlternativeLabel = "Alternative", this._enableRowActionsOnDeleted = !1, this._enableRowActionsOnDisabled = !1, this._currentSortColumn = "", this._currentSortType = "", this._copyPipeData = [], this._isFirstUpdate = !0;
  }
  static get styles() {
    return [
      w(E),
      w(F),
      w(P),
      w(I),
      w(V),
      w(j),
      q`
        :host {
          display: block;
          width: 100%;
        }

        .dss-table-header {
          padding: var(--dss-spacing-md) 0;
        }

        .dss-table-header-title {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-xs);
          margin-bottom: var(--dss-spacing-md);
        }

        .dss-table-header-title__text {
          color: var(--color-neutral-900);
          font-weight: var(--font-bold);
          font-size: 20px;
        }

        .dss-table-header-title__action {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: var(--dss-spacing-xxs);
          font-size: 14px;
          color: var(--color-primary-700);
          cursor: pointer;
          border-radius: var(--dss-radius-xs);
          font-weight: var(--font-semibold);
        }

        .dss-table-header-title__action:hover {
          color: var(--color-primary-600);
        }

        .dss-table-header-title__action:active {
          color: var(--color-primary-400);
        }

        .dss-table-header-title__action:focus-visible {
          outline: var(--dss-border-width-md) solid var(--color-blue-200);
        }

        .dss-table-header-filters {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .dss-table-header-filters__filters {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          gap: var(--dss-spacing-md);
          width: 70%;
          box-sizing: border-box;
        }

        .dss-table-header-filters--inner .dss-table-header-filters__filters {
          width: 80%;
        }

        .filters-label {
          font-size: 14px;
          font-weight: var(--font-bold);
          color: var(--color-neutral-600);
        }

        .filters-list {
          display: flex;
          flex-wrap: wrap;
          max-width: 60%;
          gap: var(--dss-spacing-xs);
        }

        .filters-list-empty {
          font-size: 14px;
          color: var(--color-neutral-600);
        }

        .filters-clean {
          padding-left: var(--dss-spacing-md);
          border-left: var(--dss-border-width-sm) solid var(--color-neutral-100);
        }

        .dss-table-header-filters__actions {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: var(--dss-spacing-md);
          width: 30%;
          box-sizing: border-box;
        }

        .dss-table-header-filters--inner .dss-table-header-filters__actions {
          width: 20%;
        }

        .dss-table-main {
          background-color: var(--color-white);
          width: 100%;
          overflow-x: auto;
        }

        .dss-table-container {
          max-width: 100%;
          overflow: auto;
        }

        .dss-table-main .table {
          min-width: 100%;
          margin: 0;
          padding: 0;
          border-collapse: collapse;
          border-spacing: 0;
          table-layout: fixed;
        }

        .dss-table-main .table.table--max-content-width {
          width: max-content;
        }

        .dss-table-main .table.table--sticky-columns {
        }

        .dss-table-main .table-header {
          width: 100%;
          position: sticky;
          top: 0;
          background-color: var(--color-white);
          z-index: 100;
        }

        .dss-table-main .table.table--sticky-columns .table-header {
          position: relative;
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-header
          .table-th:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-td:first-child {
          position: sticky;
          left: 0;
          z-index: 100;
          background-color: var(--color-white);
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-body-row:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ):hover
          .table-td:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body-row--selected:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          )
          .table-td:first-child {
          background-color: var(--color-primary-50);
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-body-row:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ):hover
          .table-td:last-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body-row--selected:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          )
          .table-td:last-child {
          background-color: var(--color-primary-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-header
          .table-th:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-body
          .table-td:nth-child(2) {
          position: sticky;
          left: 52px;
          z-index: 100;
          background-color: var(--color-white);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-body-row:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ):hover
          .table-td:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-body-row--selected:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          )
          .table-td:nth-child(2) {
          background-color: var(--color-primary-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-body
          .table-body-row--disabled
          .table-td:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--disabled
          .table-td:nth-child(2) {
          background-color: var(--color-neutral-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--multiselect
          .table-body
          .table-body-row--deleted
          .table-td:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--deleted
          .table-td:nth-child(2) {
          background-color: var(--color-red-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-header
          .table-th:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-body
          .table-td:nth-child(2) {
          position: sticky;
          left: 52px;
          z-index: 100;
          background-color: var(--color-white);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-body-row:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ):hover
          .table-td:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-body-row--selected:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          )
          .table-td:nth-child(2) {
          background-color: var(--color-primary-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-body
          .table-body-row--disabled
          .table-td:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--disabled
          .table-td:nth-child(2) {
          background-color: var(--color-neutral-50);
        }

        .dss-table-main
          .table.table--sticky-columns.table--sticky-columns--radioselect
          .table-body
          .table-body-row--deleted
          .table-td:nth-child(2),
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--deleted
          .table-td:nth-child(2) {
          background-color: var(--color-red-50);
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--deleted
          .table-td:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--deleted
          .table-td:last-child {
          background-color: var(--color-red-50);
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--disabled
          .table-td:first-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-body-row--disabled
          .table-td:last-child {
          background-color: var(--color-neutral-50);
        }

        .dss-table-main
          .table.table--sticky-columns
          .table-header
          .table-th:last-child,
        .dss-table-main
          .table.table--sticky-columns
          .table-body
          .table-td:last-child {
          position: sticky;
          right: 0;
          z-index: 100;
          background-color: var(--color-white);
        }

        .dss-table-main .table-header-row {
          width: 100%;
        }

        .dss-table-main .table-th {
          box-sizing: border-box;
          height: 56px;
        }

        .dss-table-main .table-th--checkbox {
          width: 52px;
        }

        .dss-table-main .table-th--radio {
          width: 52px;
        }

        .dss-table-main .table-th--review {
          width: 52px;
        }

        .dss-table-main .table-th--button {
        }

        .dss-table-main .table-th--actions {
          width: 140px;
          max-width: 140px;
        }

        .dss-table-main .table-th--icons-1 {
          width: 64px;
          max-width: 64px;
        }

        .dss-table-main .table-th--icons-2 {
          width: 100px;
          max-width: 100px;
        }

        .dss-table-main .table-header-column {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          gap: var(--dss-spacing-xs);
          margin: 0;
          padding: 0 var(--dss-spacing-md);
          border-bottom: var(--dss-border-width-md) solid
            var(--color-neutral-700);
          box-sizing: border-box;
          height: 100%;
        }

        .dss-table-main .table-header-column--clickable {
          cursor: pointer;
        }

        .dss-table-main .table-header-column--not-clickable {
          cursor: default;
        }

        .dss-table-main
          .table-header-column--clickable
          .table-header-column__icon {
          box-sizing: border-box;
          padding: var(--dss-spacing-tiny);
          background-color: transparent;
          border-radius: var(--dss-radius-xs);
          transition: all 0.3s ease-in;
        }

        .dss-table-main .table-header-column--clickable:focus-visible {
          box-shadow: inset 0 0 0 var(--dss-border-width-lg)
            var(--color-blue-200);
          outline: 0;
        }

        .dss-table-main
          .table-header-column--clickable:focus-visible
          .table-header-column__icon,
        .dss-table-main
          .table-header-column--clickable:hover
          .table-header-column__icon {
          color: var(--color-white);
          background-color: var(--color-primary-500);
        }

        .dss-table-main .table-header-column__title {
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          text-transform: capitalize;
        }

        .dss-table-main .table-header-column--checkbox {
          justify-content: center;
          max-width: 52px;
        }

        .dss-table-main .table-header-column--radio {
          max-width: 52px;
        }

        .dss-table-main .table-header-column--review {
          justify-content: center;
        }

        .dss-table-main .table-header-column--button {
        }

        .dss-table-main .table-header-column--actions {
        }

        .dss-table-main .table-header-column--number {
          justify-content: flex-end;
        }

        .dss-table-main .table-body {
        }

        .dss-table-main .table-body-row {
          // display: grid;
        }

        .dss-table-main .table-body-row + .table-body-row {
          border-top: var(--dss-border-width-sm) solid var(--color-neutral-100);
        }

        .dss-table-main
          .table-body-row:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ):hover,
        .dss-table-main
          .table-body-row--selected:not(.table-body-row--disabled):not(
            .table-body-row--deleted
          ) {
          background-color: var(--color-primary-50);
        }

        .dss-table-main .table-body-row--disabled {
          background-color: var(--color-neutral-50);
        }

        .dss-table-main .table-body-row--disabled .table-body-column {
          color: var(--color-neutral-500);
        }

        .dss-table-main .table-body-row--deleted {
          background-color: var(--color-red-50);
        }

        .dss-table-main .table-td {
          box-sizing: border-box;
          height: 56px;
          margin: 0;
          padding: 0;
        }

        .dss-table-main .table-body-column {
          margin: 0;
          padding: auto var(--dss-spacing-md);
          font-size: 14px;
          color: var(--color-neutral-700);
          height: 56px;
          box-sizing: border-box;
        }

        .dss-table-main .table-body-column--custom {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          padding: 0 var(--dss-spacing-md);
          gap: var(--dss-spacing-xs);
          gap: var(--dss-spacing-xs);
        }

        .dss-table-main .table-body-column--text {
          justify-content: flex-start;
        }

        .dss-table-main .table-body-column--number {
          justify-content: flex-end;
        }

        .dss-table-main .table-td--actions {
          box-sizing: border-box;
          max-width: 140px;
        }

        .dss-table-main .table-body-column--actions {
          justify-content: flex-end;
          max-width: 140px;
          box-sizing: border-box;
        }

        .dss-table-main .table-body-column--result {
          font-weight: var(--font-bold);
        }

        .dss-table-main .table-body-column--checkbox {
          max-width: 52px;
          padding-left: 0;
          padding-right: 0;
          justify-content: center;
        }

        .dss-table-main .table-body-column--radio {
          max-width: 52px;
          padding-left: 0;
          padding-right: 0;
          justify-content: center;
        }

        .dss-table-main .table-body-column--button {
          justify-content: flex-end;
        }

        .dss-table-main .table-body-column--review {
          justify-content: center;
        }

        .dss-table-main .table-body-column--font-bold {
          font-weight: var(--font-bold);
        }

        .dss-table-main .table-body-column--font-black {
          font-weight: var(--font-bold);
          color: var(--color-neutral-900);
        }

        .dss-table-main .table-body-column--icon-right {
          flex-direction: row-reverse;
        }

        .dss-table-main .table-body-column--text.table-body-column--icon-right {
          justify-content: flex-end;
        }

        .dss-table-main
          .table-body-column--number.table-body-column--icon-right {
          justify-content: flex-start;
        }

        .table-body--align-center .table-body-column {
          text-align: center;
        }

        .table-body--align-right .table-body-column {
          text-align: right;
        }

        .table-body--align-justify .table-body-column {
          text-align: justify;
        }

        ::slotted(div.dss-table-filters) {
          width: 100%;
          display: flex;
          justify-content: flex-start;
          align-items: center;
          gap: var(--dss-spacing-xs);
        }

        .table-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-xs);
          padding: var(--dss-spacing-md);
          border-top: var(--dss-border-width-sm) solid var(--color-neutral-100);
          margin-top: var(--dss-spacing-md);
        }

        .table-footer-description {
          color: var(--color-neutral-900);
          font-size: 16px;
          font-weight: var(--font-bold);
        }

        .table-footer-actions {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: var(--dss-spacing-xs);
        }

        .column-value {
          position: relative;
        }

        .column-value > .value {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .table-body-column--custom dss-tooltip {
          font-weight: var(--font-regular);
        }

        .column-value dss-tooltip {
          visibility: hidden;
        }

        .column-value:hover dss-tooltip {
          visibility: visible;
        }

        .column-value {
          position: relative;
        }

        .column-value > .value {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .table-body-column--custom dss-tooltip {
          font-weight: var(--font-regular);
        }

        .column-value dss-tooltip {
          visibility: hidden;
        }

        .column-value:hover dss-tooltip {
          visibility: visible;
        }

        .column-value--link {
          color: var(--color-primary-700);
          font-weight: 600;
          text-decoration: none;
        }

        .column-value--link:hover {
          color: var(--color-primary-900);
        }

        .column-value--link:active {
          color: var(--color-primary-800);
        }

        .column-value--link:disabled {
          color: var(--color-neutral-500);
          cursor: not-allowed;
        }

        .column-value--link:focus-visible {
          outline: var(--dss-border-width-md) solid var(--color-blue-200);
          border-radius: var(--dss-radius-xs);
        }

        .dss-table-main .table .table-body-row:focus-visible {
          box-shadow: inset 0 0 0 var(--dss-border-width-lg)
            var(--color-blue-200);
          outline: 0;
        }

        .table-header-row--hide,
        .table-header-row--hide .table-th,
        .table-header-row--hide .table-th * {
          height: 0;
          visibility: hidden;
        }
      `,
      w(z)
    ];
  }
  set hasPaginator(e) {
    const s = this._hasPaginator;
    this._hasPaginator = e, this.requestUpdate("hasPaginator", s);
  }
  get hasPaginator() {
    return this._hasPaginator;
  }
  set data(e) {
    const s = this._data;
    this._data = e, this._createTableHeader(e), this._pipeData = this._data, this._copyPipeData = [...this._data], this.requestUpdate("data", s);
  }
  get data() {
    return this._data;
  }
  set customData(e) {
    const s = this._customData;
    this._customData = e, this._createTableHeader(e), this._pipeData = this._customData, this._copyPipeData = [...this._customData], this.requestUpdate("data", s);
  }
  get customData() {
    return this._customData || [];
  }
  set customTableHeader(e) {
    const s = this._customTableHeader;
    this._customTableHeader = e, this.requestUpdate("customTableHeader", s);
  }
  get customTableHeader() {
    return this._customTableHeader || [];
  }
  set filters(e) {
    const s = this._filters;
    this._filters = e, this.requestUpdate("filters", s);
  }
  get filters() {
    return this._filters;
  }
  set currentIndex(e) {
    const s = this._currentIndex;
    this._currentIndex = e, this.requestUpdate("currentIndex", s);
  }
  get currentIndex() {
    return this._currentIndex;
  }
  set pageSize(e) {
    const s = this._pageSize;
    this._pageSize = e, this.requestUpdate("pageSize", s);
  }
  get pageSize() {
    return this._pageSize;
  }
  set pageSizeOptions(e) {
    const s = this._pageSizeOptions;
    this._pageSizeOptions = e, this.requestUpdate("pageSizeOptions", s);
  }
  get pageSizeOptions() {
    return this._pageSizeOptions;
  }
  set resultstext(e) {
    const s = this._resultstext;
    this._resultstext = e, this.requestUpdate("resultstext", s);
  }
  get resultstext() {
    return this._resultstext;
  }
  set rowsperpagetext(e) {
    const s = this._rowsperpagetext;
    this._rowsperpagetext = e, this.requestUpdate("rowsperpagetext", s);
  }
  get rowsperpagetext() {
    return this._rowsperpagetext;
  }
  set textAlign(e) {
    const s = this._textAlign;
    this._textAlign = e, this.requestUpdate("textAlign", s);
  }
  get textAlign() {
    return this._textAlign;
  }
  set headerTitle(e) {
    const s = this._headerTitle;
    this._headerTitle = e, this.requestUpdate("headerTitle", s);
  }
  get headerTitle() {
    return this._headerTitle;
  }
  set hideHeader(e) {
    const s = this._hideHeader;
    this._hideHeader = e, this.requestUpdate("hideHeader", s);
  }
  get hideHeader() {
    return this._hideHeader;
  }
  set hideColumnHeader(e) {
    const s = this._hideColumnHeader;
    this._hideColumnHeader = e, this.requestUpdate("hideColumnHeader", s);
  }
  get hideColumnHeader() {
    return this._hideColumnHeader;
  }
  set innerFilters(e) {
    const s = this._innerFilters;
    this._innerFilters = e, this.requestUpdate("innerFilters", s);
  }
  get innerFilters() {
    return this._innerFilters;
  }
  set expandTable(e) {
    const s = this._expandTable;
    this._expandTable = e, this.requestUpdate("expandTable", s);
  }
  get expandTable() {
    return this._expandTable;
  }
  set expandLabel(e) {
    const s = this._expandLabel;
    this._expandLabel = e, this.requestUpdate("expandLabel", s);
  }
  get expandLabel() {
    return this._expandLabel;
  }
  set collapseLabel(e) {
    const s = this._collapseLabel;
    this._collapseLabel = e, this.requestUpdate("collapseLabel", s);
  }
  get collapseLabel() {
    return this._collapseLabel;
  }
  set rowsOnCollapsed(e) {
    const s = this._rowsOnCollapsed;
    this._rowsOnCollapsed = e, this.requestUpdate("rowsOnCollapsed", s);
  }
  get rowsOnCollapsed() {
    return this._rowsOnCollapsed;
  }
  set filtersLabel(e) {
    const s = this._filtersLabel;
    this._filtersLabel = e, this.requestUpdate("filtersLabel", s);
  }
  get filtersLabel() {
    return this._filtersLabel;
  }
  set cleanFiltersLabel(e) {
    const s = this._cleanFiltersLabel;
    this._cleanFiltersLabel = e, this.requestUpdate("cleanFiltersLabel", s);
  }
  get cleanFiltersLabel() {
    return this._cleanFiltersLabel;
  }
  set selectedRowsLabel(e) {
    const s = this._selectedRowsLabel;
    this._selectedRowsLabel = e, this.requestUpdate("selectedRowsLabel", s);
  }
  get selectedRowsLabel() {
    return this._selectedRowsLabel;
  }
  set footerButtons(e) {
    const s = this._footerButtons;
    this._footerButtons = e, this.requestUpdate("footerButtons", s);
  }
  get footerButtons() {
    return this._footerButtons;
  }
  set maxContentWidth(e) {
    const s = this._maxContentWidth;
    this._maxContentWidth = e, this.requestUpdate("maxContentWidth", s);
  }
  get maxContentWidth() {
    return this._maxContentWidth;
  }
  set stickyColumns(e) {
    const s = this._stickyColumns;
    this._stickyColumns = e, this.requestUpdate("stickyColumns", s);
  }
  get stickyColumns() {
    return this._stickyColumns;
  }
  set multiselect(e) {
    const s = this._multiselect;
    this._multiselect = e, this.requestUpdate("multiselect", s);
  }
  get multiselect() {
    return this._multiselect;
  }
  set radioselect(e) {
    const s = this._radioselect;
    this._radioselect = e, this.requestUpdate("radioselect", s);
  }
  get radioselect() {
    return this._radioselect;
  }
  set hasRowButton(e) {
    const s = this._hasRowButton;
    this._hasRowButton = e, this.requestUpdate("hasRowButton", s);
  }
  get hasRowButton() {
    return this._hasRowButton;
  }
  set rowButtonLabel(e) {
    const s = this._rowButtonLabel;
    this._rowButtonLabel = e, this.requestUpdate("rowButtonLabel", s);
  }
  get rowButtonLabel() {
    return this._rowButtonLabel;
  }
  set hasRowActions(e) {
    const s = this._hasRowActions;
    this._hasRowActions = e, this.requestUpdate("hasRowActions", s);
  }
  get hasRowActions() {
    return this._hasRowActions;
  }
  set rowActionsIcons(e) {
    const s = this._rowActionsIcons;
    this._rowActionsIcons = e, this.requestUpdate("rowActionsIcons", s);
  }
  get rowActionsIcons() {
    return this._rowActionsIcons;
  }
  set footerButtonPrimaryLabel(e) {
    const s = this._footerButtonPrimaryLabel;
    this._footerButtonPrimaryLabel = e, this.requestUpdate("footerButtonPrimaryLabel", s);
  }
  get footerButtonPrimaryLabel() {
    return this._footerButtonPrimaryLabel;
  }
  set footerButtonSecondaryLabel(e) {
    const s = this._footerButtonSecondaryLabel;
    this._footerButtonSecondaryLabel = e, this.requestUpdate("footerButtonSecondaryLabel", s);
  }
  get footerButtonSecondaryLabel() {
    return this._footerButtonSecondaryLabel;
  }
  set footerButtonAlternativeLabel(e) {
    const s = this._footerButtonAlternativeLabel;
    this._footerButtonAlternativeLabel = e, this.requestUpdate("footerButtonAlternativeLabel", s);
  }
  get footerButtonAlternativeLabel() {
    return this._footerButtonAlternativeLabel;
  }
  set enableRowActionsOnDisabled(e) {
    const s = this._enableRowActionsOnDisabled;
    this._enableRowActionsOnDisabled = e, this.requestUpdate("enableRowActionsOnDisabled", s);
  }
  get enableRowActionsOnDisabled() {
    return this._enableRowActionsOnDisabled;
  }
  set enableRowActionsOnDeleted(e) {
    const s = this._enableRowActionsOnDeleted;
    this._enableRowActionsOnDeleted = e, this.requestUpdate("enableRowActionsOnDeleted", s);
  }
  get enableRowActionsOnDeleted() {
    return this._enableRowActionsOnDeleted;
  }
  set valueMaxLength(e) {
    const s = this._valueMaxLength;
    this._valueMaxLength = e, this.requestUpdate("valueMaxLength", s);
  }
  get valueMaxLength() {
    return this._valueMaxLength;
  }
  get _tableGridStyle() {
    return `grid-template-columns: repeat(${this._tableHeader.length}, 1fr)`;
  }
  get _tableHeight() {
    let e = "height:auto;";
    if (!this._expandTable) {
      let s = this._rowsOnCollapsed * 56;
      s += 56, e = `height:${s}px;`;
    }
    return e;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._clickOutside();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  willUpdate(e) {
    const s = e.has("data"), t = e.has("customData");
    if (!this._isFirstUpdate && (s || t)) {
      const o = {
        detail: {
          startIndex: 1,
          endIndex: this._pageSize
        }
      };
      this._paginateTable(o);
    }
    this._isFirstUpdate = !1;
  }
  _clickOutside() {
    document.addEventListener("mousedown", (e) => {
      e.composedPath().includes(this) ? e.composedPath().find((o) => o instanceof HTMLElement && o.classList.contains("table-body")) || this._resetRowsTabIndex() : this._resetRowsTabIndex();
    });
  }
  _createTableHeader(e) {
    const s = Object.keys(e[0]);
    if (s.includes("disabled")) {
      const t = s.indexOf("disabled");
      s.splice(t, 1);
    }
    if (s.includes("deleted")) {
      const t = s.indexOf("deleted");
      s.splice(t, 1);
    }
    this._tableHeader = s, this._tableHeader.forEach((t) => {
      this._tableHeaderSort[t] = "none";
    });
  }
  _sortBy(e, s) {
    this._currentSortColumn = e, s === "none" ? this._currentSortType = "ASC" : s === "ASC" ? this._currentSortType = "DSC" : s === "DSC" && (this._currentSortType = "none"), this._currentSortType === "none" ? this._pipeData = [...this._copyPipeData] : this._pipeData = this._pipeData.sort((o, c) => {
      let i, h;
      return this._customData ? (i = o[e].value, h = c[e].value) : (i = o[e], h = c[e]), i < h ? this._currentSortType === "ASC" ? -1 : 1 : i > h ? this._currentSortType === "ASC" ? 1 : -1 : 0;
    }), this._tableHeaderSort[e] = this._currentSortType, Object.keys(this._tableHeaderSort).forEach((o) => {
      o !== e && (this._tableHeaderSort[o] = "none");
    }), this.requestUpdate();
  }
  _paginateTable(e) {
    const s = e.detail.startIndex, t = e.detail.endIndex;
    if (this._customData && t <= this._customData.length ? this._pipeData = this._customData.slice(s - 1, t) : this._data && t <= this._data.length && (this._pipeData = this._data.slice(s - 1, t)), e.detail.pageSize && (this._pageSize = e.detail.pageSize), this._copyPipeData = [...this._pipeData], this._currentSortColumn && this._currentSortType) {
      let o = "";
      this._currentSortType === "ASC" ? o = "none" : this._currentSortType === "DSC" ? o = "ASC" : o = "DSC", this._sortBy(this._currentSortColumn, o);
    }
    this.requestUpdate();
  }
  _generateTableHeaderHTML() {
    let e = l``, s = l``, t = l``, o = l``;
    this._multiselect && (e = l`
        <th class="table-th table-th--checkbox">
          <div class="table-header-column table-header-column--checkbox">
            <input
              type="checkbox"
              class="dss-checkbox"
              aria-label="Seleccionar totes les files"
              @change="${this._onSelectAllRows}"
            />
          </div>
        </th>
      `), this._radioselect && (s = l`
        <th class="table-th table-th--radio">
          <div class="table-header-column table-header-column--radio"></div>
        </th>
      `), this._hasRowButton && (t = l`
        <th class="table-th table-th--button">
          <div class="table-header-column table-header-column--button"></div>
        </th>
      `), this._hasRowActions && (o = l`
        <th
          class="table-th table-th--actions table-th--icons-${this._rowActionsIcons.length}"
        >
          <div class="table-header-column table-header-column--actions"></div>
        </th>
      `);
    let c = !0;
    const i = this._tableHeader.map((u, v) => {
      const k = () => {
        this._customTableHeader ? this._customTableHeader[v].sort && this._sortBy(u, this._tableHeaderSort[u]) : this._sortBy(u, this._tableHeaderSort[u]), this.requestUpdate();
      }, R = (y) => {
        const p = y.currentTarget, f = y;
        let $ = !1;
        switch (f.key) {
          case "ArrowLeft":
            H(this.renderRoot, p, ".table-header-column--clickable"), $ = !0;
            break;
          case "ArrowRight":
            O(this.renderRoot, p, ".table-header-column--clickable"), $ = !0;
            break;
          case "Enter":
            const x = y.target;
            B(this.renderRoot, x, ".table-header-column--clickable"), $ = !0;
            break;
        }
        $ && (y.stopPropagation(), y.preventDefault());
      };
      let _ = "";
      this._customData && this._customData.length > 0 ? _ = this._pipeData[0][u].type : this._data && this._data.length > 0 && (_ = typeof this._pipeData[0][u]);
      const A = {
        "table-th--review": _ === "review",
        "table-th--link": _ === "link"
      };
      let T = !1;
      this._customTableHeader && (this._customTableHeader[v].sort || (T = !0));
      const C = {
        "table-header-column--review": _ === "review",
        "table-header-column--number": _ === "number",
        "table-header-column--link": _ === "link",
        "table-header-column--clickable": !T,
        "table-header-column--not-clickable": T
      }, a = l`
        <span class="dss-icon dss-icon--sm table-header-column__icon">
          ${u === this._currentSortColumn ? this._currentSortType === "ASC" ? l`arrow_upward` : this._currentSortType === "DSC" ? l`arrow_downward` : l`swap_vert` : l`swap_vert`}
        </span>
      `, b = l`
        <th class="table-th ${g(A)}">
          <div
            class="table-header-column ${g(C)}"
            tabindex="${c ? 0 : -1}"
            @keydown=${R}
            @click=${k}
          >
            <span class="table-header-column__title">
              ${this._customTableHeader ? l`${this._customTableHeader[v].title}` : l`${u}`}
            </span>
            ${this._customTableHeader ? this._customTableHeader[v].sort ? l`${a}` : null : l`${a}`}
          </div>
        </th>
      `;
      return c = !1, b;
    }), h = {
      "table-header-row--hide": this._hideColumnHeader
    };
    return l` <tr
      class="table-header-row ${g(h)}"
    >
      ${e} ${s} ${i}
      ${t} ${o}
    </tr>`;
  }
  _onRowCheckboxChange(e) {
    this._radioselect && this._uncheckRadioRows(), e.checked ? e.checked = !e.checked : e.checked = !0, this.requestUpdate();
  }
  _onSelectAllRows() {
    this._pipeData.forEach((e) => {
      e.disabled ? this._enableRowActionsOnDisabled && (e.checked = this._selectAllRows) : e.deleted ? this._enableRowActionsOnDeleted && (e.checked = this._selectAllRows) : e.checked = this._selectAllRows;
    }), this._selectAllRows = !this._selectAllRows, this.requestUpdate();
  }
  _onRowAction(e, s) {
    const t = {
      detail: { action: e, row: s },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onRowAction", t)), this.requestUpdate();
  }
  _onRowActionKeydown(e, s, t) {
    e.key === "Enter" && this._onRowAction(s, t);
  }
  _generateTableTdCheckbox(e, s, t, o) {
    return this._enableRowActionsOnDeleted && (o = !1), this._enableRowActionsOnDisabled && (t = !1), l`
      <td class="table-td table-td--checkbox">
        <div
          class="table-body-column table-body-column--custom table-body-column--checkbox"
        >
          <input
            type="checkbox"
            class="dss-checkbox table-body-row__action"
            aria-label="Seleccionar la fila"
            @change="${() => this._onRowCheckboxChange(e)}"
            .checked=${s}
            ?disabled=${t || o}
          />
        </div>
      </td>
    `;
  }
  _generateTableTdRadio(e, s, t, o) {
    return this._enableRowActionsOnDeleted && (o = !1), this._enableRowActionsOnDisabled && (t = !1), l`
      <td class="table-td table-td--radio">
        <div
          class="table-body-column table-body-column--custom table-body-column--radio"
        >
          <input
            type="radio"
            name="row-radio"
            class="dss-radio table-body-row__action"
            aria-label="Seleccionar la fila"
            @change="${() => this._onRowCheckboxChange(e)}"
            .checked=${s}
            ?disabled=${t || o}
          />
        </div>
      </td>
    `;
  }
  _generateTableTdButton(e, s, t) {
    return this._enableRowActionsOnDeleted && (t = !1), this._enableRowActionsOnDisabled && (s = !1), l`
      <td class="table-td table-td--button">
        <div
          class="table-body-column table-body-column--custom table-body-column--button"
        >
          <button
            type="button"
            class="dss-button dss-button--sm dss-button--secondary table-body-row__action"
            @click="${() => this._onRowAction(this._rowButtonLabel, e)}"
            @keydown="${(o) => this._onRowActionKeydown(o, this._rowButtonLabel, e)}"
            ?disabled=${s || t}
          >
            ${this._rowButtonLabel}
          </button>
        </div>
      </td>
    `;
  }
  _generateTableTdActions(e, s, t) {
    return this._enableRowActionsOnDeleted && (t = !1), this._enableRowActionsOnDisabled && (s = !1), l`
      <td class="table-td table-td--custom table-td--actions">
        <div
          class="table-body-column table-body-column--custom table-body-column--actions"
        >
          ${this._rowActionsIcons.map(
      (o, c) => l`
                <button
                  class="dss-icon-button dss-icon-button--primary dss-icon-button--md dss-table-actions-icon table-body-row__action"
                  @click="${() => this._onRowAction(`rowAction${c + 1}`, e)}"
                  @keydown="${(i) => this._onRowActionKeydown(i, this._rowButtonLabel, e)}"
                  aria-label="Row action ${c + 1}"
                  ?disabled=${s || t}
                >
                  <span class="dss-icon">${o}</span>
                </button>
              `
    )}
        </div>
      </td>
    `;
  }
  _generateTableTdSelfActions(e, s, t, o, c) {
    return this._enableRowActionsOnDeleted && (c = !1), this._enableRowActionsOnDisabled && (o = !1), l`
      <td class="table-td table-td--custom table-td--actions">
        <div
          class="table-body-column table-body-column--custom table-body-column--actions"
        >
          ${t.icons.map(
      (i, h) => l`
                <button
                  class="dss-icon-button dss-icon-button--primary dss-icon-button--md dss-table-actions-icon table-body-row__action"
                  @click="${() => this._onRowAction(`${s}Action${h + 1}`, e)}"
                  @keydown="${(u) => this._onRowActionKeydown(u, this._rowButtonLabel, e)}"
                  aria-label="Self action ${h + 1}"
                  ?disabled=${o || c}
                >
                  <span class="dss-icon">${i}</span>
                </button>
              `
    )}
        </div>
      </td>
    `;
  }
  _resetRowsTabIndex() {
    const e = this.renderRoot.querySelector('.table-body-row[tabindex="0"]');
    e == null || e.setAttribute("tabindex", "-1"), this.renderRoot.querySelectorAll(".table-body-row")[0].setAttribute("tabindex", "0");
  }
  _uncheckRadioRows() {
    this._data && this._data.length > 0 && this._pipeData.forEach((e) => {
      e.checked = !1;
    });
  }
  _generateDefaultTableBody() {
    let e, s = !0;
    return this._data && this._data.length > 0 && (e = this._pipeData.map((t) => {
      const o = t.checked ? t.checked : !1, c = t.deleted ? t.deleted : !1, i = t.disabled ? t.disabled : !1, h = (a) => {
        const b = a.relatedTarget;
        b && !b.className.includes("table-body-row") && !b.className.includes("table-body-row__action") && this._resetRowsTabIndex();
      }, u = (a) => {
        const b = a.currentTarget, y = a;
        let p = !1;
        switch (y.key) {
          case "ArrowUp":
            H(this.renderRoot, b, ".table-body-row"), p = !0;
            break;
          case "ArrowDown":
            O(this.renderRoot, b, ".table-body-row"), p = !0;
            break;
          case "Enter":
            const f = a.target;
            f.tagName === "TR" && (B(this.renderRoot, f, ".table-body-row"), (this._multiselect || this._radioselect) && (!c && !i ? (this._radioselect && this._uncheckRadioRows(), t.checked ? t.checked = !t.checked : t.checked = !0) : this._enableRowActionsOnDeleted && c ? (this._radioselect && this._uncheckRadioRows(), t.checked ? t.checked = !t.checked : t.checked = !0) : this._enableRowActionsOnDisabled && i && (this._radioselect && this._uncheckRadioRows(), t.checked ? t.checked = !t.checked : t.checked = !0), this.requestUpdate()), p = !0);
            break;
          case "Escape":
            const x = a.composedPath().find(
              (L) => L instanceof HTMLElement && L.classList.contains("table-body-row")
            );
            x && x.focus();
            break;
        }
        p && (a.stopPropagation(), a.preventDefault());
      }, v = this._multiselect ? this._generateTableTdCheckbox(t, o, i, c) : l``, k = this._radioselect ? this._generateTableTdRadio(t, o, i, c) : l``, R = this._hasRowButton ? this._generateTableTdButton(t, i, c) : l``, _ = this._hasRowActions ? this._generateTableTdActions(t, i, c) : l``, A = this._tableHeader.map((a) => {
        const b = {
          "table-body-column--number": typeof t[a] == "number"
        };
        return l`
            <td class="table-td">
              <div
                class="table-body-column table-body-column--custom ${g(b)}"
              >
                ${t[a] === "" ? l`<i class="dss-icon dss-icon--md">remove</i>` : null}
                ${t[a] === "" ? l`<i class="dss-icon dss-icon--md">remove</i>` : null}
                ${typeof t[a] == "number" ? l` ${t[a]} ` : t[a].length <= this._valueMaxLength ? l`${t[a]}` : l`${t[a]}...`}
              </div>
            </td>
          `;
      }), C = l` <tr
          class="table-body-row ${g({
        "table-body-row--selected": o,
        "table-body-row--deleted": c,
        "table-body-row--disabled": i
      })}"
          tabindex="${s ? 0 : -1}"
          style=${S(this._tableGridStyle)}
          @keydown=${u}
          @focusout=${h}
        >
          ${v} ${k} ${A}
          ${R} ${_}
        </tr>`;
      return s = !1, C;
    })), e;
  }
  _generateCustomTableBody() {
    let e, s = !0;
    return this._customData && (e = this._pipeData.map((t) => {
      let o = t.checked ? t.checked : !1;
      const c = t.deleted ? t.deleted : !1, i = t.disabled ? t.disabled : !1, h = (a) => {
        const b = a.relatedTarget;
        b && !b.className.includes("table-body-row") && !b.className.includes("table-body-row__action") && this._resetRowsTabIndex();
      }, u = (a) => {
        const b = a.currentTarget, y = a;
        let p = !1;
        switch (y.key) {
          case "ArrowUp":
            H(this.renderRoot, b, ".table-body-row"), p = !0;
            break;
          case "ArrowDown":
            O(this.renderRoot, b, ".table-body-row"), p = !0;
            break;
          case "Enter":
            const f = a.target;
            f.tagName === "TR" && (B(this.renderRoot, f, ".table-body-row"), (this._multiselect || this._radioselect) && ((!c && !i || this._enableRowActionsOnDeleted && c || this._enableRowActionsOnDisabled && i) && (t.checked ? (t.checked = !t.checked, o = t.checked) : (t.checked = !0, o = t.checked)), this.requestUpdate())), p = !0;
            break;
          case "Escape":
            const x = a.composedPath().find(
              (L) => L instanceof HTMLElement && L.classList.contains("table-body-row")
            );
            x && x.focus();
            break;
        }
        p && (a.stopPropagation(), a.preventDefault());
      }, v = this._multiselect ? this._generateTableTdCheckbox(t, o, i, c) : l``, k = this._radioselect ? this._generateTableTdRadio(t, o, i, c) : l``, R = this._hasRowButton ? this._generateTableTdButton(t, i, c) : l``, _ = this._hasRowActions ? this._generateTableTdActions(t, i, c) : l``, A = this._tableHeader.map((a) => {
        const b = (p) => {
          t[p].value = !t[p].value;
          const f = {
            detail: { action: "review", row: t },
            bubbles: !0,
            composed: !0
          };
          this.dispatchEvent(new CustomEvent("onRowAction", f)), this.requestUpdate();
        }, y = {
          "table-body-column--text": t[a].type === "text",
          "table-body-column--number": t[a].type === "number",
          "table-body-column--link": t[a].type === "link",
          "table-body-column--badge": t[a].type === "badge",
          "table-body-column--result": t[a].type === "result",
          "table-body-column--review": t[a].type === "review",
          "table-body-column--progress": t[a].type === "progress",
          "table-body-column--font-bold": t[a].fontType === "bold",
          "table-body-column--font-black": t[a].fontType === "black",
          "table-body-column--icon-right": t[a].iconRight
        };
        return l`
            <td class="table-td" style="${S(t[a].style)}">
              <div
                class="table-body-column table-body-column--custom ${g(y)}"
              >
                ${t[a].type === "text" ? l`
                      ${t[a].icon ? l`
                            <span class="dss-icon dss-icon--sm column-icon"
                              >${t[a].icon}</span
                            >
                          ` : null}
                      ${t[a].badgeBefore ? l`
                            <dss-badge
                              size="md"
                              state="${i ? "disabled" : t[a].state}"
                              text="${t[a].badgeBefore}"
                              outlined
                              hideIcon
                            >
                              ${t[a].badgeTooltip ? l`
                                    <dss-tooltip
                                      slot="tooltip"
                                      position="${t[a].badgeTooltipPosition ? t[a].badgeTooltipPosition : "top"}"
                                    >
                                      <span>${t[a].badgeTooltip}</span>
                                    </dss-tooltip>
                                  ` : null}
                            </dss-badge>
                          ` : null}

                      <span class="column-value">
                        <span class="value">
                          ${t[a].value === "" ? l`<i class="dss-icon dss-icon--md">remove</i>` : null}
                          ${t[a].value.length <= this._valueMaxLength ? l`${t[a].value}` : l`${t[a].value.slice(0, this._valueMaxLength)}...`}
                        </span>
                        ${t[a].valueTooltip ? l`
                              <dss-tooltip
                                position="${t[a].valueTooltipPosition ? t[a].valueTooltipPosition : "top"}"
                              >
                                <span>${t[a].valueTooltip}</span>
                              </dss-tooltip>
                            ` : null}
                      </span>
                    ` : t[a].type === "number" ? l`
                      ${t[a].icon ? l`
                            <span class="dss-icon dss-icon--sm column-icon"
                              >${t[a].icon}</span
                            >
                          ` : null}
                      <span class="column-value">${t[a].value}</span>
                    ` : t[a].type === "link" ? l`
                      ${t[a].icon ? l`
                            <span class="dss-icon dss-icon--sm column-icon"
                              >${t[a].icon}</span
                            >
                          ` : null}
                      ${i ? l`
                            <span class="column-value">${t[a].value}</span>
                          ` : l`
                            <a
                              class="column-value column-value--link"
                              href="${t[a].href}"
                              ?disabled=${i}
                            >
                              <span class="value">
                                ${t[a].value.length <= this._valueMaxLength ? l`${t[a].value}` : l`${t[a].value.slice(0, this._valueMaxLength)}...`}
                              </span>
                              ${t[a].valueTooltip ? l`
                                    <dss-tooltip
                                      position="${t[a].valueTooltipPosition ? t[a].valueTooltipPosition : "top"}"
                                    >
                                      <span>${t[a].valueTooltip}</span>
                                    </dss-tooltip>
                                  ` : null}
                            </a>
                          `}
                    ` : t[a].type === "badge" ? l`
                      <dss-badge
                        size="${t[a].badgeSize ? t[a].badgeSize : "md"}"
                        state="${i ? "disabled" : t[a].state}"
                        ?outlined=${t[a].outlined}
                        text="${t[a].value}"
                      ></dss-badge>
                    ` : t[a].type === "result" ? l`
                      <dss-icon-badge
                        size="sm"
                        state="${i ? "disabled" : t[a].state}"
                        icon="${t[a].icon}"
                        bubble
                      ></dss-icon-badge>
                      <span class="column-value">${t[a].value}</span>
                    ` : t[a].type === "actions" ? this._generateTableTdSelfActions(t, a, t[a], i, c) : t[a].type === "review" ? l`
                      <input
                        type="checkbox"
                        class="dss-checkbox dss-checkbox--validate"
                        ?checked="${t[a].value}"
                        @change="${() => b(a)}"
                        ?disabled=${i && !this._enableRowActionsOnDisabled || c && !this._enableRowActionsOnDeleted}
                      />
                    ` : t[a].type === "progress" ? l`
                      ${t[a].icon ? l`
                            <span class="dss-icon dss-icon--sm column-icon"
                              >${t[a].icon}</span
                            >
                          ` : null}
                      <dss-progress-indicator
                        percentage="23"
                      ></dss-progress-indicator>
                    ` : null}
              </div>
            </td>
          `;
      }), C = l` <tr
          class="table-body-row ${g({
        "table-body-row--selected": o,
        "table-body-row--deleted": c,
        "table-body-row--disabled": i
      })}"
          tabindex="${s ? 0 : -1}"
          style=${S(this._tableGridStyle)}
          @keydown=${u}
          @focusout=${h}
        >
          ${v} ${k} ${A}
          ${R} ${_}
        </tr>`;
      return s = !1, C;
    })), e;
  }
  _generateFilterChips() {
    let e;
    return this._filters && (e = this._filters.map((s) => {
      const t = (i) => {
        const h = i.target.getAttribute("term");
        typeof s == "string" ? this._filters = this._filters.filter((u) => u !== h) : this._filters = this._filters.filter((u) => u.value.trim() !== (h == null ? void 0 : h.trim())), this._emitChangeFilters(), this.requestUpdate();
      };
      return l`
          <span tabindex="0" class="dss-chip dss-chip--sm dss-chip--selected">
            ${typeof s === "string" ? l`
                  ${s}
                  <button
                    class="dss-chip__icon-button dss-icon-button dss-icon-button--primary dss-icon-button--sm"
                    @click="${t}"
                  >
                    <span class="dss-icon" term="${s}">cancel</span>
                  </button>
                ` : l`
                  <span class="dss-icon">${s.icon}</span>
                  ${s.value}
                  <button
                    class="dss-chip__icon-button dss-icon-button dss-icon-button--primary dss-icon-button--sm"
                    @click="${t}"
                  >
                    <span class="dss-icon" term=" ${s.value}"
                      >cancel</span
                    >
                  </button>
                `}
          </span>
        `;
    })), e;
  }
  _clearFilters() {
    this._filters = [], this._emitChangeFilters(), this.requestUpdate();
  }
  _countRowsChecked() {
    let e = 0;
    for (const s of this._pipeData)
      s.checked && (e += 1);
    return e;
  }
  _getRowsSelected() {
    const e = [];
    return this._pipeData.forEach((s) => {
      if (s.checked) {
        const t = { ...s };
        t.checked = void 0, e.push(t);
      }
    }), e;
  }
  // Output events
  _emitExpandAction() {
    const e = {
      detail: this._expandTable,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onExpandTable", e)), this._expandTable = !this._expandTable, this.requestUpdate();
  }
  _emitOpenFilters() {
    const e = {
      detail: !0,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onOpenFilters", e)), this.requestUpdate();
  }
  _emitChangeFilters() {
    const e = {
      detail: this._filters,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onChangeFilters", e)), this.requestUpdate();
  }
  _emitFooterAction(e) {
    const s = this._getRowsSelected(), t = {
      detail: { action: e, selectedRows: s },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onFooterAction", t)), this.requestUpdate();
  }
  render() {
    const e = {
      "table--max-content-width": this._maxContentWidth,
      "table--sticky-columns": this._maxContentWidth && this._stickyColumns,
      "table--sticky-columns--multiselect": this._maxContentWidth && this._stickyColumns && this._multiselect,
      "table--sticky-columns--radioselect": this._maxContentWidth && this._stickyColumns && this._radioselect
    }, s = {
      "table-body--align-left": this._data.length > 0 && this._textAlign === "left",
      "table-body--align-center": this._data.length > 0 && this._textAlign === "center",
      "table-body--align-right": this._data.length > 0 && this._textAlign === "right",
      "table-body--align-justify": this._data.length > 0 && this._textAlign === "justify"
    };
    return l`
      <div class="dss-table">
        ${this._hideHeader ? null : l`
              <div class="dss-table-header">
                <div class="dss-table-header-title">
                  <div class="dss-table-header-title__text">
                    ${this._headerTitle}
                  </div>
                  <div
                    class="dss-table-header-title__action"
                    role="button"
                    tabindex="0"
                    @click="${this._emitExpandAction}"
                  >
                    ${this._expandTable ? l`
                          <span class="dss-icon dss-icon--sm">fullscreen</span>
                          <span>${this._collapseLabel}</span>
                        ` : l`
                          <span class="dss-icon dss-icon--sm">fullscreen</span>
                          <span>${this._expandLabel}</span>
                        `}
                  </div>
                </div>

                ${this._innerFilters ? l`
                      <div
                        class="dss-table-header-filters dss-table-header-filters--inner"
                      >
                        <div class="dss-table-header-filters__filters">
                          <slot name="filters"></slot>
                        </div>
                        <div class="dss-table-header-filters__actions"></div>
                      </div>
                    ` : l`
                      <div
                        class="dss-table-header-filters dss-table-header-filters--outer"
                      >
                        <div class="dss-table-header-filters__filters">
                          <div class="filters-label">
                            ${this._filtersLabel}:
                          </div>
                          <div class="filters-list">
                            ${this._filters.length > 0 ? l` ${this._generateFilterChips()} ` : l`
                                  <span class="filters-list-empty">
                                    ${this._noFiltersLabel}
                                  </span>
                                `}
                          </div>
                          <div class="filters-clean">
                            ${this._filters.length > 0 ? l`
                                  <button
                                    type="button"
                                    class="dss-button dss-button--sm dss-button--secondary dss-button--icon-left"
                                    @click=${this._clearFilters}
                                  >
                                    <span class="material-symbols-rounded"
                                      >mop</span
                                    >${this._cleanFiltersLabel}
                                  </button>
                                ` : null}
                          </div>
                        </div>

                        <div class="dss-table-header-filters__actions">
                          <button
                            type="button"
                            class="dss-button dss-button--md dss-button--secondary dss-button--icon-left"
                            @click=${this._emitOpenFilters}
                          >
                            <span class="material-symbols-rounded"
                              >filter_list</span
                            >
                            ${this._openFiltersLabel}
                          </button>
                        </div>
                      </div>
                    `}
              </div>
            `}

        <div class="dss-table-main">
          <div
            class="dss-table-container"
            style="${S(this._tableHeight)}"
          >
            <table
              class="table ${g(e)}"
              cellspacing="0"
              cellpadding="0"
            >
              <thead
                class="table-header"
                style=${S(this._tableGridStyle)}
              >
                ${this._generateTableHeaderHTML()}
              </thead>
              <tbody class="table-body ${g(s)}">
                ${this._customData ? this._generateCustomTableBody() : this._generateDefaultTableBody()}
              </tbody>
            </table>
          </div>
          ${this._hasPaginator ? l`
                <dss-table-pagination
                  length=${this._customData ? this._customData.length : this._data.length}
                  pagesize=${this._pageSize}
                  pageSizeOptions=${this._pageSizeOptions}
                  currentindex=${this._currentIndex}
                  resultstext=${this._resultstext}
                  rowsperpagetext=${this._rowsperpagetext}
                  @onChangePage=${this._paginateTable}
                ></dss-table-pagination>
              ` : null}
        </div>

        ${this._multiselect ? l`
              <div class="table-footer">
                <div class="table-footer-description">
                  ${this._countRowsChecked()} ${this._selectedRowsLabel}
                </div>

                <div class="table-footer-actions">
                  ${this._footerButtons >= 3 ? l`
                        <button
                          type="button"
                          class="dss-button dss-button--md dss-button--subtle"
                          ?disabled=${this._countRowsChecked() <= 0}
                          @click=${() => this._emitFooterAction("alternative")}
                        >
                          ${this._footerButtonAlternativeLabel}
                        </button>
                      ` : null}
                  ${this._footerButtons >= 2 ? l`
                        <button
                          type="button"
                          class="dss-button dss-button--md dss-button--secondary"
                          ?disabled=${this._countRowsChecked() <= 0}
                          @click=${() => this._emitFooterAction("secondary")}
                        >
                          ${this._footerButtonSecondaryLabel}
                        </button>
                      ` : null}
                  ${this._footerButtons >= 1 ? l`
                        <button
                          type="button"
                          class="dss-button dss-button--md dss-button--primary"
                          ?disabled=${this._countRowsChecked() <= 0}
                          @click=${() => this._emitFooterAction("primary")}
                        >
                          ${this._footerButtonPrimaryLabel}
                        </button>
                      ` : null}
                </div>
              </div>
            ` : null}
      </div>
    `;
  }
}
d([
  n(m)
], r.prototype, "hasPaginator");
d([
  n({ type: Array })
], r.prototype, "data");
d([
  n({ type: Array })
], r.prototype, "customData");
d([
  n({ type: Array })
], r.prototype, "customTableHeader");
d([
  n({ type: Array })
], r.prototype, "filters");
d([
  n({ type: Number })
], r.prototype, "currentIndex");
d([
  n({ type: Number })
], r.prototype, "pageSize");
d([
  n({ type: String })
], r.prototype, "pageSizeOptions");
d([
  n({ type: String })
], r.prototype, "resultstext");
d([
  n({ type: String })
], r.prototype, "rowsperpagetext");
d([
  n({ type: String })
], r.prototype, "textAlign");
d([
  n({ type: String })
], r.prototype, "headerTitle");
d([
  n(m)
], r.prototype, "hideHeader");
d([
  n(m)
], r.prototype, "hideColumnHeader");
d([
  n(m)
], r.prototype, "innerFilters");
d([
  n(m)
], r.prototype, "expandTable");
d([
  n({ type: String })
], r.prototype, "expandLabel");
d([
  n({ type: String })
], r.prototype, "collapseLabel");
d([
  n({ type: Number })
], r.prototype, "rowsOnCollapsed");
d([
  n({ type: String })
], r.prototype, "filtersLabel");
d([
  n({ type: String })
], r.prototype, "cleanFiltersLabel");
d([
  n({ type: String })
], r.prototype, "selectedRowsLabel");
d([
  n({ type: Number })
], r.prototype, "footerButtons");
d([
  n(m)
], r.prototype, "maxContentWidth");
d([
  n(m)
], r.prototype, "stickyColumns");
d([
  n(m)
], r.prototype, "multiselect");
d([
  n(m)
], r.prototype, "radioselect");
d([
  n(m)
], r.prototype, "hasRowButton");
d([
  n({ type: String })
], r.prototype, "rowButtonLabel");
d([
  n(m)
], r.prototype, "hasRowActions");
d([
  n({ type: Array })
], r.prototype, "rowActionsIcons");
d([
  n({ type: String })
], r.prototype, "footerButtonPrimaryLabel");
d([
  n({ type: String })
], r.prototype, "footerButtonSecondaryLabel");
d([
  n({ type: String })
], r.prototype, "footerButtonAlternativeLabel");
d([
  n(m)
], r.prototype, "enableRowActionsOnDisabled");
d([
  n(m)
], r.prototype, "enableRowActionsOnDeleted");
d([
  n({ type: Number })
], r.prototype, "valueMaxLength");
export {
  r as Table
};
//# sourceMappingURL=table.js.map
