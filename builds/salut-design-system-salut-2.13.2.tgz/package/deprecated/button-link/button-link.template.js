import { classMap as l } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as n, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const t = n`dss-icon${a(o())}`, u = (s) => i`
  <a
    href="${s.linkHref}"
    class=${l({
  "dss-button-link": !0,
  "dss-button-link--disabled": !!s.disabled,
  "dss-button-link--icon-right": !!s.icon && s.iconPosition === "right"
})}
  >
    ${s.icon ? i`
          <${t} size="sm" icon="${s.icon}"></${t}>
        ` : null}
    <span class="dss-button-link-text"> ${s.label} </span>
  </a>
`;
export {
  u as buttonLinkTemplate
};
//# sourceMappingURL=button-link.template.js.map
