import { LitElement as m, unsafeCSS as p } from "lit";
import { property as e } from "lit/decorators.js";
import y from "../../foundations/icon/icon.style.css.js";
import a from "../../shared/reset.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import d from "./button-link.style.css.js";
import { buttonLinkTemplate as c } from "./button-link.template.js";
var S = Object.defineProperty, r = (i, s, l, b) => {
  for (var t = void 0, n = i.length - 1, f; n >= 0; n--)
    (f = i[n]) && (t = f(s, l, t) || t);
  return t && S(s, l, t), t;
};
class o extends m {
  constructor() {
    super(...arguments), this.linkHref = "#", this.label = "Button Link", this.icon = void 0, this.iconPosition = "left", this.disabled = !1;
  }
  static get styles() {
    return [p(y), p(a), p(d)];
  }
  render() {
    return c(this);
  }
}
r([
  e({ type: String })
], o.prototype, "linkHref");
r([
  e({ type: String })
], o.prototype, "label");
r([
  e({ type: String })
], o.prototype, "icon");
r([
  e({ type: String })
], o.prototype, "iconPosition");
r([
  e(u)
], o.prototype, "disabled");
export {
  o as ButtonLink
};
//# sourceMappingURL=button-link.js.map
