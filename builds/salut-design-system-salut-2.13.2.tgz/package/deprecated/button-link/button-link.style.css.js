const o = ":host{display:inline-block;vertical-align:middle}.dss-button-link{display:inline-flex;align-items:center;gap:var(--dss-spacing-xxs);font-size:14px;line-height:24px;font-weight:var(--font-semibold);color:var(--color-primary-500);text-decoration:none;border-radius:var(--dss-radius-xs);transition:.2s all ease-in;vertical-align:middle}.dss-button-link:visited{color:var(--color-purple-700)}.dss-button-link:hover{color:var(--color-primary-600)}.dss-button-link:active{color:var(--color-primary-400)}.dss-button-link:focus-visible{outline:var(--dss-border-width-md) solid var(--color-blue-200)}.dss-button-link.dss-button-link--disabled{cursor:not-allowed;color:var(--color-neutral-500)!important}.dss-button-link .dss-button-link-text{text-decoration:underline}.dss-button-link--icon-right{flex-direction:row-reverse}";
export {
  o as default
};
//# sourceMappingURL=button-link.style.css.js.map
