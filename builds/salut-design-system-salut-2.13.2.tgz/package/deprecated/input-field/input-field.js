import { LitElement as m, css as b, html as a } from "lit";
import { property as s } from "lit/decorators.js";
import { classMap as g } from "lit/directives/class-map.js";
import { ifDefined as p } from "lit/directives/if-defined.js";
import { booleanType as l } from "../../utils/property-types.js";
var f = Object.defineProperty, y = Object.getOwnPropertyDescriptor, i = (h, t, e, r) => {
  for (var o = y(t, e), u = h.length - 1, d; u >= 0; u--)
    (d = h[u]) && (o = d(t, e, o) || o);
  return o && f(t, e, o), o;
};
const v = "number";
class n extends m {
  constructor() {
    super(...arguments), this._type = "text", this._value = "", this._label = "", this._description = "", this._placeHolder = "", this._icon = "", this._maxLength = void 0, this._minLength = void 0, this._max = void 0, this._min = void 0, this._step = void 0, this._isInputFocused = !1, this._isGroupFocusedVisible = !1, this._isTypeNumeric = !1, this._clearable = !1, this._showError = !1, this._required = !1, this._disabled = !1, this._readonly = !1;
  }
  static get styles() {
    return b`
      :host {
        width: 100%;
        height: fit-content;
      }

      label {
        font-style: normal;
        font-weight: 400;
        font-size: 0.875rem;
        line-height: 1.5rem;
        cursor: text;
        position: absolute;
        white-space: nowrap;
        background-color: #ffffff;
        width: 100%;
      }

      input {
        outline: none;
        border: 0;
        font-size: 0.875rem;
        line-height: 1.5rem;
        font-style: normal;
        color: #1d1d1d;
        width: 100%;
        text-overflow: ellipsis;
        margin: 0;
        padding: 0;
      }

      input::placeholder {
        color: #9f9f9f;
      }

      .dss-input--invalid input::placeholder {
        color: #d36262;
      }

      .dss-input--invalid label {
        background-color: #fff6f6;
      }

      .dss-input {
        display: flex;
        flex-direction: column;
        color: #656565;
        width: 100%;
      }

      .dss-input--disabled {
        opacity: 0.6;
      }

      .dss-input--gap {
        gap: 0.25rem;
      }

      .dss-input__content {
        display: flex;
        align-items: center;
        flex: 1;
        overflow: hidden;
        position: relative;
      }

      .dss-input--disabled .dss-input__group,
      .dss-input--disabled input,
      .dss-input--disabled label {
        background-color: #f5f5f5;
        cursor: not-allowed;
      }

      .dss-input__group {
        position: relative;
        background: #ffffff;
        box-shadow: inset 0 0 0 0.063rem #d8d8d8;
        border-radius: 0.5rem;
        padding: 0.75rem;
        display: flex;
        gap: 0.5rem;
      }

      :host([small]) .dss-input__group {
        padding: 0.5rem 0.75rem;
      }

      .dss-input__group--required label::before {
        content: '*';
      }

      .dss-input__group--readOnly .dss-icon-button {
        pointer-events: none;
      }

      .dss-input__group:focus-visible,
      .dss-input__group--focused-visible,
      .dss-input--invalid .dss-input__group:focus-visible {
        outline: 0.25rem solid #8ec7e5;
        box-shadow: none;
        background-color: #ffffff;
      }

      .dss-input--invalid .dss-input__group:focus-visible input {
        background-color: #ffffff;
      }

      .dss-input--invalid .dss-input__group:focus-visible .dss-icon-button {
        background-color: transparent;
      }

      .dss-input__group--focused {
        padding: 0.25rem 0.75rem;
      }

      :host([small]) .dss-input__group--focused {
        padding: 0.063rem 0.75rem;
      }

      .dss-input__group--focused .dss-input__content label {
        font-size: 0.75rem;
        line-height: 1rem;
        transition: 0.3s;
        top: 0.25rem;
      }

      :host([small]) .dss-input__group--focused .dss-input__content label {
        top: 0.125rem;
      }

      .dss-input__group--focused .dss-input__content input,
      .dss-input__group--focused .dss-input__content input {
        margin-top: 1rem !important;
      }

      :host([small]) .dss-input__group--focused .dss-input__content input {
        margin-top: 0.875rem !important;
      }

      :host([small]) .dss-input__group--focused .dss-input__content input {
        margin-top: 0.875rem !important;
      }

      .dss-input--invalid .dss-input__group .dss-icon-button {
        color: #b60000;
      }

      .dss-input--invalid .dss-input__group {
        box-shadow: inset 0 0 0 0.063rem #b60000;
      }

      .dss-input--invalid .dss-input__group input {
        background-color: #fff6f6;
        color: #1d1d1d;
      }

      .dss-input--invalid .dss-input__group,
      .dss-input--invalid .dss-icon-button,
      .dss-input--invalid .dss-input__group .dss-icon-button:hover span {
        background-color: #fff6f6;
        color: #b60000;
      }

      .dss-input__help {
        font-style: normal;
        font-weight: 400;
        font-size: 0.75rem;
        line-height: 1rem;
        display: flex;
        padding: 0 0.75rem;
        gap: 0.5rem;
      }

      .dss-input__help .dss-input__description {
        flex: 1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .dss-input--invalid .dss-input__help,
      .dss-input--invalid .dss-input__help::after {
        color: #b60000;
      }

      .dss-input__icon {
        font-family: var(--icon-font);
        display: flex;
        align-items: center;
        font-size: 1.5rem;
      }

      :host([small]) .dss-input__group.dss-input__group--icon,
      :host([small]) .dss-input__group--focused.dss-input__group--icon,
      .dss-input__group.dss-input__group--icon,
      .dss-input__group--focused.dss-input__group--icon {
        padding-right: 0.375rem;
      }

      .dss-input__group.dss-input__group--numeric {
        padding: 0.25rem 0.5rem 0.25rem 0.75rem;
      }

      :host([small]) .dss-input__group.dss-input__group--numeric {
        padding: 0.063rem 0.625rem 0.063rem 0.75rem;
      }

      .dss-icon-button {
        font-size: 1rem;
        font-family: var(--icon-font);
        align-items: center;
        border: none;
        cursor: pointer;
        display: flex;
        background-color: transparent;
        color: #0073e6;
        padding: 0;
        height: fit-content;
        margin: auto;
        border-radius: 100%;
      }

      .dss-icon-button span {
        padding: 0.25rem;
        background-color: transparent;
        border-radius: 100%;
        transition: all 0.3s ease-in;
      }

      .dss-icon-button:hover:enabled span {
        background-color: #bfddfa;
      }

      .dss-icon-button:active:enabled span {
        background-color: #eff7ff;
        transition: none;
      }

      .dss-icon-button:disabled {
        cursor: not-allowed;
      }

      .dss-icon-button:focus-visible:enabled {
        outline: none;
      }

      .dss-input__numeric-buttons {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: all 0.3s ease-in;
        height: 40px;
      }

      .dss-input__numeric-buttons .dss-icon-button span {
        padding: 0.063rem;
        display: flex;
        justify-content: center;
        text-align: center;
        width: 18px;
        height: 18px;
        align-items: center;
      }

      :host([small]) .dss-input__numeric-buttons {
        height: 38px;
      }

      :host([small])
        .dss-input__group.dss-input__group--numeric
        .dss-icon-button
        span {
        width: 16px;
        height: 16px;
      }

      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
      }

      input[type='number'] {
        -moz-appearance: textfield;
      }
    `;
  }
  set value(t) {
    const e = this._value;
    this._value = t, this.requestUpdate("value", e);
  }
  get value() {
    return this._value;
  }
  set type(t) {
    const e = this._type;
    this._type = t, this.requestUpdate("type", e);
  }
  get type() {
    return this._type;
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set description(t) {
    const e = this._description;
    this._description = t, this.requestUpdate("description", e);
  }
  get description() {
    return this._description;
  }
  set placeHolder(t) {
    const e = this._placeHolder;
    this._placeHolder = t, this.requestUpdate("placeHolder", e);
  }
  get placeHolder() {
    return this._placeHolder;
  }
  set required(t) {
    const e = this._required;
    this._required = t, this.requestUpdate("required", e);
  }
  get required() {
    return this._required;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set readonly(t) {
    const e = this._readonly;
    this._readonly = t, this.requestUpdate("readonly", e);
  }
  get readonly() {
    return this._readonly;
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set clearable(t) {
    const e = this._clearable;
    this._clearable = t, this.requestUpdate("clearable", e);
  }
  get clearable() {
    return this._clearable;
  }
  set showError(t) {
    const e = this._showError;
    this._showError = t, this.requestUpdate("showError", e);
  }
  get showError() {
    return this._showError;
  }
  set maxLength(t) {
    const e = this._maxLength;
    this._maxLength = t, this.requestUpdate("maxLength", e);
  }
  get maxLength() {
    return this._maxLength || 0;
  }
  set minLength(t) {
    const e = this._minLength;
    this._minLength = t, this.requestUpdate("minLength", e);
  }
  get minLength() {
    return this._minLength || 0;
  }
  set max(t) {
    const e = this._max;
    this._max = t, this.requestUpdate("max", e);
  }
  get max() {
    return this._max || 0;
  }
  set min(t) {
    const e = this._min;
    this._min = t, this.requestUpdate("min", e);
  }
  get min() {
    return this._min || 0;
  }
  set step(t) {
    const e = this._step;
    this._step = t, this.requestUpdate("step", e);
  }
  get step() {
    return this._step || 0;
  }
  get _input() {
    var t;
    return (t = this.shadowRoot) == null ? void 0 : t.querySelector("input");
  }
  _handleInput() {
    this._dispatchValueChange(), this.requestUpdate();
  }
  _handleKeypress(t) {
    t.keyCode < 32 && t.preventDefault(), this._maxLength && t.target.value.length >= this._maxLength && t.preventDefault();
  }
  _handleKeyup(t) {
    (t.keyCode ? t.keyCode : t.which) === 9 && (this._isGroupFocusedVisible = !0, this._isInputFocused = !0, this._handelLabelClick());
  }
  _handleFocus() {
    this._readonly || (this._isGroupFocusedVisible = !0, this._isInputFocused = !0, this.requestUpdate());
  }
  _handleFocusOut() {
    var t, e;
    this._handleBlur(), this._isGroupFocusedVisible = !1, this._isInputFocused = !1, ((e = (t = this._input) == null ? void 0 : t.value) == null ? void 0 : e.length) === 0 && (this._value = "", this._input.value = this._value), this.requestUpdate();
  }
  _handleBlur() {
    this._isInputFocused = !1, this.requestUpdate();
  }
  _handelLabelClick() {
    var t;
    (t = this._input) == null || t.focus(), this.requestUpdate();
  }
  _cleanInput() {
    var t, e;
    (e = (t = this._input) == null ? void 0 : t.value) != null && e.length && (this._value = "", this._input.value = this._value), this._dispatchValueChange(), this.requestUpdate();
  }
  _stepUp() {
    var t, e;
    (t = this._input) == null || t.stepUp(), this._value = ((e = this._input) == null ? void 0 : e.value) || "", this._dispatchValueChange(), this.requestUpdate();
  }
  _stepDown() {
    var t, e;
    (t = this._input) == null || t.stepDown(), this._value = ((e = this._input) == null ? void 0 : e.value) || "", this._dispatchValueChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    var e, r;
    const t = {
      detail: this._isTypeNumeric ? Number((e = this._input) == null ? void 0 : e.value) : (r = this._input) == null ? void 0 : r.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", t));
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._isTypeNumeric = this._type === v, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    var r, o, u, d, _, c;
    const t = {
      "dss-input--invalid": this._showError,
      "dss-input--disabled": this._disabled,
      "dss-input--gap": this._maxLength || !!this._description
    }, e = {
      "dss-input__group--focused": ((r = this._input) == null ? void 0 : r.value) || this._isInputFocused || this._placeHolder,
      "dss-input__group--focused-visible": this._isGroupFocusedVisible,
      "dss-input__group--required": this._required,
      "dss-input__group--readOnly": this._readonly,
      "dss-input__group--numeric": this._isTypeNumeric,
      "dss-input__group--icon": this._clearable
    };
    return a`
      <div class="dss-input ${g(t)}">
        <div
          class="dss-input__group ${g(e)}"
          tabindex="0"
          @keyup=${this._handleKeyup}
        >
          ${this._icon ? a`<span class="dss-input__icon">${this._icon}</span>` : null}
          <div class="dss-input__content">
            <label @mouseup=${this._handelLabelClick}>${this._label}</label>
            <input
              .value=${this._value}
              placeholder=${p(this._placeHolder)}
              maxlength=${p(this._maxLength)}
              minlength=${p(this._minLength)}
              min=${p(this._min)}
              max=${p(this._max)}
              step=${p(this._step)}
              ?disabled=${this._disabled}
              ?required=${this._required}
              ?readonly=${this._readonly}
              @keyup=${this._handleKeyup}
              @keypress=${this._handleKeypress}
              @input="${this._handleInput}"
              @focus=${this._handleFocus}
              @focusout=${this._handleFocusOut}
              @blur=${this._handleBlur}
              .type=${this._type}
            />
          </div>
          ${this._clearable && !this._isTypeNumeric ? a`
                <button
                  type="button"
                  class="dss-icon-button"
                  @click=${this._cleanInput}
                  ?disabled=${(o = this._input) == null ? void 0 : o.disabled}
                  tabindex="-1"
                >
                  <span>close</span>
                </button>
              ` : null}
          ${this._isTypeNumeric ? a`
                <div class="dss-input__numeric-buttons">
                  <button
                    type="button"
                    class="dss-icon-button"
                    @click=${this._stepUp}
                    ?disabled=${(u = this._input) == null ? void 0 : u.disabled}
                    tabindex="-1"
                  >
                    <span>keyboard_arrow_up</span>
                  </button>
                  <button
                    type="button"
                    class="dss-icon-button"
                    @click=${this._stepDown}
                    ?disabled=${(d = this._input) == null ? void 0 : d.disabled}
                    tabindex="-1"
                  >
                    <span>keyboard_arrow_down</span>
                  </button>
                </div>
              ` : null}
        </div>
        <div class="dss-input__help">
          <div class="dss-input__description">
            <span>${this._description}</span>
          </div>
          ${this._maxLength ? a`<span>
                ${(c = (_ = this._input) == null ? void 0 : _.value) == null ? void 0 : c.length}/${this._maxLength}
              </span>` : null}
        </div>
      </div>
    `;
  }
}
i([
  s({ type: String })
], n.prototype, "value");
i([
  s({ type: String })
], n.prototype, "type");
i([
  s({ type: String })
], n.prototype, "label");
i([
  s({ type: String })
], n.prototype, "description");
i([
  s({ type: String })
], n.prototype, "placeHolder");
i([
  s(l)
], n.prototype, "required");
i([
  s(l)
], n.prototype, "disabled");
i([
  s(l)
], n.prototype, "readonly");
i([
  s({ type: String })
], n.prototype, "icon");
i([
  s(l)
], n.prototype, "clearable");
i([
  s(l)
], n.prototype, "showError");
i([
  s({ type: Number })
], n.prototype, "maxLength");
i([
  s({ type: Number })
], n.prototype, "minLength");
i([
  s({ type: Number })
], n.prototype, "max");
i([
  s({ type: Number })
], n.prototype, "min");
i([
  s({ type: Number })
], n.prototype, "step");
export {
  n as InputField
};
//# sourceMappingURL=input-field.js.map
