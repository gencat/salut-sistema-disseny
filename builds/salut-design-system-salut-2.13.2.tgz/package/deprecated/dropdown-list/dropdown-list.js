import { LitElement as f, css as y, html as h } from "lit";
import { property as s } from "lit/decorators.js";
import { classMap as _ } from "lit/directives/class-map.js";
import { ifDefined as b } from "lit/directives/if-defined.js";
import { booleanType as a } from "../../utils/property-types.js";
var g = Object.defineProperty, S = Object.getOwnPropertyDescriptor, i = (c, e, t, o) => {
  for (var n = S(e, t), d = c.length - 1, r; d >= 0; d--)
    (r = c[d]) && (n = r(e, t, n) || n);
  return n && g(e, t, n), n;
};
class l extends f {
  constructor() {
    super(...arguments), this._elements = null, this._copyElements = null, this._tick = !0, this._type = "default", this._style = null, this._boxStyle = null, this._inputStyle = null, this._selectedValue = null, this._multiple = !1, this._openWithSearch = !1, this._deselectable = !1, this._icon = "search", this._label = "", this._placeHolder = "", this._showSelector = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._labelSelectAll = "Seleccionar-ho tot", this._labelDeselectAll = "Deseleccionar-ho tot", this._selectAll = !1, this._selectElements = 0, this._isFocused = !1, this._isGroupFocusedVisible = !1;
  }
  static get styles() {
    return y`
      :host {
        width: fit-content;
        height: fit-content;
        position: relative;
      }

      label {
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 24px;
        cursor: text;
        position: absolute;
      }

      input {
        outline: none;
        border: 0;
        font-size: 14px;
        line-height: 24px;
        font-style: normal;
        color: #1d1d1d;
        width: 100%;
        text-overflow: ellipsis;
      }

      input::placeholder {
        color: #9f9f9f;
      }

      .dss-input {
        display: flex;
        flex-direction: column;
        color: #656565;
        position: relative;
      }

      .dss-input--disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }

      .dss-input__content {
        display: flex;
        align-items: center;
        flex: 1;
        overflow: hidden;
        position: relative;
      }

      .dss-input--disabled .dss-input__group,
      .dss-input--disabled input {
        background-color: #f5f5f5;
        cursor: not-allowed;
      }

      .dss-input--disabled label,
      .dss-input--disabled input {
        cursor: not-allowed;
      }

      .dss-input__group {
        position: relative;
        background: #ffffff;
        box-shadow: inset 0 0 0 1px #d8d8d8;
        border-radius: 8px;
        padding: 12px;
        display: flex;
        gap: 8px;
      }

      :host([small]) .dss-input__group {
        padding: 8px 12px;
      }

      .dss-input__group--required label::before {
        content: '*';
      }

      .dss-input--invalid .dss-input__group:focus-visible input {
        background-color: #ffffff;
      }

      .dss-input__group--focused {
        padding: 4px 12px;
      }

      :host([small]) .dss-input__group--focused {
        padding: 1px 12px;
      }

      .dss-input__group--focused .dss-input__content label {
        font-size: 12px;
        line-height: 16px;
        transition: 0.3s;
        top: 4px;
      }

      :host([small]) .dss-input__group--focused .dss-input__content label {
        top: 2px;
      }

      .dss-input__group--focused .dss-input__content input,
      .dss-input__group--focused .dss-input__content input {
        margin-top: 16px !important;
        font-family: var(--font-family);
        padding-left: 0 !important;
      }

      :host([small]) .dss-input__group--focused .dss-input__content input {
        margin-top: 14px !important;
      }

      .dss-input--invalid .dss-input__group {
        box-shadow: inset 0 0 0 1px #b60000;
      }

      .dss-input--invalid .dss-input__group,
      .dss-input--invalid .dss-icon-button,
      .dss-input--invalid .dss-input__group input,
      .dss-input--invalid .dss-input__group .dss-icon-button:hover span {
        background-color: transparent;
        color: #b60000;
      }

      .dss-input--invalid .dss-input__group input {
        color: #1d1d1d;
      }

      .dss-input__group:focus-visible,
      .dss-input__group--active {
        box-shadow: 0 0 0 4px #8ec7e5;
        background-color: #ffffff;
        outline: none;
      }

      .dss-input--invalid .dss-input__group--active {
        box-shadow: 0 0 0 4px #8ec7e5;
      }

      .dss-input--invalid input::placeholder {
        color: #d36262;
      }

      .dss-input__icon {
        font-family: var(--icon-font);
        display: flex;
        align-items: center;
        font-size: 24px;
      }

      .dss-selector {
        position: absolute;
        top: 50px;
        z-index: 100;
        display: contents;
      }

      .dss-input__group--disabled .dss-icon-button {
        pointer-events: none;
      }

      :host([small]) dss-selector {
        top: 40px;
      }

      .dss-icon-button {
        font-size: 1rem;
        font-family: var(--icon-font);
        align-items: center;
        border: none;
        cursor: pointer;
        display: flex;
        background-color: transparent;
        color: #0073e6;
        padding: 0;
        height: fit-content;
        margin: auto;
        border-radius: 100%;
      }

      .dss-icon-button span {
        padding: 0.25rem;
        background-color: transparent;
        border-radius: 100%;
        transition: all 0.3s ease-in;
      }

      .dss-icon-button:hover:enabled span {
        background-color: #bfddfa;
      }

      .dss-icon-button:active:enabled span {
        background-color: #eff7ff;
        transition: none;
      }

      .dss-icon-button:disabled {
        cursor: not-allowed;
      }

      .dss-input__group--readOnly .dss-icon-button {
        pointer-events: none;
      }

      .dss-input__group--disabled .dss-icon-button {
        pointer-events: none;
      }

      .dss-icon-button:focus-visible:enabled {
        outline: none;
      }
    `;
  }
  get _input() {
    var e;
    return (e = this.shadowRoot) == null ? void 0 : e.querySelector("input");
  }
  get _DSSinput() {
    var e;
    return (e = this.shadowRoot) == null ? void 0 : e.querySelector(".dss-input");
  }
  set icon(e) {
    const t = this._icon;
    this._icon = e, this.requestUpdate("label", t);
  }
  get icon() {
    return this._icon;
  }
  set label(e) {
    const t = this._label;
    this._label = e, this.requestUpdate("label", t);
  }
  get label() {
    return this._label;
  }
  set placeHolder(e) {
    const t = this._placeHolder;
    this._placeHolder = e, this.requestUpdate("placeHolder", t);
  }
  get placeHolder() {
    return this._placeHolder;
  }
  set required(e) {
    const t = this._required;
    this._required = e, this.requestUpdate("required", t);
  }
  get required() {
    return this._required;
  }
  set disabled(e) {
    const t = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", t);
  }
  get disabled() {
    return this._disabled;
  }
  set readonly(e) {
    const t = this._readonly;
    this._readonly = e, this.requestUpdate("readonly", t);
  }
  get readonly() {
    return this._readonly;
  }
  set elements(e) {
    const t = this._elements;
    this._elements = e, this.requestUpdate("elements", t);
  }
  get elements() {
    return this._elements || [];
  }
  set multiple(e) {
    const t = this._multiple;
    this._multiple = e, this.requestUpdate("multiple", t);
  }
  get multiple() {
    return this._multiple;
  }
  set openWithSearch(e) {
    const t = this._openWithSearch;
    this._openWithSearch = e, this.requestUpdate("openWithSearch", t);
  }
  get openWithSearch() {
    return this._openWithSearch;
  }
  set tick(e) {
    const t = this._tick;
    this._tick = e, this.requestUpdate("tick", t);
  }
  get tick() {
    return this._tick;
  }
  set deselectable(e) {
    const t = this._deselectable;
    this._deselectable = e, this.requestUpdate("deselectable", t);
  }
  get deselectable() {
    return this._deselectable;
  }
  set selectedValue(e) {
    const t = this._selectedValue;
    this._selectedValue = e, this.requestUpdate("selectedValue", t);
  }
  get selectedValue() {
    return this._selectedValue || [];
  }
  set type(e) {
    const t = this._type;
    e === "default" || e === "green" ? this._type = e : this._type = "default", this.requestUpdate("type", t);
  }
  get type() {
    return this._type;
  }
  set boxStyle(e) {
    const t = this._boxStyle;
    this._boxStyle = e, this.requestUpdate("boxStyle", t);
  }
  get boxStyle() {
    return this._boxStyle || "";
  }
  set inputStyle(e) {
    const t = this._inputStyle;
    this._inputStyle = e, this._inputStyle = `${this._inputStyle} box-sizing: border-box;`, this.requestUpdate("inputStyle", t);
  }
  get inputStyle() {
    return this._inputStyle || "";
  }
  set labelSelectAll(e) {
    const t = this._labelSelectAll;
    e !== "" && (this._labelSelectAll = e), this.requestUpdate("labelSelectAll", t);
  }
  get labelSelectAll() {
    return this._labelSelectAll;
  }
  set labelDeselectAll(e) {
    const t = this._labelDeselectAll;
    e !== "" && (this._labelDeselectAll = e), this.requestUpdate("labelDeselectAll", t);
  }
  get labelDeselectAll() {
    return this._labelDeselectAll;
  }
  set SelectAll(e) {
    const t = this._selectAll;
    this._selectAll = e, this.requestUpdate("selectAll", t);
  }
  get SelectAll() {
    return this._selectAll;
  }
  // private _isFirstEmptySelected: boolean = true;
  get _filteredElements() {
    var t;
    const e = this._input.value.toLowerCase();
    return (t = this._elements) == null ? void 0 : t.filter((o) => o.label.toLowerCase().includes(e));
  }
  get _showPlaceHolder() {
    return b(this._placeHolder) && !this._showSelector ? void 0 : this._placeHolder;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._copyElements = JSON.parse(JSON.stringify(this._elements)), this._initElementsSelected(), !this._openWithSearch && !this._disabled && document.addEventListener("click", (e) => {
        this._clickedOutsideDropdown(this, e);
      }), this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []), this._openWithSearch && this._onclick(!0), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _initElementsSelected() {
    this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []);
  }
  _clickedOutsideDropdown(e, t) {
    e !== t.target && (this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []), this._showSelector = !1, this.requestUpdate());
  }
  _handleInput() {
    this.requestUpdate();
  }
  _handleFocus() {
    this._readonly || (this._isFocused = !0, this._isGroupFocusedVisible = !0, this.requestUpdate());
  }
  _handleBlurEsc() {
    this._readonly || this._openWithSearch || (this._isFocused = !0, this._showSelector = !1, this.requestUpdate());
  }
  _handleBlur() {
    this._isFocused = !1, this._isGroupFocusedVisible = !1, this.requestUpdate();
  }
  _handleBlurComponent(e, t) {
    var o;
    if (e !== t.target) {
      if (this._openWithSearch)
        return;
      (o = this._input) == null || o.focus(), this._handleBlurEsc(), this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []);
    }
  }
  _onCancel() {
    this._showSelector = !1, this._isFocused = !1, this.requestUpdate();
  }
  _cleanInput() {
    this._input.value = "", this.requestUpdate();
  }
  _onclick(e, t) {
    var n, d;
    e || (this._isFocused = !0);
    let o = "";
    this._boxStyle && (o += this._boxStyle, o.endsWith(";") || (o += ";")), this._style = `${o} overflow: auto;${this._openWithSearch ? "" : "box-shadow: 0 1px 3px 0 #0000001a, 0 4px 8px 3px #0000000d;"}`, this._openWithSearch ? this._showSelector = !0 : this._handleKeyInput(t), this._showSelector ? (this._input.value = "", e || (n = this._input) == null || n.focus()) : (this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []), (!t || t.key !== "Enter" && t.key !== " " && t.key !== "Escape") && ((d = this._input) == null || d.blur(), this._onCancel())), this.requestUpdate();
  }
  _handleKeyInput(e) {
    (e == null ? void 0 : e.key) === "Enter" || (e == null ? void 0 : e.key) === " " ? this._showSelector = !0 : (e == null ? void 0 : e.key) === "Escape" ? this._handleBlurEsc() : this._showSelector = !this._showSelector;
  }
  _dispatchValueChange() {
    if (this._input.value) {
      const e = {
        detail: this._input.value,
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onValueChange", e));
    }
  }
  _onSelectorChanges(e) {
    this._selectedValue = e.detail, this._dispatchValueChange(), !this._multiple && !this._openWithSearch && !this._disabled && this._clickedOutsideDropdown(this, e), this.requestUpdate();
  }
  _showSelectValuesInInput(e) {
    var n, d;
    !this._multiple && Array.isArray(e) && e.length > 1 && e.splice(1);
    const t = (n = this._elements) == null ? void 0 : n.filter((r) => e.includes(r.value));
    if (this._elements = [...this._copyElements], this._openWithSearch ? this._selectElements = 0 : this._selectElements = t != null && t.length ? t.length : 0, t && t.length > 0) {
      const r = this._elements.filter((p) => t.includes(p));
      r.push(...this._elements.filter((p) => !t.includes(p))), this._elements = [...r];
    }
    if (!this._multiple) {
      this._input.value = ((d = t == null ? void 0 : t[0]) == null ? void 0 : d.label) ?? "";
      return;
    }
    const o = t == null ? void 0 : t.map((r) => r.label);
    this._input.value = (o == null ? void 0 : o.join(", ")) ?? "";
  }
  _evalueFocus(e) {
    var t;
    ((t = e.target) == null ? void 0 : t.id) !== "dss-dropdownlist" && this._showSelector && this._handleFocus();
  }
  _handleKeyup(e) {
    (e.keyCode ? e.keyCode : e.which) === 9 && (this._isGroupFocusedVisible = !0, this._isFocused = !0, this._handelLabelClick());
  }
  _handelLabelClick() {
    var e;
    (e = this._input) == null || e.focus(), this.requestUpdate();
  }
  render() {
    var n, d, r, p;
    const e = {
      "dss-input--disabled": this._disabled
    }, t = {
      "dss-selector": !this._openWithSearch,
      "dss-selector--disabled": this._disabled,
      "dss-selector-dropdown": !0
    }, o = {
      "dss-input__group--focused": ((n = this._input) == null ? void 0 : n.value) || this._showPlaceHolder || this._showSelector,
      "dss-input__group--focused-visible": this._isGroupFocusedVisible,
      "dss-input__group--required": this._required,
      "dss-input__group--active": this._isFocused,
      "dss-input__group--readOnly": this._readonly,
      "dss-input__group--disabled": this._disabled
    };
    return h` <div
      id="previous-input"
      class="dss-input ${_(e)}"
      style=${b(this._inputStyle)}
    >
      <div
        class="dss-input__group ${_(o)}"
        tabindex="0"
        @keyup=${this._handleKeyup}
      >
        <span class="dss-input__icon">${this._icon}</span>
        <div class="dss-input__content">
          <label>${this._label}</label>
          <input
            aria-label="${this._label}"
            ?disabled=${this._disabled}
            ?required=${this._required}
            ?readonly=${this._readonly || !this._showSelector}
            @input=${this._handleInput}
            @focus="${this._evalueFocus}"
            @keydown="${(u) => {
      (u.key === "Enter" || u.key === " " || u.key === "Escape") && this._onclick(!1, u);
    }}"
            @blur=${this._handleBlur}
            placeholder=${this._showPlaceHolder}
            type="text"
          />
        </div>
        ${this._openWithSearch ? h`
              <button
                type="button"
                class="dss-icon-button"
                @click=${this._cleanInput}
                ?disabled=${(r = this._input) == null ? void 0 : r.disabled}
                tabindex="-1"
              >
                <span>close</span>
              </button>
            ` : h`
              <button
                type="button"
                class="dss-icon-button"
                @click=${this._onclick}
                ?disabled=${(d = this._input) == null ? void 0 : d.disabled}
                tabindex="-1"
              >
                <span
                  >${this._showSelector ? "keyboard_arrow_up" : "keyboard_arrow_down"}</span
                >
              </button>
            `}
      </div>
      ${this._showSelector && this._filteredElements && ((p = this._filteredElements) == null ? void 0 : p.length) > 0 ? h`
            <dss-selector
              class="${_(t)}"
              .multiple=${this._multiple}
              .tick=${this._tick}
              .deselectable=${this._deselectable}
              .disabled=${this._disabled}
              .elements=${this._filteredElements}
              .filtre=${this._input.value}
              .selectedValue=${this._selectedValue}
              .type=${this._type}
              .labelSelectAll=${this._labelSelectAll}
              .labelDeselectAll=${this._labelDeselectAll}
              .selectAll=${this._selectAll}
              boxStyle=${this._style}
              elementsSelected=${this._selectElements}
              @onValueChange="${this._onSelectorChanges}"
              @keydown="${(u) => {
      u.key === "Escape" && this._handleBlurComponent(this, u);
    }}"
            >
            </dss-selector>
          ` : null}
    </div>`;
  }
}
i([
  s({ type: String })
], l.prototype, "icon");
i([
  s({ type: String })
], l.prototype, "label");
i([
  s({ type: String })
], l.prototype, "placeHolder");
i([
  s(a)
], l.prototype, "required");
i([
  s(a)
], l.prototype, "disabled");
i([
  s(a)
], l.prototype, "readonly");
i([
  s({ type: Array })
], l.prototype, "elements");
i([
  s(a)
], l.prototype, "multiple");
i([
  s(a)
], l.prototype, "openWithSearch");
i([
  s(a)
], l.prototype, "tick");
i([
  s(a)
], l.prototype, "deselectable");
i([
  s({ type: Array })
], l.prototype, "selectedValue");
i([
  s({ type: String })
], l.prototype, "type");
i([
  s({ type: String })
], l.prototype, "boxStyle");
i([
  s({ type: String })
], l.prototype, "inputStyle");
i([
  s({ type: String })
], l.prototype, "labelSelectAll");
i([
  s({ type: String })
], l.prototype, "labelDeselectAll");
i([
  s(a)
], l.prototype, "SelectAll");
export {
  l as DropDownList
};
//# sourceMappingURL=dropdown-list.js.map
