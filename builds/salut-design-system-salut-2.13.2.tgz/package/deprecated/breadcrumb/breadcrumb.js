import { LitElement as p, unsafeCSS as n } from "lit";
import { property as l } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import a from "./breadcrumb.style.css.js";
import { template as f } from "./breadcrumb.template.js";
var c = Object.defineProperty, d = (s, t, r, o) => {
  for (var e = void 0, m = s.length - 1, i; m >= 0; m--)
    (i = s[m]) && (e = i(t, r, e) || e);
  return e && c(t, r, e), e;
};
class v extends p {
  constructor() {
    super(...arguments), this.items = [];
  }
  static get styles() {
    return [n(u), n(a)];
  }
  handleItemClick(t, r) {
    var o;
    t.preventDefault(), (o = t.currentTarget) == null || o.blur(), this.dispatchEvent(new CustomEvent("onItemClick", { detail: r.href, bubbles: !0, composed: !0 }));
  }
  render() {
    return f(this);
  }
}
d([
  l({ type: Array })
], v.prototype, "items");
export {
  v as Breadcrumb
};
//# sourceMappingURL=breadcrumb.js.map
