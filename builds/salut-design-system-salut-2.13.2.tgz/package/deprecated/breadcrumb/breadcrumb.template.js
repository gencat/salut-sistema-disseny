import { nothing as l } from "lit";
import { map as m } from "lit/directives/map.js";
import { when as o } from "lit/directives/when.js";
import { unsafeStatic as c, literal as f, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as n } from "../../api/custom-element-scope.js";
const i = f`dss-icon${c(n())}`, u = (r) => e`
    <div class="dss-breadcrumb" role="navigation" aria-label="Ruta de pàgina">
      ${m(
  r.items,
  (a, t) => e`
            <a
              class="dss-breadcrumb__item"
              href="${a.href || "#"}"
              @click="${(s) => r.handleItemClick(s, a)}"
              aria-current="${t === r.items.length - 1 ? "page" : "false"}"
              title="${a.label}"
            >
              ${a.label}
            </a>
            ${o(
    t < r.items.length - 1,
    () => e`<${i} icon="keyboard_arrow_right" size="sm"></${i}>`,
    () => l
  )}
        `
)}
    </div>
  `;
export {
  u as template
};
//# sourceMappingURL=breadcrumb.template.js.map
