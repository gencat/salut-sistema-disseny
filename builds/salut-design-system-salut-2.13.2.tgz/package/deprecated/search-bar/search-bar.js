import { LitElement as E, unsafeCSS as b } from "lit";
import { state as O, property as n } from "lit/decorators.js";
import { classMap as x } from "lit/directives/class-map.js";
import { unsafeHTML as C } from "lit/directives/unsafe-html.js";
import { unsafeStatic as U, literal as F, html as T } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as k, highlightText as V } from "../../api/marker/marker.js";
import A from "../../api/marker/marker.style.css.js";
import { normalizeText as m } from "../../utils/helpers.js";
import { booleanType as _ } from "../../utils/property-types.js";
import L from "./search-bar.style.css.js";
import { template as z } from "./search-bar.template.js";
var B = Object.defineProperty, R = Object.getOwnPropertyDescriptor, a = (w, t, e, s) => {
  for (var l = s > 1 ? void 0 : s ? R(t, e) : t, c = w.length - 1, u; c >= 0; c--)
    (u = w[c]) && (l = (s ? u(t, e, l) : u(l)) || l);
  return s && l && B(t, e, l), l;
};
const q = F`dss-icon${U($())}`, D = F`dss-chip${U($())}`;
class h extends E {
  constructor() {
    super(...arguments), this._filter = "", this.innerFocus = !1, this.advancedFilter = !1, this._multiple = !1, this._icon = "search", this._placeholder = "Escriu per cercar", this._inputSize = "lg", this._invalid = !1, this._helpText = "", this._isFocused = !1, this._showClearButton = !1, this._threshold = 3, this._searchTerms = [], this._catalog = [], this._filteredCatalog = [], this._showDropdown = !1, this._isCatalogLoading = !1, this._emptyDropdownText = "Sense resultats per", this._recentSearches = !1, this._recentSearchesText = "Últimes cerques", this._dropdownStyle = "", this._searchboxStyle = "", this._showAllChips = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && this.requestUpdate();
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return [b(A), b(L)];
  }
  get _input() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set multiple(t) {
    const e = this._multiple;
    this._multiple = t, this.requestUpdate("multiple", e);
  }
  get multiple() {
    return this._multiple;
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set inputSize(t) {
    const e = this._inputSize;
    t === "md" ? this._inputSize = t : this._inputSize = "lg", this.requestUpdate("inputSize", e);
  }
  get inputSize() {
    return this._inputSize;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set invalid(t) {
    const e = this._invalid;
    t ? this._invalid = t : this._invalid = this._inputValidity ? t : !0, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set threshold(t) {
    const e = this._threshold;
    this._threshold = t, this.requestUpdate("threshold", e);
  }
  get threshold() {
    return this._threshold;
  }
  set searchTerms(t) {
    const e = this._searchTerms;
    this._searchTerms = t, this.requestUpdate("searchTerms", e);
  }
  get searchTerms() {
    return this._searchTerms;
  }
  set catalog(t) {
    const e = this._catalog;
    this._catalog = t, this.requestUpdate("catalog", e);
  }
  get catalog() {
    return this._catalog;
  }
  set emptyDropdownText(t) {
    const e = this._emptyDropdownText;
    this._emptyDropdownText = t, this.requestUpdate("emptyDropdownText", e);
  }
  get emptyDropdownText() {
    return this._emptyDropdownText;
  }
  set recentSearchesText(t) {
    const e = this._recentSearchesText;
    this._recentSearchesText = t, this.requestUpdate("recentSearchesText", e);
  }
  get recentSearchesText() {
    return this._recentSearchesText;
  }
  set recentSearches(t) {
    const e = this._recentSearches;
    this._recentSearches = t, this.requestUpdate("recentSearches", e);
  }
  get recentSearches() {
    return this._recentSearches;
  }
  set isCatalogLoading(t) {
    const e = this._isCatalogLoading;
    this._isCatalogLoading = t, this.requestUpdate("isCatalogLoading", e);
  }
  get isCatalogLoading() {
    return this._isCatalogLoading;
  }
  set dropdownStyle(t) {
    const e = this._dropdownStyle;
    this._dropdownStyle = t, this.requestUpdate("dropdownStyle", e);
  }
  get dropdownStyle() {
    return this._dropdownStyle;
  }
  _getSearchStyle() {
    return `top: ${this.renderRoot.querySelectorAll(".dss-search-bar")[0].offsetHeight + 4}px; ${this._dropdownStyle}`;
  }
  get _inputValidity() {
    var t;
    return this._input && this._input.value !== "" ? (t = this._input) == null ? void 0 : t.checkValidity() : !0;
  }
  _handleClick() {
    this.requestUpdate();
  }
  _handleInput() {
    this._filter = this._input.value;
    let t = this._input.value;
    t.length >= this._threshold ? (this._showDropdown = !0, this._filteredCatalog = this._getFilterCatalog(t), this._multiple && t.endsWith(",") && (t = t.slice(0, -1), this._searchTerms.push(t), this._input.value = "", this._searchTerms.length && this._dispatchSearchChange()), this._searchboxStyle = this._getSearchStyle(), this.requestUpdate()) : this._hideDropdown(), this._dispatchOnInput(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._isFocused = !1, this._showClearButton = !1, this.requestUpdate();
  }
  _handleKeyDown(t) {
    (t == null ? void 0 : t.key) === "Enter" ? (this._showDropdown = !0, !this._multiple && this._input.value !== "" && (this._searchTerms = [], this._searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1), this._searchboxStyle = this._getSearchStyle()) : (t == null ? void 0 : t.key) === "Escape" && (this._showDropdown = !1), this.requestUpdate();
  }
  _focusInput() {
    var t;
    (t = this._input) == null || t.focus();
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus()), this._searchTerms = [], this._dispatchSearchChange(), this._hideDropdown(), this.requestUpdate();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedFilter(t) : this._applyDefaultFilter(t);
  }
  _applyDefaultFilter(t) {
    const e = m(t);
    return this._catalog.filter((s) => m(s.value).includes(e));
  }
  _applyAdvancedFilter(t) {
    if (!m(t.trim())) return this.catalog;
    const s = m(t).split(/\s+/).filter((l) => l.length >= this._threshold);
    return s.length === 0 ? this.catalog : this.catalog.filter((l) => {
      const c = m(l.value);
      return s.every((u) => c.includes(u));
    });
  }
  _generateSearchChips() {
    let t = 0;
    return this._searchTerms.map((s) => {
      var f, y, S, v, i;
      const l = (r) => {
        const o = r.detail.text;
        this._searchTerms = this._searchTerms.filter((p) => p !== o), this._dispatchSearchChange(), this.requestUpdate();
      };
      t += 1;
      const c = {
        disabled: ((f = this._input) == null ? void 0 : f.disabled) || ((y = this._input) == null ? void 0 : y.readOnly),
        "dss-chip--selected": !((S = this._input) != null && S.disabled) && !((v = this._input) != null && v.readOnly),
        "dss-chip--hide": t > 5
      };
      return T`
				<${D}
 					class="${x(c)}"
					size="sm" 
					label="${s}" 
					selected 
					disableSelect
					hasdelete 
					?disabled=${(i = this._input) == null ? void 0 : i.disabled}
					@onDelete="${l}">
				</${D}>
      `;
    });
  }
  _generateFilterCatalog() {
    let t = !0;
    return this._filteredCatalog.map((s) => {
      const l = (i) => {
        const r = i.target.getAttribute("value");
        r && (this._multiple ? this._searchTerms.includes(r) ? this._searchTerms = this._searchTerms.filter((p) => p !== r) : this._searchTerms.push(r) : (this._input.value = r, this._showDropdown = !1, this._searchTerms = [], this._searchTerms.push(r)), this.requestUpdate(), this._dispatchSearchChange());
      }, c = (i) => {
        i && i.focus();
      }, u = (i) => {
        let r = 0;
        const o = this.renderRoot.querySelectorAll(".dss-catalog-item"), p = o.length - 1;
        i === o[0] ? c(o[p]) : (o.forEach((g, d) => {
          g === i && (r = d);
        }), c(o[r - 1]));
      }, f = (i) => {
        let r = 0;
        const o = this.renderRoot.querySelectorAll(".dss-catalog-item"), p = o.length - 1;
        i === o[p] ? c(o[0]) : (o.forEach((g, d) => {
          g === i && (r = d);
        }), c(o[r + 1]));
      }, y = (i) => {
        const r = i.currentTarget, o = i;
        let p = !1;
        switch (o.key) {
          case "ArrowUp":
            u(r), p = !0;
            break;
          case "ArrowDown":
            f(r), p = !0;
            break;
          case "Enter": {
            const g = i.target, d = this.renderRoot.querySelector('.dss-catalog-item[tabindex="0"]');
            d == null || d.setAttribute("tabindex", "-1"), i.target.setAttribute("tabindex", "0"), g.click(), p = !0;
            break;
          }
        }
        p && (i.stopPropagation(), i.preventDefault());
      }, S = {
        "dss-catalog-item--selected": this._searchTerms.includes(s.value)
        // 'disabled': this._input?.disabled,
        // 'dss-chip--selected': !this._input?.disabled,
      }, v = T`
        <div
          class="dss-catalog-item ${x(S)}"
          value="${s.value}"
          tabindex="${t ? 0 : -1}"
          @click="${l}"
          @keydown=${y}
        >
          ${s.icon ? T`
								<${q}
									class="dss-catalog-item__icon"
									icon="${s.icon}"
									size="md"
									value="${s.value}"
								></${q}>
              ` : null}
          <div class="dss-catalog-item__text" value="${s.value}">
            ${this.advancedFilter ? C(k(s.value, this._filter, this._threshold)) : C(V(s.value, this._filter))}
					</div>
        </div>
      `;
      return t = !1, v;
    });
  }
  _dispatchSearchChange() {
    const t = {
      detail: this._searchTerms,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onSearchChange", t));
  }
  _dispatchOnInput() {
    if (!this._input || this._multiple) return;
    const t = {
      detail: this._input.value,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onInput", t));
  }
  _closeDropdown() {
    document.addEventListener("mousedown", (t) => {
      t.target !== this && t.target !== this._input && (this._showDropdown = !1, this.requestUpdate());
    }), document.addEventListener("focusout", (t) => {
      const e = t.relatedTarget;
      e !== null && e !== this && e !== this._input && (this._showDropdown = !1, this.requestUpdate());
    });
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  async firstUpdated() {
    var t, e;
    try {
      await this.updateComplete, this._input && (this.observer.observe(this._input, this.observerConfig), (t = this._input) != null && t.getAttribute("placeholder") || (e = this._input) == null || e.setAttribute("placeholder", this._placeholder), this._closeDropdown(), this._searchboxStyle = this._getSearchStyle(), this.requestUpdate());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return z(this);
  }
}
a([
  O()
], h.prototype, "_filter", 2);
a([
  n(_)
], h.prototype, "innerFocus", 2);
a([
  n(_)
], h.prototype, "multiple", 1);
a([
  n({ type: String })
], h.prototype, "icon", 1);
a([
  n({ type: String })
], h.prototype, "inputSize", 1);
a([
  n({ type: String })
], h.prototype, "helpText", 1);
a([
  n(_)
], h.prototype, "invalid", 1);
a([
  n({ type: Number })
], h.prototype, "threshold", 1);
a([
  n({ type: Array })
], h.prototype, "searchTerms", 1);
a([
  n({ type: Array })
], h.prototype, "catalog", 1);
a([
  n({ type: String })
], h.prototype, "emptyDropdownText", 1);
a([
  n({ type: String })
], h.prototype, "recentSearchesText", 1);
a([
  n(_)
], h.prototype, "recentSearches", 1);
a([
  n(_)
], h.prototype, "isCatalogLoading", 1);
a([
  n({ type: String })
], h.prototype, "dropdownStyle", 1);
a([
  n(_)
], h.prototype, "advancedFilter", 2);
export {
  h as SearchBar
};
//# sourceMappingURL=search-bar.js.map
