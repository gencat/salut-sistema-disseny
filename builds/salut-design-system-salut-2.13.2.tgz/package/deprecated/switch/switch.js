import { LitElement as p, css as b, html as a } from "lit";
import { property as i } from "lit/decorators.js";
import { classMap as w } from "lit/directives/class-map.js";
import { booleanType as n } from "../../utils/property-types.js";
var _ = Object.defineProperty, u = Object.getOwnPropertyDescriptor, c = (r, s, e, o) => {
  for (var t = o > 1 ? void 0 : o ? u(s, e) : s, l = r.length - 1, h; l >= 0; l--)
    (h = r[l]) && (t = (o ? h(s, e, t) : h(t)) || t);
  return o && t && _(s, e, t), t;
};
class d extends p {
  constructor() {
    super(...arguments), this.ariaLabel = "Switch", this._checked = !1, this._disabled = !1, this._label = null, this._size = "md";
  }
  static get styles() {
    return b`
      :host {
        display: flex;
        width: fit-content;
        height: fit-content;
        gap: 0.5rem;
        align-items: center;
      }

      .dss-switch input[type='checkbox'] {
        opacity: 0;
      }

      .dss-switch {
        position: relative;
        display: flex;
        transition: 0.3s all ease-in;
      }

      .dss-switch .dss-switch__slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #656565;
        border-radius: 100px;
        transition: 0.3s all ease-in;
      }

      .dss-switch .dss-switch__slider:before {
        position: absolute;
        background-color: white;
        border-radius: 100%;
        content: '';
        box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.05),
          0px 1px 3px 1px rgba(0, 0, 0, 0.1);
        transition: 0.3s all ease-in;
      }

      .dss-switch input[type='checkbox']:hover:enabled + .dss-switch__slider {
        background-color: #535353;
      }

      .dss-switch input[type='checkbox']:enabled + .dss-switch__slider:active {
        background-color: #828282;
        transition: none;
      }

      .dss-switch input[type='checkbox']:checked + .dss-switch__slider {
        background-color: #0073e6;
      }

      .dss-switch
        input[type='checkbox']:checked:hover:enabled
        + .dss-switch__slider {
        background-color: #0064c7;
      }

      .dss-switch
        input[type='checkbox']:checked:enabled
        + .dss-switch__slider:active {
        background-color: #308deb;
        transition: none;
      }

      .dss-switch
        input[type='checkbox']:checked:enabled
        + .dss-switch__slider:active:before {
        color: #308deb;
        transition: none;
      }

      .dss-switch
        input[type='checkbox']:enabled
        + .dss-switch__slider:active:before {
        color: #828282;
        transition: none;
      }

      .dss-switch input[type='checkbox']:disabled + .dss-switch__slider {
        cursor: not-allowed;
      }

      .dss-switch input[type='checkbox']:disabled + .dss-switch__slider:before {
        color: #828282 !important;
      }

      .dss-switch
        input[type='checkbox']:checked:disabled
        + .dss-switch__slider {
        background-color: #308deb;
      }

      .dss-switch
        input[type='checkbox']:checked:disabled
        + .dss-switch__slider:before {
        color: #308deb !important;
      }

      .dss-switch input[type='checkbox']:focus {
        outline: none;
        transition: none;
      }

      .dss-switch
        input[type='checkbox']:focus-visible:enabled
        + .dss-switch__slider {
        outline: 4px solid #8ec7e5;
        transition: none;
      }

      .dss-switch.dss-switch--lg {
        width: 52px;
        height: 32px;
      }

      .dss-switch.dss-switch--lg .dss-switch__slider:before {
        font-family: var(--icon-font);
        content: 'close';
        color: var(--color-primary-500);
        font-size: 16px;
        height: 24px;
        width: 24px;
        left: 4px;
        bottom: 4px;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .dss-switch.dss-switch--lg
        input[type='checkbox']:checked
        + .dss-switch__slider:before {
        -webkit-transform: translateX(20px);
        -ms-transform: translateX(20px);
        transform: translateX(20px);
        content: 'done';
        color: var(--color-primary-500);
      }

      .dss-switch.dss-switch--md {
        width: 39px;
        height: 24px;
      }

      .dss-switch.dss-switch--md .dss-switch__slider:before {
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
      }

      .dss-switch.dss-switch--md
        input[type='checkbox']:checked
        + .dss-switch__slider:before {
        -webkit-transform: translateX(15px);
        -ms-transform: translateX(15px);
        transform: translateX(15px);
      }

      .dss-switch.dss-switch--sm {
        width: 26px;
        height: 16px;
      }

      .dss-switch.dss-switch--sm .dss-switch__slider:before {
        height: 12px;
        width: 12px;
        left: 2px;
        bottom: 2px;
      }

      .dss-switch.dss-switch--sm
        input[type='checkbox']:checked
        + .dss-switch__slider:before {
        -webkit-transform: translateX(10px);
        -ms-transform: translateX(10px);
        transform: translateX(10px);
      }

      .dss-switch__label {
        font-family: var(--font-family);
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 24px;
        color: #1d1d1d;
      }

      .dss-switch.dss-switch--lg + .dss-switch__label {
        font-weight: 600;
        font-size: 16px;
      }

      .dss-switch--disabled .dss-switch__slider {
        background-color: var(--color-neutral-200);
      }

      .dss-switch
        input[type='checkbox']:checked:disabled
        + .dss-switch__slider {
        background-color: var(--color-neutral-200);
      }

      .dss-switch
        input[type='checkbox']:checked:disabled
        + .dss-switch__slider::before {
        background-color: var(--color-neutral-400);
        color: var(--color-neutral-900) !important;
      }

      .dss-switch.dss-switch--lg
        input[type='checkbox']:checked:disabled
        + .dss-switch__slider::before {
        background-color: var(--color-neutral-100);
      }

      .dss-switch
        input[type='checkbox']:not(:checked):disabled
        + .dss-switch__slider::before {
        background-color: var(--color-neutral-400);
        color: var(--color-neutral-100) !important;
      }
    `;
  }
  set checked(s) {
    const e = this._checked;
    this._checked = s, this.requestUpdate("checked", e);
  }
  get checked() {
    return this._checked;
  }
  set disabled(s) {
    const e = this._disabled;
    this._disabled = s, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set label(s) {
    const e = this._label;
    this._label = s, this.requestUpdate("label", e);
  }
  get label() {
    return this._label || "";
  }
  set size(s) {
    const e = this._size;
    this._size = s, this.requestUpdate("size", e);
  }
  get size() {
    return this._size;
  }
  handleClick() {
    this._checked = !this._checked, this.dispatchEvent(
      new CustomEvent("onChangeValue", {
        detail: this._checked,
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    const s = {
      "dss-switch--sm": this._size === "sm",
      "dss-switch--md": this._size === "md",
      "dss-switch--lg": this._size === "lg",
      "dss-switch--disabled": this._disabled
    };
    return a`
      <label class="dss-switch ${w(s)}">
        <input
          type="checkbox"
          ?checked="${this._checked}"
          ?disabled="${this._disabled}"
          @click="${this.handleClick}"
          aria-label="${this._label ? this._label : this.ariaLabel}"
        />
        <div class="dss-switch__slider"></div>
      </label>
      ${this._label ? a`<span class="dss-switch__label">${this._label}</span>` : null}
    `;
  }
}
c([
  i(n)
], d.prototype, "checked", 1);
c([
  i(n)
], d.prototype, "disabled", 1);
c([
  i({ type: String })
], d.prototype, "label", 1);
c([
  i({ type: String })
], d.prototype, "size", 1);
c([
  i({ type: String })
], d.prototype, "ariaLabel", 2);
export {
  d as Switch
};
//# sourceMappingURL=switch.js.map
