import { LitElement as f, css as D, html as g } from "lit";
import { property as o } from "lit/decorators.js";
import { classMap as b } from "lit/directives/class-map.js";
import { ifDefined as $ } from "lit/directives/if-defined.js";
import { booleanType as u } from "../../utils/property-types.js";
var q = Object.defineProperty, C = Object.getOwnPropertyDescriptor, r = (_, t, e, s) => {
  for (var i = C(t, e), a = _.length - 1, l; a >= 0; a--)
    (l = _[a]) && (i = l(t, e, i) || i);
  return i && q(t, e, i), i;
};
const h = class h extends f {
  constructor() {
    super(...arguments), this._value = "", this._label = "", this._placeHolder = "", this._previousDate = "", this._minDate = "", this._maxDate = "", this._showCalendar = !1, this._showTime = !1, this._invalid = !1, this._showButtons = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._leftLabel = "Cancel·lar", this._rightLabel = "Acceptar", this._isFocused = !1, this._internals = this.attachInternals();
  }
  static get styles() {
    return D`
      :host {
        display: flex;
        width: fit-content;
        height: fit-content;
        position: relative;
      }

      label {
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 24px;
        cursor: text;
        position: absolute;
      }

      input {
        outline: none;
        border: 0;
        font-size: 14px;
        line-height: 24px;
        font-style: normal;
        color: #1d1d1d;
        width: 100%;
        text-overflow: ellipsis;
      }

      input::placeholder {
        color: #9f9f9f;
      }

      .dss-input {
        display: flex;
        flex-direction: column;
        color: #656565;
        position: relative;
        width: 100%;
      }

      .dss-input--disabled {
        opacity: 0.6;
      }

      .dss-input__content {
        display: flex;
        align-items: center;
        flex: 1;
      }

      .dss-input--disabled .dss-input__group,
      .dss-input--disabled input {
        background-color: #f5f5f5;
        cursor: not-allowed;
      }

      .dss-input--disabled label,
      .dss-input--disabled input {
        cursor: not-allowed;
      }

      .dss-input__group {
        position: relative;
        background: #ffffff;
        box-shadow: inset 0 0 0 1px #d8d8d8;
        border-radius: 8px;
        padding: 12px;
        display: flex;
        gap: 8px;
      }

      :host([small]) .dss-input__group {
        padding: 8px 12px;
      }

      .dss-input__group--required label::before {
        content: '*';
      }

      .dss-input--invalid .dss-input__group:focus-visible input {
        background-color: #ffffff;
      }

      .dss-input__group--focused {
        padding: 4px 12px;
      }

      :host([small]) .dss-input__group--focused {
        padding: 1px 12px;
      }

      .dss-input__group--focused .dss-input__content label {
        font-size: 12px;
        line-height: 16px;
        transition: 0.3s;
        top: 4px;
      }

      :host([small]) .dss-input__group--focused .dss-input__content label {
        top: 2px;
      }

      .dss-input__group--focused .dss-input__content input,
      .dss-input__group--focused .dss-input__content input {
        margin-top: 16px !important;
      }

      :host([small]) .dss-input__group--focused .dss-input__content input {
        margin-top: 14px !important;
      }

      .dss-input--invalid .dss-input__group {
        box-shadow: inset 0 0 0 1px #b60000;
      }

      .dss-input--invalid .dss-input__group,
      .dss-input--invalid .dss-icon-button,
      .dss-input--invalid .dss-input__group input,
      .dss-input--invalid .dss-input__group .dss-icon-button:hover span {
        background-color: #fff6f6;
        color: #b60000;
      }

      .dss-input--invalid .dss-input__group input {
        color: #1d1d1d;
      }

      .dss-input__group:focus-visible,
      .dss-input__group--active {
        box-shadow: 0 0 0 4px #8ec7e5;
        background-color: #ffffff;
        outline: none;
      }

      .dss-input--invalid .dss-input__group--active {
        box-shadow: 0 0 0 4px #8ec7e5;
      }

      .dss-input--invalid input::placeholder {
        color: #d36262;
      }

      .dss-input__icon {
        font-family: var(--icon-font);
        display: flex;
        align-items: center;
        font-size: 24px;
      }

      dss-calendar {
        position: absolute;
        top: 56px;
        z-index: 900;
      }

      :host([small]) dss-Calendar {
        top: 48px;
      }
    `;
  }
  get _input() {
    var t;
    return (t = this.shadowRoot) == null ? void 0 : t.querySelector("input");
  }
  set value(t) {
    const e = this._value;
    this._value = t, this._input && (this._input.value = t), this.requestUpdate("value", e);
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set placeHolder(t) {
    const e = this._placeHolder;
    this._placeHolder = t, this.requestUpdate("placeHolder", e);
  }
  get placeHolder() {
    return this._placeHolder;
  }
  set required(t) {
    const e = this._required;
    this._required = t, this.requestUpdate("required", e);
  }
  get required() {
    return this._required;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set readonly(t) {
    const e = this._readonly;
    this._readonly = t, this.requestUpdate("readonly", e);
  }
  get readonly() {
    return this._readonly;
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = t, this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate;
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = t, this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  // Form controls usually expose a "value" property
  get value() {
    let t = "";
    return this._input ? t = this._input.value : t = this._value, t;
  }
  // set value already implemented
  // The following properties and methods aren't strictly required,
  // but browser-level form controls provide them. Providing them helps
  // ensure consistency with browser-provided controls.
  get form() {
    return this._internals.form;
  }
  get name() {
    return this.getAttribute("name");
  }
  get type() {
    return this.localName;
  }
  get validity() {
    return this._internals.validity;
  }
  get validationMessage() {
    return this._internals.validationMessage;
  }
  get willValidate() {
    return this._internals.willValidate;
  }
  checkValidity() {
    return this._internals.checkValidity();
  }
  reportValidity() {
    return this._internals.reportValidity();
  }
  formResetCallback() {
    this._input.value = "", this.requestUpdate();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._value && (this._input.value = this._value), this._closeDropdown(), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _closeDropdown() {
    document.addEventListener("mousedown", (t) => {
      t.target !== this && (this._showCalendar = !1, this._isFocused = !1, this.requestUpdate());
    }), document.addEventListener("focusout", (t) => {
      t.target === this && (this._showCalendar = !1, this._isFocused = !1, this.requestUpdate());
    });
  }
  _handleKeyUp(t) {
    var e, s, i, a, l;
    if ((t == null ? void 0 : t.key) === "Tab" ? (this._isFocused = !0, this._handleBlur()) : (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this._showCalendar = !0, this._handleBlur()) : (t == null ? void 0 : t.key) === "Escape" && (this._isFocused = !0, this._showCalendar = !1, this._handleBlur()), t.key === "Enter" && ((e = this._input.value) == null ? void 0 : e.length) > 7) {
      const p = (s = this._input.value) == null ? void 0 : s.replace(/(\d+[/])(\d+[/])/, "$2$1"), d = new Date(p), m = (i = d.getDate()) == null ? void 0 : i.toString().padStart(2, "0"), v = (d.getMonth() + 1).toString().padStart(2, "0"), y = d.getFullYear(), w = (a = d.getHours()) == null ? void 0 : a.toString().padStart(2, "0"), x = (l = d.getMinutes()) == null ? void 0 : l.toString().padStart(2, "0");
      let c = `${m}/${v}/${y}`;
      this._showTime && (c += ` ${w}:${x}`), this._input.value = c, this._dispatchValueChange(), this.requestUpdate();
    }
  }
  _handleInput(t) {
    var s;
    const e = (s = t.target.value) == null ? void 0 : s.replace(/\D/g, "");
    this._input.value = this._formatDate(e), this._dispatchValueChange(), this.requestUpdate();
  }
  _formatDate(t) {
    let e = t.substring(0, 2), s = t.substring(2, 4);
    const i = t.substring(4, 8);
    let a = t.substring(8, 10), l = t.substring(10, 12);
    Number(e) > 3 && (e = e == null ? void 0 : e.padStart(2, "0")), Number(s) > 1 && (s = s == null ? void 0 : s.padStart(2, "0")), Number(e) > 31 && (e = "31"), Number(s) > 12 && (s = "12"), s === "02" && Number(e) > 28 && (i == null ? void 0 : i.length) === 4 && (e = new Date(Number(i), 1, 29).getMonth() === 1 ? "29" : "28");
    let p = `${e}${s ? `/${s}` : ""}${i ? `/${i}` : ""}`;
    return this._showTime && (Number(a) > 2 && (a = a == null ? void 0 : a.padStart(2, "0")), Number(a) > 23 && (a = "23"), Number(l) > 5 && (l = l == null ? void 0 : l.padStart(2, "0")), p = `${p}${a ? ` ${a}` : ""}${l ? `:${l}` : ""}`), p;
  }
  _handleFocus() {
    this._readonly || (this._placeHolder = this._showTime ? "DD/MM/YYYY HH:MM" : "DD/MM/YYYY", this.requestUpdate());
  }
  _handleBlur() {
    this.requestUpdate();
  }
  _handelLabelClick() {
    var t;
    (t = this._input) == null || t.focus(), this.requestUpdate();
  }
  _onDateChange(t) {
    const e = t.detail;
    this._input.value = e, this._showCalendar = !1, this._dispatchValueChange(), this.requestUpdate();
  }
  _onCancel() {
    this._showCalendar = !1, this._input.value = this._previousDate || "", this.placeHolder = "", this.requestUpdate();
  }
  _onclick() {
    var t, e;
    this._disabled || this._readonly || (this._showCalendar = !this._showCalendar, this._previousDate = this._input.value, this._showCalendar ? (t = this._input) == null || t.focus() : ((e = this._input) == null || e.blur(), this._onCancel()), this.requestUpdate());
  }
  _dispatchValueChange() {
    const t = {
      detail: this._input.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", t));
  }
  render() {
    var s;
    const t = {
      "dss-input--invalid": this._invalid,
      "dss-input--disabled": this._disabled
    }, e = {
      "dss-input__group--focused": ((s = this._input) == null ? void 0 : s.value) || this._placeHolder || this._showCalendar || this._isFocused,
      "dss-input__group--required": this._required,
      "dss-input__group--active": this._showCalendar || this._isFocused
    };
    return g`
      <div
        class="dss-input ${b(t)}"
        @click=${this._onclick}
      >
        <div class="dss-input__group ${b(e)}">
          <span class="dss-input__icon">calendar_today</span>
          <div class="dss-input__content">
            <label @mouseup=${this._handelLabelClick}>${this._label}</label>
            <input
              ?disabled=${this._disabled}
              ?required=${this._required}
              ?readonly=${this._readonly}
              @input=${this._handleInput}
              @focus=${this._handleFocus}
              @blur=${this._handleBlur}
              @keyup=${this._handleKeyUp}
              placeholder=${$(this._placeHolder)}
              type="text"
            />
          </div>
        </div>
      </div>
      ${this._showCalendar ? g`
            <dss-calendar
              .selectedDate=${this._input.value}
              .showTime=${this._showTime}
              .showButtons=${this._showButtons}
              .leftLabel=${this._leftLabel}
              .rightLabel=${this._rightLabel}
              .minDate=${this._minDate}
              .maxDate=${this._maxDate}
              @onDateChange=${this._onDateChange}
              @onCancel=${this._onCancel}
            ></dss-calendar>
          ` : null}
    `;
  }
};
h.formAssociated = !0, h.shadowRootOptions = {
  ...f.shadowRootOptions,
  delegatesFocus: !0
};
let n = h;
r([
  o({ type: String, attribute: !0 })
], n.prototype, "value");
r([
  o({ type: String })
], n.prototype, "label");
r([
  o({ type: String })
], n.prototype, "placeHolder");
r([
  o(u)
], n.prototype, "required");
r([
  o(u)
], n.prototype, "disabled");
r([
  o(u)
], n.prototype, "readonly");
r([
  o(u)
], n.prototype, "showTime");
r([
  o(u)
], n.prototype, "showButtons");
r([
  o({ type: String })
], n.prototype, "leftLabel");
r([
  o({ type: String })
], n.prototype, "rightLabel");
r([
  o({ type: String })
], n.prototype, "minDate");
r([
  o({ type: String })
], n.prototype, "maxDate");
r([
  o(u)
], n.prototype, "invalid");
export {
  n as DatePicker
};
//# sourceMappingURL=date-picker.js.map
