const r = "*{scrollbar-width:thin;scrollbar-color:var(--color-neutral-100) var(--color-white)}*::-webkit-scrollbar{width:6px;height:6px}*::-webkit-scrollbar-track{background:var(--color-white);border-radius:128px}*::-webkit-scrollbar-thumb{background-color:var(--color-neutral-100);border-radius:128px}";
export {
  r as default
};
//# sourceMappingURL=scrollbar.style.css.js.map
