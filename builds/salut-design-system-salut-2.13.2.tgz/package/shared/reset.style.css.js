const e = "*,*:before,*:after{box-sizing:border-box}*{margin:0;padding:0;font-family:var(--font-family)}ul,ol{list-style:none}";
export {
  e as default
};
//# sourceMappingURL=reset.style.css.js.map
