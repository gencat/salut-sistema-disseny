const s = ".dss-elevation--sm{box-shadow:var(--dss-elevation-sm)}.dss-elevation--md{box-shadow:var(--dss-elevation-md)}.dss-elevation--lg{box-shadow:var(--dss-elevation-lg)}";
export {
  s as default
};
//# sourceMappingURL=elevation.style.css.js.map
