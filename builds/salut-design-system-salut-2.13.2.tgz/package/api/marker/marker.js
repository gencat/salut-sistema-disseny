import { normalizeText as o } from "../../utils/helpers.js";
function a(l, t, f = 1) {
  if (!t) return l;
  const h = o(l), s = o(t);
  if (!s || s.length < f) return l;
  let i = "", e = 0, n = h.indexOf(s);
  for (; n !== -1; )
    i += l.slice(e, n), i += `<span class="dss-mark">${l.slice(n, n + t.length)}</span>`, e = n + t.length, n = h.indexOf(s, e);
  return i += l.slice(e), i;
}
function u(l, t, f = 1) {
  if (!t) return l;
  const h = o(l), s = t.split(/\s+/).map((n) => o(n)).filter((n) => n.length >= f);
  if (s.length === 0) return l;
  let i = "", e = 0;
  for (; e < l.length; ) {
    let n = null, c = 0;
    for (const r of s)
      r.length !== 0 && h.startsWith(r, e) && r.length > c && (n = l.substr(e, r.length), c = r.length);
    n ? (i += `<span class="dss-mark">${n}</span>`, e += c) : (i += l[e], e++);
  }
  return i;
}
export {
  a as highlightText,
  u as highlightTextMultiple
};
//# sourceMappingURL=marker.js.map
