const o = ".dss-mark{background-color:var(--color-yellow-200);color:var(--color-neutral-500)}";
export {
  o as default
};
//# sourceMappingURL=marker.style.css.js.map
