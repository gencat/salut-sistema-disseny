import { getCustomElementSuffix as f } from "./custom-element-scope.js";
function s(e, t) {
  const m = f(), o = `${e}${m}`;
  customElements.define(o, t);
}
export {
  s as registerCustomElement
};
//# sourceMappingURL=custom-element-register.js.map
