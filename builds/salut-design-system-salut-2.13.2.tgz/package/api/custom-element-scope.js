let t = "";
function u(e) {
  t = `-${e}`;
}
function f() {
  return t;
}
export {
  f as getCustomElementSuffix,
  u as setCustomElementSuffix
};
//# sourceMappingURL=custom-element-scope.js.map
