import { LitElement as y, unsafeCSS as f } from "lit";
import { property as r } from "lit/decorators.js";
import l from "../../shared/reset.style.css.js";
import { booleanType as m } from "../../utils/property-types.js";
import g from "./typography.style.css.js";
import { template as h } from "./typography.template.js";
var d = Object.defineProperty, e = (i, n, s, u) => {
  for (var t = void 0, p = i.length - 1, a; p >= 0; p--)
    (a = i[p]) && (t = a(n, s, t) || t);
  return t && d(n, s, t), t;
};
class o extends y {
  constructor() {
    super(...arguments), this.tag = "div", this.variant = "body-2", this.fontWeight = "inherit", this.fontColor = void 0, this.underline = !1;
  }
  static get styles() {
    return [f(l), f(g)];
  }
  render() {
    return h(this);
  }
}
e([
  r({ type: String })
], o.prototype, "tag");
e([
  r({ type: String })
], o.prototype, "variant");
e([
  r({ type: String })
], o.prototype, "fontWeight");
e([
  r({ type: String })
], o.prototype, "fontColor");
e([
  r(m)
], o.prototype, "underline");
export {
  o as Typography
};
//# sourceMappingURL=typography.js.map
