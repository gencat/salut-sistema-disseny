import { classMap as s } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as i, html as o } from "lit/static-html.js";
const e = (a) => {
  const t = i`${l(a.tag)}`, r = {
    "dss-typography": !0,
    [`${a.variant}`]: !!a.variant,
    [`dss-typography--${a.fontWeight}`]: a.variant.includes("body") && a.fontWeight !== "inherit",
    [`dss-typography--color-${a.fontColor}`]: !!a.fontColor,
    "dss-typography--underline": a.variant.includes("body") && a.underline
  };
  return o`
    <${t} class="${s(r)}">
      <slot></slot>
    </${t}>  
  `;
};
export {
  e as template
};
//# sourceMappingURL=typography.template.js.map
