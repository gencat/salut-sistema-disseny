import { LitElement as m, unsafeCSS as a } from "lit";
import { property as r, state as d } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import u from "./icon.style.css.js";
import { template as c } from "./icon.template.js";
var h = Object.defineProperty, e = (s, p, n, S) => {
  for (var t = void 0, i = s.length - 1, f; i >= 0; i--)
    (f = s[i]) && (t = f(p, n, t) || t);
  return t && h(p, n, t), t;
};
class o extends m {
  constructor() {
    super(...arguments), this.size = "md", this.icon = "", this.fill = !1, this.spin = !1, this.fontLoaded = !1;
  }
  static get styles() {
    return [a(y), a(u)];
  }
  firstUpdated() {
    document.fonts.load('1em "Dss Material Symbols"').then(() => {
      this.fontLoaded = !0;
    });
  }
  render() {
    return c(this);
  }
}
e([
  r({ type: String })
], o.prototype, "size");
e([
  r({ type: String })
], o.prototype, "icon");
e([
  r(l)
], o.prototype, "fill");
e([
  r(l)
], o.prototype, "spin");
e([
  d()
], o.prototype, "fontLoaded");
export {
  o as Icon
};
//# sourceMappingURL=icon.js.map
