const s = ".dss-form-select-options{opacity:0;visibility:hidden;z-index:999}:host(.animation-enabled) .dss-form-select-options{transition:opacity var(--animation-delay) ease-out,visibility var(--animation-delay) ease-out}.dss-form-select-options--visible{opacity:1;visibility:visible}.dss-form-select-options--open-with-search{display:block;margin-top:var(--dss-spacing-xxs)}.dss-form-select-options--md{top:44px}.dss-input-group:has(dss-chip:focus-within){outline:0;border-color:var(--color-neutral-100)}.dss-input-group.dss-input-group--read-only:has(dss-chip:focus-within){outline:0;border-top-color:transparent;border-left-color:transparent;border-right-color:transparent;border-radius:0}";
export {
  s as default
};
//# sourceMappingURL=form-select.style.css.js.map
