import { nothing as l } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as i, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as a } from "../../api/custom-element-scope.js";
const x = i`dss-icon${d(a())}`, u = i`dss-icon-button${d(a())}`, D = i`dss-tooltip${d(a())}`, S = i`dss-form-select-options${d(a())}`, T = i`dss-chip${d(a())}`, C = (s) => {
  var $, t, h, b, w, f, g, _, v, p;
  return e`
  <input 
    type="hidden" 
    class="dss-hidden-value" 
    .name=${s.name} 
    .value=${s.value} 
    @change=${s._onChange} 
  />

  <div class="${r({
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s.required,
    "dss-input-wrapper--disabled": s.disabled,
    [`dss-input-wrapper--${s.size}`]: !!s.size,
    "dss-input-wrapper--no-label": s.hideLabel
  })}">

    ${s.size === "sm" && !s.hideLabel ? e`
      <div class="dss-wrapper-label">
        <label class="dss-label" for="${s._getEffectiveId()}">${s.label}</label>
      </div>
      ` : l}

    <div class="${r({
    "dss-input-group": !0,
    [`dss-input-group--${s.size}`]: !!s.size,
    "dss-input-group--invalid": s.invalid && !s.showDropdown,
    // 'dss-input-group--invalid': component.invalid || !component._inputValidity,
    "dss-input-group--required": s.required,
    "dss-input-group--disabled": s.disabled,
    "dss-input-group--focused": s.value || (($ = s._input) == null ? void 0 : $.value) || s.placeholder || s._isFocused,
    "dss-input-group--read-only": s.readonly,
    "dss-input-group--no-label": s.hideLabel,
    "dss-input-group--numeric": s.type === "number",
    "dss-input-group--read-only-empty": ((t = s._input) == null ? void 0 : t.readOnly) && ((h = s._input) == null ? void 0 : h.placeholder) === "" && !((b = s._input) != null && b.value)
    // component.readOnly && component.placeholder === '' && !component._input?.value,
  })}">

      ${s.icon ? e`
        <${x} icon="${s.icon}" class="dss-input-icon"></${x}>
        ` : l}

      <div class="dss-input-field">
      
        ${s.size !== "sm" && !s.hideLabel ? e`
          <label class="dss-label" for="${s._getEffectiveId()}">${s.label}</label>
          ` : l}

        ${s.inputPrefix ? e`
           <span class="dss-input-inputPrefix">${s.inputPrefix}</span>
          ` : l}

        <input
          class="dss-input"
          id="${s._getEffectiveId()}"
          .type="text"
          .name="${s.name ?? l}"
          .placeholder=${s._placeholder}
          ?disabled=${s.disabled}
          ?readonly=${s.readonly}
          ?required=${s.required}
          ?autofocus=${s.autofocus}
          spellcheck=${s.spellcheck ? "true" : "false"}
          autocorrect=${s.autocorrect ? "on" : "off"}
          autocomplete=${s.autocomplete}
          autocapitalize=${s.autocapitalize}
          min=${s.min ?? l}
          max=${s.max ?? l}
          step=${s.step ?? l}
          minlength=${s.minLength ?? l}
          maxlength=${s.maxLength ?? l}
          pattern=${s.pattern ?? l}
          inputmode=${s.inputmode ?? l}
          aria-label="${s.hideLabel ? s.label : l}"
          @input=${s._handleInput}
          @focusin=${s._handleFocusIn}
          @focusout=${s._handleFocusOut}
          @keydown=${s._handleKeyDown}
          @click=${s._handleClick}
        />

        ${!s.showDropdown && s._isTruncated && s.selectedValue && ((w = s.selectedValue) == null ? void 0 : w.length) === 1 ? e`
            <${D}>${(f = s._input) == null ? void 0 : f.value}</${D}>
          ` : l}

      </div>

      ${s.multiple && s._isTruncated && s.selectedValue && ((g = s.selectedValue) == null ? void 0 : g.length) > 1 ? e`
          <${T}
            label="${s.selectedValue.length}"
            size="xs"
            ?selected=${s.showDropdown}
            @onToggle=${s._toggleDropdown}>
          </${T}>
        ` : l}

      ${!s.openWithSearch && !s.readonly ? e`
          <${u}
            class="dss-icon-button dss-input-dropdown__toggle"
            size="md"
            icon="${s.showDropdown ? "keyboard_arrow_up" : "keyboard_arrow_down"}"
            label="${s.showDropdown ? "Tancar dropdown" : "Obrir dropdown"}"
            hideTooltip
            ariaExpanded="${s.showDropdown}"
            variant="primary"
            ?disabled=${s.disabled}
            disableTabindex
            @onClick=${s._toggleDropdown}
          ></${u}>
        ` : s.openWithSearch ? e`
          <${u}
            class="dss-icon-button dss-input-dropdown__toggle"
            size="md"
            label="Esborra la selecció"
            hideTooltip
            icon="close"
            variant="primary"
            ?disabled=${s.disabled || s.readonly}
            disableTabindex
            @onClick=${s._cleanInput}
          ></${u}>
        ` : l}
    </div>

    <${S}
      ariaLabel="Llista d'elements"
      id="dss-form-select-options"
      class="${r({
    "dss-form-select-options": !s.openWithSearch,
    "dss-form-select-options--visible": s.showDropdown,
    "dss-form-select-options--open-with-search": s.openWithSearch,
    "dss-form-select-options--disabled": s.disabled,
    "dss-form-select-options-dropdown": !0,
    "dss-form-select-options--md": !s.openWithSearch && s.size === "md"
  })}"
      .isOpen=${s.showDropdown}
      .multiple=${s.multiple}
      .tick=${s.tick}
      .deselectable=${s.deselectable}
      .disabled=${s.disabled}
      .elements=${s._filteredElements}
      .filter=${(_ = s._input) == null ? void 0 : _.value}
      .filterThreshold=${s.filterThreshold}
      .searchThreshold=${s.searchThreshold}
      .value=${s.selectedValue}
      .type=${s.type}
      .labelSelectAll=${s.labelSelectAll}
      .labelDeselectAll=${s.labelDeselectAll}
      .selectAll=${s.selectAll}
      isDisplayed=${s.showDropdown}
      selectedCounter=${s._selectElements}
      boxStyle=${s.dropdownStyle}
      boxShadow
      @option-changed="${s._handleSelectorChange}"
      @keydown="${(y) => {
    y.key === "Escape" && s._handleBlurSelector(void 0, y);
  }}"
      @focusout=${s._handleFocusOut}
      ?readonly=${s.readonly}
      .advancedFilter=${s.advancedFilter}
    >
    </${S}>

    ${s.helpText && !s.openWithSearch ? e`
      <div class="${r({
    "dss-input-help": !0,
    "dss-input-help--invalid": s.invalid && !s.showDropdown,
    "dss-input-help--disabled": s.disabled
  })}">
        <span>${s.helpText}</span>
        ${s.maxLength ? e`
          <span>
            ${((p = (v = s._input) == null ? void 0 : v.value) == null ? void 0 : p.length) ?? 0}/${s.maxLength}
          </span>` : l}
      </div>
      ` : l}
  </div>  
`;
};
export {
  C as template
};
//# sourceMappingURL=form-select.template.js.map
