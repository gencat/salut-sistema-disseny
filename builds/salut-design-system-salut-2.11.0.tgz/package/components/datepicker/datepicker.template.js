import { nothing as r } from "lit";
import { classMap as a } from "lit/directives/class-map.js";
import { ifDefined as n } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as d, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const p = d`dss-calendar${l(e())}`, b = d`dss-icon${l(e())}`, h = d`dss-icon-button${l(e())}`, v = d`dss-tooltip${l(e())}`, z = (s) => {
  var u, t, $, _;
  const f = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s._required,
    "dss-input-wrapper--disabled": s._disabled,
    [`dss-input-wrapper--${s.inputSize}`]: !!s.inputSize,
    "dss-input-wrapper--no-label": !s._labelSlot
  }, C = {
    "dss-input-group": !0,
    [`dss-input-group--${s.inputSize}`]: !!s.inputSize,
    "dss-input-group--invalid": s._invalid || !s._inputValidity,
    "dss-input-group--required": s._required,
    "dss-input-group--disabled": s._disabled,
    "dss-input-group--focused": ((u = s._input) == null ? void 0 : u.value) || s._placeholder || s._isFocused,
    "dss-input-group--read-only": s._readonly,
    "dss-input-group--no-label": !s._labelSlot
  }, g = {
    "dss-input-help": !0,
    "dss-input-help--invalid": s._invalid,
    "dss-input-help--disabled": s._disabled
  }, w = {
    "dss-calendar": !0,
    "dss-calendar--visible": s._showCalendar && !s._readonly,
    "dss-calendar--disabled": s._disabled,
    "dss-calendar--md": s.inputSize !== "lg"
  };
  return i`
  
      <div class="${a(f)}">
  
        ${s.inputSize === "sm" ? i`
          <div class="dss-wrapper-label">
            <slot name="label" @click=${s._focusInput}></slot>
          </div>
          ` : r}
  
        <div 
          class="dss-input-dropdown-wrapper"
          role="combobox"
          aria-controls="datepicker-calendar"
          aria-expanded=${n(s._showCalendar)}>
          <div class="${a(C)}">
            ${s.icon && s.icon !== "" ? i`
              <${b} icon="${s.icon}" class="dss-input-icon"></${b}>
              ` : r}
            <div class="dss-input-field">
              ${s.inputSize !== "sm" ? i`
                <slot name="label" @click=${s._focusInput}></slot>
                ` : r}
              <slot name="input"
                @click=${s._handleClick}
                @input=${s._handleInput}
                @focusin=${s._handleFocus}
                @focusout=${s._handleBlur}
                @keydown=${s._handleKeyUp}
              ></slot>
              ${!s._showCalendar && s._isTruncated ? i`
                  <${v}>${(t = s._input) == null ? void 0 : t.value}</${v}>
                ` : null}
            </div>
            
            <${h}
              size="md"
              icon="close"
              @onClick=${s._clearDate}
              ?hidden=${!(($ = s._input) != null && $.value) || s._readonly || s._disabled}
            ></${h}>

          </div>
  
          <${p}
            role="listbox"
            aria-label="Datepicker Calendar"
            id="datepicker-calendar"
            class="${a(w)}"
            .selectedDate=${(_ = s._input) == null ? void 0 : _.value}
            .showTime=${s._showTime}
            .showButtons=${s._showButtons}
            .leftLabel=${s._leftLabel}
            .rightLabel=${s._rightLabel}
            .minDate=${s._minDate}
            .maxDate=${s._maxDate}
            timepickerLabel=${s._timepickerLabel}
            .timepicker=${s._timepicker}
            .customCalendar=${s.customCalendar}
            .customTimeListOptions=${s._customTimeListOptions}
            .minutesRange=${s._minutesRange}
            .minHour=${s._minHour}
            .maxHour=${s._maxHour}
            @onDateChange=${s._onDateChange}
            @onCancel=${s._onCancel}
          ></${p}>
        </div>
  
        ${s._helpText ? i`
              <div class="${a(g)}">
                <span>${s._helpText}</span>
              </div>
            ` : null}
      </div>
    `;
};
export {
  z as template
};
//# sourceMappingURL=datepicker.template.js.map
