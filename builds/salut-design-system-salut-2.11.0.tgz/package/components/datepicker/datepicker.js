import { createPopper as y } from "@popperjs/core";
import { LitElement as w, unsafeCSS as m } from "lit";
import { property as r } from "lit/decorators.js";
import { booleanType as p } from "../../utils/property-types.js";
import { template as D } from "./datepicker.template.js";
import C from "../../shared/scrollbar.style.css.js";
import x from "../input/input.style.css.js";
import L from "./datepicker.style.css.js";
var T = Object.defineProperty, k = Object.getOwnPropertyDescriptor, n = (_, t, e, i) => {
  for (var s = i > 1 ? void 0 : i ? k(t, e) : t, a = _.length - 1, h; a >= 0; a--)
    (h = _[a]) && (s = (i ? h(t, e, s) : h(s)) || s);
  return i && s && T(t, e, s), s;
};
class o extends w {
  constructor() {
    super(), this.icon = "calendar_today", this.inputSize = "lg", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.customCalendar = void 0, this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this._timepickerLabel = "Seleccionar l'hora", this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._placeholder = "", this._externalPlaceholder = "", this._previousDate = "", this._minDate = "", this._maxDate = "", this._showCalendar = !1, this._showTime = !1, this._invalid = !1, this._showButtons = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._isFocused = !1, this._helpText = "", this._helpTextBackup = "", this._inputValidity = !0, this._popperInstance = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showCalendar && this._closeCalendar();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [m(x), m(C), m(L)];
  }
  get _input() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  get _labelSlot() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="label"]')) || void 0;
    return t == null ? void 0 : t.assignedElements()[0];
  }
  get _label() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="label"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this._showButtons = !0, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = t, this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate;
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = t, this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set value(t) {
    t !== void 0 && this.requestUpdate();
  }
  get value() {
    var t;
    return (t = this._input) == null ? void 0 : t.value;
  }
  disconnectedCallback() {
    this._removeCalendarListener(), this.observer.disconnect(), this.visibleObserver.disconnect();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._helpTextBackup = this.helpText, this._createPopperCalendar(), this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input)), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _createPopperCalendar() {
    var i, s;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-input-group"), e = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-calendar");
    t && e && (this._popperInstance = y(t, e, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  _checkInputAttributes() {
    var a, h, u, l, d, c;
    const t = (a = this._input) == null ? void 0 : a.getAttribute("placeholder");
    t && (this._placeholder = t, this._externalPlaceholder = t);
    const e = (h = this._input) == null ? void 0 : h.getAttribute("readonly");
    this._readonly = e !== null;
    const i = (u = this._input) == null ? void 0 : u.getAttribute("disabled");
    this._disabled = i !== null;
    const s = (l = this._input) == null ? void 0 : l.getAttribute("required");
    this._required = s !== null, (d = this._input) != null && d.value && ((c = this._input) == null ? void 0 : c.value) !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleValidity() {
    var e;
    const t = (e = this._input) == null ? void 0 : e.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && this._showCalendar && this._closeCalendar();
  }
  _closeCalendar() {
    var t, e;
    this._removeCalendarListener(), (t = this._input) == null || t.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this._showCalendar = !1, (e = this._input) == null || e.blur(), this.validate && this._validateDate(), this.requestUpdate();
  }
  _handleKeyUp(t) {
    var e, i, s, a, h;
    if ((t == null ? void 0 : t.key) === "Tab" ? (this._isFocused = !0, this._handleBlur()) : (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this._showCalendar = !0, this._popperInstance.update(), this._handleBlur(), this._addCalendarListener()) : (t == null ? void 0 : t.key) === "Escape" && (this._closeCalendar(), this._handleBlur()), t.key === "Enter" && this._input && ((e = this._input.value) == null ? void 0 : e.length) > 7 && this._input) {
      const u = (i = this._input.value) == null ? void 0 : i.replace(/(\d+[/])(\d+[/])/, "$2$1"), l = new Date(u), d = (s = l.getDate()) == null ? void 0 : s.toString().padStart(2, "0"), c = (l.getMonth() + 1).toString().padStart(2, "0"), g = l.getFullYear(), b = (a = l.getHours()) == null ? void 0 : a.toString().padStart(2, "0"), v = (h = l.getMinutes()) == null ? void 0 : h.toString().padStart(2, "0");
      let f = `${d}/${c}/${g}`;
      this._showTime && (f += ` ${b}:${v}`, this._handleValidity()), this._input && (this._input.value = f), this._dispatchValueChange(), this._showCalendar ? this._closeCalendar() : this.requestUpdate();
    }
  }
  _handleInput(t) {
    var i;
    const e = (i = t.target.value) == null ? void 0 : i.replace(/\D/g, "");
    this._input && (this._input.value = this._formatDate(e), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _formatDate(t) {
    let e = t.substring(0, 2), i = t.substring(2, 4);
    const s = t.substring(4, 8);
    let a = t.substring(8, 10), h = t.substring(10, 12);
    Number(e) > 3 && (e = e == null ? void 0 : e.padStart(2, "0")), Number(i) > 1 && (i = i == null ? void 0 : i.padStart(2, "0")), Number(e) > 31 && (e = "31"), Number(i) > 12 && (i = "12"), i === "02" && Number(e) > 28 && (s == null ? void 0 : s.length) === 4 && (e = new Date(Number(s), 1, 29).getMonth() === 1 ? "29" : "28");
    let u = `${e}${i ? `/${i}` : ""}${s ? `/${s}` : ""}`;
    return this._showTime && (Number(a) > 2 && (a = a == null ? void 0 : a.padStart(2, "0")), Number(a) > 23 && (a = "23"), Number(h) > 5 && (h = h == null ? void 0 : h.padStart(2, "0")), u = `${u}${a ? ` ${a}` : ""}${h ? `:${h}` : ""}`), u;
  }
  _handleFocus() {
    var t;
    this._readonly || (this._externalPlaceholder !== "" ? this._placeholder = this._externalPlaceholder : this._placeholder = this._showTime ? "DD/MM/AAAA HH:MM" : "DD/MM/AAAA", (t = this._input) == null || t.setAttribute("placeholder", this._placeholder), this.requestUpdate());
  }
  _handleBlur() {
    this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    var t;
    !this._disabled && !this._readonly && ((t = this._input) == null || t.focus(), this._handleClick());
  }
  _handleClick() {
    this._showCalendar = !0, this._popperInstance.update(), this._addCalendarListener(), this.requestUpdate();
  }
  _onDateChange(t) {
    const e = t.detail;
    this._input && (this._input.value = e, this._handleValidity()), this._closeCalendar(), this._dispatchValueChange();
  }
  _onCancel() {
    this._closeCalendar(), this._input && (this._input.value = this._previousDate || "", this._handleValidity()), this.requestUpdate();
  }
  _dispatchValueChange() {
    var e;
    const t = {
      detail: (e = this._input) == null ? void 0 : e.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", t));
  }
  _checkInputOverflow() {
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, s = document.createElement("canvas").getContext("2d");
    if (!s) return;
    s.font = e;
    const a = s.measureText(this._input.value).width;
    this._isTruncated = a > this._input.offsetWidth;
  }
  _validateDate() {
    var e;
    const t = this._checkDateFormat((e = this._input) == null ? void 0 : e.value);
    this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    const e = this._showTime ? 16 : 10;
    if (t === "")
      return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
    if (t.length < e)
      return this._helpText = this.errorMessageFormat, this._invalid = !0, !0;
    if (this._minDate || this._maxDate) {
      const i = this._showTime ? t.substring(0, 10) : t, s = new Date(this._convertToISO(i)), a = new Date(this._convertToISO(this._minDate)), h = new Date(this._convertToISO(this._maxDate));
      if (a && s < a)
        return this._helpText = this.errorMessageMinDate, this._invalid = !0, !0;
      if (h && s > h)
        return this._helpText = this.errorMessageMaxDate, this._invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
  }
  _convertToISO(t) {
    const [e, i, s] = t.split("/");
    return `${s}-${i}-${e}`;
  }
  _dispatchOnValidate(t) {
    var i;
    const e = {
      detail: {
        date: (i = this._input) == null ? void 0 : i.value,
        invalid: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onValidate", e));
  }
  _clearDate() {
    this._input && (this._input.value = "", this._handleValidity(), this._dispatchValueChange(), this.requestUpdate());
  }
  render() {
    return D(this);
  }
}
n([
  r(p)
], o.prototype, "showTime", 1);
n([
  r(p)
], o.prototype, "showButtons", 1);
n([
  r({ type: String })
], o.prototype, "leftLabel", 1);
n([
  r({ type: String })
], o.prototype, "rightLabel", 1);
n([
  r({ type: String })
], o.prototype, "minDate", 1);
n([
  r({ type: String })
], o.prototype, "maxDate", 1);
n([
  r(p)
], o.prototype, "invalid", 1);
n([
  r({ type: String })
], o.prototype, "icon", 2);
n([
  r({ type: String })
], o.prototype, "inputSize", 2);
n([
  r({ type: String })
], o.prototype, "helpText", 1);
n([
  r({ type: String })
], o.prototype, "timepicker", 1);
n([
  r({ type: Number })
], o.prototype, "minutesRange", 1);
n([
  r({ type: Number })
], o.prototype, "minHour", 1);
n([
  r({ type: Number })
], o.prototype, "maxHour", 1);
n([
  r({ type: Array })
], o.prototype, "customTimeListOptions", 1);
n([
  r({ type: String })
], o.prototype, "timepickerLabel", 1);
n([
  r({ type: String })
], o.prototype, "value", 1);
n([
  r({ type: String })
], o.prototype, "dropdownPlacement", 2);
n([
  r(p)
], o.prototype, "dropdownFixed", 2);
n([
  r({ type: Array })
], o.prototype, "customCalendar", 2);
n([
  r(p)
], o.prototype, "validate", 2);
n([
  r(p)
], o.prototype, "errorMessageFormat", 2);
n([
  r(p)
], o.prototype, "errorMessageMinDate", 2);
n([
  r(p)
], o.prototype, "errorMessageMaxDate", 2);
export {
  o as Datepicker_
};
//# sourceMappingURL=datepicker.js.map
