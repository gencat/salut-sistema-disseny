import { LitElement as _, unsafeCSS as u } from "lit";
import { property as h, state as c } from "lit/decorators.js";
import v from "../../shared/reset.style.css.js";
import { deleteSeparatorMask as m, applyMask as f } from "../../utils/mask.js";
import { booleanType as d } from "../../utils/property-types.js";
import g from "./input.style.css.js";
import { template as y } from "./input.template.js";
var b = Object.defineProperty, x = Object.getOwnPropertyDescriptor, s = (r, t, e, a) => {
  for (var i = a > 1 ? void 0 : a ? x(t, e) : t, p = r.length - 1, l; p >= 0; p--)
    (l = r[p]) && (i = (a ? l(t, e, i) : l(i)) || i);
  return a && i && b(t, e, i), i;
};
class n extends _ {
  constructor() {
    super(...arguments), this.maskRegex = void 0, this.maskReplace = void 0, this.allowedChars = void 0, this.icon = "add_box", this.inputSize = "lg", this.unit = void 0, this.inputPrefix = void 0, this._label = "Label", this._placeholder = "", this._maxLength = void 0, this._invalid = !1, this._helpText = "", this._isFocused = !1, this._isTypeNumeric = !1, this._inputValidity = !0, this._removeMinWidth = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this._previousValue = void 0, this._isTruncated = !1, this.intervalId = null;
  }
  static get styles() {
    return [u(v), u(g)];
  }
  // Properties
  get _input() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  get _labelSlot() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="label"]')) || void 0;
    return t == null ? void 0 : t.assignedElements()[0];
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set removeMinWidth(t) {
    const e = this._removeMinWidth;
    this._removeMinWidth = t, this.requestUpdate("removeMinWidth", e);
  }
  get removeMinWidth() {
    return this._removeMinWidth;
  }
  set value(t) {
    t !== void 0 && this.requestUpdate();
  }
  get value() {
    var t;
    return ((t = this._input) == null ? void 0 : t.value) || "";
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  _handleClick() {
    this.requestUpdate();
  }
  _handleInput() {
    var t, e;
    if (this._isTypeNumeric && this._maxLength && this._input && (this._input.value = this._input.value.slice(0, this._maxLength)), this.maskRegex && this.maskReplace && this._input) {
      this._previousValue && this._previousValue.length > ((t = this._input) == null ? void 0 : t.value.length) && (this._input.value = m(this._previousValue, this._input.value, this.maskReplace));
      const a = f(this._input.value, this.maskRegex, this.maskReplace, this.allowedChars);
      a !== this._input.value && (this._input.value = a);
    }
    this._previousValue = (e = this._input) == null ? void 0 : e.value, this._handleValidity(), this._dispatchOnChange(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._isFocused = !1, this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    var t;
    (t = this._input) == null || t.focus();
  }
  _handleValidity() {
    var e;
    const t = (e = this._input) == null ? void 0 : e.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _stepUp() {
    var t;
    (t = this._input) == null || t.stepUp(), this._handleValidity(), this._dispatchValueChange(), this._dispatchOnChange(), this.requestUpdate();
  }
  _stepDown() {
    var t;
    (t = this._input) == null || t.stepDown(), this._handleValidity(), this._dispatchValueChange(), this._dispatchOnChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    if (this._input) {
      const t = {
        detail: this._input.value,
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onInputChange", t));
    }
  }
  _dispatchOnChange() {
    if (!this._input) return;
    const t = {
      detail: this._input.value,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onChange", t));
  }
  _checkInputAttributes() {
    var a, i, p, l, o;
    const t = (a = this._input) == null ? void 0 : a.getAttribute("placeholder");
    t && (this._placeholder = t), ((i = this._input) == null ? void 0 : i.getAttribute("type")) === "number" && (this._isTypeNumeric = !0);
    const e = (p = this._input) == null ? void 0 : p.getAttribute("maxlength");
    this._maxLength = e ? +e : void 0, (l = this._input) != null && l.value && ((o = this._input) == null ? void 0 : o.value) !== "" && this._handleValidity();
  }
  _checkInputOverflow() {
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, i = document.createElement("canvas").getContext("2d");
    if (!i) return;
    i.font = e;
    const p = i.measureText(this._input.value).width;
    this._isTruncated = p > this._input.offsetWidth;
  }
  _onHold(t) {
    this.intervalId = window.setInterval(() => {
      t === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this.intervalId !== null && (clearInterval(this.intervalId), this.intervalId = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig)), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return y(this);
  }
}
s([
  h({ type: String })
], n.prototype, "label", 1);
s([
  h({ type: String })
], n.prototype, "maskRegex", 2);
s([
  h({ type: String })
], n.prototype, "maskReplace", 2);
s([
  h({ type: String })
], n.prototype, "allowedChars", 2);
s([
  h({ type: String })
], n.prototype, "icon", 2);
s([
  h({ type: String })
], n.prototype, "inputSize", 2);
s([
  h({ type: String })
], n.prototype, "unit", 2);
s([
  h({ type: String })
], n.prototype, "inputPrefix", 2);
s([
  h({ type: String })
], n.prototype, "helpText", 1);
s([
  h(d)
], n.prototype, "invalid", 1);
s([
  h(d)
], n.prototype, "removeMinWidth", 1);
s([
  h({ type: String })
], n.prototype, "value", 1);
s([
  c()
], n.prototype, "intervalId", 2);
export {
  n as Input
};
//# sourceMappingURL=input.js.map
