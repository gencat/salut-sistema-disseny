import { LitElement as d, unsafeCSS as f } from "lit";
import { property as r } from "lit/decorators.js";
import { booleanType as n } from "../../utils/property-types.js";
import c from "./progress-indicator.style.css.js";
import { template as m } from "./progress-indicator.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, s = (a, t, o, p) => {
  for (var e = p > 1 ? void 0 : p ? g(t, o) : t, l = a.length - 1, h; l >= 0; l--)
    (h = a[l]) && (e = (p ? h(t, o, e) : h(e)) || e);
  return p && e && y(t, o, e), e;
};
class i extends d {
  constructor() {
    super(...arguments), this.description = "", this.state = "default", this.percentage = 0, this.hasFailed = !1, this.hidePercentage = !1, this._title = void 0, this._label = "Barra de progrés";
  }
  static get styles() {
    return f(c);
  }
  set title(t) {
    const o = this._title;
    this._title = t, this._label = `Barra de progrés ${t}`, this.requestUpdate("title", o);
  }
  get title() {
    return this._title ?? "";
  }
  updated(t) {
    t.has("hasFailed") && this.hasFailed && (this.state = "error");
  }
  render() {
    return m(this);
  }
}
s([
  r({ type: String })
], i.prototype, "description", 2);
s([
  r({ type: String })
], i.prototype, "state", 2);
s([
  r({ type: Number })
], i.prototype, "percentage", 2);
s([
  r(n)
], i.prototype, "hasFailed", 2);
s([
  r(n)
], i.prototype, "hidePercentage", 2);
s([
  r({ type: String })
], i.prototype, "title", 1);
export {
  i as ProgressIndicator
};
//# sourceMappingURL=progress-indicator.js.map
