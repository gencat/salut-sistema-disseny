import { nothing as c } from "lit";
import { classMap as b } from "lit/directives/class-map.js";
import { ifDefined as r } from "lit/directives/if-defined.js";
import { unsafeStatic as $, literal as o, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as n } from "../../api/custom-element-scope.js";
const l = o`dss-icon${$(n())}`, u = o`dss-button${$(n())}`, a = o`dss-icon-button${$(n())}`, E = (e) => i`
  <div class="dss-tabs">
    <div class="dss-tabs-header">
      <button
        class="dss-tabs-scroll-button dss-tabs-scroll-button--prev"
        @click=${() => e._scrollMenu(-1)}
      >
        <${l} icon="chevron_left" size="md"></${l}>
      </button>

      <div
        role="tablist"
        aria-label="${e._label}"
        class="dss-tabs-menu"
      >
        ${e._tabs.map(
  (s, t) => i`
            
              <div
                id="${s.id}"
                class="${b({
    "dss-tabs-item": !0,
    "dss-tabs-item--selected": !!s.selected,
    "dss-tabs-item--disabled": !!s.disabled,
    "dss-tabs-item--focused": t === e._focusedIndex
  })}"
                role="presentation"
                draggable="${e.canOrder}"
                @dragstart=${(d) => e.onDragStart(d, t)}
                @dragend=${(d) => e.onDragEnd(d)}
                @dragover=${(d) => e.onDragOver(d)}
                @dragleave=${(d) => e.onDragLeave(d)}
                @drop=${(d) => e.onDrop(d, t)}
              >
                ${e.canOrder ? i`
                    <${l} icon="drag_indicator" label="Moure" size="sm"></${l}>
                  ` : c}

                <slot name="badge-${s.id}" class="tab-badge"></slot>

                ${s.icon ? i`
                    <${l} icon="${s.icon}" size="md"></${l}>
                  ` : c}

                ${s.isEditing ? i`
                    <input 
                      id="${s.id}-edit" 
                      type="text" 
                      class="dss-tabs-item__input" 
                      aria-label="Títol de la pestanya" 
                      value="${s.text}"
                      size=${s.text.length || 1}
                      @focusout=${(d) => e._handleInputFocusout(d, s)}
                      @keydown=${(d) => e._handleEditKeydown(d, s)}
                      />

                    <${a} 
                      class="save-edit" 
                      variant="success" 
                      icon="check" 
                      label="Confirma" 
                      hideTooltip
                      size="sm" 
                      @click="${() => e._handleEditSave(s)}"
                    ></${a}>
                    
                    <${a} 
                      class="cancel-edit" 
                      variant="error" 
                      icon="close" 
                      label="Cancel·la"
                      hideTooltip
                      size="sm"
                      @keydown="${(d) => e._handleEditCancelKeydown(d, s)}"
                      @mousedown="${(d) => e._handleEditCancel(d, s)}"
                      @focusout=${(d) => e._handleEditCancelFocusout(d, s)}
                    ></${a}>
                  ` : i`

                  <button
                    id="${s.id}"
                    class="dss-tabs-item__button ${r(s.selected ? "dss-tabs-item__button--selected" : "")}"
                    type="button"
                    role="tab"
                    aria-selected="${r(s.selected ? s.selected : "false")}"
                    tabindex="${r(s.selected ? 0 : -1)}"
                    @click=${() => e.changeTab(s)}
                    ?disabled=${s.disabled}
                    @focusin=${() => e.onItemFocus(t)}
                    @focusout=${() => e.onItemBlur(t)}
                  >
                    <span class="tab-text focus"> ${s.text} </span>
                  </button>

                  ${e.canEdit ? i`
                      <${a} 
                        icon="edit"
                        label="Edita"
                        hideTooltip
                        size="sm" 
                        ?disabled=${s.disabled || s.disableEdit}
                        ?disableTabindex=${!s.selected}
                        @click="${() => e._handleEdit(s)}"
                      ></${a}>
                    ` : c}

                  ${e.canDelete ? i`
                      <${a} 
                        variant="error" 
                        icon="delete" 
                        label="Eliminar"
                        hideTooltip 
                        size="sm" 
                        ?disabled=${s.disabled || s.disableDelete}
                        ?disableTabindex=${!s.selected}
                        @click=${() => e._handleDelete(s)}
                      ></${a}>
                    ` : c}
                  
                  `}

              </div>
            `
)}
        ${e._addTabEnabled ? i`
              <div class="dss-tabs-item dss-tabs-item--add-tab">
                <${u}
                  size="sm"
                  variant="secondary"
                  icon="add"
                  label="${e._addTabText}"
                  @onClick="${e.addNewTab}"
                ></${u}>
              </div>
            ` : null}
      </div>

      <button
        class="dss-tabs-scroll-button dss-tabs-scroll-button--next"
        @click=${() => e._scrollMenu(1)}
      >
        <${l} icon="chevron_right" size="md"></${l}>
      </button>
    </div>

    <div class="dss-tabs-body">
      <slot></slot>
    </div>
  </div>
`;
export {
  E as tabsListTemplate
};
//# sourceMappingURL=tabs-list.template.js.map
