import { createPopper as m } from "@popperjs/core";
import { LitElement as b, unsafeCSS as u } from "lit";
import { property as o } from "lit/decorators.js";
import v from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import C from "./action-menu.style.css.js";
import { actionMenuTemplate as L } from "./action-menu.template.js";
var w = Object.defineProperty, O = Object.getOwnPropertyDescriptor, r = (p, e, t, s) => {
  for (var i = s > 1 ? void 0 : s ? O(e, t) : e, n = p.length - 1, h; n >= 0; n--)
    (h = p[n]) && (i = (s ? h(e, t, i) : h(i)) || i);
  return s && i && w(e, t, i), i;
};
class l extends b {
  constructor() {
    super(), this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || (this.classList.remove("visible"), this._isVisible = !1, this._removeDropdownListener());
      },
      {
        root: null,
        threshold: 0
      }
    ), this.disablePopper = !1, this.disableParentClick = !1, this.open = !1, this.dropdownFixed = !1, this._fullWidth = !1, this._popperInstance = null, this._parent = null, this._trigger = null, this._position = "right-start", this._isVisible = !1, this._disableClickOutside = !0, this._isFirstUpdate = !0, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [u(v), u(C)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("onClose", this._handleCloseAllMenus), this._handleConnectedCallback();
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.removeEventListener("onClose", this._handleCloseAllMenus), this.visibleObserver.disconnect(), this._popperInstance && (this._popperInstance.destroy(), this._popperInstance = null);
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(e) {
    this._checkClickOutside(e);
  }
  _handleFocusOut(e) {
    this._checkFocusOut(e);
  }
  _handleConnectedCallback() {
    if (this._isFirstUpdate) return;
    const e = this.style.position;
    e !== "absolute" && e !== "fixed" && e !== "relative" && (this._popperInstance ? this._popperInstance.update() : this._initActionMenu());
  }
  set fullWidth(e) {
    const t = this._fullWidth;
    this._fullWidth = e, this.requestUpdate("fullWidth", t);
  }
  get fullWidth() {
    return this._fullWidth;
  }
  set position(e) {
    const t = this._position;
    this._position = e, this.requestUpdate("fullWidth", t);
  }
  get position() {
    return this._position;
  }
  createPopperInstance(e) {
    this._popperInstance = m(e, this, {
      placement: this._position,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "flip",
          enabled: !0,
          options: {
            boundary: "viewport",
            rootBoundary: "viewport"
          }
        },
        {
          name: "preventOverflow",
          enabled: !0,
          options: {
            boundary: "viewport",
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        },
        {
          name: "offset",
          options: {
            offset: [0, 8]
          }
        }
      ]
    }), this.visibleObserver.observe(e), e.addEventListener("mousedown", () => this._openByParent()), e.addEventListener("keydown", (t) => {
      const s = t.key;
      (s === "Enter" || s === "Space") && this._openByParent();
    });
  }
  _openByParent() {
    !this._isVisible && !this.disableParentClick && setTimeout(() => {
      this._popperInstance && this._popperInstance.update(), this.classList.add("visible"), this._disableClickOutside = !1, this._isVisible = !0, this._addDropdownListener();
    }, 0);
  }
  _handleCloseAllMenus() {
    this._closeMenu();
  }
  _handleSlotChange() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector("slot");
    if (e) {
      const s = e.assignedElements({ flatten: !0 }).filter((i) => i.tagName.toLowerCase() === "dss-action-menu-item");
      s.forEach((i, n) => {
        n === 0 ? i.setAttribute("first", "") : i.removeAttribute("first"), n === s.length - 1 ? i.setAttribute("last", "") : i.removeAttribute("last");
      });
    }
  }
  _checkClickOutside(e) {
    var c;
    if (this.disableParentClick && this._disableClickOutside)
      return;
    const t = e.composedPath(), s = this.closest("dss-action-menu-item"), i = s && t.includes(s);
    if (s && !i)
      return this._closeMenu();
    const n = t.includes(this._parent);
    if (!t.some(
      (d) => d instanceof HTMLElement && (d.tagName.toLowerCase() === "dss-action-menu" || d.tagName.toLowerCase() === "ul" && d.classList.contains("dss-action-menu"))
    ) && !n && !this.disablePopper)
      return this._closeMenu();
    const _ = this._parent.classList.contains("dss-split-button-action"), f = (c = this._parent) == null ? void 0 : c.getAttribute("data-expanded");
    if (_ && f === "false")
      return this._closeMenu();
  }
  _checkFocusOut(e) {
    const t = e.relatedTarget;
    t !== null && t !== this && t.tagName.toLowerCase() !== "dss-action-menu-item" && this._closeMenu();
  }
  _closeMenu() {
    setTimeout(() => {
      this.classList.contains("visible") && (this.classList.remove("visible"), this._isVisible = !1, this.dispatchEvent(new CustomEvent("onCloseActionMenu")), this._removeDropdownListener());
    }, 0);
  }
  _initActionMenu() {
    var s;
    const e = this.assignedSlot;
    this._parent = e ? e.parentElement : this.parentElement, this._parent && !this.disablePopper && this.createPopperInstance(this._parent), this.disablePopper && (this.classList.add("visible"), this._addDropdownListener());
    const t = (s = this.shadowRoot) == null ? void 0 : s.querySelector("slot");
    t && t.addEventListener("slotchange", () => this._handleSlotChange()), this._handleSlotChange();
  }
  async firstUpdated() {
    await this.updateComplete, this._initActionMenu(), this._isFirstUpdate = !1;
  }
  updated(e) {
    super.updated(e), e.has("position") && this._popperInstance && this._popperInstance.setOptions({
      placement: this.position
    }), e.has("open") && (this.open ? (this.classList.add("visible"), this._isVisible = !0, this._popperInstance && this._popperInstance.update(), setTimeout(() => {
      this._addDropdownListener(), this._disableClickOutside = !1;
    }, 100)) : (this.classList.remove("visible"), this._isVisible = !1, this._disableClickOutside = !0, this._removeDropdownListener()));
  }
  render() {
    return L(this);
  }
}
r([
  o(a)
], l.prototype, "fullWidth", 1);
r([
  o({ type: String })
], l.prototype, "position", 1);
r([
  o(a)
], l.prototype, "disablePopper", 2);
r([
  o(a)
], l.prototype, "disableParentClick", 2);
r([
  o(a)
], l.prototype, "open", 2);
r([
  o(a)
], l.prototype, "dropdownFixed", 2);
export {
  l as ActionMenu
};
//# sourceMappingURL=action-menu.js.map
