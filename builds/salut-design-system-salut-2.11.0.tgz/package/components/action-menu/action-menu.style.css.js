const i = ":host{display:block;width:-moz-max-content;width:max-content;opacity:0;visibility:hidden;z-index:999;transition:opacity var(--animation-delay) ease-out}:host(.visible){opacity:1;visibility:visible}.dss-action-menu{border-radius:var(--dss-radius-sm);box-shadow:0 1px 3px #0000001a,0 4px 8px 3px #0000000d;min-width:160px;width:-moz-max-content;width:max-content;max-width:280px;background-color:var(--color-white);overflow:hidden}.dss-action-menu--full-width{width:100%}";
export {
  i as default
};
//# sourceMappingURL=action-menu.style.css.js.map
