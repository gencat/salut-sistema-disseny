import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as t, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { checkTextTruncate as u } from "../../utils/helpers.js";
const d = t`dss-icon-button${a(l())}`, $ = t`dss-decorative-icon${a(l())}`, e = t`dss-badge${a(l())}`, c = t`dss-icon-badge${a(l())}`, r = t`dss-tooltip${a(l())}`, _ = t`dss-notification-badge${a(l())}`, n = (i) => {
  const o = {
    "dss-accordion--open": i._isOpen,
    "dss-accordion--box": i._accordionStyle === "box",
    "dss-accordion--inner": i._accordionStyle === "inner",
    "dss-accordion--widget": i._widget
  };
  return s`
    <div class="dss-accordion ${g(o)}">
      <div class="dss-accordion-header">
        <div class="dss-accordion-header__info">
          <div class="dss-accordion-title">
            ${i._icon ? s`
                  <${$} icon=${i._icon} state=${i._iconStatus} size="sm"></${$}>
                ` : null}
            ${i._hasCheckbox ? s`
                  <div class="dss-accordion-title__checkbox dss-form-field">
                    <slot
                      name="checkbox"
                      @click=${i._dispatchCheckboxChange}
                    ></slot>
                    <slot name="checkboxLabel"></slot>
                  </div>
                ` : s`
                  <div
                    class="dss-accordion-title__text" @mouseenter=${u}
                    @click="${i._toggleAccordion}"
                  >
                    ${i._title ? s` ${i._title} ` : s` ${i._type} ${i._index} `}
                    <${r} ?tooltipFixed="${i.tooltipFixed}" class="title-tooltip" aria-hidden="true">
                      ${i._title ? s` ${i._title} ` : s` ${i._type} ${i._index} `}
                    </${r}>


                  </div>
                `}
          </div>
        </div>

        <div class="dss-accordion-header__config">

            <div class="dss-accordion-header__config-info">
              ${i._widgetBadgeText ? s`
                    <${e}
                      size="md"
                      state="${i._widgetBadgeState}"
                      outlined
                      hideIcon
                      text="${i._widgetBadgeText}"
                    ></${e}>
                  ` : null}

              ${i._results ? s`
                  <${e}
                    size="md"
                    state="${i._resultsState}"
                    outlined
                    hideIcon
                    text="${i._results} ${i._resultsText}"
                  ></${e}>
                ` : null}

              ${i.info ? s`
                  <${c}  size="md" state="${i.infoBadgeState}" icon="${i.infoBadgeIcon}" ?outlined="${i.infoBadgeOutlined}">
                    <${r} ?tooltipFixed="${i.tooltipFixed}" slot="tooltip">
                      <span>${i.info}</span>
                    </${r} >
                  </${c} >
                ` : null}

              ${i._notifications ? s`
                  <${_}
                    state="${i._notificationsState}"
                    value="${i._notifications}"
                  >
                  </${_}>
                ` : null}

            </div>

            ${i._results || i._notifications || i.info || i._widgetBadgeText ? s`
                <span class="dss-accordion-widget__divider"></span>
              ` : null}

           

            <div class="dss-accordion-header__config-actions">
              ${i.hasPrimaryAction ? s`
                  <${d}
                    size="md"
                    label="${i.primaryActionLabel}"
                    icon="${i.primaryActionIcon}"
                    variant="${i.primaryActionStatus}"
                    ?disabled=${i.primaryActionDisabled}
                    @onClick=${i._dispatchPrimaryAction}
                  ></${d}>
                ` : null}

              ${i._hasSecondaryAction ? s`
                  <${d}
                    size="md"
                    label="${i.secondaryActionLabel}"
                    icon="${i._secondaryActionIcon}"
                    variant="${i._secondaryActionStatus}"
                    ?disabled=${i._secondaryActionDisabled}
                    @onClick=${i._dispatchSecondaryAction}
                  ></${d}>
                ` : null}

              ${i._widgetShowNext ? s`
                    <${d}
                      size="md"
                      variant="primary"
                      label="Següent"
                      icon="arrow_forward"
                      @onClick="${i._dispatchWidgetNext}"
                    >
                    </${d}>
                  ` : null}
              ${i._widgetShowClose ? s`
                    <${d}
                      size="md"
                      variant="default"
                      icon="close"
                      label="Tancar"
                      @onClick="${i._dispatchWidgetClose}"
                    >
                    </${d}>
                  ` : null}
              <${d}
                label="${i._isOpen ? `Obrir ${i._title} acordió` : `Tancar ${i._title} acordió`}"
                hideTooltip
                ariaExpanded="${i._isOpen}"
                size="md"
                icon="${i._isOpen ? "expand_less" : "expand_more"}"
                variant="primary"
                @onClick=${i._toggleAccordion}
              ></${d}>
            </div>
        </div>
      </div>

      <div class="dss-accordion-panel">
        <slot></slot>
      </div>
    </div>
  `;
};
export {
  n as template
};
//# sourceMappingURL=accordion.template.js.map
