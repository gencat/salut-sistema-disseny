import { LitElement as m, unsafeCSS as d } from "lit";
import { property as o, state as h } from "lit/decorators.js";
import y from "../../api/marker/marker.style.css.js";
import S from "../../shared/reset.style.css.js";
import _ from "../../shared/scrollbar.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import b from "./form-select-options.style.css.js";
import { template as v } from "./form-select-options.template.js";
var A = Object.defineProperty, s = (u, e, t, l) => {
  for (var i = void 0, a = u.length - 1, c; a >= 0; a--)
    (c = u[a]) && (i = c(e, t, i) || i);
  return i && A(e, t, i), i;
};
class r extends m {
  constructor() {
    super(...arguments), this.isOpen = !1, this.elements = null, this.value = null, this._value = null, this.type = "default", this.filter = null, this.multiple = !1, this.tick = !0, this.deselectable = !1, this.selectAll = !1, this.isDisplayed = !1, this.readonly = !1, this.disabled = !1, this.boxShadow = !1, this.advancedFilter = !1, this.searchThreshold = 1, this.filterThreshold = 1, this.boxStyle = "", this.selectedCounter = 0, this.ariaLabel = null, this.labelSelectAll = "Seleccionar-ho tot", this.labelDeselectAll = "Deseleccionar-ho tot", this.emptySelectorLabel = "Sense resultats per", this.emptyFilterLabel = "Escriu per cercar.", this._elementId = `dss-selector-${(/* @__PURE__ */ new Date()).getTime()}`, this._elementSelectAll = [], this._style = null, this._isAllSelected = !1;
  }
  static get styles() {
    return [d(S), d(_), d(y), d(b)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  // LIT LIFECYCLE
  updated(e) {
    e.has("value") && queueMicrotask(() => {
      this._updateSelectedValues();
    }), e.has("boxStyle") && queueMicrotask(() => {
      this._style = this.boxStyle;
    }), e.has("filter") && this.selectAll && queueMicrotask(() => {
      this._areAllElementsSelected();
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._elementSelectAll = [this.labelSelectAll], this._areAllElementsSelected();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  // METHODS
  _updateSelectedValues() {
    var t, l;
    if (!this.value || this.value.length === 0) {
      this._value = null;
      return;
    }
    if (this.multiple) {
      this._value = ((t = this.elements) == null ? void 0 : t.filter((i) => this.value.includes(i.value))) || null;
      return;
    }
    const e = (l = this.elements) == null ? void 0 : l.find((i) => i.value === this.value[0]);
    this._value = e ? [e] : null;
  }
  _areAllElementsSelected() {
    if (!this.elements || !this._value) {
      this._elementSelectAll = [this.labelSelectAll], this._isAllSelected = !1;
      return;
    }
    const e = this._value.map((l) => l.value), t = this.elements.map((l) => l.value);
    this._isAllSelected = e.length === t.length && e.every((l) => t.includes(l)), this._isAllSelected ? this._elementSelectAll = [this.labelDeselectAll] : this._elementSelectAll = [this.labelSelectAll];
  }
  _valueIsSelected(e) {
    var t;
    return ((t = this._value) == null ? void 0 : t.some((l) => l.value === e)) || !1;
  }
  _manuallySelect(e, t) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly) return;
    const l = this._valueIsSelected(t);
    if (!this.multiple && !this.deselectable && l) return;
    const i = e.target, a = i.className.includes("dss-mark") ? i.parentElement : i;
    a && a.className.includes("dss-form-field") ? a.querySelector("input").checked = !l : a && (a.parentElement.querySelector("input").checked = !l), this._returnSelectedValues(t), this._areAllElementsSelected();
  }
  _manuallySelectAll(e) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly || !this.multiple && !this.deselectable && this._isAllSelected) return;
    const t = e.target;
    t.className.includes("dss-form-field") ? (t.querySelector("input").checked = !t.querySelector("input").checked, this._returnSelecteAllValues(t.querySelector("input").checked)) : (t.parentElement.querySelector("input").checked = !t.parentElement.querySelector("input").checked, this._returnSelecteAllValues(t.parentElement.querySelector("input").checked)), this._areAllElementsSelected();
  }
  _returnSelecteAllValues(e) {
    var i, a;
    e ? this._value = ((i = this.elements) == null ? void 0 : i.filter((c) => c.value)) || [] : this._value = [];
    const l = {
      detail: ((a = this._value) == null ? void 0 : a.map((c) => c.value)) || null,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", l)), this.requestUpdate();
  }
  _returnSelectedValues(e) {
    var c, f;
    const t = Array.from(((c = this.shadowRoot) == null ? void 0 : c.querySelectorAll("input:checked")) || []).map((p) => p.getAttribute("value")).filter((p) => p == null ? !1 : this.multiple ? !0 : p === e), l = t.indexOf(this._elementSelectAll[0]);
    l !== -1 && t.splice(l, 1), this._value = ((f = this.elements) == null ? void 0 : f.filter((p) => t.includes(p.value))) || [];
    let i;
    this.multiple ? i = t : i = t[0] || null;
    const a = {
      detail: i,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", a)), this.requestUpdate();
  }
  selectFirstMatch() {
    var l;
    const e = (l = this.shadowRoot) == null ? void 0 : l.querySelectorAll(".dss-form-field");
    let t = null;
    for (const i of e || []) {
      const a = i.getAttribute("data-label");
      if (a && this.filter && a.toLowerCase() === this.filter.toLowerCase()) {
        t = i;
        break;
      }
    }
    t && t.click();
  }
  moveFocus() {
    var i;
    const e = (i = this.shadowRoot) == null ? void 0 : i.querySelectorAll(".dss-form-field");
    if (!e || e.length === 0) return;
    const l = e[0].querySelector("input");
    l && l.focus();
  }
  _focusEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.add("dss-form-field__focus");
  }
  _blurEvent(e) {
    const l = e.target.closest(".dss-form-field");
    l == null || l.classList.remove("dss-form-field__focus");
  }
  render() {
    return v(this);
  }
}
s([
  o(n)
], r.prototype, "isOpen");
s([
  o({ type: Array })
], r.prototype, "elements");
s([
  o({ type: Array })
], r.prototype, "value");
s([
  h()
], r.prototype, "_value");
s([
  o({ type: String })
], r.prototype, "type");
s([
  o({
    type: String,
    converter: (u) => (u == null ? void 0 : u.toLowerCase()) ?? null
  })
], r.prototype, "filter");
s([
  o(n)
], r.prototype, "multiple");
s([
  o(n)
], r.prototype, "tick");
s([
  o(n)
], r.prototype, "deselectable");
s([
  o(n)
], r.prototype, "selectAll");
s([
  o(n)
], r.prototype, "isDisplayed");
s([
  o(n)
], r.prototype, "readonly");
s([
  o(n)
], r.prototype, "disabled");
s([
  o(n)
], r.prototype, "boxShadow");
s([
  o(n)
], r.prototype, "advancedFilter");
s([
  o({ type: Number })
], r.prototype, "searchThreshold");
s([
  o({ type: Number })
], r.prototype, "filterThreshold");
s([
  o({ type: String })
], r.prototype, "boxStyle");
s([
  o({ type: Number })
], r.prototype, "selectedCounter");
s([
  o({ type: String })
], r.prototype, "ariaLabel");
s([
  o({ type: String })
], r.prototype, "labelSelectAll");
s([
  o({ type: String })
], r.prototype, "labelDeselectAll");
s([
  o({ type: String })
], r.prototype, "emptySelectorLabel");
s([
  o({ type: String })
], r.prototype, "emptyFilterLabel");
s([
  h()
], r.prototype, "_elementId");
s([
  h()
], r.prototype, "_elementSelectAll");
s([
  h()
], r.prototype, "_style");
s([
  h()
], r.prototype, "_isAllSelected");
export {
  r as FormSelectOptions
};
//# sourceMappingURL=form-select-options.js.map
