import { classMap as $ } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as d, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const i = d`dss-icon${a(o())}`, t = d`dss-tooltip${a(o())}`, b = (s) => l`
  <button
    type=${s.type}
    class=${$({
  "dss-button": !0,
  "dss-button--full-width": !!s.fullWidth,
  [`dss-button--${s.variant}`]: !!s.variant,
  [`dss-button--${s.size}`]: !!s.size,
  "dss-button--icon-left": !!s.icon && !s.onlyIcon && s.iconPosition === "left",
  "dss-button--icon-right": !!s.icon && !s.onlyIcon && s.iconPosition === "right",
  "dss-button--only-icon": !!s.onlyIcon
})}
    aria-label="${s.label}"
    ?disabled=${s.disabled}
    ?hidden=${s.hidden}
    @click=${s._handleClick}
	  @mouseenter=${s.checkTextTruncate}
  >
    ${s.icon ? l`
          <${i}
						class="dss-icon"
            size=${s._getIconSize()}
            icon=${s.icon}
            >${s.icon}</${i}>
        ` : null}
    ${s.onlyIcon ? null : l`
					<span class="dss-button-text">
						${s.label}
					</span>
        `}
		
		<${t} ?tooltipFixed="${s.tooltipFixed}" class="dss-button__tooltip" aria-hidden="true">
			${s.label}
		</${t}>
  </button>
`;
export {
  b as template
};
//# sourceMappingURL=button.template.js.map
