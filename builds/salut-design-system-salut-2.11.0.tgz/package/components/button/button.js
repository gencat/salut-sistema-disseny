import { LitElement as u, unsafeCSS as d } from "lit";
import { property as t } from "lit/decorators.js";
import c from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import f from "./button.style.css.js";
import { template as h } from "./button.template.js";
var m = Object.defineProperty, e = (p, r, s, l) => {
  for (var i = void 0, a = p.length - 1, y; a >= 0; a--)
    (y = p[a]) && (i = y(r, s, i) || i);
  return i && m(r, s, i), i;
};
class o extends u {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.label = "", this.icon = void 0, this.iconPosition = "left", this.disabled = !1, this.hidden = !1, this.onlyIcon = !1, this.fullWidth = !1, this.size = "md", this.tooltipFixed = !1;
  }
  static get styles() {
    return [d(c), d(f)];
  }
  _handleClick() {
    const r = this.closest("form");
    this.type === "submit" && r ? r.requestSubmit() : this.type === "reset" && r && r.reset(), this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  checkTextTruncate(r) {
    if (!r) return;
    const s = r.target, l = s.querySelector(".dss-button-text"), i = l.scrollWidth > l.offsetWidth;
    s.setAttribute("data-truncated", i.toString());
  }
  render() {
    return h(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "variant");
e([
  t({ type: String })
], o.prototype, "label");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "iconPosition");
e([
  t(n)
], o.prototype, "disabled");
e([
  t(n)
], o.prototype, "hidden");
e([
  t(n)
], o.prototype, "onlyIcon");
e([
  t(n)
], o.prototype, "fullWidth");
e([
  t({ type: String })
], o.prototype, "size");
e([
  t(n)
], o.prototype, "tooltipFixed");
export {
  o as Button
};
//# sourceMappingURL=button.js.map
