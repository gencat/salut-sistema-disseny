import { LitElement as T, unsafeCSS as E } from "lit";
import { html as b } from "lit/static-html.js";
import { property as _ } from "lit/decorators.js";
import { classMap as v } from "lit/directives/class-map.js";
import { booleanType as y } from "../../utils/property-types.js";
import { startOfMonth as F, endOfMonth as Y, eachDayOfInterval as k, getDay as O } from "date-fns";
import x from "../../foundations/icon/icon.style.css.js";
import q from "../button/button.style.css.js";
import L from "../icon-button/icon-button.style.css.js";
import C from "./calendar.style.css.js";
import { template as U } from "./calendar.template.js";
var H = Object.defineProperty, $ = Object.getOwnPropertyDescriptor, l = (w, t, e, r) => {
  for (var s = r > 1 ? void 0 : r ? $(t, e) : t, a = w.length - 1, h; a >= 0; a--)
    (h = w[a]) && (s = (r ? h(t, e, s) : h(s)) || s);
  return r && s && H(t, e, s), s;
};
const f = [
  "Gener",
  "Febrer",
  "Març",
  "Abril",
  "Maig",
  "Juny",
  "Juliol",
  "Agost",
  "Setembre",
  "Octubre",
  "Novembre",
  "Desembre"
], z = ["dl", "dm", "dc", "dj", "dv", "ds", "dg"];
class u extends T {
  constructor() {
    super(), this.customCalendar = void 0, this._range = !1, this._isRangeStartFocused = !1, this._isRangeEndFocused = !1, this._rangeStartDate = null, this._rangeEndDate = null, this._rangeOverDate = null, this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._timepickerLabel = "", this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._days = this._getDays(), this._selectedDate = null, this._showTime = !1, this._showButtons = !0, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._minDate = null, this._maxDate = null, this._timepickerValue = "", this._showMonthSelector = !1, this._showYearSelector = !1, this._yearsRangeStart = (/* @__PURE__ */ new Date()).getFullYear() - 18, this._yearsRangeEnd = (/* @__PURE__ */ new Date()).getFullYear() + 1, this._isTimeFormatValid = !1, this._focusFirstElementHandler = this._focusFirstElement.bind(this);
  }
  static get styles() {
    return [E(x), E(q), E(L), E(C)];
  }
  set range(t) {
    const e = this._range;
    this._range = t, this.requestUpdate("range", e);
  }
  get range() {
    return this._range;
  }
  set isRangeStartFocused(t) {
    const e = this._isRangeStartFocused;
    this._isRangeStartFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeStartFocused() {
    return this._isRangeStartFocused;
  }
  set isRangeEndFocused(t) {
    const e = this._isRangeEndFocused;
    this._isRangeEndFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeEndFocused() {
    return this._isRangeEndFocused;
  }
  set selectedDate(t) {
    const e = this._selectedDate;
    this._selectedDate = this._getDateString(t), this._updateCurrentDate(), this.requestUpdate("selectedDate", e);
  }
  get selectedDate() {
    var t;
    return ((t = this._selectedDate) == null ? void 0 : t.toString()) || "";
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = this._getDateString(t), this.requestUpdate("minDate", e);
  }
  get minDate() {
    var t;
    return ((t = this._minDate) == null ? void 0 : t.toString()) || "";
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = this._getDateString(t), this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    var t;
    return ((t = this._maxDate) == null ? void 0 : t.toString()) || "";
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set rangeStartDate(t) {
    const e = this._rangeStartDate;
    this._rangeStartDate = this._getDateString(t), this.requestUpdate("rangeStartDate", e);
  }
  get rangeStartDate() {
    var t;
    return ((t = this._rangeStartDate) == null ? void 0 : t.toString()) || "";
  }
  set rangeEndDate(t) {
    const e = this._rangeEndDate;
    this._rangeEndDate = this._getDateString(t), this.requestUpdate("rangeEndDate", e);
  }
  get rangeEndDate() {
    var t;
    return ((t = this._rangeEndDate) == null ? void 0 : t.toString()) || "";
  }
  connectedCallback() {
    super.connectedCallback(), this._range && window.addEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._range && window.removeEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  _focusFirstElement() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector("#firstCalendarElement");
    t == null || t.focus();
  }
  _prev() {
    this._currMonth -= 1, this._update();
  }
  _next() {
    this._currMonth += 1, this._update();
  }
  _update() {
    (this._currMonth < 0 || this._currMonth > 11) && (this._date = new Date(this._currYear, this._currMonth, (/* @__PURE__ */ new Date()).getDate()), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth()), this._days = this._getDays(), this.requestUpdate();
  }
  _getDays() {
    const t = [], e = F(new Date(this._currYear, this._currMonth)), r = Y(new Date(this._currYear, this._currMonth)), s = k({ start: e, end: r }), a = O(e);
    for (let h = a === 0 ? 6 : a - 1; h > 0; h -= 1)
      t.push(0);
    for (const h of s)
      t.push(h.getDate());
    return t;
  }
  _getCustomType(t) {
    if (!this.customCalendar) return !1;
    const r = new Date(this._currYear, this._currMonth, t).toLocaleDateString("es-ES"), s = this.customCalendar.find((a) => a.date === r);
    return s ? s.type : !1;
  }
  _isToday(t) {
    const e = /* @__PURE__ */ new Date();
    return t === e.getDate() && this._currMonth === e.getMonth() && this._currYear === e.getFullYear();
  }
  _isWeekend(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return e.getDay() === 0 || e.getDay() === 6;
  }
  _isInactive(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return t ? this._minDate && this._maxDate ? !(e >= this._minDate && e <= this._maxDate) : this._minDate ? !(e >= this._minDate) : this._maxDate ? !(e <= this._maxDate) : !1 : !0;
  }
  _isSelected(t) {
    var e, r, s, a, h, D;
    return this._range ? t === ((e = this._rangeStartDate) == null ? void 0 : e.getDate()) && this._currMonth === ((r = this._rangeStartDate) == null ? void 0 : r.getMonth()) && this._currYear === ((s = this._rangeStartDate) == null ? void 0 : s.getFullYear()) || this._isSelectedRangeEnd(t) : t === ((a = this._selectedDate) == null ? void 0 : a.getDate()) && this._currMonth === ((h = this._selectedDate) == null ? void 0 : h.getMonth()) && this._currYear === ((D = this._selectedDate) == null ? void 0 : D.getFullYear());
  }
  _isFocusable(t) {
    return this._range && (this._rangeStartDate || this._rangeEndDate) ? this._isSelectedRangeStart(t) || this._isSelectedRangeEnd(t) : this._selectedDate ? this._isSelected(t) : this._isToday(t);
  }
  _isSelectedRangeStart(t) {
    var e, r, s, a, h, D, m, S;
    return this._range && this._rangeStartDate && this._rangeEndDate ? !this._compareSelectedRangeDates() && t === ((e = this._rangeStartDate) == null ? void 0 : e.getDate()) && this._currMonth === ((r = this._rangeStartDate) == null ? void 0 : r.getMonth()) && this._currYear === ((s = this._rangeStartDate) == null ? void 0 : s.getFullYear()) : this._range && this._rangeStartDate && !this._rangeEndDate ? this._rangeOverDate !== null && ((a = this._rangeStartDate) == null ? void 0 : a.getTime()) < ((h = this._rangeOverDate) == null ? void 0 : h.getTime()) && t === ((D = this._rangeStartDate) == null ? void 0 : D.getDate()) && this._currMonth === ((m = this._rangeStartDate) == null ? void 0 : m.getMonth()) && this._currYear === ((S = this._rangeStartDate) == null ? void 0 : S.getFullYear()) && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : (this._range && this._rangeStartDate === this._rangeEndDate, !1);
  }
  _isSelectedRangeEnd(t) {
    var e, r, s;
    return !this._compareSelectedRangeDates() && t === ((e = this._rangeEndDate) == null ? void 0 : e.getDate()) && this._currMonth === ((r = this._rangeEndDate) == null ? void 0 : r.getMonth()) && this._currYear === ((s = this._rangeEndDate) == null ? void 0 : s.getFullYear());
  }
  _isOverRangeDate(t) {
    var r, s, a;
    const e = t === ((r = this._rangeOverDate) == null ? void 0 : r.getDate()) && this._currMonth === ((s = this._rangeOverDate) == null ? void 0 : s.getMonth()) && this._currYear === ((a = this._rangeOverDate) == null ? void 0 : a.getFullYear());
    return this._range && this._rangeOverDate && this._rangeStartDate && !this._rangeEndDate ? e && this._rangeOverDate.getTime() > this._rangeStartDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _compareSelectedRangeDates() {
    return this._rangeStartDate && this._rangeEndDate ? this._rangeStartDate.getFullYear() === this._rangeEndDate.getFullYear() && this._rangeStartDate.getMonth() === this._rangeEndDate.getMonth() && this._rangeStartDate.getDate() === this._rangeEndDate.getDate() : !0;
  }
  _isBetweenRange(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return !this._isInactive(t) && this._rangeStartDate && this._rangeEndDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() : !1;
  }
  _isBetweenRangeOnMouseOver(t) {
    const e = new Date(this._currYear, this._currMonth, t), r = this._isInactive(t);
    return !r && this._rangeStartDate && !this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !r && this._rangeStartDate && this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _selectDate(t) {
    this._selectedDate = new Date(this._currYear, this._currMonth, t), this._range && !this._showButtons && (this._rangeStartDate && this._rangeEndDate && !this._isRangeEndFocused && this._selectedDate.getTime() >= this._rangeEndDate.getTime() && (this._rangeStartDate = null, this._rangeEndDate = null), this._isRangeStartFocused || !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this._range && this._showButtons && (this._rangeStartDate && this._rangeEndDate && (this._rangeStartDate = null, this._rangeEndDate = null), !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this.requestUpdate(), !this._showButtons && (this._range ? this._emitRange() : this._emitDate());
  }
  _selectRangeOverDate(t) {
    this._range && (this._rangeOverDate = new Date(this._currYear, this._currMonth, t), this.requestUpdate());
  }
  _removeRangeOverDate() {
    this._rangeOverDate = null, this.requestUpdate();
  }
  _onCancel() {
    const t = new CustomEvent("onCancel", {
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(t);
  }
  _onAccept() {
    this._range ? this._emitRange() : this._emitDate();
  }
  _emitDate() {
    var a, h, D, m;
    const t = (h = (a = this._selectedDate) == null ? void 0 : a.getDate()) == null ? void 0 : h.toString().padStart(2, "0"), e = (this._currMonth + 1).toString().padStart(2, "0");
    let r = `${t}/${e}/${this._currYear}`;
    if (this._showTime) {
      const S = (D = this._currHour) == null ? void 0 : D.toString().padStart(2, "0"), c = (m = this._currMin) == null ? void 0 : m.toString().padStart(2, "0");
      r += ` ${S}:${c}`;
    }
    const s = new CustomEvent("onDateChange", {
      detail: r,
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(s);
  }
  _emitRange() {
    var s, a, h, D, m, S, c, i, o, n, g, d;
    let t = null;
    if (((s = this._rangeStartDate) == null ? void 0 : s.getDate()) != null && ((a = this._rangeStartDate) == null ? void 0 : a.getMonth()) != null && ((h = this._rangeStartDate) == null ? void 0 : h.getFullYear()) != null) {
      const p = (D = this._rangeStartDate.getDate()) == null ? void 0 : D.toString().padStart(2, "0"), M = (((m = this._rangeStartDate) == null ? void 0 : m.getMonth()) + 1).toString().padStart(2, "0");
      t = `${p}/${M}/${(S = this._rangeStartDate) == null ? void 0 : S.getFullYear()}`;
    }
    let e = null;
    if (((c = this._rangeEndDate) == null ? void 0 : c.getDate()) != null && ((i = this._rangeEndDate) == null ? void 0 : i.getMonth()) != null && ((o = this._rangeEndDate) != null && o.getFullYear())) {
      const p = (n = this._rangeEndDate.getDate()) == null ? void 0 : n.toString().padStart(2, "0"), M = (((g = this._rangeEndDate) == null ? void 0 : g.getMonth()) + 1).toString().padStart(2, "0");
      e = `${p}/${M}/${(d = this._rangeEndDate) == null ? void 0 : d.getFullYear()}`;
    }
    const r = new CustomEvent("onRangeChange", {
      detail: {
        rangeStart: t,
        rangeEnd: e
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(r);
  }
  _updateCurrentDate() {
    if (!this._selectedDate) {
      this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth();
      return;
    }
    if (this._currMonth = this._selectedDate.getMonth(), this._currYear = this._selectedDate.getFullYear(), this._currHour = this._selectedDate.getHours(), this._currMin = this._selectedDate.getMinutes(), this._days = this._getDays(), this._currHour !== void 0 && this._currMin !== void 0) {
      const t = String(this._currHour).padStart(2, "0"), e = String(this._currMin).padStart(2, "0");
      this._timepickerValue = `${t}:${e}`, this._isTimeFormatValid = this._currHour >= 0 && this._currHour <= 23 && this._currMin >= 0 && this._currMin <= 59;
    }
  }
  _getDateString(t) {
    const e = t == null ? void 0 : t.replace(/(\d+[/])(\d+[/])/, "$2$1"), r = this._showTime ? 14 : 8;
    return (e == null ? void 0 : e.length) > r ? new Date(e) : null;
  }
  _onSelectTime(t) {
    if (this._isTimeFormatValid = !1, t.detail.status === "VALID") {
      this._isTimeFormatValid = !0;
      const e = t.detail.value;
      this._currHour = +e.substring(0, 2), this._currMin = +e.substring(3, 5);
    }
    this.requestUpdate();
  }
  _toggleMonthSelector() {
    this._showMonthSelector = !0, this.requestUpdate();
  }
  _onMonthSelectorClick(t) {
    const e = f.indexOf(t);
    this._currMonth = e, this._update(), this._showMonthSelector = !1, this.requestUpdate();
  }
  _toggleYearSelector() {
    this._showYearSelector = !0, this.requestUpdate();
  }
  _onYearSelectorClick(t) {
    this._currYear = t, this._update(), this._showYearSelector = !1, this.requestUpdate();
  }
  _generateYearsRangeOptions() {
    const t = [];
    for (let r = this._yearsRangeStart; r <= this._yearsRangeEnd; r += 1)
      t.push(r);
    return t.map((r) => {
      const s = (i) => {
        i && i.focus();
      }, a = (i) => {
        let o = 0;
        const n = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), g = n.length - 1;
        i === n[0] ? s(n[g]) : (n.forEach((d, p) => {
          d === i && (o = p);
        }), s(n[o - 1]));
      }, h = (i) => {
        let o = 0;
        const n = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), g = n.length - 1;
        i === n[g] ? s(n[0]) : (n.forEach((d, p) => {
          d === i && (o = p);
        }), s(n[o + 1]));
      }, D = (i) => {
        const o = i.currentTarget, n = i;
        let g = !1;
        switch (n.key) {
          case "ArrowUp":
          case "ArrowLeft":
            a(o), g = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            h(o), g = !0;
            break;
          case "Enter":
            const d = i.target, p = this.renderRoot.querySelector(
              '.calendar-selector-options__item--year[tabindex="0"]'
            );
            p == null || p.setAttribute("tabindex", "-1"), i.target.setAttribute("tabindex", "0"), d.click(), g = !0;
            break;
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), g = !0;
            break;
        }
        g && (i.stopPropagation(), i.preventDefault());
      }, S = (/* @__PURE__ */ new Date()).getFullYear(), c = {
        "calendar-selector-options__item--current": r === S,
        "calendar-selector-options__item--selected": r === this._currYear
      };
      return b`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--year ${v(c)}"
          tabindex="${r === this._currYear ? 0 : -1}"
          role="button"
          @keydown=${D}
          @click=${() => this._onYearSelectorClick(r)}
        >
          ${r}
        </div>
      `;
    });
  }
  _generateMonthsOptions() {
    return f.map((e) => {
      const r = (c) => {
        c && c.focus();
      }, s = (c) => {
        let i = 0;
        const o = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = o.length - 1;
        c === o[0] ? r(o[n]) : (o.forEach((g, d) => {
          g === c && (i = d);
        }), r(o[i - 1]));
      }, a = (c) => {
        let i = 0;
        const o = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = o.length - 1;
        c === o[n] ? r(o[0]) : (o.forEach((g, d) => {
          g === c && (i = d);
        }), r(o[i + 1]));
      }, h = (c) => {
        const i = c.currentTarget, o = c;
        let n = !1;
        switch (o.key) {
          case "ArrowUp":
          case "ArrowLeft":
            s(i), n = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            a(i), n = !0;
            break;
          case "Enter":
            const g = c.target, d = this.renderRoot.querySelector(
              '.calendar-selector-options__item--month[tabindex="0"]'
            );
            d == null || d.setAttribute("tabindex", "-1"), c.target.setAttribute("tabindex", "0"), g.click(), n = !0;
            break;
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), n = !0;
            break;
        }
        n && (c.stopPropagation(), c.preventDefault());
      }, m = (/* @__PURE__ */ new Date()).getMonth(), S = {
        "calendar-selector-options__item--current": f.indexOf(e) === m,
        "calendar-selector-options__item--selected": f.indexOf(e) === this._currMonth
      };
      return b`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--month ${v(S)}"
          tabindex="${f.indexOf(e) === this._currMonth ? 0 : -1}"
          role="button"
          @keydown=${h}
          @click=${() => this._onMonthSelectorClick(e)}
        >
          ${e.length <= 4 ? b`${e}` : b`${e.slice(0, 3)}.`}
        </div>
      `;
    });
  }
  _onYearRangeStepUp() {
    this._yearsRangeStart += 20, this._yearsRangeEnd += 20, this.requestUpdate();
  }
  _onYearRangeStepDown() {
    this._yearsRangeStart -= 20, this._yearsRangeEnd -= 20, this.requestUpdate();
  }
  _onHeaderMonthKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--month[tabindex="0"]').focus();
    }, 50));
  }
  _onHeaderYearKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--year[tabindex="0"]').focus();
    }, 50));
  }
  _validateSelectedDate() {
    return !!(!this._range && !this._selectedDate || !this._range && this._showTime && !this._isTimeFormatValid || this._range && (!this._rangeStartDate || !this._rangeEndDate));
  }
  _handleCalendarKeydown(t) {
    (t == null ? void 0 : t.key) === "Escape" && this._onCancel();
  }
  render() {
    return U(this);
  }
}
l([
  _({ type: Array })
], u.prototype, "customCalendar", 2);
l([
  _(y)
], u.prototype, "range", 1);
l([
  _(y)
], u.prototype, "isRangeStartFocused", 1);
l([
  _(y)
], u.prototype, "isRangeEndFocused", 1);
l([
  _({ type: String })
], u.prototype, "selectedDate", 1);
l([
  _({ type: String })
], u.prototype, "minDate", 1);
l([
  _({ type: String })
], u.prototype, "maxDate", 1);
l([
  _(y)
], u.prototype, "showTime", 1);
l([
  _(y)
], u.prototype, "showButtons", 1);
l([
  _({ type: String })
], u.prototype, "leftLabel", 1);
l([
  _({ type: String })
], u.prototype, "rightLabel", 1);
l([
  _({ type: String })
], u.prototype, "timepicker", 1);
l([
  _({ type: Number })
], u.prototype, "minutesRange", 1);
l([
  _({ type: Number })
], u.prototype, "minHour", 1);
l([
  _({ type: Number })
], u.prototype, "maxHour", 1);
l([
  _({ type: Array })
], u.prototype, "customTimeListOptions", 1);
l([
  _({ type: String })
], u.prototype, "timepickerLabel", 1);
l([
  _({ type: String })
], u.prototype, "rangeStartDate", 1);
l([
  _({ type: String })
], u.prototype, "rangeEndDate", 1);
export {
  u as Calendar,
  f as MONTH,
  z as WEEK
};
//# sourceMappingURL=calendar.js.map
