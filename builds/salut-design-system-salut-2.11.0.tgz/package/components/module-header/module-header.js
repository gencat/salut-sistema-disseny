import { LitElement as f, unsafeCSS as o } from "lit";
import { property as n } from "lit/decorators.js";
import y from "../../foundations/typography/typography.css.js";
import a from "../../shared/reset.style.css.js";
import d from "./module-header.style.css.js";
import { template as u } from "./module-header.template.js";
var g = Object.defineProperty, l = (e, p, s, S) => {
  for (var t = void 0, r = e.length - 1, i; r >= 0; r--)
    (i = e[r]) && (t = i(p, s, t) || t);
  return t && g(p, s, t), t;
};
class m extends f {
  constructor() {
    super(...arguments), this.title = "", this.legend = "";
  }
  static get styles() {
    return [o(a), o(d), o(y)];
  }
  render() {
    return u(this);
  }
}
l([
  n({ type: String })
], m.prototype, "title");
l([
  n({ type: String })
], m.prototype, "legend");
export {
  m as ModuleHeader
};
//# sourceMappingURL=module-header.js.map
