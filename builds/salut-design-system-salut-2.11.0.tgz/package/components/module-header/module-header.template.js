import { html as e } from "lit/static-html.js";
const l = (s) => e`
  <header class='dss-module-header'>
    <h2 class='dss-headline--sm'>${s.title}</h2>
    <div class='dss-module-header__child-container'>
      <p class='dss-legend--sm'>${s.legend}</p>
      <slot></slot>
    </div>
  </header>
`;
export {
  l as template
};
//# sourceMappingURL=module-header.template.js.map
