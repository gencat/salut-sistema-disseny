import { createPopper as d } from "@popperjs/core";
import { LitElement as f, unsafeCSS as h } from "lit";
import { property as o } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import u from "./tooltip.style.css.js";
import { template as b } from "./tooltip.template.js";
var v = Object.defineProperty, s = (r, t, e, n) => {
  for (var i = void 0, a = r.length - 1, c; a >= 0; a--)
    (c = r[a]) && (i = c(t, e, i) || i);
  return i && v(t, e, i), i;
};
class p extends f {
  constructor() {
    super(...arguments), this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        if (e.type === "attributes" && e.attributeName === "data-popper-placement") {
          const n = this.getAttribute("data-popper-placement");
          n && this._propagatePlacement(n);
        }
    }, this.observer = new MutationObserver(this.callback), this.position = "top", this.align = "left", this.hide = !1, this.noHeightLimit = !1, this.tooltipFixed = !1, this._popperInstance = null;
  }
  static get styles() {
    return [h(m), h(u)];
  }
  connectedCallback() {
    super.connectedCallback();
    const t = this.parentElement;
    t && this.createPopperInstance(t);
  }
  disconnectedCallback() {
    this.observer.disconnect(), this._popperInstance && (this._popperInstance.destroy(), this._popperInstance = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.observer.observe(this, this.observerConfig);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    super.updated(t), t.has("position") && this._popperInstance && this._popperInstance.setOptions({
      placement: this.position
    });
  }
  createPopperInstance(t) {
    this._popperInstance = d(t, this, {
      placement: this.position,
      strategy: this.tooltipFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 8]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ],
      onFirstUpdate: (e) => {
        this._propagatePlacement(e.placement);
      }
    }), t.addEventListener("mouseenter", () => {
      this._openTooltip();
    }), t.addEventListener("mouseleave", () => {
      this._closeTooltip();
    }), t.addEventListener("focusin", () => {
      this.classList.contains("visible") || this._openTooltip();
    }), t.addEventListener("focusout", () => {
      this.classList.contains("visible") && this._closeTooltip();
    });
  }
  _openTooltip() {
    var t;
    (t = this._popperInstance) == null || t.update(), this.classList.add("visible");
  }
  _closeTooltip() {
    this.classList.remove("visible");
  }
  _propagatePlacement(t) {
    const e = this.renderRoot.querySelector(".dss-tooltip-box");
    e && e.setAttribute("data-popper-placement", t);
  }
  updateTooltip() {
    this._popperInstance.update();
  }
  render() {
    return b(this);
  }
}
s([
  o({ type: String })
], p.prototype, "position");
s([
  o({ type: String })
], p.prototype, "align");
s([
  o(l)
], p.prototype, "hide");
s([
  o(l)
], p.prototype, "noHeightLimit");
s([
  o(l)
], p.prototype, "tooltipFixed");
export {
  p as Tooltip
};
//# sourceMappingURL=tooltip.js.map
