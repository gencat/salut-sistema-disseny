import { classMap as s } from "lit/directives/class-map.js";
import { html as o } from "lit/static-html.js";
const d = (i) => {
  const t = {
    "dss-tooltip": !0,
    [`dss-tooltip--${i.position}`]: !!i.position,
    [`dss-tooltip--align-${i.align}`]: !!i.align,
    "dss-tooltip--hidden": i.hide,
    "dss-tooltip--no-height-limit": i.noHeightLimit
  };
  return o`
    <div class="${s(t)}">
      <slot></slot>
    </div>
  `;
};
export {
  d as template
};
//# sourceMappingURL=tooltip.template.js.map
