import { LitElement as y, unsafeCSS as p } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import f from "./user-feedback.style.css.js";
import { userFeedbackTemplate as g } from "./user-feedback.template.js";
var u = Object.defineProperty, e = (s, a, l, S) => {
  for (var i = void 0, o = s.length - 1, n; o >= 0; o--)
    (n = s[o]) && (i = n(a, l, i) || i);
  return i && u(a, l, i), i;
};
class r extends y {
  constructor() {
    super(...arguments), this.variant = "default", this.size = "lg", this.imageSrc = "", this.imageAlt = "", this.title = "", this.description = "", this.hasDetails = !1, this.detailsLabel = "Veure detalls", this.hideFooter = !1, this.status = "error", this._detailsExpanded = !1;
  }
  static get styles() {
    return [p(m), p(h), p(f)];
  }
  _handleDetailsClick() {
    this._detailsExpanded = !this._detailsExpanded, this.requestUpdate();
  }
  render() {
    return g(this);
  }
}
e([
  t({ type: String })
], r.prototype, "variant");
e([
  t({ type: String })
], r.prototype, "size");
e([
  t({ type: String })
], r.prototype, "imageSrc");
e([
  t({ type: String })
], r.prototype, "imageAlt");
e([
  t({ type: String })
], r.prototype, "title");
e([
  t({ type: String })
], r.prototype, "description");
e([
  t(d)
], r.prototype, "hasDetails");
e([
  t({ type: String })
], r.prototype, "detailsLabel");
e([
  t(d)
], r.prototype, "hideFooter");
e([
  t({ type: String })
], r.prototype, "status");
export {
  r as UserFeedback
};
//# sourceMappingURL=user-feedback.js.map
