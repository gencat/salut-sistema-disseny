import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as c, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
import b from "../../assets/img/feedback-empty.svg.js";
import r from "../../assets/img/feedback-error.svg.js";
import f from "../../assets/img/feedback-not_found.svg.js";
import k from "../../assets/img/feedback-success.svg.js";
import m from "../../assets/img/feedback-warning.svg.js";
import _ from "../../assets/img/feedback-work_in_progress.svg.js";
const i = c`dss-icon${l(u())}`, E = (s) => {
  const d = {
    "dss-user-feedback": !0,
    [`dss-user-feedback--${s.size}`]: s.size,
    [`dss-user-feedback--${s.variant}`]: s.variant
  };
  let e;
  if (s.imageSrc)
    e = s.imageSrc;
  else
    switch (s.status) {
      case "error":
        e = r;
        break;
      case "success":
        e = k;
        break;
      case "warning":
        e = m;
        break;
      case "empty":
        e = b;
        break;
      case "work-in-progress":
        e = _;
        break;
      case "not-found":
        e = f;
        break;
      default:
        e = r;
    }
  return a`
    <div class="${t(d)}">
      <img
        class="dss-user-feedback__image"
        src="${e}"
        alt="${s.imageSrc ? s.imageAlt : s.status}"
      />
      <div class="dss-user-feedback__body">
        <h4 class="dss-user-feedback__title">${s.title}</h4>
        <p class="dss-user-feedback__description">${s.description}</p>
        ${s.hasDetails ? a`
              <div class="dss-user-feedback__details-action">
                <button
                  class="dss-user-feedback__details-button"
                  @click="${s._handleDetailsClick}"
                >
                  <span class="dss-user-feedback__details-button-text">
                    ${s.detailsLabel}
                  </span>
                  <${i} icon="${s._detailsExpanded ? "expand_less" : "expand_more"}" size="sm"></${i}>
                </button>
              </div>

              ${s._detailsExpanded ? a`
                    <div class="dss-user-feedback__details-content">
                      <slot name="details"></slot>
                    </div>
                  ` : null}
            ` : null}
      </div>
      ${s.hideFooter ? null : a`
            <div class="dss-user-feedback__button-group">
              <slot></slot>
            </div>
          `}
    </div>
  `;
};
export {
  E as userFeedbackTemplate
};
//# sourceMappingURL=user-feedback.template.js.map
