const t = ':host{display:block;min-width:-moz-fit-content;min-width:fit-content}.dss-footer__container{align-items:center;padding:24px;display:flex;flex-direction:row;box-shadow:0 1px 2px #0000000d,0 1px 3px 1px #0000001a}.dss-footer__logo-content{height:24px;display:flex;margin-bottom:24px}.dss-footer__content{display:flex;align-items:center;justify-content:center;width:100%}.dss-footer__content p{display:none}@media (min-width: 768px){.dss-footer__container{padding:16px 24px;flex-direction:row;width:100%}.dss-footer__logo-content{margin-bottom:0}.dss-footer__content{justify-content:space-between}.dss-footer__content p{display:block;position:relative;margin-left:32px}.dss-footer__content p:before{content:"";width:1px;height:24px;background-color:var(--color-neutral-100);position:absolute;left:-16px;top:-4px;margin:auto}}@media only screen and (max-height: 808px){.dss-footer__container{display:none}}';
export {
  t as default
};
//# sourceMappingURL=footer.style.css.js.map
