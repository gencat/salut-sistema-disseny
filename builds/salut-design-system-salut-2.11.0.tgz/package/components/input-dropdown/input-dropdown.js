import { createPopper as y } from "@popperjs/core";
import { LitElement as w, unsafeCSS as _ } from "lit";
import { property as r } from "lit/decorators.js";
import g from "../../shared/reset.style.css.js";
import { normalizeText as u } from "../../utils/helpers.js";
import { booleanType as p } from "../../utils/property-types.js";
import { sort as b } from "../../utils/sorting.js";
import v from "../input/input.style.css.js";
import S from "./input-dropdown.style.css.js";
import { template as E } from "./input-dropdown.template.js";
var V = Object.defineProperty, D = Object.getOwnPropertyDescriptor, h = (c, e, t, s) => {
  for (var i = s > 1 ? void 0 : s ? D(e, t) : e, l = c.length - 1, o; l >= 0; l--)
    (o = c[l]) && (i = (s ? o(e, t, i) : o(i)) || i);
  return s && i && V(e, t, i), i;
};
class n extends w {
  constructor() {
    super(), this.dropdownOffsetX = void 0, this.dropdownOffsetY = void 0, this.icon = "search", this.inputSize = "lg", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.advancedFilter = !1, this._elements = null, this._copyElements = null, this._tick = !0, this._type = "default", this._boxStyle = null, this._selectedValue = null, this._multiple = !1, this._openWithSearch = !1, this._deselectable = !1, this._placeHolder = "", this._showDropdown = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._labelSelectAll = "Seleccionar-ho tot", this._labelDeselectAll = "Deseleccionar-ho tot", this._selectAll = !1, this._selectElements = 0, this._isFocused = !1, this._helpText = "", this._invalid = !1, this._inputValidity = !0, this._filteredElements = [], this._dropdownPlaceholder = "Seleccionar", this._selectorStyle = "", this._isFiltering = !1, this._placeholderEmpty = "Escriu per cercar", this._filterThreshold = 1, this._searchThreshold = 2, this._unorder = !1, this._popperInstance = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._input && this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || this._showDropdown && this._closeDropdown();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [_(v), _(g), _(S)];
  }
  get _input() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  get _label() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="label"]')) || void 0;
    return this.requestUpdate(), e == null ? void 0 : e.assignedElements()[0];
  }
  set placeHolder(e) {
    const t = this._placeHolder;
    this._placeHolder = e, this.requestUpdate("placeHolder", t);
  }
  get placeHolder() {
    return this._placeHolder;
  }
  set unorder(e) {
    const t = this._unorder;
    this._unorder = e, this.requestUpdate("unorder", t);
  }
  get unorder() {
    return this._unorder;
  }
  set elements(e) {
    const t = this._elements;
    if (this._unorder)
      this._elements = e;
    else {
      const s = b(e, "label", "asc", "string");
      this._elements = s;
    }
    e && (this._input && !this._isFiltering && (this._input.value = ""), this._filteredElements = this._getFilteredElements(), this._copyElements = [...this._elements], this._initElementsSelected(), this.requestUpdate()), this.requestUpdate("elements", t);
  }
  get elements() {
    return this._elements || [];
  }
  set multiple(e) {
    const t = this._multiple;
    this._multiple = e, this.requestUpdate("multiple", t);
  }
  get multiple() {
    return this._multiple;
  }
  set tick(e) {
    const t = this._tick;
    this._tick = e, this.requestUpdate("tick", t);
  }
  get tick() {
    return this._tick;
  }
  set openWithSearch(e) {
    var s;
    const t = this._openWithSearch;
    this._openWithSearch = e, e && (this._showDropdown = e, (s = this._popperInstance) == null || s.update(), this._isFocused = !0), this.requestUpdate("openWithSearch", t);
  }
  get openWithSearch() {
    return this._openWithSearch;
  }
  set showDropdown(e) {
    const t = this._showDropdown;
    this._showDropdown = e, this.requestUpdate("showDropdown", t);
  }
  get showDropdown() {
    return this._showDropdown;
  }
  set deselectable(e) {
    const t = this._deselectable;
    this._deselectable = e, this.requestUpdate("deselectable", t);
  }
  get deselectable() {
    return this._deselectable;
  }
  set selectedValue(e) {
    const t = this._selectedValue;
    e && (this._selectedValue = e), this._elements && this._selectedValue && (this._selectedValue.length > 0 && (this._isFocused = !0), this._initElementsSelected()), this.requestUpdate("selectedValue", t);
  }
  get selectedValue() {
    return this._selectedValue || [];
  }
  set type(e) {
    const t = this._type;
    e === "default" || e === "green" ? this._type = e : this._type = "default", this.requestUpdate("type", t);
  }
  get type() {
    return this._type;
  }
  set boxStyle(e) {
    const t = this._boxStyle;
    this._boxStyle = e, this.requestUpdate("boxStyle", t);
  }
  get boxStyle() {
    return this._boxStyle || "";
  }
  set selectorStyle(e) {
    const t = this._selectorStyle;
    this._selectorStyle = e, this.requestUpdate("selectorStyle", t);
  }
  get selectorStyle() {
    return this._selectorStyle || "";
  }
  set labelSelectAll(e) {
    const t = this._labelSelectAll;
    e !== "" && (this._labelSelectAll = e), this.requestUpdate("labelSelectAll", t);
  }
  get labelSelectAll() {
    return this._labelSelectAll;
  }
  set labelDeselectAll(e) {
    const t = this._labelDeselectAll;
    e !== "" && (this._labelDeselectAll = e), this.requestUpdate("labelDeselectAll", t);
  }
  get labelDeselectAll() {
    return this._labelDeselectAll;
  }
  set selectAll(e) {
    const t = this._selectAll;
    this._selectAll = e, this.requestUpdate("selectAll", t);
  }
  get selectAll() {
    return this._selectAll;
  }
  set invalid(e) {
    const t = this._invalid;
    this._invalid = e, this.requestUpdate("invalid", t);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(e) {
    const t = this._helpText;
    this._helpText = e, this.requestUpdate("helpText", t);
  }
  get helpText() {
    return this._helpText;
  }
  set dropdownPlaceholder(e) {
    const t = this._dropdownPlaceholder;
    this._dropdownPlaceholder = e, this.requestUpdate("dropdownPlaceholder", t);
  }
  get dropdownPlaceholder() {
    return this._dropdownPlaceholder;
  }
  set placeholderEmpty(e) {
    const t = this._placeholderEmpty;
    this._placeholderEmpty = e, this.requestUpdate("placeholderEmpty", t);
  }
  get placeholderEmpty() {
    return this._placeholderEmpty;
  }
  set filterThreshold(e) {
    const t = this._filterThreshold;
    this._filterThreshold = e, this.requestUpdate("filterThreshold", t);
  }
  get filterThreshold() {
    return this._filterThreshold;
  }
  set searchThreshold(e) {
    const t = this._searchThreshold;
    this._searchThreshold = e, this.requestUpdate("searchThreshold", t);
  }
  get searchThreshold() {
    return this._searchThreshold;
  }
  set value(e) {
    e !== void 0 && this.requestUpdate();
  }
  get value() {
    var e;
    return ((e = this._input) == null ? void 0 : e.value) || "";
  }
  disconnectedCallback() {
    this._removeOutsideClickListener(), this.observer.disconnect(), this.visibleObserver.disconnect();
  }
  _addOutsideClickListener() {
    document.addEventListener("mousedown", this._handleOutsideClick);
  }
  _removeOutsideClickListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  _handleOutsideClick(e) {
    this._clickedOutsideDropdown(this, e);
  }
  _closeDropdown() {
    var e;
    this._removeOutsideClickListener(), this._showDropdown = !1, this._isFiltering = !1, this._isFocused = !1, (e = this._input) == null || e.blur(), this.requestUpdate(), setTimeout(() => {
      this.classList.add("animation-enabled");
    }, 400);
  }
  _getFilteredElements() {
    var t, s, i;
    const e = ((t = this._elements) == null ? void 0 : t.filter(
      (l) => {
        var o;
        return (o = this._selectedValue) == null ? void 0 : o.includes(l.value);
      }
    )) || [];
    if ((s = this._input) != null && s.value && this._input.value.length >= this._searchThreshold) {
      const l = u((i = this._input) == null ? void 0 : i.value);
      return this.advancedFilter ? this._applyAdvancedFilter(l, e) : this._applyDefaultFilter(l, e);
    }
    return this._elements;
  }
  _applyDefaultFilter(e, t) {
    var s;
    if (e) {
      const i = ((s = this._elements) == null ? void 0 : s.filter(
        (l) => {
          var o;
          return !((o = this._selectedValue) != null && o.includes(l.value)) && // Excluir elementos ya seleccionados del filtro
          u(l.label).includes(e);
        }
      )) || [];
      return [...t, ...i];
    }
  }
  _applyAdvancedFilter(e, t) {
    var l;
    const s = u(e).split(/\s+/).filter((o) => o.length >= this._searchThreshold);
    if (s.length === 0)
      return [...t];
    const i = ((l = this._elements) == null ? void 0 : l.filter(
      (o) => {
        var d;
        return !((d = this._selectedValue) != null && d.includes(o.value)) && // Excluir seleccionados
        s.every((a) => u(o.label).includes(a));
      }
    )) || [];
    return [...t, ...i];
  }
  async firstUpdated() {
    var e;
    try {
      await this.updateComplete, this.classList.add("animation-enabled"), this._createPopperDropdown(), this._input && (this._input.classList.add("dss-input-skip-native"), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input), this._checkInputAttributes()), this._elements && (this._filteredElements = this._getFilteredElements(), this._initElementsSelected()), this._openWithSearch && this._input && (this._input.value = "", (e = this._input) != null && e.getAttribute("placeholder") || this._input.setAttribute("placeholder", this._dropdownPlaceholder)), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _initElementsSelected() {
    this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []), this._checkInputOverflow();
  }
  _checkInputOverflow() {
    if (!this._input) return;
    const e = window.getComputedStyle(this._input), t = `${e.fontWeight} ${e.fontSize} ${e.fontFamily}`, i = document.createElement("canvas").getContext("2d");
    if (!i) return;
    i.font = t;
    const l = Number.parseFloat(e.paddingLeft), o = Number.parseFloat(e.paddingRight), d = this._input.offsetWidth - l - o, a = i.measureText(this._input.value).width;
    this._isTruncated = a > d;
  }
  _clickedOutsideDropdown(e, t) {
    var s, i, l;
    this._showDropdown && (t.composedPath().includes(e) || (this._input && (this._input.value = "", this._isFiltering = !1), (s = this._elements) != null && s.length && (this._initElementsSelected(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())), (i = this._elements) != null && i.length || ((l = this._input) == null || l.removeAttribute("placeholder"), this._placeHolder = ""), this._hidePlaceholder(), this._closeDropdown()));
  }
  _handleInput() {
    this._isFiltering = !0, this._filteredElements = this._getFilteredElements(), this.requestUpdate();
  }
  _handleBlurEsc() {
    this._readonly || this._openWithSearch || this._closeDropdown();
  }
  _handleBlurSelector(e, t) {
    var s;
    if (e !== t.target) {
      if (this._openWithSearch)
        return;
      (s = this._input) == null || s.focus(), this._handleBlurEsc(), this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []);
    }
  }
  _toggleDropdown() {
    var e, t, s, i, l;
    (e = this._elements) != null && e.length && this._showDropdown && this._input ? (this._initElementsSelected(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : (t = this._elements) != null && t.length && !this._showDropdown && this._input && (this._input.value = "", this._showPlaceholder(), (s = this._input) == null || s.focus()), this._showDropdown = !this._showDropdown, this._showDropdown && (this._updatePopperDropdown(), this._addOutsideClickListener()), !((i = this._elements) != null && i.length) && !this._showDropdown && ((l = this._input) == null || l.removeAttribute("placeholder"), this._placeHolder = "", this._isFiltering = !1, this._isFocused = !1), this.requestUpdate();
  }
  _getSelectedItems() {
    var e;
    return !this._selectedValue || this._selectedValue.length <= 0 ? [] : (e = this._elements) == null ? void 0 : e.filter((t) => {
      var s;
      return (s = this._selectedValue) == null ? void 0 : s.includes(t.value);
    });
  }
  _dispatchValueChange() {
    if (this._input) {
      const e = {
        detail: {
          inputValue: this._input.value,
          selectedValue: this._selectedValue,
          selectedItems: this._getSelectedItems()
        },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onInputDropdownChange", e));
    }
  }
  _onSelectorChanges(e) {
    !this._multiple && !this._openWithSearch && (this._isFiltering = !1);
    const t = e.detail;
    this._selectedValue = typeof t == "string" ? [e.detail] : e.detail, !this._multiple && !this._disabled && (this._openWithSearch || (this._closeDropdown(), this._initElementsSelected()), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _showSelectValuesInInput(e) {
    var i, l;
    !this._multiple && Array.isArray(e) && e.length > 1 && e.splice(1);
    const t = (i = this._elements) == null ? void 0 : i.filter((o) => e.includes(o.value));
    if (this._elements = [...this._copyElements], this._openWithSearch ? this._selectElements = 0 : this._selectElements = t != null && t.length ? t.length : 0, t && t.length > 0) {
      const o = this._elements.filter((d) => t.includes(d));
      o.push(...this._elements.filter((d) => !t.includes(d))), this._elements = [...o], this._filteredElements = this._elements;
    }
    if (!this._multiple && this._input && !this._isFiltering) {
      this._input.value = ((l = t == null ? void 0 : t[0]) == null ? void 0 : l.label) ?? "", this._deselectable && this._input.value === "" && (this._filteredElements = [...this._copyElements]);
      return;
    }
    const s = t == null ? void 0 : t.map((o) => o.label);
    this._input && !this._isFiltering && (this._input.value = (s == null ? void 0 : s.join(", ")) ?? "");
  }
  _checkInputAttributes() {
    var l, o, d, a, f, m;
    const e = (l = this._input) == null ? void 0 : l.getAttribute("placeholder");
    e && (this._placeHolder = e);
    const t = (o = this._input) == null ? void 0 : o.getAttribute("readonly");
    this._readonly = t !== null;
    const s = (d = this._input) == null ? void 0 : d.getAttribute("disabled");
    this._disabled = s !== null;
    const i = (a = this._input) == null ? void 0 : a.getAttribute("required");
    this._required = i !== null, (f = this._input) != null && f.value && ((m = this._input) == null ? void 0 : m.value) !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this.requestUpdate();
  }
  _handleFocusOut(e) {
    var o, d, a;
    const t = e.relatedTarget;
    if (t instanceof HTMLElement && t.contains(this)) return;
    const s = (o = this.shadowRoot) == null ? void 0 : o.querySelector("dss-selector"), i = (d = this.shadowRoot) == null ? void 0 : d.querySelector(".dss-input-dropdown__toggle"), l = (a = this.shadowRoot) == null ? void 0 : a.querySelector("dss-chip");
    t !== null && t !== this._input && t !== s && t !== i && t !== l && (this._selectedValue && this._initElementsSelected(), this._hidePlaceholder(), this._closeDropdown()), this.requestUpdate();
  }
  _handleKeyDown(e) {
    var t;
    (e == null ? void 0 : e.key) === "Enter" ? this._showDropdown ? this._keyboardFilterMatch() : this._handleClick() : (e == null ? void 0 : e.key) === "Escape" ? (this._closeDropdown(), this._initElementsSelected(), this._hidePlaceholder(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : (e == null ? void 0 : e.key) === "ArrowDown" || (e == null ? void 0 : e.key) === "ArrowUp" ? (e.preventDefault(), e.stopPropagation(), ((t = this.shadowRoot) == null ? void 0 : t.querySelector("#dss-selector")).moveFocus()) : (e == null ? void 0 : e.key) !== "Tab" && (this._showDropdown || this._handleClick()), this.requestUpdate();
  }
  _handleClick() {
    !this._disabled && !this._readonly && (this._input && (!this._openWithSearch && !this._isFiltering && (this._input.value = ""), this._showPlaceholder()), this._isFocused = !0, this._showDropdown = !0, this._updatePopperDropdown(), this._addOutsideClickListener(), this.requestUpdate());
  }
  _focusInput() {
    var e;
    (e = this._input) == null || e.focus(), this._handleClick();
  }
  _keyboardFilterMatch() {
    var s, i;
    if (!((s = this._filteredElements) == null ? void 0 : s.find(
      (l) => {
        var o;
        return l.label.toLowerCase() === ((o = this._input) == null ? void 0 : o.value.toLowerCase());
      }
    ))) return;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelector("#dss-selector");
    t && t.selectFirstMatch();
  }
  _showPlaceholder() {
    var e, t, s, i;
    !this._placeHolder && !((e = this._elements) != null && e.length) ? (t = this._input) == null || t.setAttribute("placeholder", this._placeholderEmpty) : !this._placeHolder && ((s = this._elements) != null && s.length) && ((i = this._input) == null || i.setAttribute("placeholder", this._dropdownPlaceholder));
  }
  _hidePlaceholder() {
    var e;
    this._placeHolder || (e = this._input) == null || e.removeAttribute("placeholder");
  }
  _handleValidity() {
    var t;
    const e = (t = this._input) == null ? void 0 : t.checkValidity();
    e !== void 0 && (this._inputValidity = e);
  }
  _cleanInput() {
    this._input && (this._isFiltering = !1, this._input.value = "", this._filteredElements = this._getFilteredElements(), this.requestUpdate());
  }
  _createPopperDropdown() {
    var s, i;
    if (this._openWithSearch) return;
    const e = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-input-group"), t = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-selector");
    e && t && (this._popperInstance = y(e, t, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "preventOverflow",
          options: {
            padding: { top: 8, bottom: 8, left: 8, right: 8 }
          }
        },
        {
          name: "matchWidth",
          enabled: !0,
          phase: "beforeWrite",
          fn({ state: l }) {
            l.elements.popper.style.width = `${e.offsetWidth}px`;
          },
          effect: ({ state: l }) => {
            l.elements.popper.style.width = `${e.offsetWidth}px`;
          }
        }
      ]
    }));
  }
  _updatePopperDropdown() {
    if (this.dropdownOffsetX && this.dropdownOffsetY) {
      const e = this.dropdownOffsetX, t = this.dropdownOffsetY;
      this._popperInstance.setOptions({
        modifiers: [
          {
            name: "popperOffsets",
            phase: "write",
            fn({ state: s }) {
              s.modifiersData.popperOffsets = {
                x: e,
                // Coordenada X deseada
                y: t
                // Coordenada Y deseada
              };
            }
          },
          {
            name: "applyStyles",
            phase: "write",
            // Se ejecuta al final
            fn({ state: s }) {
              var i, l, o, d;
              Object.assign(s.elements.popper.style, {
                position: s.options.strategy,
                left: `${(l = (i = s == null ? void 0 : s.modifiersData) == null ? void 0 : i.popperOffsets) == null ? void 0 : l.x}px`,
                top: `${(d = (o = s == null ? void 0 : s.modifiersData) == null ? void 0 : o.popperOffsets) == null ? void 0 : d.y}px`,
                transform: "none"
                // Desactiva transformaciones automáticas
              });
            }
          }
        ]
      });
    } else
      this._popperInstance.update();
    setTimeout(() => {
      this.classList.remove("animation-enabled");
    }, 400);
  }
  render() {
    return E(this);
  }
}
h([
  r({ type: Number })
], n.prototype, "dropdownOffsetX", 2);
h([
  r({ type: Number })
], n.prototype, "dropdownOffsetY", 2);
h([
  r({ type: String })
], n.prototype, "icon", 2);
h([
  r({ type: String })
], n.prototype, "placeHolder", 1);
h([
  r(p)
], n.prototype, "unorder", 1);
h([
  r({ type: Array })
], n.prototype, "elements", 1);
h([
  r(p)
], n.prototype, "multiple", 1);
h([
  r(p)
], n.prototype, "tick", 1);
h([
  r(p)
], n.prototype, "openWithSearch", 1);
h([
  r(p)
], n.prototype, "showDropdown", 1);
h([
  r(p)
], n.prototype, "deselectable", 1);
h([
  r({ type: Array })
], n.prototype, "selectedValue", 1);
h([
  r({ type: String })
], n.prototype, "type", 1);
h([
  r({ type: String })
], n.prototype, "boxStyle", 1);
h([
  r({ type: String })
], n.prototype, "selectorStyle", 1);
h([
  r({ type: String })
], n.prototype, "labelSelectAll", 1);
h([
  r({ type: String })
], n.prototype, "labelDeselectAll", 1);
h([
  r(p)
], n.prototype, "selectAll", 1);
h([
  r(p)
], n.prototype, "invalid", 1);
h([
  r({ type: String })
], n.prototype, "inputSize", 2);
h([
  r({ type: String })
], n.prototype, "helpText", 1);
h([
  r({ type: String })
], n.prototype, "dropdownPlaceholder", 1);
h([
  r({ type: String })
], n.prototype, "placeholderEmpty", 1);
h([
  r({ type: Number })
], n.prototype, "filterThreshold", 1);
h([
  r({ type: Number })
], n.prototype, "searchThreshold", 1);
h([
  r({ type: String })
], n.prototype, "value", 1);
h([
  r({ type: String })
], n.prototype, "dropdownPlacement", 2);
h([
  r(p)
], n.prototype, "dropdownFixed", 2);
h([
  r(p)
], n.prototype, "advancedFilter", 2);
export {
  n as InputDropdown
};
//# sourceMappingURL=input-dropdown.js.map
