import { nothing as a } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { ifDefined as C } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as d, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const y = d`dss-icon${e(i())}`, u = d`dss-icon-button${e(i())}`, S = d`dss-selector${e(i())}`, c = d`dss-chip${e(i())}`, f = d`dss-tooltip${e(i())}`, E = (s) => {
  var t, _, $, h, b, p, w, v;
  const D = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s._required,
    "dss-input-wrapper--disabled": s._disabled,
    [`dss-input-wrapper--${s.inputSize}`]: !!s.inputSize
  }, T = {
    "dss-input-group": !0,
    [`dss-input-group--${s.inputSize}`]: !!s.inputSize,
    "dss-input-group--invalid": s._invalid || !s._inputValidity,
    "dss-input-group--required": s._required,
    "dss-input-group--disabled": s._disabled,
    "dss-input-group--focused": ((t = s._input) == null ? void 0 : t.value) || s._placeHolder || s._isFocused,
    "dss-input-group--read-only": s._readonly,
    "dss-input-group--no-label": !s._label,
    "dss-input-group--read-only-empty": ((_ = s._input) == null ? void 0 : _.readOnly) && (($ = s._input) == null ? void 0 : $.placeholder) === "" && !((h = s._input) != null && h.value)
  }, k = {
    "dss-input-help": !0,
    "dss-input-help--invalid": s._invalid,
    "dss-input-help--disabled": s._disabled
  }, x = {
    "dss-selector": !s._openWithSearch,
    "dss-selector--visible": s._showDropdown,
    "dss-selector--open-with-search": s._openWithSearch,
    "dss-selector--disabled": s._disabled,
    "dss-selector-dropdown": !0,
    "dss-selector--md": !s._openWithSearch && s.inputSize === "md"
  };
  return l`

    <div class="${r(D)}" style=${C(s._boxStyle ?? void 0)}>

      ${s.inputSize === "sm" ? l`
        <div class="dss-wrapper-label">
          <slot name="label" @click=${s._focusInput}></slot>
        </div>
        ` : a}

      <div class="dss-input-dropdown-wrapper">
        <div class="${r(T)}">

          ${s.icon && s.icon !== "" ? l`
            <${y} icon="${s.icon}" class="dss-input-icon"></${y}>
            ` : a}

          <div class="dss-input-field">
            ${s.inputSize !== "sm" ? l`
              <slot name="label" @click=${s._focusInput}></slot>
              ` : a}
            <slot name="input"
              @click=${s._handleClick}
              @input=${s._handleInput}
              @focusin=${s._handleFocusIn}
              @focusout=${s._handleFocusOut}
              @keydown=${s._handleKeyDown}
            ></slot>

            ${!s._showDropdown && s._isTruncated && s._selectedValue && ((b = s._selectedValue) == null ? void 0 : b.length) === 1 ? l`
                <${f}>${(p = s._input) == null ? void 0 : p.value}</${f}>
              ` : null}


          </div>

          ${s.multiple && s._isTruncated && s._selectedValue && ((w = s._selectedValue) == null ? void 0 : w.length) > 1 ? l`
              <${c}
                label="${s._selectedValue.length}"
                size="xs"
                ?selected=${s._showDropdown}
                @onToggle=${s._toggleDropdown}>
              </${c}>
            ` : null}

          ${!s._openWithSearch && !s._readonly ? l`
                <${u}
                  class="dss-icon-button dss-input-dropdown__toggle"
                  size="md"
                  icon="${s._showDropdown ? "keyboard_arrow_up" : "keyboard_arrow_down"}"
                  label="${s._showDropdown ? "Tancar dropdown" : "Obrir dropdown"}"
                  hideTooltip
                  ariaExpanded="${s._showDropdown}"
                  variant="primary"
                  ?disabled=${s._disabled}
                  disableTabindex
                  @onClick=${s._toggleDropdown}
                ></${u}>
              ` : s._openWithSearch ? l`
                <${u}
                  class="dss-icon-button dss-input-dropdown__toggle"
                  size="md"
                  label="Esborra la selecció"
                  hideTooltip
                  icon="close"
                  variant="primary"
                  ?disabled=${s._disabled || s._readonly}
                  disableTabindex
                  @onClick=${s._cleanInput}
                ></${u}>
              ` : a}
          </div>

          <${S}
            ariaLabel="Llista d'elements"
            id="dss-selector"
            class="${r(x)}"
            .isOpen=${s._showDropdown}
            .multiple=${s._multiple}
            .tick=${s._tick}
            .deselectable=${s._deselectable}
            .disabled=${s._disabled}
            .elements=${s._filteredElements}
            .filtre=${(v = s._input) == null ? void 0 : v.value}
            .filterThreshold=${s._filterThreshold}
            .searchThreshold=${s._searchThreshold}
            .selectedValue=${s._selectedValue}
            .type=${s._type}
            .labelSelectAll=${s._labelSelectAll}
            .labelDeselectAll=${s._labelDeselectAll}
            .selectAll=${s._selectAll}
            ?advancedFilter=${s.advancedFilter}
            isDisplayed=${s._showDropdown}
            elementsSelected=${s._selectElements}
            boxStyle=${s._selectorStyle}
            boxShadow
            @onValueChange="${s._onSelectorChanges}"
            @keydown="${(g) => {
    g.key === "Escape" && s._handleBlurSelector(void 0, g);
  }}"
            @focusout=${s._handleFocusOut}
            ?readonly=${s._readonly}
          >
          </${S}>

      </div>

      ${s._helpText && !s._openWithSearch ? l`
            <div class="${r(k)}">
              <span>${s._helpText}</span>
            </div>
          ` : null}

    </div>
  `;
};
export {
  E as template
};
//# sourceMappingURL=input-dropdown.template.js.map
