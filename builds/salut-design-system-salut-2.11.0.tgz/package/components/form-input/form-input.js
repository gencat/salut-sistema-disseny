import { LitElement as v, unsafeCSS as c } from "lit";
import { query as _, property as i, state as a } from "lit/decorators.js";
import m from "../../shared/reset.style.css.js";
import { deleteSeparatorMask as f, applyMask as g } from "../../utils/mask.js";
import { booleanType as r, booleanConverter as l } from "../../utils/property-types.js";
import b from "./form-input.style.css.js";
import { template as S } from "./form-input.template.js";
var k = Object.defineProperty, e = (d, s, o, n) => {
  for (var p = void 0, h = d.length - 1, y; h >= 0; h--)
    (y = d[h]) && (p = y(s, o, p) || p);
  return p && k(s, o, p), p;
};
const u = class u extends v {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.hasActions = !1, this._defaultId = `dss-input-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._previousValue = null, this.internals = this.attachInternals();
  }
  static get styles() {
    return [c(m), c(b)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._stopHold();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(s) {
    s.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(s) {
    this.disabled = s;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(s) {
    this.value = s ?? "", this._input.value = s ?? "";
  }
  render() {
    return S(this);
  }
  _handleFocusin() {
    this._isFocused = !0;
  }
  _handleFocusout() {
    this._isFocused = !1;
  }
  _onInput(s) {
    const o = s.target;
    if (this.maskRegex && this.maskReplace) {
      this._previousValue && this._previousValue.length > (o == null ? void 0 : o.value.length) && (o.value = f(this._previousValue, o.value, this.maskReplace));
      const n = g(o.value, this.maskRegex, this.maskReplace, this.allowedChars);
      n !== o.value && (o.value = n);
    }
    this._previousValue = o.value, this.value = o.value, this._handleValidity(), this.dispatchEvent(new Event("input", { bubbles: !1, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    var o;
    const s = (o = this._input) == null ? void 0 : o.checkValidity();
    this.invalid = !s, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _stepUp() {
    var s;
    (s = this._input) == null || s.stepUp(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _stepDown() {
    var s;
    (s = this._input) == null || s.stepDown(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _onHold(s) {
    this._onHoldInterval = window.setInterval(() => {
      s === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this._onHoldInterval !== null && (clearInterval(this._onHoldInterval), this._onHoldInterval = null);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
};
u.formAssociated = !0;
let t = u;
e([
  _("input.dss-input")
], t.prototype, "_input");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i(r)
], t.prototype, "hideLabel");
e([
  i({ type: String })
], t.prototype, "name");
e([
  i({ type: String })
], t.prototype, "id");
e([
  i({ type: String })
], t.prototype, "type");
e([
  i({ type: String })
], t.prototype, "placeholder");
e([
  i({ type: String })
], t.prototype, "value");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "disabled");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "readonly");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "required");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "invalid");
e([
  i({ type: Number })
], t.prototype, "step");
e([
  i({ type: Number })
], t.prototype, "min");
e([
  i({ type: Number })
], t.prototype, "max");
e([
  i({ type: Number })
], t.prototype, "minLength");
e([
  i({ type: Number })
], t.prototype, "maxLength");
e([
  i({ type: String })
], t.prototype, "pattern");
e([
  i({ type: String })
], t.prototype, "inputmode");
e([
  i({ type: String })
], t.prototype, "autocapitalize");
e([
  i({ type: String })
], t.prototype, "autocomplete");
e([
  i(r)
], t.prototype, "autocorrect");
e([
  i(r)
], t.prototype, "autofocus");
e([
  i(r)
], t.prototype, "spellcheck");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "helpText");
e([
  i({ type: String })
], t.prototype, "maskRegex");
e([
  i({ type: String })
], t.prototype, "maskReplace");
e([
  i({ type: String })
], t.prototype, "allowedChars");
e([
  i({ type: String })
], t.prototype, "unit");
e([
  i({ type: String })
], t.prototype, "inputPrefix");
e([
  i(r)
], t.prototype, "hasActions");
e([
  a()
], t.prototype, "_isFocused");
e([
  a()
], t.prototype, "_isTruncated");
e([
  a()
], t.prototype, "_onHoldInterval");
e([
  a()
], t.prototype, "_previousValue");
export {
  t as FormInput
};
//# sourceMappingURL=form-input.js.map
