import { LitElement as h, unsafeCSS as m } from "lit";
import { property as o } from "lit/decorators.js";
import { itemListTemplate as l } from "./item-list.template.js";
import g from "../../foundations/icon/icon.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import a from "../decorative-icon/decorative-icon.style.css.js";
import w from "./item-list.style.css.js";
var _ = Object.defineProperty, y = Object.getOwnPropertyDescriptor, r = (p, t, e, s) => {
  for (var i = s > 1 ? void 0 : s ? y(t, e) : t, d = p.length - 1, c; d >= 0; d--)
    (c = p[d]) && (i = (s ? c(t, e, i) : c(i)) || i);
  return s && i && _(t, e, i), i;
};
class n extends h {
  constructor() {
    super(...arguments), this.tooltipFixed = !1, this._items = [], this._widget = !1, this._widgetActions = [], this._widgetIcons = [];
  }
  static get styles() {
    return [m(g), m(a), m(w)];
  }
  set items(t) {
    const e = this._items;
    this._items = t, this.requestUpdate("items", e);
  }
  get items() {
    return this._items;
  }
  set widget(t) {
    const e = this._widget;
    this._widget = t, this.requestUpdate("widget", e);
  }
  get widget() {
    return this._widget;
  }
  set widgetActions(t) {
    const e = this._widgetActions;
    this._widgetActions = t, this.requestUpdate("widgetActions", e);
  }
  get widgetActions() {
    return this._widgetActions;
  }
  set widgetIcons(t) {
    const e = this._widgetIcons;
    this._widgetIcons = t, this.requestUpdate("widgetIcons", e);
  }
  get widgetIcons() {
    return this._widgetIcons;
  }
  /* METHODS */
  _dispatchItemAction(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItem", e));
  }
  _dispatchItemChip(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItemChip", e));
  }
  _dispatchWidgetAction(t, e) {
    const s = {
      detail: { item: t, action: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickWidgetAction", s));
  }
  /* LIT LIFECYCLE */
  render() {
    return l(this);
  }
}
r([
  o(u)
], n.prototype, "tooltipFixed", 2);
r([
  o({ type: Array })
], n.prototype, "items", 1);
r([
  o({ type: Boolean })
], n.prototype, "widget", 1);
r([
  o({ type: Array })
], n.prototype, "widgetActions", 1);
r([
  o({ type: Array })
], n.prototype, "widgetIcons", 1);
export {
  n as ItemList
};
//# sourceMappingURL=item-list.js.map
