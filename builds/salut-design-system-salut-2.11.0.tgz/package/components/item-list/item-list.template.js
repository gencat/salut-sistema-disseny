import { unsafeStatic as a, literal as l, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
import { classMap as x } from "lit/directives/class-map.js";
import { ifDefined as d } from "lit/directives/if-defined.js";
const o = l`dss-badge${a(c())}`, r = l`dss-icon-badge${a(c())}`, $ = l`dss-tooltip${a(c())}`, n = l`dss-chip${a(c())}`, h = l`dss-icon${a(c())}`, p = l`dss-icon-button${a(c())}`, S = l`dss-decorative-icon${a(c())}`, B = (s) => i`
  <div
    class=${x({
  "dss-item-list": !0,
  "dss-item-list--widget": s._widget
})}
  >
    ${s._items.map((t) => {
  var b, v;
  const u = (e) => {
    const g = e.target, _ = g.scrollWidth > g.offsetWidth;
    g.setAttribute("data-truncated", _.toString());
  };
  return i`
        <div class="dss-item-list__item">
          ${s._widget && t.iconBadgeLeftState ? i`
                <div class="item-widget-badge">
                  <${r} size="sm"
                    state="${d(t.iconBadgeLeftState)}"
                    icon="${d(t.iconBadgeLeftIcon)}"
                    aria-label="${t.iconBadgeLabel}"
                  > 
                    ${t.iconBadgeLabel ? i`<${$} slot="tooltip" aria-hidden="true" ?tooltipFixed="${s.tooltipFixed}">${t.iconBadgeLabel}</${$}>` : null}
                  </${r}>  
                </div>
              ` : null}

          <div class="item-details">
            ${s._widget && t.date ? i`
                  <div class="item-details__date">
                    <span>${t.date}</span>
                  </div>
                ` : null}
            <div class="item-details__title">
              ${t.decorativeIcon ? i`
                    <${S} icon=${t.decorativeIcon} size="sm" state=${d(t.decorativeIconType)}
                    >
                    </${S}>
                  ` : null}
              <div class="item-details__title-text" @mouseenter=${u}>
                ${t.title}
                <${$} ?tooltipFixed="${s.tooltipFixed}" class="title-tooltip" slot="tooltip" aria-hidden="true">${t.title}</${$}>
              </div>
            </div>
            <div class="item-details__subtitle" @mouseenter=${u}>
              ${t.subtitle}
              <${$} ?tooltipFixed="${s.tooltipFixed}" class="title-tooltip" slot="tooltip" aria-hidden="true">${t.subtitle}</${$}>
            </div>
          </div>

          ${t.id ? i`
            <slot name="item-custom-${t.id}"></slot>
          ` : i`
            ${t.badgeText && !s._widget ? t.badgeIcon ? i`
                    <div class="item-action">
                      <${o}
                        text="${t.badgeText}"
                        icon="${t.badgeIcon}"
                        size="${t.badgeSize ? t.badgeSize : "sm"}"
                        state="${t.badgeState ? t.badgeState : "undeterminated"}"
                      >
                      </${o}>
                    </div>
                  ` : i`
                    <div class="item-action">
                      <${o}
                        text="${t.badgeText}"
                        size="${t.badgeSize ? t.badgeSize : "sm"}"
                        state="${t.badgeState ? t.badgeState : "undeterminated"}"
                      >
                      </${o}>
                    </div>
                  ` : null}
            
            ${t.chipText && !s._widget ? i`
                  
                  <${n} 
                    size="${t.chipSize ? t.chipSize : "xs"}" 
                    icon=${d(t.chipIcon)}
                    label="${t.chipText}" 
                    disableSelect
                    ?selected=${t.chipSelected}
                    @click=${() => s._dispatchItemChip(t)}></${n}>
                 
                ` : null}

            ${t.actionIcon && !s._widget ? i`
                  <div class="item-action">
                    <${p} 
                      size="md" 
                      icon=${t.actionIcon} 
                      label="${t.actionLabel}" 
                      variant=${t.actionIconType ? t.actionIconType : "primary"} 
                      @click=${() => s._dispatchItemAction(t)}>
                    </${p}>
                  </div>
                ` : null}
            ${s._widget ? i`
                  <div class="item-widget">
                    ${t.description ? i`
                          <div class="item-widget-description">
                            ${t.description}
                          </div>
                        ` : null}
                    ${(b = t.icons) != null && b.length ? i`
                          ${t.icons.map(
    (e) => i`
                              <${h} size="md" icon="${e.icon}"></${h}>
                            `
  )}
                        ` : null}
                    ${t.iconBadgeRightState ? i`
                          <${r}
                            size="sm"
                            state="${d(t.iconBadgeRightState)}"
                            icon="${d(t.iconBadgeRightIcon)}"
                          />
                        ` : null}
                     ${t.chipText ? i`
                          <${n} 
                            size="${t.chipSize ? t.chipSize : "xs"}" 
                            icon=${d(t.chipIcon)}
                            label="${t.chipText}" 
                            disableSelect
                            ?selected=${t.chipSelected}
                            @click=${() => s._dispatchItemChip(t)}></${n}>
                        ` : null}
                    ${(v = t.actions) != null && v.length ? i`
                          ${t.actions.map(
    (e) => i`
                              <${p}
                                label="${e.label}"
                                icon="${e.icon}"
                                variant="${e.type}"
                                @onClick=${() => s._dispatchWidgetAction(t, e.action)}
                              />
                            `
  )}
                        ` : null}
                  </div>
                ` : null}
          `}
        </div>
      `;
})}
  </div>
`;
export {
  B as itemListTemplate
};
//# sourceMappingURL=item-list.template.js.map
