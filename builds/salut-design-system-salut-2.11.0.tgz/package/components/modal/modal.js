import { LitElement as u, unsafeCSS as n } from "lit";
import { property as i } from "lit/decorators.js";
import y from "../../foundations/icon/icon.style.css.js";
import f from "../../shared/scrollbar.style.css.js";
import { booleanType as h } from "../../utils/property-types.js";
import g from "../button/button.style.css.js";
import S from "../icon-button/icon-button.style.css.js";
import v from "./modal.style.css.js";
import { modalTemplate as w } from "./modal.template.js";
var b = Object.defineProperty, C = Object.getOwnPropertyDescriptor, l = (c, e, t, s) => {
  for (var o = s > 1 ? void 0 : s ? C(e, t) : e, a = c.length - 1, r; a >= 0; a--)
    (r = c[a]) && (o = (s ? r(e, t, o) : r(o)) || o);
  return s && o && b(e, t, o), o;
};
const H = 250;
class d extends u {
  constructor() {
    super(), this.fullHeight = !1, this.fullWidth = !1, this.flexBody = !1, this.removeBodyPadding = !1, this.jcef = !1, this._open = !1, this._modalTitle = "Title", this._state = "", this._hideCloseIcon = !1, this._hasScroll = !1, this._modalStyle = void 0, this._modalHeader = null, this._modalFooter = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [
      n(y),
      n(f),
      n(g),
      n(S),
      n(v)
    ];
  }
  set open(e) {
    const t = this._open;
    this._open = e, this.requestUpdate("open", t);
  }
  get open() {
    return this._open;
  }
  set modalTitle(e) {
    const t = this._modalTitle;
    this._modalTitle = e, this.requestUpdate("modalTitle", t);
  }
  get modalTitle() {
    return this._modalTitle;
  }
  set state(e) {
    const t = this._state;
    this._state = e, this.requestUpdate("state", t);
  }
  get state() {
    return this._state;
  }
  set hideCloseIcon(e) {
    const t = this._hideCloseIcon;
    this._hideCloseIcon = e, this.requestUpdate("hideCloseIcon", t);
  }
  get hideCloseIcon() {
    return this._hideCloseIcon;
  }
  set hasScroll(e) {
    const t = this._hasScroll;
    this._hasScroll = e, this.requestUpdate("hasScroll", t);
  }
  get hasScroll() {
    return this._hasScroll;
  }
  set modalStyle(e) {
    const t = this._modalStyle;
    this._modalStyle = e, this.requestUpdate("modalStyle", t);
  }
  get modalStyle() {
    return this._modalStyle || "";
  }
  get _headerSlot() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="header"]')) || void 0;
    return e == null ? void 0 : e.assignedElements()[0];
  }
  get _footerSlot() {
    var t;
    const e = ((t = this.shadowRoot) == null ? void 0 : t.querySelector('slot[name="footer"]')) || void 0;
    return e == null ? void 0 : e.assignedElements()[0];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  updated(e) {
    e.has("open") && (this._open ? this._showDialog() : this._hideDialog());
  }
  _showDialog() {
    this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), document.addEventListener("keydown", this._handleKeydown), document.body.style.overflow = "hidden";
  }
  _hideDialog() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      this.classList.remove("hide"), this.style.visibility = "hidden", document.removeEventListener("keydown", this._handleKeydown);
    }, H), document.body.style.overflow = "";
  }
  _close() {
    this.open = !1, this._hideDialog(), this.requestUpdate();
    const e = new Event("onModalClosed");
    this.dispatchEvent(e);
    const t = new Event("onClose");
    this.dispatchEvent(t);
  }
  _getStateIcon() {
    let e = "";
    switch (this._state) {
      case "success":
        e = "check_circle";
        break;
      case "error":
        e = "cancel";
        break;
      case "alert":
        e = "report";
        break;
      case "info":
        e = "info";
        break;
      default:
        e = "";
    }
    return e;
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._close();
  }
  _handleOutsideClick(e) {
    var t;
    if (this._open) {
      const s = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-dialog"), o = e.composedPath();
      s && o.includes(this) && !o.includes(s) && this._close();
    }
  }
  fixEmptyFooter() {
    var t;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-dialog");
    e != null && e.classList.contains("dss-dialog--footer-empty") && this.requestUpdate();
  }
  _handleScroll(e) {
    var s, o, a, r;
    const t = e.target;
    t && (t.scrollTop > 0 ? (s = this._modalHeader) == null || s.classList.add("dss-dialog-header--scrolled") : (o = this._modalHeader) == null || o.classList.remove("dss-dialog-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? (a = this._modalFooter) == null || a.classList.add("dss-dialog-footer--scrolled") : (r = this._modalFooter) == null || r.classList.remove("dss-dialog-footer--scrolled"));
  }
  async firstUpdated() {
    var t, s, o, a, r;
    await this.updateComplete, this._footerSlot && this.fixEmptyFooter();
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-dialog-body");
    if (this._hasScroll && e) {
      e.addEventListener("scroll", this._handleScroll.bind(this)), this._modalHeader = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-dialog-header"), this._modalFooter = (o = this.shadowRoot) == null ? void 0 : o.querySelector(".dss-dialog-footer");
      const p = this._modalHeader ? this._modalHeader.clientHeight : 0, m = this._modalFooter ? this._modalFooter.clientHeight : 0, _ = (((r = (a = this.shadowRoot) == null ? void 0 : a.querySelector(".dss-dialog")) == null ? void 0 : r.clientHeight) || 0) - p - m;
      e.scrollHeight > _ && this._modalFooter.classList.add("dss-dialog-footer--scrolled");
    }
  }
  render() {
    return w(this);
  }
}
l([
  i(h)
], d.prototype, "open", 1);
l([
  i({ type: String })
], d.prototype, "modalTitle", 1);
l([
  i({ type: String })
], d.prototype, "state", 1);
l([
  i(h)
], d.prototype, "hideCloseIcon", 1);
l([
  i(h)
], d.prototype, "hasScroll", 1);
l([
  i({ type: String })
], d.prototype, "modalStyle", 1);
l([
  i(h)
], d.prototype, "fullHeight", 2);
l([
  i(h)
], d.prototype, "fullWidth", 2);
l([
  i(h)
], d.prototype, "flexBody", 2);
l([
  i(h)
], d.prototype, "removeBodyPadding", 2);
l([
  i(h)
], d.prototype, "jcef", 2);
export {
  d as Modal
};
//# sourceMappingURL=modal.js.map
