import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as o, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
const l = o`dss-decorative-icon${d($())}`, i = o`dss-icon-button${d($())}`, x = (a) => {
  const t = {
    dragover: a._dragOver,
    "upload-box--disabled": a._disabled,
    "upload-box--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  }, _ = {
    dragover: a._dragOver,
    "upload-box-help--disabled": a._disabled,
    "upload-box-help--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  };
  return s`
    <!-- Drag and drop -->
      <div class="upload-box-wrapper">
        <div
          class="upload-box ${e(t)}"
          @dragover="${a._onDragOver}"
          @dragleave="${a._onDragLeave}"
          @drop="${a._onDrop}"
        >
          <${l} icon=${a.dragAndDropIcon} size="lg" state="${a._hasMaxUploadFilesError ? "error" : "default"}" disabled=${a._disabled}></${l}>
          <div class="upload-box-cta">
            <div class="upload-box-cta__message">
              <span class="action" @click=${a._onClick}>
                ${a.fileExplorerMessage}
              </span>
              ${a.dragAndDropMessage}
            </div>
            <div class="upload-box-cta__requirements">
              ${a.filesFormatMessage}
            </div>
          </div>
          <slot name="input"></slot>
        </div>

        ${a.helpText || a._hasMaxUploadFilesError ? s`
            <div class="upload-box-help ${e(_)}">
              ${a._hasMaxUploadFilesError ? s`${a.maxUploadFilesMessage}` : s`${a.helpText}`}
            </div>
          ` : null}
        
      </div>

      <!--Uploaded files -->
      <div class="upload-box-files">
        <ul class="file-list">
          ${a._files.map(
    (r, c) => s`
              <li class="file">
                ${a._fileErrors[r.name] ? s`
                      <${l} icon="error_outline" size="sm" state="error"></${l}>
                    ` : r.status === "loading" ? s`
                      <${l} icon="downloading" size="sm" state="info"></${l}>
                    ` : s`
                      <${l} icon="check" size="sm" state="success"></${l}>
                    `}
                <div class="file-description">
                  <p class="file-description__name">

                    ${a._fileErrors[r.name] ? s`
                        ${r.name}
                      ` : r.status === "loading" ? s`${r.name} <span class="dot-flashing"></span>` : a.disableOpenFile ? s`
                            ${r.name}
                          ` : s`
                            <span class="upload-box__file-link" @click="${() => a._dispatchOpenFile(r)}">
                              ${r.name}
                            </span>
                          `}

                   
                  </p>
                  ${a._fileErrors[r.name] ? s`
                        <p class="file-description__error">
                          ${a._fileErrors[r.name]}
                        </p>
                      ` : ""}
                </div>
                <div class="file-actions">
                  ${r.status === "loading" ? s`
                        <${i}
                        size="sm"
                        icon="block"
                        variant="error"
                        label="Cancel·lar"
                        ></${i}>
                      ` : s`
                        ${r.status === "error" ? s`
                              <${i}
                              size="sm"
                              label="Recarregar"
                              icon="restart_alt"
                              variant="primary"
                              @click="${() => a._reloadFile(r)}"
                              ></${i}>
                            ` : s``}
                        <${i}
                        size="sm"
                        icon="delete"
                        label="Eliminar"
                        variant="error"
                        @click="${() => a._removeFile(c)}"
                        ></${i}>
                      `}
                </div>
              </li>
            `
  )}
        </ul>
      </div>
  `;
};
export {
  x as template
};
//# sourceMappingURL=upload-box.template.js.map
