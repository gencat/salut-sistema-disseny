import { LitElement as _, unsafeCSS as a } from "lit";
import { property as i } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import p from "./badge.states.css.js";
import f from "./badge.style.css.js";
import { template as g } from "./badge.template.js";
var m = Object.defineProperty, y = Object.getOwnPropertyDescriptor, s = (l, t, e, d) => {
  for (var n = d > 1 ? void 0 : d ? y(t, e) : t, h = l.length - 1, c; h >= 0; h--)
    (c = l[h]) && (n = (d ? c(t, e, n) : c(n)) || n);
  return d && n && m(t, e, n), n;
};
class o extends _ {
  constructor() {
    super(...arguments), this.tooltipPosition = "top", this.width = void 0, this.showIcon = !1, this._icon = "warning", this._iconSize = "sm", this._iconFill = !1, this._size = "sm", this._text = "", this._state = "", this._disabled = !1, this._isIconDefined = !1, this._outlined = !1, this._dot = !1, this._hideIcon = !1, this._isFirstUpdated = !0, this._isTextTruncated = !1;
  }
  static get styles() {
    return [a(u), a(f), a(p)];
  }
  get _tooltip() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="tooltip"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this._isIconDefined = !0, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  set size(t) {
    const e = this._size;
    this._size = t, t === "xl" ? this._iconSize = "md" : this._iconSize = "sm", this.requestUpdate("size", e);
  }
  get size() {
    return this._size;
  }
  set text(t) {
    const e = this._text;
    this._text = t, this.requestUpdate("text", e);
  }
  get text() {
    return this._text;
  }
  set state(t) {
    const e = this._state;
    this._state = t, this._generateDefaultIcon(t), this.requestUpdate("state", e);
  }
  get state() {
    return this._state;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set outlined(t) {
    const e = this._outlined;
    this._outlined = t, this.requestUpdate("outlined", e);
  }
  get outlined() {
    return this._outlined;
  }
  set dot(t) {
    const e = this._dot;
    this._dot = t, this.requestUpdate("dot", e);
  }
  get dot() {
    return this._dot;
  }
  set hideIcon(t) {
    const e = this._hideIcon;
    this._hideIcon = t, this.requestUpdate("hideIcon", e);
  }
  get hideIcon() {
    return this._hideIcon;
  }
  async firstUpdated() {
    var t;
    if (await this.updateComplete, this.width) {
      const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-badge");
      e && (e.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("text") && this._checkTextTruncated(), !this._isFirstUpdated && t.has("state") && (this._iconFill = !1, this._generateDefaultIcon(this.state));
  }
  _checkTextTruncated() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector(".dss-badge__text");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  _updateIconFill(t) {
    this._iconFill = !t.includes("low") || t === "correct";
  }
  _generateDefaultIcon(t) {
    t && !this._isIconDefined && (t.includes("danger") ? (this._icon = "warning", this._updateIconFill(t)) : t.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(t)) : t.includes("slight") ? (this._icon = "error", this._updateIconFill(t)) : t.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(t)) : t.includes("undeterminated") ? this._icon = "circle" : t.includes("undetermined") ? this._icon = "circle" : t.includes("critic") ? this._icon = "cancel" : t.includes("alert") ? this._icon = "report" : t.includes("ideal") ? this._icon = "check_circle" : t.includes("info") ? this._icon = "info" : t.includes("neutral") && (this._icon = "circle"));
  }
  render() {
    return g(this);
  }
}
s([
  i({ type: String })
], o.prototype, "icon", 1);
s([
  i({ type: String })
], o.prototype, "size", 1);
s([
  i({ type: String })
], o.prototype, "text", 1);
s([
  i({ type: String })
], o.prototype, "state", 1);
s([
  i(r)
], o.prototype, "disabled", 1);
s([
  i(r)
], o.prototype, "outlined", 1);
s([
  i(r)
], o.prototype, "dot", 1);
s([
  i(r)
], o.prototype, "hideIcon", 1);
s([
  i({ type: String })
], o.prototype, "tooltipPosition", 2);
s([
  i({ type: String })
], o.prototype, "width", 2);
s([
  i(r)
], o.prototype, "showIcon", 2);
export {
  o as Badge
};
//# sourceMappingURL=badge.js.map
