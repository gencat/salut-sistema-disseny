import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as e, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const a = e`dss-icon${i(l())}`, t = e`dss-tooltip${i(l())}`, h = (s) => {
  const _ = {
    "dss-badge": !0,
    [`dss-badge--${s._size}`]: !!s._size,
    [`dss-badge--${s._state}`]: !!s._state && !s._outlined,
    [`dss-badge--${s._state}-outlined`]: !!s._state && !s._outlined,
    "dss-badge--danger": s._state === "danger",
    "dss-badge--danger-low": s._state === "danger-low",
    "dss-badge--danger-high": s._state === "danger-high",
    "dss-badge--moderate": s._state === "moderate",
    "dss-badge--moderate-low": s._state === "moderate-low",
    "dss-badge--moderate-high": s._state === "moderate-high",
    "dss-badge--slight": s._state === "slight",
    "dss-badge--slight-low": s._state === "slight-low",
    "dss-badge--slight-high": s._state === "slight-high",
    "dss-badge--correct": s._state === "correct",
    "dss-badge--undeterminated": s._state === "undeterminated",
    "dss-badge--critic": s._state === "critic" && !s._outlined,
    "dss-badge--critical": s._state === "critical" && !s._outlined,
    "dss-badge--critic-outlined": s._state === "critic" && s._outlined,
    "dss-badge--critical-outlined": s._state === "critical" && s._outlined,
    "dss-badge--alert": s._state === "alert" && !s._outlined,
    "dss-badge--alert-outlined": s._state === "alert" && s._outlined,
    "dss-badge--ideal": s._state === "ideal" && !s._outlined,
    "dss-badge--ideal-outlined": s._state === "ideal" && s._outlined,
    "dss-badge--info": s._state === "info" && !s._outlined,
    "dss-badge--info-outlined": s._state === "info" && s._outlined,
    "dss-badge--info-alt": s._state === "info-alt" && !s._outlined,
    "dss-badge--info-alt-outlined": s._state === "info-alt" && s._outlined,
    "dss-badge--neutral": s._state === "neutral" && !s._outlined,
    "dss-badge--neutral-outlined": s._state === "neutral" && s._outlined,
    "dss-badge--disabled": s._disabled,
    "dss-badge--dot": s._dot
  };
  return d`
		<div class="${g(_)}">
			${!s.hideIcon && s._size !== "sm" || s.showIcon && s._size === "sm" ? d`
					<${a} class="dss-badge-button__icon" icon="${s._icon}" size="${s._iconSize}" ?fill="${s._iconFill}"></${a}>
				` : null}
			<span class="dss-badge__text">${s._text}</span>
			${s._isTextTruncated ? d`<${t} position="${s.tooltipPosition}">${s._text}</${t}>` : d`<slot name="tooltip"></slot>`}
		</div>	
  `;
};
export {
  h as template
};
//# sourceMappingURL=badge.template.js.map
