import { nothing as o } from "lit";
import { classMap as n } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as l, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
import { checkTextTruncate as t } from "../../utils/helpers.js";
const u = l`dss-icon-button${i(r())}`, d = l`dss-button${i(r())}`, a = l`dss-tooltip${i(r())}`, v = (s) => e`
  <div
    class=${n({
  "dss-header-menu-professional": !0,
  "dss-header-menu-professional--jcef": s.jcef
})}
  >
    <div class="dss-header-menu-professional-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-professional-details">
      <div class="dss-header-menu-professional-details__name">
        ${s.name}
      </div>
      <div class="dss-header-menu-professional-details__info">
        ${s.center ? e`
              <span
                class="dss-header-menu-professional-details__info-label dss-header-menu-professional-details__info-label--center"
                >${s.center}</span
              >
            ` : null}
      </div>
    </div>
    <${u} 
      icon="${s._toggleIcon}"
      label="${s._toggleLabel}"
      variant="primary"
      @onClick="${s._toggleDropdown}"
      ?disabled=${s.disabled}>
    </${u}>
   
    <div
      class=${n({
  "dss-header-menu-professional-dropdown": !0,
  "dss-header-menu-professional-dropdown--expanded": !!s._showDropdown,
  "dss-header-menu-professional-dropdown--hide-details": !!s.hideDropdownDetails
})}
    >
      <div class="dss-header-menu-professional-dropdown__info">
        <div class="dss-header-menu-professional-dropdown__details">
          <div class="dss-header-menu-professional-dropdown__details-title">
            ${s.infoLabel}
          </div>

          <div class="dss-header-menu-professional-dropdown__details-content">
            <div class="dss-header-menu-professional-dropdown__details-subtitle">
              ${s.name}
            </div>

            ${s.center ? e`
                  <div class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${t}>
                    ${s.center}
                    <${a} class="description-tooltip" aria-hidden="true">
                      ${s.center}
                    </${a}>
                  </div>
                ` : null}
            ${s.collegiate ? e`
                  <p class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${t}>
                    ${s.collegiateLabel} ${s.collegiate}
                    <${a} class="description-tooltip" aria-hidden="true">
                      ${s.collegiate}
                    </${a}>
                  </p>
                ` : null}
          </div>

          
        </div>

        ${s.hideViewDetails ? o : e`
            <${d}
              class="dss-header-menu-professional-dropdown__view-details-button"
              variant="link"
              size="md"
              label="${s.detailsLabel}"
              fullWidth
              @click="${s._handleViewDetails}">
            </${d}>
					`}

        <div class="dss-header-menu-professional__divider"></div>

        ${s.hideDropdownPreferences ? null : e`
              <div class="dss-header-menu-professional-dropdown__preferences">
                <div class="dss-header-menu-professional-dropdown__details-title">
                  ${s.preferencesLabel}
                </div>
                <div class="dss-header-menu-professional-dropdown__preferences__options">
                  <slot></slot>
                </div>
              </div>
            `}
      </div>

      <div class="dss-header-menu-professional-dropdown__actions">
        ${s.showLogout ? e`
          <${d}
            variant="secondary"
            label="${s.logoutLabel}"
            fullWidth
            @onClick="${s._handleLogout}"
          ></${d}>
          ` : o}
        
        <${d}
          label="${s.exitLabel}"
          fullWidth
          @onClick="${s._handleExit}"
        ></${d}>
      </div>

      
    </div>
    
  </div>
`;
export {
  v as headerMenuProfessionalTemplate
};
//# sourceMappingURL=header-menu-professional.template.js.map
