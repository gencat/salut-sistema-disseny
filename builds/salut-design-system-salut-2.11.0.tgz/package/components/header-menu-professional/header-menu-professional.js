import { LitElement as g, unsafeCSS as c } from "lit";
import { property as e } from "lit/decorators.js";
import w from "../../foundations/icon/icon.style.css.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import _ from "./header-menu-professional.style.css.js";
import { headerMenuProfessionalTemplate as b } from "./header-menu-professional.template.js";
var D = Object.defineProperty, t = (p, n, s, a) => {
  for (var i = void 0, r = p.length - 1, d; r >= 0; r--)
    (d = p[r]) && (i = d(n, s, i) || i);
  return i && D(n, s, i), i;
};
class o extends g {
  constructor() {
    super(), this.disabled = !1, this.name = void 0, this.center = void 0, this.collegiate = void 0, this.infoLabel = "Les meves dades", this.collegiateLabel = "Col·legiat nº", this.preferencesLabel = "Preferences de treball", this.detailsLabel = "Veure més detalls", this.detailsHref = void 0, this.detailsIcon = "info", this.detailsIconPosition = "left", this.showLogout = !1, this.logoutLabel = "Tancar sessió", this.exitLabel = "Sortir", this.hideViewDetails = !1, this.hideDropdownDetails = !1, this.hideDropdownPreferences = !1, this.jcef = !1, this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Tancar menú", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [c(y), c(w), c(_)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Obrir menú del professional" : "Tancar menú del professional", this._showDropdown && setTimeout(() => {
      this._updatePreferencesDropdownPosition();
    }, 100), this.requestUpdate();
  }
  _handleLogout() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("onLogout", { bubbles: !1, composed: !1 }));
  }
  _handleExit() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("onExit", { bubbles: !1, composed: !1 }));
  }
  _handleDocumentClick(n) {
    this._clickedOutside(this, n);
  }
  _handleViewDetails() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("onViewDetails", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _clickedOutside(n, s) {
    s.composedPath().includes(n) || this._showDropdown && this._toggleDropdown();
  }
  _updatePreferencesDropdownPosition() {
    var i, r;
    const n = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-header-menu-professional-dropdown"), s = (r = this.shadowRoot) == null ? void 0 : r.querySelector(
      ".dss-header-menu-professional-dropdown__preferences__options"
    ), a = s == null ? void 0 : s.querySelector("slot");
    if (s && a) {
      const d = a.assignedElements({ flatten: !0 });
      for (const h of d) {
        const f = s.offsetLeft, u = n.offsetTop, m = h.offsetTop - u + 44;
        h.setAttribute("dropdownOffsetX", f.toString()), h.setAttribute("dropdownOffsetY", m.toString());
      }
    }
  }
  render() {
    return b(this);
  }
}
t([
  e(l)
], o.prototype, "disabled");
t([
  e({ type: String })
], o.prototype, "name");
t([
  e({ type: String })
], o.prototype, "center");
t([
  e({ type: String })
], o.prototype, "collegiate");
t([
  e({ type: String })
], o.prototype, "infoLabel");
t([
  e({ type: String })
], o.prototype, "collegiateLabel");
t([
  e({ type: String })
], o.prototype, "preferencesLabel");
t([
  e({ type: String })
], o.prototype, "detailsLabel");
t([
  e({ type: String })
], o.prototype, "detailsHref");
t([
  e({ type: String })
], o.prototype, "detailsIcon");
t([
  e({ type: String })
], o.prototype, "detailsIconPosition");
t([
  e(l)
], o.prototype, "showLogout");
t([
  e({ type: String })
], o.prototype, "logoutLabel");
t([
  e({ type: String })
], o.prototype, "exitLabel");
t([
  e(l)
], o.prototype, "hideViewDetails");
t([
  e(l)
], o.prototype, "hideDropdownDetails");
t([
  e(l)
], o.prototype, "hideDropdownPreferences");
t([
  e(l)
], o.prototype, "jcef");
export {
  o as HeaderMenuProfessional
};
//# sourceMappingURL=header-menu-professional.js.map
