const e = ":host{display:block;width:100%;height:100%}.dss-custom-table{display:flex;flex-direction:column;height:100%;width:100%;overflow:hidden}.dss-custom-table-header{position:relative;z-index:300;background-color:var(--color-white)}.dss-custom-table-header,.dss-custom-table-footer{flex:0 1 auto}.dss-custom-table-body{flex:1 1 auto;overflow:auto}.table-footer{display:flex;justify-content:space-between;align-items:center;gap:var(--dss-spacing-xs);padding:var(--dss-spacing-md);border-top:var(--dss-border-width-sm) solid var(--color-neutral-100);margin-top:var(--dss-spacing-md)}.table-footer-description{color:var(--color-neutral-900);font-size:16px;font-weight:var(--font-bold)}::slotted(.table-footer-actions){display:flex;justify-content:flex-end;align-items:center;gap:var(--dss-spacing-xs)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}";
export {
  e as default
};
//# sourceMappingURL=custom-table.style.css.js.map
