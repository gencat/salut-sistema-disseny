import { nothing as t } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as a, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
const d = a`dss-icon${l(c())}`, m = a`dss-notification-badge${l(c())}`, f = a`dss-decorative-icon${l(c())}`, r = a`dss-tooltip${l(c())}`, I = (s) => {
  var n;
  return i`
  <div class="dss-list-menu">
    ${s.title || s.description ? i`
      <div class="dss-list-menu-header">
        <h4 class="dss-list-menu-header-title" id="menu-title">
          ${s.icon ? i`<${f} icon="${s.icon}" state="default" size="md" />` : ""}
          ${s.title}
        </h4>
        <p class="dss-list-menu-header-description" id="menu-description">
          ${s.description}
        </p>
      </div>
    ` : t}
    
    <ul class="dss-list-menu-nav" role="menu" aria-labelledby="menu-title" aria-describedby="menu-description">
      ${(n = s.items) == null ? void 0 : n.map((e, o) => {
    const $ = {
      "dss-list-menu-item": !0,
      selected: s.selectedItemIndex === o,
      disabled: !!e.disabled
    };
    return i`
          <li
            class="${u($)}"
            role="menuitem"
            aria-disabled="${e.disabled ? "true" : "false"}"
            tabindex="${e.disabled ? -1 : 0}"
            @click="${() => s.handleItemClick(o)}"
          >
            <${d} icon="${e.icon}"></${d}>
            <span class="dss-list-menu-item__content-text">${e.label}</span>
            <div class="notification-placeholder">
              ${e.hasNotification ? i`<${m} dot state="succes" type="default" />` : t}
            </div>
            ${e.hasAction ? i`<${d} icon="chevron_right"></${d}>` : t}
            ${e.isTruncated ? i`<${r}>${e.label}</${r}>` : t}
          </li>
        `;
  })}
    </ul>
  </div>
`;
};
export {
  I as template
};
//# sourceMappingURL=list-menu.template.js.map
