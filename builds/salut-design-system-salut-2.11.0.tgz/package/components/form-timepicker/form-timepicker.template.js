import { nothing as s } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
import { ifDefined as k } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as r, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const b = r`dss-icon${l(u())}`, a = r`dss-button${l(u())}`, _ = r`dss-tooltip${l(u())}`, h = (i) => {
  var t, p, $, v, w;
  return d`
      <div class="${e({
    "dss-input-group": !0,
    [`dss-input-group--${i.size}`]: !!i.size,
    "dss-input-group--invalid": i.invalid,
    "dss-input-group--required": i.required,
    "dss-input-group--disabled": i.disabled,
    "dss-input-group--focused": i.value || ((t = i._input) == null ? void 0 : t.value) || i.placeholder || i._isFocused,
    "dss-input-group--read-only": i.readonly,
    "dss-input-group--no-label": i.hideLabel,
    "dss-input-group--numeric": i.type === "number",
    "dss-input-group--read-only-empty": ((p = i._input) == null ? void 0 : p.readOnly) && (($ = i._input) == null ? void 0 : $.placeholder) === "" && !((v = i._input) != null && v.value)
  })}">
      ${i.icon ? d`
        <${b} icon="${i.icon}" class="dss-input-icon"></${b}>
        ` : s}
      <div class="dss-input-field">
        ${i.size !== "sm" && !i.hideLabel ? d`
          <label class="dss-label" for=${i._getEffectiveId()}>${i.label}</label>
          ` : s}
        <input
          class="dss-input"
          .type="${i.type}"
          .name="${i.name ?? s}"
          id="${i._getEffectiveId()}"
          .placeholder=${i.placeholder}
          .value=${i.value}
          ?disabled=${i.disabled}
          ?readonly=${i.readonly}
          ?required=${i.required}
          ?autofocus=${i.autofocus}
          spellcheck=${i.spellcheck ? "true" : "false"}
          autocorrect=${i.autocorrect ? "on" : "off"}
          autocomplete=${i.autocomplete}
          autocapitalize=${i.autocapitalize}
          min=${i.min ?? s}
          max=${i.max ?? s}
          step=${i.step ?? s}
          minlength=${i.minLength ?? s}
          maxlength=${i.maxLength ?? s}
          pattern=${i.pattern ?? s}
          inputmode=${i.inputmode ?? s}
          aria-label="${i.hideLabel ? i.label : s}"
          @click=${i._handleClick}
          @input=${i._handleInput}
          @focusin=${i._handleFocusin}
          @focusout=${i._handleFocusout}
          @keydown=${i._handleKeyDown}
        />
      </div>
      ${i._isTruncated ? d`
        <${_}>${(w = i._input) == null ? void 0 : w.value}</${_}>
        ` : s}
    </div>
  `;
}, y = (i) => d`
  <div class="${e({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": i.required,
  "dss-input-wrapper--disabled": i.disabled,
  [`dss-input-wrapper--${i.size}`]: !!i.size,
  "dss-input-wrapper--no-label": i.hideLabel
})}">

    ${i.size === "sm" && !i.hideLabel ? d`
      <div class="dss-wrapper-label">
        <label class="dss-label" for=${i._getEffectiveId()}>${i.label}</label>
      </div>
      ` : s}

    ${i.dropdown === "" ? d`
        ${h(i)}
      ` : d`
        <div class="dss-input-dropdown-wrapper"
          role="combobox"
          aria-controls="timepicker-options"
          aria-expanded=${k(i.showDropdown)}
        >
          ${h(i)}

          <div
            id="timepicker-options"
            class="${e({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--list": !0,
  "dss-timepicker-dropdown--open": i.showDropdown,
  "dss-timepicker-dropdown--lg": i.size === "lg",
  "dss-timepicker-dropdown--md": i.size !== "lg",
  "dss-timepicker-dropdown--list--visible": i.showDropdown && i.dropdown === "list"
})}"
            role="listbox"
            aria-label="Timepicker Options"
          >
            <div class="dss-timepicker-dropdown__container">
              ${d`${i._generateTimeListOptionsHTML(i._timeListOptions, i.customTimeListOptions)}`}
            </div>
          </div>

          <div
            id="timepicker-options"
            class="${e({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--manual": !0,
  "dss-timepicker-dropdown--open": i.showDropdown,
  "dss-timepicker-dropdown--lg": i.size === "lg",
  "dss-timepicker-dropdown--md": i.size !== "lg",
  "dss-timepicker-dropdown--manual--visible": i.showDropdown && i.dropdown === "manual"
})}"
            role="listbox"
            aria-label="Timepicker Options"
          >
            <div class="dss-timepicker-dropdown__manual">
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--hour"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualHour", i._timeManualHourOptions)}
              </div>
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--minute"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualMinutes", i._timeManualMinutesOptions)}
              </div>
            </div>
            <div class="dss-timepicker-dropdown__actions">
              <${a} 
                label="Cancel-lar"
                size="md"
                variant="secondary"
                @onClick=${i._timeManualSelectorCancel}
              ></${a}>
              <${a}
                label="Seleccionar"
                size="md"
                variant="primary"
                ?disabled=${i._checkDisableTimeManualSelector()}
                @onClick=${i._timeManualSelectorAccept}
              ></${a}>
            </div>
          </div>
  
        </div>
      `}

    ${i._helpText ? d`
      <div class="${e({
  "dss-input-help": !0,
  "dss-input-help--invalid": i.invalid,
  "dss-input-help--disabled": i.disabled
})}">
        <span>${i._helpText}</span>
      </div>
      ` : s}
  </div>  
`;
export {
  y as template
};
//# sourceMappingURL=form-timepicker.template.js.map
