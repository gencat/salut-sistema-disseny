import { LitElement as u, unsafeCSS as d } from "lit";
import { queryAssignedElements as p, property as r } from "lit/decorators.js";
import { getCustomElementSuffix as f } from "../../api/custom-element-scope.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as b, booleanConverter as v } from "../../utils/property-types.js";
import k from "./form-checkbox-group.style.css.js";
import { template as _ } from "./form-checkbox-group.template.js";
var C = Object.defineProperty, i = (c, e, t, o) => {
  for (var a = void 0, n = c.length - 1, l; n >= 0; n--)
    (l = c[n]) && (a = l(e, t, a) || a);
  return a && C(e, t, a), a;
};
const y = `dss-form-checkbox${f()}`, h = class h extends u {
  constructor() {
    super(), this.name = "checkbox-group-host", this.label = "", this.hideLabel = !1, this.value = [], this.orientation = "vertical", this.disabled = !1, this._onCheckboxChange = (e) => {
      const t = e.target, o = t.value;
      t.checked ? this.value.includes(o) || (this.value = [...this.value, o]) : this.value = this.value.filter((a) => a !== o), this._emitChange();
    }, this.internals = this.attachInternals();
  }
  static get styles() {
    return [d(m), d(k)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("change", this._onCheckboxChange);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("change", this._onCheckboxChange);
  }
  updated(e) {
    if (e.has("value")) {
      const t = new FormData();
      this.value.forEach((o) => t.append(this.name, o)), this.internals.setFormValue(t), this._updateCheckedState();
    }
    e.has("name") && this._updateNameState(), e.has("disabled") && this._updateDisabledState();
  }
  formResetCallback() {
    this.value = [];
  }
  formStateRestoreCallback(e) {
    this.value = e ? e.split(",") : [];
  }
  render() {
    return _(this);
  }
  _emitChange() {
    const e = {
      detail: { value: this.value },
      bubbles: !1,
      composed: !0
    }, t = new CustomEvent("value-changed", e);
    this.dispatchEvent(t);
  }
  _updateCheckedState() {
    if (this._checkboxes)
      for (const e of this._checkboxes)
        e.checked || (e.checked = this.value.includes(e.value));
  }
  _updateNameState() {
    if (this._checkboxes)
      for (const e of this._checkboxes)
        e.name = this.name;
  }
  _updateDisabledState() {
    this._checkboxes && this._checkboxes.forEach((e) => {
      e.disabled = this.disabled;
    });
  }
};
h.formAssociated = !0;
let s = h;
i([
  p({ selector: y.toString() })
], s.prototype, "_checkboxes");
i([
  r({ type: String })
], s.prototype, "name");
i([
  r({ type: String })
], s.prototype, "label");
i([
  r(b)
], s.prototype, "hideLabel");
i([
  r({ type: Array })
], s.prototype, "value");
i([
  r({ type: String })
], s.prototype, "orientation");
i([
  r({ converter: v, reflect: !0 })
], s.prototype, "disabled");
export {
  s as FormCheckboxGroup
};
//# sourceMappingURL=form-checkbox-group.js.map
