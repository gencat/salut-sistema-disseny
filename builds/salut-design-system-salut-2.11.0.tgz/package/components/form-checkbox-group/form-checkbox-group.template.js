import { html as s } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
const a = (o) => s`
  <div class="${l({
  "dss-checkbox-group": !0,
  [`dss-checkbox-group--${o.orientation}`]: !0
})}"
    role="radiogroup"
    aria-labelledby="checkbox-group-label"
  >
    <div id="checkbox-group-label" class="${l({
  "dss-checkbox-group__label": !0,
  "dss-checkbox-group__label--sr-only": o.hideLabel
})}">
      ${o.label}
    </div>
    <div class="dss-checkbox-group__options">
      <slot></slot>
    </div>
  </div>  
`;
export {
  a as template
};
//# sourceMappingURL=form-checkbox-group.template.js.map
