import { LitElement as h, unsafeCSS as d } from "lit";
import { property as e } from "lit/decorators.js";
import c from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import y from "./header-menu-patient.style.css.js";
import { headerMenuPatientTemplate as m } from "./header-menu-patient.template.js";
var u = Object.defineProperty, t = (r, o, s, _) => {
  for (var n = void 0, a = r.length - 1, l; a >= 0; a--)
    (l = r[a]) && (n = l(o, s, n) || n);
  return n && u(o, s, n), n;
};
class i extends h {
  constructor() {
    super(), this.disabled = !1, this.variant = "default", this.name = void 0, this.cip = void 0, this.age = void 0, this.gender = void 0, this.phoneMain = void 0, this.phoneAlt = void 0, this.mail = void 0, this.address = void 0, this.addressURL = "#", this.infoLabel = "Dades del pacient", this.assignedLabel = "Professionals assignats", this.detailsLabel = "Veure més detalls", this.editLabel = "Editar usuari", this.hideViewDetails = !1, this.jcef = !1, this.edit = !1, this.assignments = void 0, this.hideCopyCip = !1, this.upLabel = "UP", this.upMessage = "Usuari desplaçat: no pertany a l’equip d’atenció primària", this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Tancar menú", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [d(g), d(c), d(y)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Obrir menú del pacient" : "Tancar menú del pacient", this.requestUpdate();
  }
  _handleViewDetails() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("onViewDetails", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _handleEdit() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("onEdit", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _handleCIPClick(o) {
    this._handleCopyCIP(o), this._toggleDropdown();
  }
  _handleCopyCIP(o) {
    o.stopPropagation(), this.cip && (navigator.clipboard.writeText(this.cip), this.dispatchEvent(
      new CustomEvent("onCopyCIP", {
        detail: { text: this.cip },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _getGenderIcon() {
    var s;
    return ((s = this.gender) == null ? void 0 : s.toLowerCase()) === "femení" ? "female" : "male";
  }
  _handleDocumentClick(o) {
    this._clickedOutside(this, o);
  }
  _clickedOutside(o, s) {
    s.composedPath().includes(o) || this._showDropdown && this._toggleDropdown();
  }
  render() {
    return m(this);
  }
}
t([
  e(p)
], i.prototype, "disabled");
t([
  e({ type: String })
], i.prototype, "variant");
t([
  e({ type: String })
], i.prototype, "name");
t([
  e({ type: String })
], i.prototype, "cip");
t([
  e({ type: String })
], i.prototype, "age");
t([
  e({ type: String })
], i.prototype, "gender");
t([
  e({ type: String })
], i.prototype, "phoneMain");
t([
  e({ type: String })
], i.prototype, "phoneAlt");
t([
  e({ type: String })
], i.prototype, "mail");
t([
  e({ type: String })
], i.prototype, "address");
t([
  e({ type: String })
], i.prototype, "addressURL");
t([
  e({ type: String })
], i.prototype, "infoLabel");
t([
  e({ type: String })
], i.prototype, "assignedLabel");
t([
  e({ type: String })
], i.prototype, "detailsLabel");
t([
  e({ type: String })
], i.prototype, "editLabel");
t([
  e(p)
], i.prototype, "hideViewDetails");
t([
  e(p)
], i.prototype, "jcef");
t([
  e(p)
], i.prototype, "edit");
t([
  e({ type: Array })
], i.prototype, "assignments");
t([
  e(p)
], i.prototype, "hideCopyCip");
t([
  e({ type: String })
], i.prototype, "upLabel");
t([
  e({ type: String })
], i.prototype, "upMessage");
export {
  i as HeaderMenuPatient
};
//# sourceMappingURL=header-menu-patient.js.map
