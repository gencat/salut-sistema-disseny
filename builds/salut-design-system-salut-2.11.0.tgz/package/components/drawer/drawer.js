import { LitElement as w, unsafeCSS as d } from "lit";
import { property as l } from "lit/decorators.js";
import p from "../../foundations/icon/icon.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import u from "../icon-button/icon-button.style.css.js";
import m from "./drawer.style.css.js";
import { template as _ } from "./drawer.template.js";
var y = Object.defineProperty, a = (n, e, t, r) => {
  for (var s = void 0, i = n.length - 1, o; i >= 0; i--)
    (o = n[i]) && (s = o(e, t, s) || s);
  return s && y(e, t, s), s;
};
const v = 250;
class h extends w {
  /* METHODS */
  constructor() {
    super(), this.variant = "default", this.jcef = !1, this.open = !1, this.title = "", this._drawerHeader = null, this._drawerFooter = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [d(f), d(p), d(u), d(m)];
  }
  _showDrawer() {
    this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), document.body.style.overflow = "hidden";
  }
  _hideDrawer() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      this.classList.remove("hide"), this.style.visibility = "hidden";
    }, v), document.body.style.overflow = "";
  }
  _handleClose() {
    this.open = !1, this._hideDrawer(), this.requestUpdate();
    const e = new Event("onDrawerClosed");
    this.dispatchEvent(e);
    const t = new Event("onClose");
    this.dispatchEvent(t);
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._handleClose();
  }
  _handleOutsideClick(e) {
    var t;
    if (this.open) {
      const r = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".drawer"), s = e.composedPath();
      r && s.includes(this) && !s.includes(r) && this._handleClose();
    }
  }
  _handleScroll(e) {
    var r, s, i, o;
    const t = e.target;
    t && (t.scrollTop > 0 ? (r = this._drawerHeader) == null || r.classList.add("drawer-header--scrolled") : (s = this._drawerHeader) == null || s.classList.remove("drawer-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? (i = this._drawerFooter) == null || i.classList.add("drawer-footer--scrolled") : (o = this._drawerFooter) == null || o.classList.remove("drawer-footer--scrolled"));
  }
  /* LIT LIFECYCLE */
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  updated(e) {
    e.has("open") && (this.open ? this._showDrawer() : this._hideDrawer());
  }
  firstUpdated() {
    var t, r, s;
    const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".drawer");
    e && (e.addEventListener("scroll", this._handleScroll.bind(this)), this._drawerHeader = (r = this.shadowRoot) == null ? void 0 : r.querySelector(".drawer-header"), this._drawerFooter = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".drawer-footer"), e.scrollHeight > e.clientHeight && this._drawerFooter.classList.add("drawer-footer--scrolled"));
  }
  render() {
    return _(this);
  }
}
a([
  l({ type: String })
], h.prototype, "variant");
a([
  l(c)
], h.prototype, "jcef");
a([
  l(c)
], h.prototype, "open");
a([
  l({ type: String })
], h.prototype, "title");
export {
  h as Drawer
};
//# sourceMappingURL=drawer.js.map
