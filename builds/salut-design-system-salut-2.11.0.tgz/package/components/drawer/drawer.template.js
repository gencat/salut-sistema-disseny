import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as s, literal as d, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const a = d`dss-icon-button${s(i())}`, v = (r) => {
  const e = {
    "drawer--filter": r.variant === "filter",
    "drawer--jcef": r.jcef
  };
  return l`
    <div class="drawer ${t(e)}">
      <div class="drawer-header">
        <div class="drawer-header-title">${r.title}</div>
        <${a}
          variant="default"
          icon="close"
          label="Tancar"
          size="lg"
          @click=${r._handleClose}
        >
        </${a}>
      </div>
      <div class="drawer-body">
        <slot name="drawer-body"></slot>
      </div>
      <div class="drawer-footer">
        <slot name="drawer-footer"></slot>
      </div>
    </div>
  `;
};
export {
  v as template
};
//# sourceMappingURL=drawer.template.js.map
