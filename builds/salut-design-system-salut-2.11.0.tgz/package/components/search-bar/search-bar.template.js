import { classMap as d } from "lit/directives/class-map.js";
import { ifDefined as $ } from "lit/directives/if-defined.js";
import { unsafeStatic as i, literal as r, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const l = r`dss-icon${i(e())}`, w = r`dss-spinner${i(e())}`, v = r`dss-tooltip${i(e())}`, b = r`dss-icon-button${i(e())}`, S = (s) => {
  var c, h, t, _, u;
  const g = {
    "dss-search-bar--invalid": s._invalid || !s._inputValidity,
    "dss-search-bar--disabled": (c = s._input) == null ? void 0 : c.disabled,
    "dss-search-bar--required": (h = s._input) == null ? void 0 : h.required,
    "dss-search-bar--read-only": (t = s._input) == null ? void 0 : t.readOnly,
    "dss-search-bar--focused": s._isFocused,
    "dss-search-bar--default": !s._multiple,
    "dss-search-bar--multiple": s._multiple,
    "dss-search-bar--show-chips": s._showAllChips,
    "dss-search-bar--md": s._inputSize === "md",
    "dss-search-bar--inner-focus": s.innerFocus,
    "dss-search-bar--has-value": s._showClearButton || ((_ = s._input) == null ? void 0 : _.value) || s._searchTerms.length > 0
  }, f = {}, p = {};
  return a`
    <div class="dss-search">
        <div
          class="dss-search-bar ${d(g)}"
          role="combobox"
          aria-controls="search-catalog"
          aria-expanded=${$(s._showDropdown)}
        >
          <div class="dss-search-bar__icon">
            <${l} size="md" icon="${s._icon}"  @click=${s._focusInput}></${l}>
          </div>

          <div class="dss-search-bar__container">
            ${s._multiple ? a`
                  <div class="dss-search-bar__chips">
                    ${a`${s._generateSearchChips()}`}
                    ${!s._showAllChips && s._searchTerms.length > 5 ? a`
                          <div class="dss-chip__counter">
                            +${s._searchTerms.length - 5}
                            <${v}
                              class="dss-chip__tooltip"
                              position="bottom"
                              align="left"
                              noHeightLimit
                            >
                              ${s._searchTerms.slice(5, s._searchTerms.length).map(
    (o) => a`<span class="dss-chip__tooltip-item">
                                        ${o}
                                      </span>`
  )}
                            </${v}>
                          </div>
                        ` : null}
                  </div>
                ` : null}

            <div class="dss-search-bar__input">
              <slot name="label" @click=${s._focusInput}></slot>
              <slot
                name="input"
                @click=${s._handleClick}
                @input=${s._handleInput}
                @keydown=${s._handleKeyDown}
                @focusin=${s._handleFocusIn}
                @focusout=${s._handleFocusOut}
              ></slot>
            </div>
          </div>

          <div class="dss-search-bar__clear">
            <${b} 
              icon="cancel" 
              variant="primary" 
              size="md" 
              @click=${s._clearSearch}
              label="Esborra la cerca"
            >
            </${b}>
          </div>
        </div>

        ${s._helpText ? a`
              <div class="dss-search-help ${d(f)}">
                <span>${s._helpText}</span>
              </div>
            ` : null}
        ${s._showDropdown && ((u = s._catalog) == null ? void 0 : u.length) > 0 && s._input.value.length >= s._threshold ? a`
              <div
                id="search-catalog"
                class="dss-search-dropdown ${d(p)}"
                style=${$(s._searchboxStyle)}
                role="listbox"
                aria-label="Search Catalog"
              >
                ${s._isCatalogLoading ? a`
                      <div class="dss-search-catalog--empty">
											  <${w} size="md"/>
                      </div>
                    ` : a`
                      ${s._filteredCatalog.length > 0 ? a`
                            ${s._recentSearches ? a`
                                  <div class="dss-search-title">
                                    ${s._recentSearchesText}
                                  </div>
                                ` : null}
                            <div class="dss-search-catalog">
                              ${a`${s._generateFilterCatalog()}`}
                            </div>
                          ` : a`
                            <div
                              class="dss-search-catalog dss-search-catalog--empty"
                            >
                              <${l} size="sm" icon="info"></${l}>
                              <span class="text">
                                ${s._emptyDropdownText}: ${s._input.value}
                              </span>
                            </div>
                          `}
                    `}
              </div>
            ` : null}
      </div>
  `;
};
export {
  S as template
};
//# sourceMappingURL=search-bar.template.js.map
