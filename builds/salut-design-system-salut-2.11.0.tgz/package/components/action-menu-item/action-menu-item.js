import { LitElement as p, unsafeCSS as d } from "lit";
import { property as s } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import _ from "./action-menu-item.style.css.js";
import { actionMenuItemTemplate as f } from "./action-menu-item.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, i = (l, t, e, r) => {
  for (var n = r > 1 ? void 0 : r ? g(t, e) : t, c = l.length - 1, h; c >= 0; c--)
    (h = l[c]) && (n = (r ? h(t, e, n) : h(n)) || n);
  return r && n && y(t, e, n), n;
};
class o extends p {
  constructor() {
    super(...arguments), this.leftIconFill = !1, this.rightIconFill = !1, this.actionLabel = "", this._state = "primary", this._label = "Label", this._leftIcon = void 0, this._rightIcon = void 0, this._actionIcon = void 0, this._actionState = "primary", this._notifications = 0, this._notificationsState = "error", this._selected = !1, this._disabled = !1, this._hasNestedMenu = !1, this._nestedMenuPosition = "top", this._first = !1, this._last = !1;
  }
  static get styles() {
    return [d(u), d(_)];
  }
  set state(t) {
    const e = this._state;
    this._state = t === "error" ? t : "primary", this.requestUpdate("state", e);
  }
  get state() {
    return this._state;
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set leftIcon(t) {
    const e = this._leftIcon;
    this._leftIcon = t, this.requestUpdate("leftIcon", e);
  }
  get leftIcon() {
    return this._leftIcon || "";
  }
  set rightIcon(t) {
    const e = this._rightIcon;
    this._rightIcon = t, this.requestUpdate("rightIcon", e);
  }
  get rightIcon() {
    return this._rightIcon || "";
  }
  set actionIcon(t) {
    const e = this._actionIcon;
    this._actionIcon = t, this.requestUpdate("actionIcon", e);
  }
  get actionIcon() {
    return this._actionIcon || "";
  }
  set actionState(t) {
    const e = this._actionState;
    this._actionState = t, this.requestUpdate("actionState", e);
  }
  get actionState() {
    return this._actionState;
  }
  set notifications(t) {
    const e = this._notifications;
    this._notifications = t, this.requestUpdate("notifications", e);
  }
  get notifications() {
    return this._notifications;
  }
  set notificationsState(t) {
    const e = this._notificationsState;
    this._notificationsState = t, this.requestUpdate("notificationsState", e);
  }
  get notificationsState() {
    return this._notificationsState;
  }
  set selected(t) {
    const e = this._selected;
    this._selected = t, this.requestUpdate("selected", e);
  }
  get selected() {
    return this._selected;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set hasNestedMenu(t) {
    const e = this._hasNestedMenu;
    this._hasNestedMenu = t, this.requestUpdate("hasNestedMenu", e);
  }
  get hasNestedMenu() {
    return this._hasNestedMenu;
  }
  set nestedMenuPosition(t) {
    const e = this._nestedMenuPosition;
    this._nestedMenuPosition = t, this.requestUpdate("nestedMenuPosition", e);
  }
  get nestedMenuPosition() {
    return this._nestedMenuPosition;
  }
  set first(t) {
    const e = this._first;
    this._first = t, this.requestUpdate("first", e);
  }
  get first() {
    return this._first;
  }
  set last(t) {
    const e = this._last;
    this._last = t, this.requestUpdate("last", e);
  }
  get last() {
    return this._last;
  }
  _handleItemClick() {
    this._hasNestedMenu ? (this._selected = !0, this.requestUpdate()) : (this.dispatchEvent(new CustomEvent("onClick", { bubbles: !1, composed: !1 })), this.dispatchEvent(new CustomEvent("onClose", { bubbles: !0, composed: !0 })));
  }
  _handleKeydown(t) {
    const e = t.key;
    e === "Enter" || e === "Space" ? this._handleItemClick() : e === "Escape" && this._selected && this._unselectItem();
  }
  _handleAction(t) {
    t.stopPropagation(), this.dispatchEvent(new CustomEvent("onAction", { detail: this._label }));
  }
  _clickOutside() {
    document.addEventListener("mousedown", (t) => {
      t.composedPath().includes(this) || this._selected && this._unselectItem();
    });
  }
  _unselectItem() {
    this._selected = !1, this.requestUpdate();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._clickOutside();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return f(this);
  }
}
i([
  s({ type: String })
], o.prototype, "state", 1);
i([
  s({ type: String })
], o.prototype, "label", 1);
i([
  s({ type: String })
], o.prototype, "leftIcon", 1);
i([
  s(a)
], o.prototype, "leftIconFill", 2);
i([
  s(a)
], o.prototype, "rightIconFill", 2);
i([
  s({ type: String })
], o.prototype, "rightIcon", 1);
i([
  s({ type: String })
], o.prototype, "actionLabel", 2);
i([
  s({ type: String })
], o.prototype, "actionIcon", 1);
i([
  s({ type: String })
], o.prototype, "actionState", 1);
i([
  s({ type: Number })
], o.prototype, "notifications", 1);
i([
  s({ type: String })
], o.prototype, "notificationsState", 1);
i([
  s(a)
], o.prototype, "selected", 1);
i([
  s(a)
], o.prototype, "disabled", 1);
i([
  s(a)
], o.prototype, "hasNestedMenu", 1);
i([
  s({ type: String })
], o.prototype, "nestedMenuPosition", 1);
i([
  s(a)
], o.prototype, "first", 1);
i([
  s(a)
], o.prototype, "last", 1);
export {
  o as ActionMenuItem
};
//# sourceMappingURL=action-menu-item.js.map
