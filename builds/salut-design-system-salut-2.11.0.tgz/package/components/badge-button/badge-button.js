import { LitElement as p, unsafeCSS as d } from "lit";
import { property as i } from "lit/decorators.js";
import _ from "../../shared/reset.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import u from "./badge-button.states.css.js";
import f from "./badge-button.style.css.js";
import { template as m } from "./badge-button.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, s = (l, t, e, r) => {
  for (var n = r > 1 ? void 0 : r ? g(t, e) : t, h = l.length - 1, a; h >= 0; h--)
    (a = l[h]) && (n = (r ? a(t, e, n) : a(n)) || n);
  return r && n && y(t, e, n), n;
};
class o extends p {
  constructor() {
    super(...arguments), this.type = "button", this.label = "", this.disabled = !1, this.hidden = !1, this.hideIcon = !1, this.showIcon = !1, this.outlined = !1, this.width = void 0, this._size = "sm", this._action = "dropdown", this._actionIcon = "expand_more", this._state = "", this._icon = "", this._isIconDefined = !1, this._iconSize = "sm", this._iconFill = !1, this._isTextTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [d(_), d(f), d(u)];
  }
  get _tooltip() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="tooltip"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set size(t) {
    const e = this._size;
    this._size = t, t === "xl" ? this._iconSize = "md" : this._iconSize = "sm", this.requestUpdate("size", e);
  }
  get size() {
    return this._size;
  }
  set action(t) {
    const e = this._action;
    switch (this._action = t, t) {
      case "details":
        this._actionIcon = "visibility";
        break;
      case "external":
        this._actionIcon = "open_in_new";
        break;
      default:
        this._actionIcon = "expand_more";
    }
    this.requestUpdate("action", e);
  }
  get action() {
    return this._action;
  }
  set state(t) {
    const e = this._state;
    this._state = t, this._generateDefaultIcon(t), this.requestUpdate("state", e);
  }
  get state() {
    return this._state;
  }
  set icon(t) {
    const e = this._icon;
    this._icon = t, this._isIconDefined = !0, this.requestUpdate("icon", e);
  }
  get icon() {
    return this._icon;
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !1, composed: !1 }));
  }
  _updateIconFill(t) {
    this._iconFill = !t.includes("low") || t === "correct";
  }
  _generateDefaultIcon(t) {
    t && !this._isIconDefined && (t.includes("danger") ? (this._icon = "warning", this._updateIconFill(t)) : t.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(t)) : t.includes("slight") ? (this._icon = "error", this._updateIconFill(t)) : t.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(t)) : t.includes("undeterminated") ? this._icon = "circle" : t.includes("undetermined") ? this._icon = "circle" : t.includes("critic") ? this._icon = "cancel" : t.includes("alert") ? this._icon = "report" : t.includes("ideal") ? this._icon = "check_circle" : t.includes("info") ? this._icon = "info" : t.includes("neutral") && (this._icon = "circle"));
  }
  _checkTextTruncated() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelector(".dss-badge-button__label");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("label") && this._checkTextTruncated(), !this._isFirstUpdated && t.has("state") && (this._iconFill = !1, this._generateDefaultIcon(this.state));
  }
  async firstUpdated() {
    var t;
    if (await this.updateComplete, this.width) {
      const e = (t = this.shadowRoot) == null ? void 0 : t.querySelector(".dss-badge-button");
      e && (e.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  render() {
    return m(this);
  }
}
s([
  i({ type: String })
], o.prototype, "type", 2);
s([
  i({ type: String })
], o.prototype, "label", 2);
s([
  i(c)
], o.prototype, "disabled", 2);
s([
  i(c)
], o.prototype, "hidden", 2);
s([
  i(c)
], o.prototype, "hideIcon", 2);
s([
  i(c)
], o.prototype, "showIcon", 2);
s([
  i(c)
], o.prototype, "outlined", 2);
s([
  i({ type: String })
], o.prototype, "size", 1);
s([
  i({ type: String })
], o.prototype, "action", 1);
s([
  i({ type: String })
], o.prototype, "state", 1);
s([
  i({ type: String })
], o.prototype, "icon", 1);
s([
  i({ type: String })
], o.prototype, "width", 2);
export {
  o as BadgeButton
};
//# sourceMappingURL=badge-button.js.map
