import { nothing as $ } from "lit";
import { classMap as b } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as l, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const a = l`dss-icon${d(e())}`, t = l`dss-tooltip${d(e())}`, o = (s) => i`
  <button
    type=${s.type}
    class=${b({
  "dss-badge-button": !0,
  [`dss-badge-button--${s._size}`]: !!s._size,
  [`dss-badge-button--${s._size}`]: !!s._size,
  [`dss-badge-button--${s.state}`]: !!s.state,
  [`dss-badge-button--${s.state}-outlined`]: !!s.state && s.outlined
})}
    ?disabled=${s.disabled}
    ?hidden=${s.hidden}
    @click=${s._handleClick}
  >
		${!s.hideIcon && s._size !== "sm" || s.showIcon && s._size === "sm" ? i`
				<${a} class="dss-badge-button__icon" icon="${s._icon}" size="${s._iconSize}" ?fill="${s._iconFill}"></${a}>
			` : $}
		<span class="dss-badge-button__label">${s.label}</span>
		<div class="dss-badge-button__action">
			<${a} class="dss-badge-button__icon" icon="${s._actionIcon}" size="${s._iconSize}"></${a}>
		</div>
		${s._isTextTruncated ? i`<${t}>${s.label}</${t}>` : i`<slot name="tooltip"></slot>`}
  </button>
`;
export {
  o as template
};
//# sourceMappingURL=badge-button.template.js.map
