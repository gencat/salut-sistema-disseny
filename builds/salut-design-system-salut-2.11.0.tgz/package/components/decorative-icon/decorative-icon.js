import { LitElement as f, unsafeCSS as m } from "lit";
import { property as e } from "lit/decorators.js";
import l from "../../shared/reset.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import y from "./decorative-icon.style.css.js";
import { template as c } from "./decorative-icon.template.js";
var u = Object.defineProperty, r = (i, p, n, v) => {
  for (var t = void 0, s = i.length - 1, a; s >= 0; s--)
    (a = i[s]) && (t = a(p, n, t) || t);
  return t && u(p, n, t), t;
};
class o extends f {
  constructor() {
    super(...arguments), this.icon = void 0, this.state = "default", this.size = "md", this.disabled = !1;
  }
  static get styles() {
    return [m(l), m(y)];
  }
  render() {
    return c(this);
  }
}
r([
  e({ type: String })
], o.prototype, "icon");
r([
  e({ type: String })
], o.prototype, "state");
r([
  e({ type: String })
], o.prototype, "size");
r([
  e(d)
], o.prototype, "disabled");
export {
  o as DecorativeIcon
};
//# sourceMappingURL=decorative-icon.js.map
