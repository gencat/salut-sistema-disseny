import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as d, html as r } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const i = d`dss-icon${a(o())}`, f = (s) => {
  const e = {
    "dss-decorative-icon": !0,
    [`dss-decorative-icon--${s.size}`]: !!s.size,
    [`dss-decorative-icon--${s.state}`]: s.state !== "default",
    "dss-decorative-icon--disabled": s.disabled
  };
  return r`
    <div class="${t(e)}" aria-hidden="true">
      <${i} icon="${s.icon}" size="${s.size}"></${i}>
    </div>
  `;
};
export {
  f as template
};
//# sourceMappingURL=decorative-icon.template.js.map
