import { LitElement as y, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./icon-button.style.css.js";
import { template as f } from "./icon-button.template.js";
var u = Object.defineProperty, e = (p, n, a, b) => {
  for (var i = void 0, s = p.length - 1, d; s >= 0; s--)
    (d = p[s]) && (i = d(n, a, i) || i);
  return i && u(n, a, i), i;
};
class o extends y {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.size = "md", this.label = "", this.icon = void 0, this.disabled = !1, this.hidden = !1, this.disableTabindex = !1, this.ariaExpanded = void 0, this.tooltipFixed = !1, this.hideTooltip = !1;
  }
  static get styles() {
    return [l(h), l(m)];
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  render() {
    return f(this);
  }
}
e([
  t({ type: String })
], o.prototype, "type");
e([
  t({ type: String })
], o.prototype, "variant");
e([
  t({ type: String })
], o.prototype, "size");
e([
  t({ type: String })
], o.prototype, "label");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t(r)
], o.prototype, "disabled");
e([
  t(r)
], o.prototype, "hidden");
e([
  t(r)
], o.prototype, "disableTabindex");
e([
  t(r)
], o.prototype, "ariaExpanded");
e([
  t(r)
], o.prototype, "tooltipFixed");
e([
  t(r)
], o.prototype, "hideTooltip");
export {
  o as IconButton
};
//# sourceMappingURL=icon-button.js.map
