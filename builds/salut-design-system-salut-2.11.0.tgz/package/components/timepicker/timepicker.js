import { createPopper as M } from "@popperjs/core";
import { LitElement as D, unsafeCSS as x } from "lit";
import { property as d } from "lit/decorators.js";
import { classMap as H } from "lit/directives/class-map.js";
import { unsafeStatic as V, literal as F, html as q } from "lit/static-html.js";
import { getCustomElementSuffix as R } from "../../api/custom-element-scope.js";
import { booleanType as S } from "../../utils/property-types.js";
import { template as U } from "./timepicker.template.js";
import I from "../../shared/scrollbar.style.css.js";
import A from "../input/input.style.css.js";
import $ from "./timepicker.style.css.js";
var C = Object.defineProperty, E = Object.getOwnPropertyDescriptor, c = (y, t, e, i) => {
  for (var s = i > 1 ? void 0 : i ? E(t, e) : t, o = y.length - 1, l; o >= 0; o--)
    (l = y[o]) && (s = (i ? l(t, e, s) : l(s)) || s);
  return i && s && C(t, e, s), s;
};
const L = F`dss-icon${V(R())}`;
class _ extends D {
  constructor() {
    super(), this.inputSize = "lg", this.icon = "schedule", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this._value = "", this._placeholder = "", this._inputSize = "lg", this._dropdown = "", this._required = !1, this._disabled = !1, this._readonly = !1, this._invalid = !1, this._showDropdown = !1, this._helpText = "", this._oldHelpText = "", this._errorTimeFormatText = "Format d'hora no vàlid", this._errorTimeOptionText = "Opció de temps no disponible", this._manualHourSelector = "", this._manualMinuteSelector = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._timeListOptions = [], this._customTimeListOptions = [], this._timeManualHourOptions = [], this._timeManualMinutesOptions = [], this._inputValidity = !0, this._isFirstUpdated = !0, this._popperInstanceList = null, this._popperInstanceManual = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showDropdown && this._closeDropdown();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._timePattern = /^\d{0,4}$/g, this._timeSeparator = ":", this._timeInputOldValue = "", this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [x(A), x(I), x($)];
  }
  get _input() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="input"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  get _label() {
    var e;
    const t = ((e = this.shadowRoot) == null ? void 0 : e.querySelector('slot[name="label"]')) || void 0;
    return this.requestUpdate(), t == null ? void 0 : t.assignedElements()[0];
  }
  set value(t) {
    const e = this._value;
    this._value = t, this._input && (this._input.value = t), this.requestUpdate("value", e);
  }
  get value() {
    return this._value;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this._oldHelpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set errorTimeFormatText(t) {
    const e = this._errorTimeFormatText;
    this._errorTimeFormatText = t, this.requestUpdate("errorTimeFormatText", e);
  }
  get errorTimeFormatText() {
    return this._errorTimeFormatText;
  }
  set errorTimeOptionText(t) {
    const e = this._errorTimeOptionText;
    this._errorTimeOptionText = t, this.requestUpdate("errorTimeOptionText", e);
  }
  get errorTimeOptionText() {
    return this._errorTimeOptionText;
  }
  set dropdown(t) {
    const e = this._dropdown;
    this._dropdown = t, this.requestUpdate("dropdown", e);
  }
  get dropdown() {
    return this._dropdown;
  }
  set showDropdown(t) {
    const e = this._showDropdown;
    this._showDropdown = t, this.requestUpdate("showDropdown", e);
  }
  get showDropdown() {
    return this._showDropdown;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.observer.disconnect(), this.visibleObserver.disconnect();
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._createPopperList(), this._createPopperManual(), this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input)), this._updateTimeOptions(), this._isFirstUpdated = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _createPopperList() {
    var i, s;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-input-group"), e = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-timepicker-dropdown--list");
    t && e && (this._popperInstanceList = M(t, e, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "flip",
          enabled: !0,
          options: {
            boundary: "viewport",
            rootBoundary: "viewport"
          }
        },
        {
          name: "preventOverflow",
          enabled: !0,
          options: {
            boundary: "viewport",
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        },
        {
          name: "matchWidth",
          enabled: !0,
          phase: "write",
          fn({ state: o }) {
            o.elements.popper.style.width = `${t.offsetWidth}px`;
          },
          effect: ({ state: o }) => {
            o.elements.popper.style.width = `${t.offsetWidth}px`;
          }
        }
      ]
    }));
  }
  _createPopperManual() {
    var i, s;
    const t = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-input-group"), e = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-timepicker-dropdown--manual");
    t && e && (this._popperInstanceManual = M(t, e, {
      placement: "bottom",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "flip",
          enabled: !0,
          options: {
            boundary: "viewport",
            rootBoundary: "viewport"
          }
        },
        {
          name: "preventOverflow",
          enabled: !0,
          options: {
            boundary: "viewport",
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  _updateTimeOptions() {
    this._dropdown && (this._timeListOptions = this._generateTimeListOptions(), this._timeManualHourOptions = this._generateTimeManualHoursOptions(), this._timeManualMinutesOptions = this._generateTimeManualMinutesOptions());
  }
  _checkInputAttributes() {
    var l, p, v, m, f, g, b;
    const t = (l = this._input) == null ? void 0 : l.getAttribute("placeholder");
    t && (this._placeholder = t), ((p = this._input) == null ? void 0 : p.getAttribute("readonly")) !== null && (this._readonly = !0), ((v = this._input) == null ? void 0 : v.getAttribute("disabled")) !== null && (this._disabled = !0), ((m = this._input) == null ? void 0 : m.getAttribute("required")) !== null && (this._required = !0);
    const o = (f = this._input) == null ? void 0 : f.getAttribute("value");
    o !== null && (this._value = o), (g = this._input) != null && g.value && ((b = this._input) == null ? void 0 : b.value) !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleValidity() {
    var e;
    const t = (e = this._input) == null ? void 0 : e.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showDropdown && this._closeDropdown();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && (this._showDropdown && this._closeDropdown(), this.requestUpdate());
  }
  _closeDropdown() {
    var t;
    this._removeDropdownListener(), this._showDropdown = !1, (t = this._input) == null || t.blur(), this.requestUpdate();
  }
  _timeMask(t, e, i) {
    const s = [];
    for (let o = 0; o < t.length; o += 1)
      o !== 0 && o % e === 0 && s.push(i), s.push(t[o]);
    return s.join("");
  }
  _timeUnmask(t) {
    return t.replace(/[^\d]/g, "");
  }
  _timeValidate(t) {
    const e = t.slice(0, 2), i = t.slice(3, 5);
    this._input && +e >= 0 && +e <= 23 && +i >= 0 && +i <= 59 ? (this._invalid = !1, this._helpText = this._oldHelpText, this._dropdown && this._dropdown === "list" && !this._timeListOptions.includes(this._input.value) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._dropdown && this._dropdown === "manual" && (!this._timeManualHourOptions.includes(e) || !this._timeManualMinutesOptions.includes(i)) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._closeDropdown()) : (this._helpText = this._errorTimeFormatText, this._invalid = !0), this._dispatchValueChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    if (this._input) {
      const t = {
        detail: {
          value: this._input.value,
          status: this._invalid ? "INVALID" : "VALID"
        },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onTimepickerChange", t));
    }
  }
  _handleClick() {
    if (this._showDropdown = !0, this._addDropdownListener(), this._popperInstanceList && this._popperInstanceList.update(), this._popperInstanceManual && this._popperInstanceManual.update(), this._value && (this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual")) {
      const t = this._value.slice(0, 2);
      this._timeManualOptionsScrollTo(t), setTimeout(() => {
        this._timeManualOptionsScrollTo();
      }, 500);
    }
    this.requestUpdate();
  }
  _handleInput() {
    if (this._input) {
      let t = this._input.value;
      t = this._timeUnmask(t), t.match(this._timePattern) ? (t = this._timeMask(t, 2, this._timeSeparator), this._input.value = t) : this._input.value = this._timeInputOldValue, this._input.value.length === 5 && (this._timeValidate(this._input.value), this._handleValidity()), this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual" && this._timeManualOptionsScrollTo();
    }
  }
  _handleKeyDown(t) {
    this._input && (this._timeInputOldValue = this._input.value, (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this._showDropdown = !0, this._addDropdownListener(), this._popperInstanceList && this._popperInstanceList.update(), this._popperInstanceManual && this._popperInstanceManual.update(), this.requestUpdate()) : (t == null ? void 0 : t.key) === "Escape" && this._closeDropdown());
  }
  _handleFocus() {
    this._placeholder = "00:00", this._input && this._input.setAttribute("placeholder", this._placeholder), this.requestUpdate();
  }
  _handleBlur() {
    this._placeholder = "", this._input && this._input.removeAttribute("placeholder"), this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    var t;
    this._disabled || ((t = this._input) == null || t.focus(), this._handleClick());
  }
  _generateTimeListOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1)
      for (let i = 0; i < 60; i += this._minutesRange) {
        const s = e.toString().padStart(2, "0"), o = i.toString().padStart(2, "0");
        t.push(`${s}:${o}`);
      }
    return t;
  }
  _generateTimeListOptionsHTML(t, e) {
    let i = !0;
    const s = e && e.length > 0;
    return (s ? e : t).map((p) => {
      const v = (u) => {
        u && u.focus();
      }, m = (u) => {
        let r = 0;
        const a = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), n = a.length - 1;
        u === a[0] ? v(a[n]) : (a.forEach((h, w) => {
          h === u && (r = w);
        }), v(a[r - 1]));
      }, f = (u) => {
        let r = 0;
        const a = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), n = a.length - 1;
        u === a[n] ? v(a[0]) : (a.forEach((h, w) => {
          h === u && (r = w);
        }), v(a[r + 1]));
      }, g = (u) => {
        if (this._input) {
          const r = u.target.getAttribute("value");
          r && (this._input.value = r, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
        }
      }, b = (u) => {
        const r = u.currentTarget, a = u;
        let n = !1;
        switch (a.key) {
          case "ArrowUp":
            m(r), n = !0;
            break;
          case "ArrowDown":
            f(r), n = !0;
            break;
          case "Enter": {
            const h = u.target.querySelector("input"), w = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
            w == null || w.setAttribute("tabindex", "-1"), u.target.setAttribute("tabindex", "0"), h == null || h.click(), n = !0;
            break;
          }
        }
        n && (u.stopPropagation(), u.preventDefault());
      }, T = {
        "option--busy": typeof p == "object" && p.state === "ocupat"
      }, O = q`
        <div class="dss-timepicker-dropdown__option ${H(T)}">
          <label
            class="dss-timepicker-dropdown__label"
            tabindex="${i ? 0 : -1}"
            @keydown=${b}
          >
            ${s && typeof p == "object" ? p.value : p}

            <input
              class="dss-timepicker-dropdown__input-radio"
              name="timeList"
              type="radio"
              @click="${g}"
              .value="${s && typeof p == "object" ? p.value : p}"
            />
						<${L} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${L}>
          </label>
        </div>
      `;
      return i = !1, O;
    });
  }
  _generateTimeManualHoursOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualMinutesOptions() {
    const t = [];
    for (let e = 0; e < 60; e += this._minutesRange) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualOptionsHTML(t, e) {
    let i = !0;
    return e.map((o) => {
      const l = (m) => {
        const f = m.target.getAttribute("value");
        f && (t === "timepickerManualHour" ? this._manualHourSelector = f : t === "timepickerManualMinutes" && (this._manualMinuteSelector = f), this.requestUpdate());
      }, p = (m) => {
        const f = m.currentTarget, g = m;
        let b = !1;
        const T = (r) => {
          r && r.focus();
        }, O = (r) => {
          let a = 0;
          const n = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), h = n.length - 1;
          r === n[0] ? T(n[h]) : (n.forEach((w, k) => {
            w === r && (a = k);
          }), T(n[a - 1]));
        }, u = (r) => {
          let a = 0;
          const n = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), h = n.length - 1;
          r === n[h] ? T(n[0]) : (n.forEach((w, k) => {
            w === r && (a = k);
          }), T(n[a + 1]));
        };
        switch (g.key) {
          case "ArrowUp":
            O(f), b = !0;
            break;
          case "ArrowDown":
            u(f), b = !0;
            break;
          case "Enter": {
            const r = m.target.parentElement, a = r == null ? void 0 : r.querySelector("input"), n = this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            );
            if (n == null || n.setAttribute("tabindex", "-1"), m.target.setAttribute("tabindex", "0"), a == null || a.click(), t === "timepickerManualHour") {
              const h = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              T(h);
            } else if (t === "timepickerManualMinutes") {
              const h = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                h.focus();
              }, 0);
            }
            b = !0;
            break;
          }
        }
        b && (m.stopPropagation(), m.preventDefault());
      }, v = q`
        <div class="dss-timepicker-manual-item">
          <input
            id="${t + o}"
            class="dss-timepicker-manual-item__input-radio"
            name="${t}"
            type="radio"
            @click="${l}"
            .value="${o}"
          />
          <label
            for="${t + o}"
            class="dss-timepicker-manual-item__label ${t}"
            tabindex="${i ? 0 : -1}"
            @keydown=${p}
          >
            ${o}
          </label>
        </div>
      `;
      return i = !1, v;
    });
  }
  _checkDisableTimeManualSelector() {
    return this._manualHourSelector === "" || this._manualMinuteSelector === "";
  }
  /* eslint no-param-reassign: "off" */
  _timeManualSelectorCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((e) => {
      e.checked = !1;
    }), this._manualHourSelector = "", this._manualMinuteSelector = "", this._handleValidity(), this._closeDropdown();
  }
  _timeManualSelectorAccept() {
    this._input && (this._input.value = `${this._manualHourSelector}:${this._manualMinuteSelector}`, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
  }
  /* eslint no-param-reassign: "off" */
  _timeListOptionsScrollTo() {
    if (this._input) {
      const t = this._input.value.trim(), e = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
      let i = !1;
      e.forEach((s) => {
        const o = s.value;
        if (!i && o.startsWith(t)) {
          const l = s.closest("label");
          i = !0, l && (setTimeout(() => {
            l.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), o === t && (s.checked = !0));
        }
      });
    }
  }
  _timeManualOptionsScrollTo(t) {
    if (this._input) {
      const e = t ? t.trim() : this._input.value.trim();
      if (e.length <= 2) {
        const i = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
        );
        let s = !1;
        i.forEach((o) => {
          const l = o.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !s && l.startsWith(e) && (s = !0, setTimeout(() => {
            o.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), l === e && o.click());
        });
      } else {
        const i = e.slice(3), s = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
        );
        let o = !1;
        s.forEach((l) => {
          const p = l.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !o && p.startsWith(i) && (o = !0, l.scrollIntoView({
            behavior: "smooth",
            block: "center",
            inline: "nearest"
          }), p === i && l.click());
        });
      }
    }
  }
  _checkInputOverflow() {
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, s = document.createElement("canvas").getContext("2d");
    if (!s) return;
    s.font = e;
    const o = s.measureText(this._input.value).width;
    this._isTruncated = o > this._input.offsetWidth;
  }
  render() {
    return U(this);
  }
}
c([
  d({ type: String, attribute: !0 })
], _.prototype, "value", 1);
c([
  d(S)
], _.prototype, "invalid", 1);
c([
  d({ type: String })
], _.prototype, "helpText", 1);
c([
  d({ type: String })
], _.prototype, "errorTimeFormatText", 1);
c([
  d({ type: String })
], _.prototype, "errorTimeOptionText", 1);
c([
  d({ type: String })
], _.prototype, "dropdown", 1);
c([
  d(S)
], _.prototype, "showDropdown", 1);
c([
  d({ type: Number })
], _.prototype, "minutesRange", 1);
c([
  d({ type: Number })
], _.prototype, "minHour", 1);
c([
  d({ type: Number })
], _.prototype, "maxHour", 1);
c([
  d({ type: Array })
], _.prototype, "customTimeListOptions", 1);
c([
  d({ type: String })
], _.prototype, "inputSize", 2);
c([
  d({ type: String })
], _.prototype, "icon", 2);
c([
  d({ type: String })
], _.prototype, "dropdownPlacement", 2);
c([
  d(S)
], _.prototype, "dropdownFixed", 2);
export {
  _ as Timepicker
};
//# sourceMappingURL=timepicker.js.map
