const x = ".dss-elevation--sm{box-shadow:0 1px 3px 1px #0000001a,0 0 2px #0000000d}.dss-elevation--md{box-shadow:0 2px 3px #0000001a,0 0 8px 3px #0000000d}.dss-elevation--lg{box-shadow:0 4px 4px #0000001a,0 0 12px 6px #0000000d}.dss-elevation--left{box-shadow:-2px 0 1px #0000000d}.dss-elevation--right{box-shadow:2px 0 1px #0000000d}.dss-elevation--top{box-shadow:0 -2px 1px #0000000d}";
export {
  x as default
};
//# sourceMappingURL=elevation.style.css.js.map
