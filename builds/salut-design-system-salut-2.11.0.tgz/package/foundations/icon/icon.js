import { LitElement as l, unsafeCSS as a } from "lit";
import { property as i, state as m } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import { booleanType as y } from "../../utils/property-types.js";
import u from "./icon.style.css.js";
import { template as c } from "./icon.template.js";
var h = Object.defineProperty, e = (o, n, p, S) => {
  for (var t = void 0, s = o.length - 1, f; s >= 0; s--)
    (f = o[s]) && (t = f(n, p, t) || t);
  return t && h(n, p, t), t;
};
class r extends l {
  constructor() {
    super(...arguments), this.size = "md", this.icon = "", this.fill = !1, this.fontLoaded = !1;
  }
  static get styles() {
    return [a(d), a(u)];
  }
  firstUpdated() {
    document.fonts.load('1em "Dss Material Symbols"').then(() => {
      this.fontLoaded = !0;
    });
  }
  render() {
    return c(this);
  }
}
e([
  i({ type: String })
], r.prototype, "size");
e([
  i({ type: String })
], r.prototype, "icon");
e([
  i(y)
], r.prototype, "fill");
e([
  m()
], r.prototype, "fontLoaded");
export {
  r as Icon
};
//# sourceMappingURL=icon.js.map
