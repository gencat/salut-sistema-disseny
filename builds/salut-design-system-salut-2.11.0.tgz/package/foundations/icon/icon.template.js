import { html as i } from "lit";
import { classMap as a } from "lit/directives/class-map.js";
const d = (s) => i`

  ${s.fontLoaded ? i`
      <i
        class=${a({
  "dss-icon": !0,
  "dss-icon--fill": s.fill,
  [`dss-icon--${s.size}`]: !!s.size
})}
        aria-hidden="true"
        translate="no"
      >
        ${s.icon}
      </i>
    ` : i`
      <span
        class=${a({
  "dss-icon-ghost": !0,
  [`dss-icon-ghost--${s.size}`]: !!s.size
})}>
      </span>
    `}
`;
export {
  d as template
};
//# sourceMappingURL=icon.template.js.map
