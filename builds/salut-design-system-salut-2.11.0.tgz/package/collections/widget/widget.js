import { LitElement as d, unsafeCSS as l } from "lit";
import { property as t } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import f from "../../shared/scrollbar.style.css.js";
import { booleanType as i } from "../../utils/property-types.js";
import S from "./widget.style.css.js";
import { template as u } from "./widget.template.js";
var g = Object.defineProperty, e = (p, n, s, h) => {
  for (var r = void 0, a = p.length - 1, c; a >= 0; a--)
    (c = p[a]) && (r = c(n, s, r) || r);
  return r && g(n, s, r), r;
};
class o extends d {
  constructor() {
    super(...arguments), this.variant = "box", this.icon = void 0, this.iconStatus = void 0, this.title = "Title", this.results = void 0, this.resultsState = "info", this.resultsLabel = "", this.info = void 0, this.infoBadgeState = "critic", this.infoBadgeIcon = "", this.infoBadgeOutlined = !0, this.notifications = void 0, this.notificationsState = "info", this.hasAction = !1, this.hasNext = !1, this.hasClose = !1, this.actionLabel = void 0, this.actionIcon = void 0, this.actionVariant = "primary", this.actionDisabled = !1, this.tooltipFixed = !1, this.hasScroll = !1, this.folded = !1, this._eventOptions = {
      bubbles: !1,
      composed: !1
    };
  }
  static get styles() {
    return [l(y), l(f), l(S)];
  }
  checkTextTruncate(n) {
    if (!n) return;
    const s = n.target, h = s.scrollWidth > s.offsetWidth;
    s.setAttribute("data-truncated", h.toString());
  }
  handleAction() {
    this.dispatchEvent(new CustomEvent("onAction", this._eventOptions));
  }
  handleNext() {
    this.dispatchEvent(new CustomEvent("onNext", this._eventOptions));
  }
  handleClose() {
    this.dispatchEvent(new CustomEvent("onClose", this._eventOptions));
  }
  firstUpdated() {
    this.hasScroll && this.classList.add("scrollable");
  }
  render() {
    return u(this);
  }
}
e([
  t({ type: String })
], o.prototype, "variant");
e([
  t({ type: String })
], o.prototype, "icon");
e([
  t({ type: String })
], o.prototype, "iconStatus");
e([
  t({ type: String })
], o.prototype, "title");
e([
  t({ type: String })
], o.prototype, "results");
e([
  t({ type: String })
], o.prototype, "resultsState");
e([
  t({ type: String })
], o.prototype, "resultsLabel");
e([
  t({ type: String })
], o.prototype, "info");
e([
  t({ type: String })
], o.prototype, "infoBadgeState");
e([
  t({ type: String })
], o.prototype, "infoBadgeIcon");
e([
  t(i)
], o.prototype, "infoBadgeOutlined");
e([
  t({ type: Number })
], o.prototype, "notifications");
e([
  t({ type: String })
], o.prototype, "notificationsState");
e([
  t(i)
], o.prototype, "hasAction");
e([
  t(i)
], o.prototype, "hasNext");
e([
  t(i)
], o.prototype, "hasClose");
e([
  t({ type: String })
], o.prototype, "actionLabel");
e([
  t({ type: String })
], o.prototype, "actionIcon");
e([
  t({ type: String })
], o.prototype, "actionVariant");
e([
  t(i)
], o.prototype, "actionDisabled");
e([
  t(i)
], o.prototype, "tooltipFixed");
e([
  t(i)
], o.prototype, "hasScroll");
e([
  t(i)
], o.prototype, "folded");
export {
  o as Widget
};
//# sourceMappingURL=widget.js.map
