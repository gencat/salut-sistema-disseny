import { nothing as d } from "lit";
import { classMap as c } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as e, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const a = e`dss-icon-button${t(l())}`, $ = e`dss-badge${t(l())}`, f = e`dss-icon-badge${t(l())}`, g = e`dss-notification-badge${t(l())}`, u = e`dss-decorative-icon${t(l())}`, r = e`dss-tooltip${t(l())}`, x = (s) => {
  const v = {
    "dss-widget": !0,
    [`dss-widget--${s.variant}`]: !!s.variant,
    "dss-widget--scroll": s.hasScroll,
    "dss-widget--folded": s.folded
  };
  return i`
  <div class="${c(v)}">
    <div class="dss-widget-header">
      <div class="dss-widget-header__info">
        <div class="dss-widget-title">
          ${s.icon ? i`
                <${u} icon=${s.icon} state=${s.iconStatus} size="sm"></${u}>
            ` : d}
          <div
            class="dss-widget-title__text" 
            @mouseenter=${s.checkTextTruncate}>
            ${s.title}
            <${r} ?tooltipFixed="${s.tooltipFixed}" class="title-tooltip" aria-hidden="true">
              ${s.title}
            </${r}>
          </div>
        </div>
      </div>

      <div class="dss-widget-header__config">
          <div class="dss-widget-header__config-info">
            ${s.results && s.resultsLabel === "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results}"
                ></${$}>
              ` : s.results && s.resultsLabel !== "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results} ${s.resultsLabel}"
                ></${$}>
              ` : d}
  
            ${s.info ? i`
                <${f}  size="md" state="${s.infoBadgeState}" icon="${s.infoBadgeIcon}" ?outlined="${s.infoBadgeOutlined}">
                  <${r} ?tooltipFixed="${s.tooltipFixed}" slot="tooltip">
                    <span>${s.info}</span>
                  </${r} >
                </${f} >
              ` : d}

            ${s.notifications ? i`
                <${g}
                  state="${s.notificationsState}"
                  value="${s.notifications}"
                >
                </${g}>
              ` : d}
          </div>

          ${(s.results || s.notifications || s.info) && (s.hasAction || s.hasNext || s.hasClose) ? i`
              <span class="dss-widget-header__divider"></span>
            ` : d}

          <div class="dss-widget-header__config-actions">
              ${s.hasAction ? i`
                  <${a}
                    size="md"
                    icon="${s.actionIcon}"
                    label="${s.actionLabel}"
                    variant="${s.actionVariant}"
                    ?disabled=${s.actionDisabled}
                    @onClick=${s.handleAction}
                  ></${a}>
                ` : d}

            ${s.hasNext ? i`
                  <${a}
                    size="md"
                    variant="primary"
                    label="Següent"
                    icon="arrow_forward"
                    @onClick="${s.handleNext}"
                  >
                  </${a}>
                ` : d}
            ${s.hasClose ? i`
                  <${a}
                    size="md"
                    variant="default"
                    icon="close"
                    label="Tancar"
                    @onClick="${s.handleClose}"
                  >
                  </${a}>
                ` : d}
          </div>
      </div>
    </div>
    ${s.folded ? d : i`
      <div class="dss-widget-body">
        <slot></slot> 
      </div>
      `}
  </div>
  `;
};
export {
  x as template
};
//# sourceMappingURL=widget.template.js.map
