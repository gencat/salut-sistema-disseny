import { LitElement as m, unsafeCSS as f } from "lit";
import { property as n } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as y } from "../../utils/property-types.js";
import g from "./header.style.css.js";
import { headerTemplate as S } from "./header.template.js";
var v = Object.defineProperty, p = (d, t, e, i) => {
  for (var r = void 0, s = d.length - 1, o; s >= 0; s--)
    (o = d[s]) && (r = o(t, e, r) || r);
  return r && v(t, e, r), r;
};
class l extends m {
  constructor() {
    super(...arguments), this.title = "", this.area = void 0, this.logoSrc = void 0, this.jcef = !1;
  }
  static get styles() {
    return [f(u), f(h), f(g)];
  }
  _propagateProperties() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelectorAll("slot");
    t && t.forEach((i) => {
      i.assignedElements().forEach((s) => {
        this.jcef ? s.setAttribute("jcef", "true") : s.removeAttribute("jcef");
      });
    });
  }
  _updateSlotsDivider() {
    var e;
    const t = (e = this.shadowRoot) == null ? void 0 : e.querySelectorAll("slot");
    t && t.forEach((i) => {
      const s = i.assignedNodes({ flatten: !0 }).filter((a) => {
        var c;
        return !(a.nodeType === Node.TEXT_NODE && ((c = a == null ? void 0 : a.textContent) == null ? void 0 : c.trim()) === "");
      }).length > 0, o = i.previousElementSibling;
      o && o.classList.contains("dss-header-divider") && (o.style.display = s ? "block" : "none");
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties(), this._updateSlotsDivider();
  }
  render() {
    return S(this);
  }
}
p([
  n({ type: String })
], l.prototype, "title");
p([
  n({ type: String })
], l.prototype, "area");
p([
  n({ type: String })
], l.prototype, "logoSrc");
p([
  n(y)
], l.prototype, "jcef");
export {
  l as Header
};
//# sourceMappingURL=header.js.map
