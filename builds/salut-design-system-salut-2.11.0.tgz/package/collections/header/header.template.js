import { html as a } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
import d from "../../assets/img/salut-logotip-default.svg.js";
const t = (s) => a`
  <header
    class=${e({
  "dss-header": !0
})}
  >
    <div class="dss-header-left">
      <div class="dss-header-brand">
        <img
          class="dss-header-logo"
          src="${s.logoSrc ? s.logoSrc : d}"
          alt="Salut logotip"
        />
        ${s.title ? a`
              <div class="dss-header-title">
                ${s.area ? a`
                      <span class="dss-header-title__area"
                        >${s.area}</span
                      >
                    ` : null}
                <span class="dss-header-title__name">${s.title}</span>
              </div>
            ` : null}
      </div>
      <div class="dss-header-divider"></div>
      <slot name="patient-menu"></slot>
      <div class="dss-header-divider"></div>
      <slot name="allergies"></slot>
      <div class="dss-header-divider"></div>
      <slot name="situation-marks"></slot>
    </div>
    <div class="dss-header-right">
      <slot name="links"></slot>
      <slot name="notifications"></slot>
      <div class="dss-header-divider"></div>
      <slot name="professional-menu"></slot>
    </div>
  </header>
`;
export {
  t as headerTemplate
};
//# sourceMappingURL=header.template.js.map
