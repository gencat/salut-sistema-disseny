import { LitElement as p, unsafeCSS as c } from "lit";
import { property as r } from "lit/decorators.js";
import f from "../../api/marker/marker.style.css.js";
import u from "../../shared/reset.style.css.js";
import _ from "../../shared/scrollbar.style.css.js";
import { normalizeText as n } from "../../utils/helpers.js";
import { booleanType as m } from "../../utils/property-types.js";
import y from "./preset-texts.style.css.js";
import { template as g } from "./preset-texts.template.js";
var x = Object.defineProperty, o = (d, e, t, i) => {
  for (var s = void 0, a = d.length - 1, h; a >= 0; a--)
    (h = d[a]) && (s = h(e, t, s) || s);
  return s && x(e, t, s), s;
};
class l extends p {
  constructor() {
    super(...arguments), this.title = "Textos predefinits", this.buttonLabelCancel = "Cancel-lar", this.buttonLabelSelect = "Seleccionar text", this.descriptionLabel = "Des del centre de configuració pots editar o eliminar aquest text.", this.items = [], this.open = !1, this.searchThreshold = 3, this.noResultsTitle = "Sense resultats", this.noResultsLabel = "No s’ha trobat cap resultat per a la teva cerca. Prova amb un altre terme.", this.noDataTitle = "Sense dades", this.noDataLabel = "No s’ha trobat cap text predefinit.", this._categories = [], this._currentCategory = "", this._selectedText = "", this._isFirstUpdate = !0, this._itemsBackup = [], this._filter = "", this._selectedIndex = void 0;
  }
  static get styles() {
    return [c(u), c(_), c(f), c(y)];
  }
  _handleTabChange(e) {
    this._currentCategory = e.detail, this._getDefaultSelectedText(this._currentCategory), this.requestUpdate(), setTimeout(() => {
      this._handleScroll();
    }, 500);
  }
  _handleCancel() {
    this._onClose();
  }
  _handleSelect() {
    this._onClose(), this._dispatchSelectText();
  }
  _onClose() {
    this.open = !1, this.requestUpdate();
    const e = new Event("onPredefinedTextsClosed");
    this.dispatchEvent(e);
  }
  _onSelectText(e, t) {
    this._selectedText = t, this._selectedIndex = e, this.requestUpdate();
  }
  _dispatchSelectText() {
    const e = {
      detail: this._selectedText,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onTextSelected", e));
  }
  _setCategories() {
    this._isFirstUpdate && (this._categories = [
      { label: "Propis", selected: !0 },
      { label: "Generals", selected: !1 }
    ], this._currentCategory = this._categories[0].label, this._getDefaultSelectedText(this._currentCategory)), this.requestUpdate();
  }
  _getDefaultSelectedText(e) {
    var i;
    const t = this.items.filter((s) => s.category === e);
    if (this._filter !== "") {
      const s = t.find(
        (a) => n(a.title).includes(this._filter) || n(a.text).includes(this._filter)
      );
      this._selectedText = s ? s.text : "";
      return;
    }
    this._selectedText = ((i = t[0]) == null ? void 0 : i.text) || "";
  }
  _checkScroll() {
    var i, s;
    const e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-predefined-texts-content"), t = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-predefined-texts-options");
    !e || !t || (t.scrollHeight > t.clientHeight && e.classList.add("dss-predefined-texts-content--scrolled-bottom"), t.addEventListener("scroll", this._handleScroll.bind(this)));
  }
  _handleScroll() {
    var i, s;
    const e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-predefined-texts-content"), t = (s = this.shadowRoot) == null ? void 0 : s.querySelector(".dss-predefined-texts-options");
    !e || !t || (t.scrollHeight <= t.clientHeight && (e.classList.remove("dss-predefined-texts-content--scrolled-top"), e.classList.remove("dss-predefined-texts-content--scrolled-bottom")), t.scrollTop > 0 ? e.classList.add("dss-predefined-texts-content--scrolled-top") : e.classList.remove("dss-predefined-texts-content--scrolled-top"), t.scrollHeight - t.scrollTop !== t.clientHeight ? e.classList.add("dss-predefined-texts-content--scrolled-bottom") : e.classList.remove("dss-predefined-texts-content--scrolled-bottom"));
  }
  _handleSearch(e) {
    const t = e.target;
    t.value.length >= this.searchThreshold ? this._filter = n(t.value) : this._filter = "", this._getDefaultSelectedText(this._currentCategory), this._selectedIndex = void 0, this.requestUpdate();
  }
  _clearFilter() {
    this._filter = "", this._getDefaultSelectedText(this._currentCategory), this._selectedIndex = void 0, this.requestUpdate();
  }
  _filterItems() {
    return this.items.filter((e) => {
      const t = e.category === this._currentCategory, i = !this._filter || n(e.title).includes(this._filter) || n(e.text).includes(this._filter);
      return t && i;
    });
  }
  async firstUpdated() {
    await this.updateComplete, this.items && (this._itemsBackup = [...this.items], this._checkScroll(), this._setCategories(), this._isFirstUpdate = !1);
  }
  willUpdate(e) {
    e.has("items") && (this._itemsBackup = [...this.items], this._setCategories());
  }
  render() {
    return g(this);
  }
}
o([
  r({ type: String })
], l.prototype, "title");
o([
  r({ type: String })
], l.prototype, "buttonLabelCancel");
o([
  r({ type: String })
], l.prototype, "buttonLabelSelect");
o([
  r({ type: String })
], l.prototype, "descriptionLabel");
o([
  r({ type: Array })
], l.prototype, "items");
o([
  r(m)
], l.prototype, "open");
o([
  r({ type: Number })
], l.prototype, "searchThreshold");
o([
  r({ type: String })
], l.prototype, "noResultsTitle");
o([
  r({ type: String })
], l.prototype, "noResultsLabel");
o([
  r({ type: String })
], l.prototype, "noDataTitle");
o([
  r({ type: String })
], l.prototype, "noDataLabel");
export {
  l as PresetTexts
};
//# sourceMappingURL=preset-texts.js.map
