import { LitElement as d, unsafeCSS as o, css as f } from "lit";
import { property as m } from "lit/decorators.js";
import { unsafeStatic as u, literal as c, html as y } from "lit/static-html.js";
import { getCustomElementSuffix as b } from "../../../api/custom-element-scope.js";
import v from "../../../components/icon-button/icon-button.style.css.js";
import S from "../../../foundations/icon/icon.style.css.js";
import h from "../../../shared/reset.style.css.js";
import { booleanType as g } from "../../../utils/property-types.js";
var _ = Object.defineProperty, a = (r, s, i, C) => {
  for (var t = void 0, e = r.length - 1, n; e >= 0; e--)
    (n = r[e]) && (t = n(s, i, t) || t);
  return t && _(s, i, t), t;
};
const l = c`dss-icon-button${u(b())}`;
class p extends d {
  constructor() {
    super(...arguments), this.position = "right", this.disabled = !1;
  }
  static get styles() {
    return [
      o(h),
      o(S),
      o(v),
      f`
        :host {
          display: block;
        }
      `
    ];
  }
  render() {
    return y`
      <div class="dss-card-menu">
				<${l}
					size="md"
					label="Menú"
					icon="more_vert"
					variant="primary"
					?disabled=${this.disabled}
				></${l}>
				<slot></slot>
      </div>
    `;
  }
}
a([
  m({ type: String })
], p.prototype, "position");
a([
  m(g)
], p.prototype, "disabled");
export {
  p as CardMenu
};
//# sourceMappingURL=card-menu.js.map
