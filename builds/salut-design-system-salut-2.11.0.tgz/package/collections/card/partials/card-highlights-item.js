import { LitElement as p, unsafeCSS as a, css as m } from "lit";
import { property as i } from "lit/decorators.js";
import { classMap as f } from "lit/directives/class-map.js";
import { unsafeStatic as u, literal as _, html as c } from "lit/static-html.js";
import v from "../../../foundations/icon/icon.style.css.js";
import b from "../../../shared/reset.style.css.js";
import { booleanType as n } from "../../../utils/property-types.js";
import { getCustomElementSuffix as x } from "../../../api/custom-element-scope.js";
var y = Object.defineProperty, s = (d, r, o, S) => {
  for (var t = void 0, l = d.length - 1, h; l >= 0; l--)
    (h = d[l]) && (t = h(r, o, t) || t);
  return t && y(r, o, t), t;
};
const g = _`dss-icon${u(x())}`;
class e extends p {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1, this.icon = "", this.title = "Title", this.text = "Item";
  }
  static get styles() {
    return [
      a(b),
      a(v),
      m`
        .dss-card-highligth {
					width: 100%;
          background-color: var(--color-blue-50);
          padding: var(--dss-spacing-xxs) var(--dss-spacing-xs);
          border-radius: var(--dss-radius-sm);
        }

        .dss-card-highligth__title {
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          color: var(--color-blue-700);
        }

        .dss-card-highligth__item {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-xxs);
          font-size: 14px;
          line-height: 24px;
          color: var(--color-blue-700);
        }

        .dss-card-highligth.deleted {
          background-color: var(--color-red-50);
        }

        .dss-card-highligth.deleted .dss-card-highligth__title,
        .dss-card-highligth.deleted .dss-card-highligth__item {
          color: var(--color-red-700);
        }

        .dss-card-highligth.disabled {
          background-color: var(--color-neutral-50);
        }

        .dss-card-highligth.disabled .dss-card-highligth__title,
        .dss-card-highligth.disabled .dss-card-highligth__item {
          color: var(--color-neutral-700);
        }
      `
    ];
  }
  render() {
    const r = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return c`
      <div class="dss-card-highligth ${f(r)}">
        <h5 class="dss-card-highligth__title">${this.title}</h5>
        <p class="dss-card-highligth__item">
          ${this.icon ? c`
            <${g} size="sm" icon="${this.icon}"></${g}>
            ` : ""}
          ${this.text}
        </p>
      </div>
    `;
  }
}
s([
  i(n)
], e.prototype, "deleted");
s([
  i(n)
], e.prototype, "disabled");
s([
  i({ type: String })
], e.prototype, "icon");
s([
  i({ type: String })
], e.prototype, "title");
s([
  i({ type: String })
], e.prototype, "text");
export {
  e as CardHighlightsItem
};
//# sourceMappingURL=card-highlights-item.js.map
