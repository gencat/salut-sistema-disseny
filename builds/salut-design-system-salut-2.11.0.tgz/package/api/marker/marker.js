import { normalizeText as f } from "../../utils/helpers.js";
function g(n, i) {
  if (!i) return n;
  const o = f(n), r = f(i);
  if (!r) return n;
  let t = "", e = 0, l = o.indexOf(r);
  for (; l !== -1; )
    t += n.slice(e, l), t += `<span class="dss-mark">${n.slice(l, l + i.length)}</span>`, e = l + i.length, l = o.indexOf(r, e);
  return t += n.slice(e), t;
}
function u(n, i, o = 1) {
  if (!i) return n;
  const r = f(n), t = i.split(/\s+/).map((s) => f(s)).filter((s) => s.length >= o);
  if (t.length === 0) return n;
  let e = "", l = 0;
  for (; l < n.length; ) {
    let s = null, c = 0;
    for (const h of t)
      h.length !== 0 && r.startsWith(h, l) && h.length > c && (s = n.substr(l, h.length), c = h.length);
    s ? (e += `<span class="dss-mark">${s}</span>`, l += c) : (e += n[l], l++);
  }
  return e;
}
export {
  g as highlightText,
  u as highlightTextMultiple
};
//# sourceMappingURL=marker.js.map
