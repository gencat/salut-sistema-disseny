import { nothing as d } from "lit";
import { classMap as v } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as a, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const e = a`dss-icon-button${t(l())}`, $ = a`dss-badge${t(l())}`, g = a`dss-icon-badge${t(l())}`, h = a`dss-notification-badge${t(l())}`, f = a`dss-decorative-icon${t(l())}`, r = a`dss-tooltip${t(l())}`, o = a`dss-typography${t(l())}`, _ = (s) => {
  const u = {
    "dss-widget": !0,
    [`dss-widget--${s.variant}`]: !!s.variant,
    "dss-widget--scroll": s.hasScroll,
    "dss-widget--folded": s.folded
  };
  return i`
  <div class="${v(u)}">
    <div class="dss-widget-header">
      <div class="dss-widget-header__info">
        <div class="dss-widget-title">
          ${s.icon ? i`
                <${f} icon=${s.icon} state=${s.iconStatus} size="sm"></${f}>
            ` : d}
          <div
            class="dss-widget-title__text" 
            @mouseenter=${s.checkTextTruncate}>
            ${s.title}
            <${r} class="title-tooltip" aria-hidden="true">
              ${s.title}
            </${r}>
          </div>
        </div>
      </div>

      <div class="dss-widget-header__config">
          <div class="dss-widget-header__config-info">
            ${s.helpText ? i`<${o} variant="body-3">${s.helpText}</${o}>` : null}
            ${s.results && s.resultsLabel === "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results}"
                ></${$}>
              ` : s.results && s.resultsLabel !== "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results} ${s.resultsLabel}"
                ></${$}>
              ` : d}
  
            ${s.info ? i`
                <${g}  size="md" state="${s.infoBadgeState}" icon="${s.infoBadgeIcon}" ?outlined="${s.infoBadgeOutlined}">
                  <${r} slot="tooltip">
                    <span>${s.info}</span>
                  </${r} >
                </${g} >
              ` : d}

            ${s.notifications ? i`
                <${h}
                  state="${s.notificationsState}"
                  value="${s.notifications}"
                >
                </${h}>
              ` : d}
          </div>

          ${(s.helpText || s.results || s.notifications || s.info) && (s.hasAction || s.hasNext || s.hasClose) ? i`
              <span class="dss-widget-header__divider"></span>
            ` : d}

          <div class="dss-widget-header__config-actions">
              ${s.hasAction ? i`
                  <${e}
                    size="md"
                    icon="${s.actionIcon}"
                    label="${s.actionLabel}"
                    variant="${s.actionVariant}"
                    ?fill=${s.actionFill}
                    ?disabled=${s.actionDisabled}
                    ?tooltipFixed=${s.tooltipFixed}
                    tooltipPosition="${s.tooltipPosition}"
                    ?hideTooltip="${s.hideTooltip}"
                    @onClick=${s.handleAction}
                  ></${e}>
                ` : d}

            ${s.hasNext ? i`
                  <${e}
                    size="md"
                    variant="primary"
                    label="Següent"
                    icon="arrow_forward"
                    hideTooltip
                    @onClick="${s.handleNext}"
                  >
                  </${e}>
                ` : d}
            ${s.hasClose ? i`
                  <${e}
                    size="md"
                    variant="default"
                    icon="close"
                    label="Tancar"
                    hideTooltip
                    @onClick="${s.handleClose}"
                  >
                  </${e}>
                ` : d}
          </div>
      </div>
    </div>
    ${s.folded ? d : i`
      <div class="dss-widget-body">
        <slot></slot> 
      </div>
      `}
  </div>
  `;
};
export {
  _ as template
};
//# sourceMappingURL=widget.template.js.map
