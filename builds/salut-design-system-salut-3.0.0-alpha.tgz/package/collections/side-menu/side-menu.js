import { LitElement as m, unsafeCSS as u } from "lit";
import { property as a } from "lit/decorators.js";
import { getCustomElementSuffix as _ } from "../../api/custom-element-scope.js";
import f from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import C from "../../shared/scrollbar.style.css.js";
import { booleanType as h } from "../../utils/property-types.js";
import b from "./side-menu.style.css.js";
import { sidemenuTemplate as w } from "./side-menu.template.js";
var y = Object.defineProperty, M = Object.getOwnPropertyDescriptor, d = (p, e, t, o) => {
  for (var s = o > 1 ? void 0 : o ? M(e, t) : e, i = p.length - 1, n; i >= 0; i--)
    (n = p[i]) && (s = (o ? n(e, t, s) : n(s)) || s);
  return o && s && y(e, t, s), s;
};
class l extends m {
  constructor() {
    super(), this.createMenuItems = [], this.roleMenuItems = [], this.globalMenuItems = [], this.axiaHidden = !1, this.axiaDisabled = !1, this.axiaLabel = "Axia", this._hasManualSelected = !1, this._disabled = !1, this._expanded = !1, this._toggleDisabled = !1, this._toggleLabel = "Tancar menú", this._hideCreateMenu = !1, this._createDisabled = !1, this._createLabel = "Crear", this._createMenuPosition = "top", this._createNotifications = 0, this._showCreateDropdown = !1, this._scrollContainerClass = "dss-layout-sidebar", this._resizeTimer = null, this._othersTopItem = null, this._dropdown = null, this._isFirstUpdated = !0, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleResizeBound = this._handleResize.bind(this), this._handleContainerScrollBound = this._handleContainerScroll.bind(this);
  }
  static get styles() {
    return [u(g), u(C), u(f), u(b)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), document.addEventListener("mousedown", this._handleDocumentClickBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), document.removeEventListener("mousedown", this._handleDocumentClickBound), this._scrollContainer && this._scrollContainer.removeEventListener("scroll", this._handleContainerScrollBound);
  }
  set expanded(e) {
    const t = this._expanded;
    this._expanded = e, this.requestUpdate("expanded", t);
  }
  get expanded() {
    return this._expanded;
  }
  set disabled(e) {
    const t = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", t);
  }
  get disabled() {
    return this._disabled;
  }
  set toggleLabel(e) {
    const t = this._toggleLabel;
    this._toggleLabel = e, this.requestUpdate("toggleLabel", t);
  }
  get toggleLabel() {
    return this._toggleLabel;
  }
  set createLabel(e) {
    const t = this._createLabel;
    this._createLabel = e, this.requestUpdate("createLabel", t);
  }
  get createLabel() {
    return this._createLabel;
  }
  set createMenuPosition(e) {
    const t = this._createMenuPosition;
    this._createMenuPosition = e, this.requestUpdate("createMenuPosition", t);
  }
  get createMenuPosition() {
    return this._createMenuPosition;
  }
  set createNotifications(e) {
    const t = this._createNotifications;
    this._createNotifications = e, this.requestUpdate("createNotifications", t);
  }
  get createNotifications() {
    return this._createNotifications;
  }
  set createDisabled(e) {
    const t = this._createDisabled;
    this._createDisabled = e, this.requestUpdate("createDisabled", t);
  }
  get createDisabled() {
    return this._createDisabled;
  }
  set hideCreateMenu(e) {
    const t = this._hideCreateMenu;
    this._hideCreateMenu = e, this.requestUpdate("hideCreateMenu", t);
  }
  get hideCreateMenu() {
    return this._hideCreateMenu;
  }
  set scrollContainerClass(e) {
    const t = this._scrollContainerClass;
    this._scrollContainerClass = e, this.requestUpdate("scrollContainerClass", t);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  get _createNotification() {
    return this.shadowRoot?.querySelector("dss-notification-badge") || void 0;
  }
  get _createSection() {
    return this.shadowRoot?.querySelector(".dss-sidemenu-create");
  }
  _propagateProperties() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((t) => {
      t.assignedElements().forEach((s) => {
        this._expanded ? s.setAttribute("expanded", "true") : s.removeAttribute("expanded"), this._scrollContainerClass ? s.setAttribute("scrollContainerClass", this._scrollContainerClass) : s.removeAttribute("scrollContainerClass");
      });
    });
  }
  _handleResize() {
    this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._checkWindowInnerwidth(), this._updateTopMenu(), this._getHiddenRoleNotifications();
    }, 250);
  }
  _getHiddenRoleNotifications() {
    if (!this._othersTopItem) return;
    const e = this._othersTopItem.querySelectorAll("dss-action-menu-item"), t = Array.from(e).filter(
      (s) => s.parentElement?.parentElement === this._othersTopItem && s.classList.contains("hidden") === !1
    );
    let o = 0;
    for (const s of t) {
      const i = s.getAttribute("notifications");
      i && (o += Number(i));
    }
    this._othersTopItem.setAttribute("notifications", o.toString());
  }
  _getTopMenuItems(e) {
    const t = e.querySelectorAll("dss-sidemenu-list-item"), o = Array.from(t).filter(
      (c) => c.classList.contains("dss-sidemenu-top-menu__other-items") === !1
    ), i = e.querySelector(".dss-sidemenu-top-menu__other-items").querySelectorAll("dss-action-menu");
    if (!i) return;
    const n = i[0], r = Array.from(n.querySelectorAll("dss-action-menu-item")).filter(
      (c) => c.parentElement === n
    );
    return { defaultItems: o, hiddenItems: r };
  }
  async _updateTopMenu() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu");
    if (!e) return;
    const t = this._getTopMenuItems(e);
    if (!t) return;
    const o = 40;
    let s = 0, i = 0;
    for (const [n, r] of t.defaultItems.entries()) {
      if (s += o, n === 0) {
        r.classList.remove("hidden");
        continue;
      }
      s <= e.clientHeight ? r.classList.remove("hidden") : (r.classList.add("hidden"), i += 1), s += 4;
    }
    if (this._othersTopItem = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu__other-items"), i > 0) {
      if (this._othersTopItem?.classList.remove("hidden"), e.scrollHeight > e.clientHeight) {
        const n = t.defaultItems.filter((c) => !c.classList.contains("hidden")), r = n[n.length - 1];
        r !== t.defaultItems[0] && (r.classList.add("hidden"), i += 1);
      }
      t.hiddenItems && (t.hiddenItems.forEach((r) => r.classList.add("hidden")), t.hiddenItems.slice(-i).forEach((r) => r.classList.remove("hidden")));
    } else
      this._othersTopItem?.classList.add("hidden");
  }
  _checkWindowInnerwidth() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-toggle");
    window.innerWidth < 1024 ? (this.removeAttribute("expanded"), this._toggleDisabled = !0, e.disabled = !0, e.classList.add("dss-sidemenu-toggle--hidden")) : (this._toggleDisabled = !1, e.disabled = !1, e.classList.remove("dss-sidemenu-toggle--hidden"));
  }
  _clickedOutsideCreateMenu(e, t) {
    t.composedPath().includes(e) || this._closeCreateDropdown();
  }
  _closeCreateDropdown() {
    this._showCreateDropdown && (this._showCreateDropdown = !1, this._toggleCreateMenuTooltip(), this.requestUpdate());
  }
  _handleKeydownEscape(e) {
    const o = e.detail.shadowRoot?.querySelector("slot");
    if (!o) return;
    const i = `dss-action-menu${_()}`, r = o.assignedElements({ flatten: !0 }).find((c) => c.tagName.toLowerCase() === i);
    r && r.classList.contains("visible") && r._closeMenu();
  }
  _handleDocumentClick(e) {
    this._createSection && this._clickedOutsideCreateMenu(this._createSection, e);
  }
  _openCreateMenu() {
    this._showCreateDropdown = !0, this._toggleCreateMenuTooltip(), this.requestUpdate();
  }
  _toggleCreateMenuTooltip() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create__tooltip");
    this._showCreateDropdown ? e?.classList.add("force-hidden") : e?.classList.remove("force-hidden");
  }
  _toggleSidemenu() {
    this._expanded ? this.removeAttribute("expanded") : this.setAttribute("expanded", "true");
  }
  _handleCreateMouseEnter() {
    this._createNotification && this._createNotification.setAttribute("isHover", "true");
  }
  _handleCreateMouseLeave() {
    this._createNotification && this._createNotification.removeAttribute("isHover");
  }
  _handleCreateMouseDown() {
    this._createNotification && this._createNotification.setAttribute("isActive", "true");
  }
  _handleCreateFocusout(e) {
    if (this._showCreateDropdown) {
      const t = e.relatedTarget;
      t === null && this._closeCreateDropdown(), t && !this._createSection.contains(t) && t.tagName !== "DSS-ACTION-MENU-ITEM" && this._closeCreateDropdown();
    }
  }
  _handleCreateMouseUp() {
    this._createNotification && this._createNotification.removeAttribute("isActive");
  }
  _handleMenuClick(e, t) {
    if (t.nestedMenu || t.disabled) return;
    t.external || this._selectSidenenuItem(e);
    const o = e.composedPath(), s = o.some((c) => c instanceof HTMLElement && c.classList.contains("dss-sidemenu-top-menu")), i = o.some(
      (c) => c instanceof HTMLElement && c.classList.contains("dss-sidemenu-bottom-menu")
    );
    let n = "";
    s ? n = "role" : i ? n = "global" : n = "create";
    const r = {
      detail: {
        menu: n,
        label: t.label,
        item: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onSidemenuClick", r));
  }
  _selectSidenenuItem(e) {
    this.shadowRoot?.querySelectorAll('dss-sidemenu-list-item[selected="true"]')?.forEach((i) => {
      i.removeAttribute("selected");
    });
    const s = e.currentTarget.closest("dss-sidemenu-list-item");
    s && s.setAttribute("selected", "true"), this._hasManualSelected = !0, this.requestUpdate();
  }
  get _scrollContainer() {
    return document.querySelector(`.${this._scrollContainerClass}`);
  }
  _getCreateDropdownFixedPosition() {
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create");
    if (!e) return;
    const t = e.getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-create__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _handleContainerScroll() {
    this._getCreateDropdownFixedPosition();
  }
  _handleAxia() {
    const e = {
      detail: !0,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onToggleAxia", e));
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties();
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create__dropdown");
    e && (this._dropdown = e, this._getCreateDropdownFixedPosition()), this._scrollContainer && this._scrollContainer.addEventListener("scroll", this._handleContainerScrollBound), this._othersTopItem = this.shadowRoot?.querySelector(".dss-sidemenu-top-menu__other-items"), this._expanded && this.requestUpdate(), this._isFirstUpdated = !1;
  }
  updated(e) {
    super.updated(e), (e.has("expanded") || e.has("disabled")) && (this._propagateProperties(), this._getCreateDropdownFixedPosition()), this._isFirstUpdated || requestAnimationFrame(() => this._updateTopMenu());
  }
  render() {
    return w(this);
  }
}
d([
  a({ type: Array })
], l.prototype, "createMenuItems", 2);
d([
  a({ type: Array })
], l.prototype, "roleMenuItems", 2);
d([
  a({ type: Array })
], l.prototype, "globalMenuItems", 2);
d([
  a(h)
], l.prototype, "axiaHidden", 2);
d([
  a(h)
], l.prototype, "axiaDisabled", 2);
d([
  a({ type: String })
], l.prototype, "axiaLabel", 2);
d([
  a(h)
], l.prototype, "expanded", 1);
d([
  a(h)
], l.prototype, "disabled", 1);
d([
  a({ type: String })
], l.prototype, "toggleLabel", 1);
d([
  a({ type: String })
], l.prototype, "createLabel", 1);
d([
  a({ type: String })
], l.prototype, "createMenuPosition", 1);
d([
  a({ type: Number })
], l.prototype, "createNotifications", 1);
d([
  a(h)
], l.prototype, "createDisabled", 1);
d([
  a(h)
], l.prototype, "hideCreateMenu", 1);
d([
  a({ type: String })
], l.prototype, "scrollContainerClass", 1);
export {
  l as Sidemenu_
};
//# sourceMappingURL=side-menu.js.map
