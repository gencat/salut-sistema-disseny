import { nothing as l } from "lit";
import { classMap as x } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as n, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as $ } from "../../api/custom-element-scope.js";
import g from "../../assets/img/logo_axia.svg.js";
const r = n`dss-icon${t($())}`, o = n`dss-tooltip${t($())}`, v = n`dss-notification-badge${t($())}`, _ = n`dss-sidemenu-list${t($())}`, c = n`dss-sidemenu-list-item${t($())}`, h = n`dss-action-menu${t($())}`, f = n`dss-action-menu-item${t($())}`, b = (e, s, i) => a`
    <${h} class="dss-sidemenu-nested-menu">
      ${e.map(
  (d) => a`
        <${f}
          class=${x({
    hidden: !!s
  })}
          lefticon=${d.icon}
          label=${d.label}
          notifications=${d.notifications}
          ?disabled=${d.disabled}
          ?hasNestedMenu=${!!d.nestedMenu}
           @click=${(u) => i._handleMenuClick(u, d)}
        >
          ${d.nestedMenu ? b(d.nestedMenu, !1, i) : l}
        </${f}>
      `
)}
    </${h}>
  `, k = (e) => {
  if (!e._othersTopItem) return 0;
  const s = e._othersTopItem.querySelectorAll("dss-action-menu-item"), i = Array.from(s).filter(
    (u) => u.parentElement?.parentElement === e._othersTopItem && u.classList.contains("hidden") === !1
  );
  let d = 0;
  for (const u of i) {
    const M = u.getAttribute("notifications");
    M && (d += Number(M));
  }
  return d;
}, E = (e) => a`
  <aside
    class=${x({
  "dss-sidemenu": !0,
  "dss-sidemenu--expanded": !!e._expanded
})}
  >
    ${e.roleMenuItems.length > 0 ? a`
        <div class="dss-sidemenu-top-menu">
          <${_} ?expanded=${e._expanded}>
            ${e.roleMenuItems.map(
  (s) => a`
              <${c}
                icon=${s.icon}
                label=${s.label}
                notifications=${s.notifications}
                ?selected=${s.selected && !e._hasManualSelected}
                ?disabled=${s.disabled}
                ?hasNestedMenu=${!!s.nestedMenu}
                ?expanded=${e._expanded}
                @click=${(i) => e._handleMenuClick(i, s)}
                @keydownEscape=${e._handleKeydownEscape}
                >
                ${s.nestedMenu ? b(s.nestedMenu, !1, e) : l}
              </${c}>
            `
)}
            <${c} 
              class="dss-sidemenu-top-menu__other-items hidden"
              expanded=${e._expanded}
              icon="more_horiz"
              label="Altres"
              notifications=${k(e)}
              @keydownEscape=${e._handleKeydownEscape}
              hasNestedMenu>
               ${b(e.roleMenuItems, !0, e)}
            </${c}>
          </${_}>
        </div>
    ` : l}

    ${e._hideCreateMenu ? l : a`
          <div
            class="dss-sidemenu-create"
            @focusout="${e._handleCreateFocusout}"
          >
            <button
              class="dss-sidemenu-create__button"
              ?disabled=${e._createDisabled}
              @click="${e._openCreateMenu}"
              @mouseenter="${e._handleCreateMouseEnter}"
              @mouseleave="${e._handleCreateMouseLeave}"
              @mousedown="${e._handleCreateMouseDown}"
              @mouseup="${e._handleCreateMouseUp}"
              aria-label="${e._createLabel}"
            >
              <span class="dss-sidemenu-create__button__content">
                <${r} class="dss-sidemenu-create__icon" size="md" icon="add"></${r}>
                ${e._createNotifications && !e._showCreateDropdown && !e._createDisabled ? a`
                      <${v}
                        class=${x({
  "dss-sidemenu-create__notification": !0,
  "dss-sidemenu-create__notification--expanded": !0
})}
                        value="${e._createNotifications}"
                        state="error"
                        type="default"
                        borderWhite
                      />
                    ` : null}
              </span>
              ${e._expanded ? a` ${e._createLabel} ` : null}
            </button>

            <${o} position="right" class="dss-sidemenu-create__tooltip" delay="800" ?hidden=${e._expanded}>
              ${e._createLabel}
            </${o}>

            <${h}>
              ${e.createMenuItems.map(
  (s) => a`
                <${f}
                  label=${s.label}
                  notifications=${s.notifications}
                  @click=${(i) => e._handleMenuClick(i, s)}
                  >
                </${f}>
              `
)}
            </${h}>
          </div>
        `}

    <div class="dss-sidemenu-bottom">
      <div class="dss-sidemenu-bottom-menu">
        <div class="dss-sidemenu-divider"></div>
          ${e.globalMenuItems.length > 0 ? a`
            <${_} ?expanded=${e._expanded}>
              ${e.globalMenuItems.map(
  (s) => a`
                <${c}
                  icon=${s.icon}
                  label=${s.label}
                  notifications=${s.notifications}
                  ?selected=${s.selected && !e._hasManualSelected}
                  ?disabled=${s.disabled}
                  ?hasNestedMenu=${!!s.nestedMenu}
                  ?expanded=${e._expanded}
                  @click=${(i) => e._handleMenuClick(i, s)}
                  @keydownEscape=${e._handleKeydownEscape}
                  >
                  ${s.nestedMenu ? b(s.nestedMenu, !1, e) : l}
                </${c}>
              `
)}
            </${_}>
           ` : l}
          ${e.axiaHidden ? l : a`
            <div class="dss-sidemenu-toggle-axia">
              <button
                class="dss-sidemenu-axia"
                ?disabled=${e.axiaDisabled}
                @click="${e._handleAxia}"
              >
                <span class="dss-sidemenu-axia__content">
                  <img src="${g}" alt="Logo Axia" class="dss-sidemenu-axia__logo" />
                  <span class="dss-sidemenu-axia__label">${e.axiaLabel}</span>
                </span>
              </button>
              <${o} position="right" class="dss-sidemenu-axia__tooltip" delay="800" ?hidden=${e._expanded}>
                ${e.axiaLabel}
              </${o}>
            </div>
          `}
        </div>
     
      
      <button
        class="dss-sidemenu-toggle"
        ?disabled=${e._toggleDisabled}
        @click="${e._toggleSidemenu}"
        aria-label="${e._expanded ? "col·lapsar menú" : "expandir menú"}"
      >
        ${e._expanded ? a`
              <${r} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_left"></${r}>
            ` : a`
              <${r} class="dss-sidemenu-toggle__icon" size="md" icon="chevron_right"></${r}>
            `}
        ${e._expanded ? a` ${e._toggleLabel} ` : null}
      </button>
    </div>
  </aside>
`;
export {
  E as sidemenuTemplate
};
//# sourceMappingURL=side-menu.template.js.map
