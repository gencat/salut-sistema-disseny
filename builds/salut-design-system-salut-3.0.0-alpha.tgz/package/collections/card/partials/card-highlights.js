import { LitElement as m, css as u, html as f } from "lit";
import { property as a } from "lit/decorators.js";
import { booleanType as o } from "../../../utils/property-types.js";
var h = Object.defineProperty, l = (r, t, s, n) => {
  for (var e = void 0, d = r.length - 1, i; d >= 0; d--)
    (i = r[d]) && (e = i(t, s, e) || e);
  return e && h(t, s, e), e;
};
class p extends m {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return u`
      :host {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(10px, 1fr));
        gap: var(--dss-spacing-sm);
      }
    `;
  }
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((s) => {
      s.assignedElements().forEach((e) => {
        this.deleted ? e.setAttribute("deleted", "true") : e.removeAttribute("deleted"), this.disabled ? e.setAttribute("disabled", "true") : e.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), (t.has("deleted") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return f` <slot></slot> `;
  }
}
l([
  a(o)
], p.prototype, "deleted");
l([
  a(o)
], p.prototype, "disabled");
export {
  p as CardHighlights
};
//# sourceMappingURL=card-highlights.js.map
