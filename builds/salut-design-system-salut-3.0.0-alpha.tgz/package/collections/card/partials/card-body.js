import { LitElement as f, unsafeCSS as u, css as m, html as b } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as l } from "../../../utils/property-types.js";
import c from "../../../foundations/icon/icon.style.css.js";
var h = Object.defineProperty, a = (r, t, s, n) => {
  for (var e = void 0, d = r.length - 1, o; d >= 0; d--)
    (o = r[d]) && (e = o(t, s, e) || e);
  return e && h(t, s, e), e;
};
class p extends f {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      u(c),
      m`
        :host {
          display: flex;
          flex-direction: column;
          gap: var(--dss-spacing-xxs);
        }
      `
    ];
  }
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((s) => {
      s.assignedElements().forEach((e) => {
        this.deleted ? e.setAttribute("deleted", "true") : e.removeAttribute("deleted"), this.disabled ? e.setAttribute("disabled", "true") : e.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), (t.has("deleted") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return b` <slot></slot> `;
  }
}
a([
  i(l)
], p.prototype, "deleted");
a([
  i(l)
], p.prototype, "disabled");
export {
  p as CardBody
};
//# sourceMappingURL=card-body.js.map
