import { LitElement as m, unsafeCSS as f, css as u } from "lit";
import { property as d } from "lit/decorators.js";
import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as b, literal as v, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as y } from "../../../api/custom-element-scope.js";
import _ from "../../../foundations/icon/icon.style.css.js";
import S from "../../../shared/reset.style.css.js";
import { booleanType as r } from "../../../utils/property-types.js";
var x = Object.defineProperty, i = (o, e, a, h) => {
  for (var s = void 0, n = o.length - 1, c; n >= 0; n--)
    (c = o[n]) && (s = c(e, a, s) || s);
  return s && x(e, a, s), s;
};
const p = v`dss-icon${b(y())}`;
class l extends m {
  constructor() {
    super(...arguments), this.flag = !1, this.hasMenu = !1, this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return [
      f(S),
      f(_),
      // actionMenuStyles,
      u`
        .dss-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-lg);
					width: 100%;
        }

        .dss-card-header-title {
          flex: 1;
        }

        .dss-card-header-actions {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: var(--dss-spacing-xs);
        }

        .dss-card-header-actions__flag {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* METHODS */
  _propagateProperties() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((a) => {
      a.assignedElements().forEach((s) => {
        this.deleted ? s.setAttribute("deleted", "true") : s.removeAttribute("deleted"), this.disabled ? s.setAttribute("disabled", "true") : s.removeAttribute("disabled");
      });
    });
  }
  /* LIT LIFECYCLE */
  updated(e) {
    super.updated(e), (e.has("deleted") || e.has("disabled")) && this._propagateProperties();
  }
  render() {
    const e = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return t`
      <div class="dss-card-header">
        <div class="dss-card-header-title ${g(e)}">
          <slot name="title"></slot>
        </div>
        ${this.flag || this.hasMenu ? t`
              <div class="dss-card-header-actions">
                ${this.flag ? t`<${p} icon="flag" size="md" fill class="dss-card-header-actions__flag"></${p}>` : ""}
                ${this.hasMenu ? t` <slot name="menu"></slot> ` : t``}
              </div>
            ` : t``}
      </div>
    `;
  }
}
i([
  d(r)
], l.prototype, "flag");
i([
  d(r)
], l.prototype, "hasMenu");
i([
  d(r)
], l.prototype, "deleted");
i([
  d(r)
], l.prototype, "disabled");
export {
  l as CardHeader
};
//# sourceMappingURL=card-header.js.map
