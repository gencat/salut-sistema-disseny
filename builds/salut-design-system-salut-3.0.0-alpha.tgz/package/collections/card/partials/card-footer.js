import { LitElement as p, css as u, html as f } from "lit";
import { property as d } from "lit/decorators.js";
import { booleanType as a } from "../../../utils/property-types.js";
var m = Object.defineProperty, n = (r, t, e, c) => {
  for (var s = void 0, o = r.length - 1, i; o >= 0; o--)
    (i = r[o]) && (s = i(t, e, s) || s);
  return s && m(t, e, s), s;
};
class l extends p {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1;
  }
  static get styles() {
    return u`
      :host {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        width: 100%;
        gap: var(--dss-spacing-sm);
        padding-top: var(--dss-spacing-sm) !important;
        border-top: var(--dss-border-width-sm) solid var(--color-neutral-100);
      }
    `;
  }
  get _footerContent() {
    const t = this.shadowRoot?.querySelector("slot") || void 0;
    return this.requestUpdate(), t?.assignedElements();
  }
  _propagateProperties() {
    if (this._footerContent)
      for (const t of this._footerContent)
        this.disabled ? t.setAttribute("disabled", "true") : t.removeAttribute("disabled"), this.deleted ? t.classList.contains("dss-button--primary") && (t.classList.remove("dss-button--primary"), t.classList.add("dss-button--error")) : t.classList.contains("dss-button--error") && (t.classList.add("dss-button--primary"), t.classList.remove("dss-button--error"));
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), (t.has("deleted") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return f` <slot></slot> `;
  }
}
n([
  d(a)
], l.prototype, "deleted");
n([
  d(a)
], l.prototype, "disabled");
export {
  l as CardFooter
};
//# sourceMappingURL=card-footer.js.map
