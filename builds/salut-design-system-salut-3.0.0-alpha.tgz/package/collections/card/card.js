import { LitElement as m, unsafeCSS as p } from "lit";
import { property as s } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import b from "./card.style.css.js";
import { template as y } from "./card.template.js";
var c = Object.defineProperty, o = (a, t, l, n) => {
  for (var e = void 0, d = a.length - 1, f; d >= 0; d--)
    (f = a[d]) && (e = f(t, l, e) || e);
  return e && c(t, l, e), e;
};
class i extends m {
  constructor() {
    super(...arguments), this.selected = !1, this.dragged = !1, this.deleted = !1, this.disabled = !1, this.hasClose = !1, this.hasDetails = !1;
  }
  static get styles() {
    return [p(u), p(h), p(b)];
  }
  /* METHODS */
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((l) => {
      l.assignedElements().forEach((e) => {
        this.deleted ? e.setAttribute("deleted", "true") : e.removeAttribute("deleted"), this.disabled ? e.setAttribute("disabled", "true") : e.removeAttribute("disabled");
      });
    });
  }
  /* EVENTS */
  _dispatchClose() {
    this.dispatchEvent(new CustomEvent("onClose", { bubbles: !0 }));
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), (t.has("deleted") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return y(this);
  }
}
o([
  s(r)
], i.prototype, "selected");
o([
  s(r)
], i.prototype, "dragged");
o([
  s(r)
], i.prototype, "deleted");
o([
  s(r)
], i.prototype, "disabled");
o([
  s(r)
], i.prototype, "hasClose");
o([
  s(r)
], i.prototype, "hasDetails");
export {
  i as Card
};
//# sourceMappingURL=card.js.map
