import { LitElement as p, unsafeCSS as n } from "lit";
import { property as s } from "lit/decorators.js";
import f from "../../api/marker/marker.style.css.js";
import u from "../../shared/reset.style.css.js";
import _ from "../../shared/scrollbar.style.css.js";
import { normalizeText as a } from "../../utils/helpers.js";
import { booleanType as m } from "../../utils/property-types.js";
import y from "./preset-texts.style.css.js";
import { template as x } from "./preset-texts.template.js";
var g = Object.defineProperty, i = (d, t, e, l) => {
  for (var o = void 0, c = d.length - 1, h; c >= 0; c--)
    (h = d[c]) && (o = h(t, e, o) || o);
  return o && g(t, e, o), o;
};
class r extends p {
  constructor() {
    super(...arguments), this.title = "Textos predefinits", this.titleText = "Textos predefinits", this.buttonLabelCancel = "Cancel-lar", this.buttonLabelSelect = "Seleccionar text", this.descriptionLabel = "Des del centre de configuració pots editar o eliminar aquest text.", this.items = [], this.open = !1, this.searchThreshold = 3, this.noResultsTitle = "Sense resultats", this.noResultsLabel = "No s’ha trobat cap resultat per a la teva cerca. Prova amb un altre terme.", this.noDataTitle = "Sense dades", this.noDataLabel = "No s’ha trobat cap text predefinit.", this._categories = [], this._currentCategory = "", this._selectedText = "", this._isFirstUpdate = !0, this._itemsBackup = [], this._filter = "", this._selectedIndex = void 0;
  }
  static get styles() {
    return [n(u), n(_), n(f), n(y)];
  }
  _handleTabChange(t) {
    this._currentCategory = t.detail, this._getDefaultSelectedText(this._currentCategory), this.requestUpdate(), setTimeout(() => {
      this._handleScroll();
    }, 500);
  }
  _handleCancel() {
    this._onClose();
  }
  _handleSelect() {
    this._onClose(), this._dispatchSelectText();
  }
  _onClose() {
    this.open = !1, this.requestUpdate();
    const t = new Event("onPredefinedTextsClosed");
    this.dispatchEvent(t);
  }
  _onSelectText(t, e) {
    this._selectedText = e, this._selectedIndex = t, this.requestUpdate();
  }
  _dispatchSelectText() {
    const t = {
      detail: this._selectedText,
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onTextSelected", t));
  }
  _setCategories() {
    this._isFirstUpdate && (this._categories = [
      { label: "Propis", selected: !0 },
      { label: "Generals", selected: !1 }
    ], this._currentCategory = this._categories[0].label, this._getDefaultSelectedText(this._currentCategory)), this.requestUpdate();
  }
  _getDefaultSelectedText(t) {
    const e = this.items.filter((l) => l.category === t);
    if (this._filter !== "") {
      const l = e.find(
        (o) => a(o.title).includes(this._filter) || a(o.text).includes(this._filter)
      );
      this._selectedText = l ? l.text : "";
      return;
    }
    this._selectedText = e[0]?.text || "";
  }
  _checkScroll() {
    const t = this.shadowRoot?.querySelector(".dss-predefined-texts-content"), e = this.shadowRoot?.querySelector(".dss-predefined-texts-options");
    !t || !e || (e.scrollHeight > e.clientHeight && t.classList.add("dss-predefined-texts-content--scrolled-bottom"), e.addEventListener("scroll", this._handleScroll.bind(this)));
  }
  _handleScroll() {
    const t = this.shadowRoot?.querySelector(".dss-predefined-texts-content"), e = this.shadowRoot?.querySelector(".dss-predefined-texts-options");
    !t || !e || (e.scrollHeight <= e.clientHeight && (t.classList.remove("dss-predefined-texts-content--scrolled-top"), t.classList.remove("dss-predefined-texts-content--scrolled-bottom")), e.scrollTop > 0 ? t.classList.add("dss-predefined-texts-content--scrolled-top") : t.classList.remove("dss-predefined-texts-content--scrolled-top"), e.scrollHeight - e.scrollTop !== e.clientHeight ? t.classList.add("dss-predefined-texts-content--scrolled-bottom") : t.classList.remove("dss-predefined-texts-content--scrolled-bottom"));
  }
  _handleSearch(t) {
    const e = t.target;
    e.value.length >= this.searchThreshold ? this._filter = a(e.value) : this._filter = "", this._getDefaultSelectedText(this._currentCategory), this._selectedIndex = void 0, this.requestUpdate();
  }
  _clearFilter() {
    this._filter = "", this._getDefaultSelectedText(this._currentCategory), this._selectedIndex = void 0, this.requestUpdate();
  }
  _filterItems() {
    return this.items.filter((t) => {
      const e = t.category === this._currentCategory, l = !this._filter || a(t.title).includes(this._filter) || a(t.text).includes(this._filter);
      return e && l;
    });
  }
  async firstUpdated() {
    await this.updateComplete, this.items && (this._itemsBackup = [...this.items], this._checkScroll(), this._setCategories(), this._isFirstUpdate = !1);
  }
  updated(t) {
    super.updated(t), t.has("title") && queueMicrotask(() => {
      this.title !== "Textos predefinits" && (this.titleText = this.title);
    });
  }
  willUpdate(t) {
    t.has("items") && (this._itemsBackup = [...this.items], this._setCategories());
  }
  render() {
    return x(this);
  }
}
i([
  s({ type: String })
], r.prototype, "title");
i([
  s({ type: String })
], r.prototype, "titleText");
i([
  s({ type: String })
], r.prototype, "buttonLabelCancel");
i([
  s({ type: String })
], r.prototype, "buttonLabelSelect");
i([
  s({ type: String })
], r.prototype, "descriptionLabel");
i([
  s({ type: Array })
], r.prototype, "items");
i([
  s(m)
], r.prototype, "open");
i([
  s({ type: Number })
], r.prototype, "searchThreshold");
i([
  s({ type: String })
], r.prototype, "noResultsTitle");
i([
  s({ type: String })
], r.prototype, "noResultsLabel");
i([
  s({ type: String })
], r.prototype, "noDataTitle");
i([
  s({ type: String })
], r.prototype, "noDataLabel");
export {
  r as PresetTexts
};
//# sourceMappingURL=preset-texts.js.map
