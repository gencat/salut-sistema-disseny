import { LitElement as h, unsafeCSS as p } from "lit";
import { property as i } from "lit/decorators.js";
import u from "../../foundations/icon/icon.style.css.js";
import c from "../../shared/reset.style.css.js";
import { booleanType as f } from "../../utils/property-types.js";
import m from "./header.style.css.js";
import { headerTemplate as y } from "./header.template.js";
var g = Object.defineProperty, o = (n, t, r, d) => {
  for (var e = void 0, s = n.length - 1, a; s >= 0; s--)
    (a = n[s]) && (e = a(t, r, e) || e);
  return e && g(t, r, e), e;
};
class l extends h {
  constructor() {
    super(...arguments), this.title = "", this.titleText = "", this.titleFullWidth = !1, this.area = void 0, this.logoSrc = void 0, this.jcef = !1;
  }
  static get styles() {
    return [p(c), p(u), p(m)];
  }
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((r) => {
      r.assignedElements().forEach((e) => {
        this.jcef ? e.setAttribute("jcef", "true") : e.removeAttribute("jcef");
      });
    });
  }
  _updateSlotsDivider() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((r) => {
      const e = r.assignedNodes({ flatten: !0 }).filter((a) => !(a.nodeType === Node.TEXT_NODE && a?.textContent?.trim() === "")).length > 0, s = r.previousElementSibling;
      s && s.classList.contains("dss-header-divider") && (s.style.display = e ? "block" : "none");
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties(), this._updateSlotsDivider();
  }
  updated(t) {
    super.updated(t), t.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return y(this);
  }
}
o([
  i({ type: String })
], l.prototype, "title");
o([
  i({ type: String })
], l.prototype, "titleText");
o([
  i(f)
], l.prototype, "titleFullWidth");
o([
  i({ type: String })
], l.prototype, "area");
o([
  i({ type: String })
], l.prototype, "logoSrc");
o([
  i(f)
], l.prototype, "jcef");
export {
  l as Header
};
//# sourceMappingURL=header.js.map
