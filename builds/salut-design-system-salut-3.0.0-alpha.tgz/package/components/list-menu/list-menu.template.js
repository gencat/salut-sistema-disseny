import { nothing as t } from "lit";
import { classMap as $ } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as a, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
const d = a`dss-icon${l(c())}`, u = a`dss-notification-badge${l(c())}`, m = a`dss-decorative-icon${l(c())}`, o = a`dss-tooltip${l(c())}`, x = (s) => i`
  <div class="dss-list-menu">
    ${s.titleText || s.description ? i`
      <div class="dss-list-menu-header">
        <h4 class="dss-list-menu-header-title" id="menu-title">
          ${s.icon ? i`<${m} icon="${s.icon}" state="default" size="md" />` : ""}
          ${s.titleText}
        </h4>
        <p class="dss-list-menu-header-description" id="menu-description">
          ${s.description}
        </p>
      </div>
    ` : t}
    
    <ul class="dss-list-menu-nav" role="menu" aria-labelledby="menu-title" aria-describedby="menu-description">
      ${s.items?.map((e, n) => {
  const r = {
    "dss-list-menu-item": !0,
    selected: s.selectedItemIndex === n,
    disabled: !!e.disabled
  };
  return i`
          <li
            class="${$(r)}"
            role="menuitem"
            aria-disabled="${e.disabled ? "true" : "false"}"
            tabindex="${e.disabled ? -1 : 0}"
            @click="${() => s.handleItemClick(n)}"
          >
            <${d} icon="${e.icon}"></${d}>
            <span class="dss-list-menu-item__content-text">${e.label}</span>
            <div class="notification-placeholder">
              ${e.hasNotification ? i`<${u} dot state="succes" type="default" />` : t}
            </div>
            ${e.hasAction ? i`<${d} icon="chevron_right"></${d}>` : t}
            ${e.isTruncated ? i`<${o}>${e.label}</${o}>` : t}
          </li>
        `;
})}
    </ul>
  </div>
`;
export {
  x as template
};
//# sourceMappingURL=list-menu.template.js.map
