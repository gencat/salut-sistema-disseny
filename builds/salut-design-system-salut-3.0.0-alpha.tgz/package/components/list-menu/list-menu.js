import { LitElement as a, unsafeCSS as h } from "lit";
import { property as l, state as p } from "lit/decorators.js";
import m from "../../shared/reset.style.css.js";
import u from "./list-menu.style.css.js";
import { template as f } from "./list-menu.template.js";
var y = Object.defineProperty, n = (d, e, t, i) => {
  for (var s = void 0, r = d.length - 1, c; r >= 0; r--)
    (c = d[r]) && (s = c(e, t, s) || s);
  return s && y(e, t, s), s;
};
class o extends a {
  constructor() {
    super(), this.title = "", this.titleText = "", this.description = "", this.icon = null, this.items = [], this.disabled = !1, this.selectedItemIndex = null, this._isFirstUpdate = !0, this._resizeTimer = null, this._handleResizeBound = this._handleResize.bind(this);
  }
  static get styles() {
    return [h(m), h(u)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("keydown", this.onKeyDown), window.addEventListener("resize", this._handleResizeBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("keydown", this.onKeyDown), window.removeEventListener("resize", this._handleResizeBound);
  }
  _handleResize() {
    this._isFirstUpdate || (this._resizeTimer && clearTimeout(this._resizeTimer), this._resizeTimer = setTimeout(() => {
      this._checkTextsToTruncated();
    }, 500));
  }
  handleItemClick(e) {
    const t = this.items[e];
    t.disabled || (this.selectedItemIndex = e, this.dispatchEvent(
      new CustomEvent("item-clicked", {
        detail: { label: t.label },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  onKeyDown(e) {
    e.code === "ArrowDown" ? (e.preventDefault(), this.moveFocus(1)) : e.code === "ArrowUp" ? (e.preventDefault(), this.moveFocus(-1)) : (e.code === "Enter" || e.code === "Space" || e.code === "NumpadEnter") && (e.preventDefault(), this.selectedItemIndex !== null && this.handleItemClick(this.selectedItemIndex));
  }
  moveFocus(e) {
    const t = this.shadowRoot?.querySelectorAll(".dss-list-menu-item:not(.disabled)") || [];
    if (t.length === 0) return;
    let i = (this.selectedItemIndex ?? -1) + e;
    i < 0 && (i = t.length - 1), i >= t.length && (i = 0), this.selectedItemIndex = Array.from(t).findIndex((s, r) => r === i), t[i]?.focus();
  }
  _checkTextsToTruncated() {
    const e = this.shadowRoot?.querySelectorAll(".dss-list-menu-item__content-text") || [];
    for (const [t, i] of e.entries()) {
      const s = i.clientWidth, r = i.scrollWidth;
      this.items[t].isTruncated = s < r;
    }
    this.requestUpdate();
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._checkTextsToTruncated(), this._isFirstUpdate = !1;
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(e) {
    super.updated(e), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return f(this);
  }
}
n([
  l({ type: String })
], o.prototype, "title");
n([
  l({ type: String })
], o.prototype, "titleText");
n([
  l({ type: String })
], o.prototype, "description");
n([
  l({ type: String })
], o.prototype, "icon");
n([
  l({ type: Array })
], o.prototype, "items");
n([
  l({ type: String })
], o.prototype, "disabled");
n([
  p()
], o.prototype, "selectedItemIndex");
export {
  o as ListMenu
};
//# sourceMappingURL=list-menu.js.map
