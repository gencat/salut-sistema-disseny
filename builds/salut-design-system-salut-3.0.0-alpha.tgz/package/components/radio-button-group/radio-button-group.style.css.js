const o = ".dss-radio-button-group,.dss-radio-button-group__options{display:flex;flex-direction:column;gap:var(--dss-spacing-xs)}.dss-radio-button-group--horizontal .dss-radio-button-group__options{flex-direction:row}.dss-radio-button-group__label{font-size:14px;font-style:normal;font-weight:600;line-height:24px;color:var(--color-neutral-700)}.dss-radio-button-group__label--sr-only{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0 0 0 0)!important;white-space:nowrap!important;border:0!important}";
export {
  o as default
};
//# sourceMappingURL=radio-button-group.style.css.js.map
