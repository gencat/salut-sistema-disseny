import { html as a } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
const t = (o) => a`
  <div class="${r({
  "dss-radio-button-group": !0,
  [`dss-radio-button-group--${o.orientation}`]: !0
})}"
    role="radiogroup"
    aria-labelledby="radio-group-label"
  >
    <div id="radio-group-label" class="${r({
  "dss-radio-button-group__label": !0,
  "dss-radio-button-group__label--sr-only": o.hideLabel
})}">
      ${o.label}
    </div>
    <div class="dss-radio-button-group__options">
      <slot></slot>
    </div>
  </div>  
`;
export {
  t as template
};
//# sourceMappingURL=radio-button-group.template.js.map
