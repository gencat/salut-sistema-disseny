import { nothing as a, html as d } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
const s = (e) => d`
  <div class="${l({
  "dss-checkbox-wrapper": !0,
  "dss-checkbox-wrapper--required": e.required,
  "dss-checkbox-wrapper--disabled": e.disabled,
  "dss-checkbox-wrapper--hidden-label": e.hideLabel,
  "dss-checkbox-wrapper--validate": e.variant === "validation"
})}">
  	<div class="dss-checkbox-container">
      <input
        class="dss-checkbox-input"
        type="checkbox"
        name="${e.name ?? a}"
        id="${e._getEffectiveId()}"
        .value="${e.value ? e.value : null}"
        ?disabled="${e.disabled}"
        ?readonly="${e.readonly}"
        ?required="${e.required}"
        .checked="${e.checked}"
        .tabIndex="${e.tabIndex}"
        aria-label="${e.hideLabel ? e.label : a}"
        @change=${e._handleChange}
      />
    </div>
    <label for="${e._getEffectiveId()}" class="dss-checkbox-label" aria-hidden="${e.hideLabel}">
      ${e.hideLabel ? a : e.label}
    </label>
  </div>  
`;
export {
  s as template
};
//# sourceMappingURL=checkbox.template.js.map
