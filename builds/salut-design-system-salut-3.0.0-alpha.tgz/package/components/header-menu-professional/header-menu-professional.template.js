import { nothing as o } from "lit";
import { classMap as n } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as l, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
import { checkTextTruncate as t } from "../../utils/helpers.js";
const u = l`dss-icon-button${i(r())}`, d = l`dss-button${i(r())}`, a = l`dss-tooltip${i(r())}`, v = (e) => s`
  <div
    class=${n({
  "dss-header-menu-professional": !0,
  "dss-header-menu-professional--jcef": e.jcef
})}
  >
    <div class="dss-header-menu-professional-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-professional-details">
      <div class="dss-header-menu-professional-details__name">
        ${e.name}
      </div>
      <div class="dss-header-menu-professional-details__info">
        ${e.center ? s`
              <span
                class="dss-header-menu-professional-details__info-label dss-header-menu-professional-details__info-label--center"
                >${e.center}</span
              >
            ` : null}
      </div>
    </div>
    <${u} 
      icon="${e._toggleIcon}"
      label="${e._toggleLabel}"
      variant="primary"
      @onClick="${e._toggleDropdown}"
      ?disabled=${e.disabled}
      ariaLabel="${e._toggleLabel} menú professional"
      ariaExpanded="${e._showDropdown ? "true" : "false"}"
      hideTooltip
      >
    </${u}>
   
    <div
      class=${n({
  "dss-header-menu-professional-dropdown": !0,
  "dss-header-menu-professional-dropdown--expanded": !!e._showDropdown,
  "dss-header-menu-professional-dropdown--hide-details": !!e.hideDropdownDetails
})}
    >
      <div class="dss-header-menu-professional-dropdown__info">
        <div class="dss-header-menu-professional-dropdown__details">
          <div class="dss-header-menu-professional-dropdown__details-title">
            ${e.infoLabel}
          </div>

          <div class="dss-header-menu-professional-dropdown__details-content">
            <div class="dss-header-menu-professional-dropdown__details-subtitle">
              ${e.name}
            </div>

            ${e.center ? s`
                  <div class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${t}>
                    ${e.center}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${e.center}
                    </${a}>
                  </div>
                ` : null}
            ${e.collegiate ? s`
                  <p class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${t}>
                    ${e.collegiateLabel} ${e.collegiate}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${e.collegiate}
                    </${a}>
                  </p>
                ` : null}
          </div>

          
        </div>

        ${e.hideViewDetails ? o : s`
            <${d}
              class="dss-header-menu-professional-dropdown__view-details-button"
              variant="link"
              size="md"
              label="${e.detailsLabel}"
              fullWidth
              @click="${e._handleViewDetails}">
            </${d}>
					`}

        <div class="dss-header-menu-professional__divider"></div>

        ${e.hideDropdownPreferences ? null : s`
              <div class="dss-header-menu-professional-dropdown__preferences">
                <div class="dss-header-menu-professional-dropdown__details-title">
                  ${e.preferencesLabel}
                </div>
                <div class="dss-header-menu-professional-dropdown__preferences__options">
                  <slot></slot>
                </div>
              </div>
            `}
      </div>

      <div class="dss-header-menu-professional-dropdown__actions">
        ${e.showLogout ? s`
          <${d}
            variant="secondary"
            label="${e.logoutLabel}"
            fullWidth
            @onClick="${e._handleLogout}"
          ></${d}>
          ` : o}
        
        <${d}
          label="${e.exitLabel}"
          fullWidth
          @onClick="${e._handleExit}"
        ></${d}>
      </div>

      
    </div>
    
  </div>
`;
export {
  v as headerMenuProfessionalTemplate
};
//# sourceMappingURL=header-menu-professional.template.js.map
