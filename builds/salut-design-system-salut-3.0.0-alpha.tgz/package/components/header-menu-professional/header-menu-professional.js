import { LitElement as u, unsafeCSS as h } from "lit";
import { property as e } from "lit/decorators.js";
import { getCustomElementSuffix as m } from "../../api/custom-element-scope.js";
import { getPortalContainer as g } from "../../api/portal-manager/portal-manager.js";
import w from "../../foundations/icon/icon.style.css.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import _ from "./header-menu-professional.style.css.js";
import { headerMenuProfessionalTemplate as b } from "./header-menu-professional.template.js";
var D = Object.defineProperty, t = (c, r, i, l) => {
  for (var n = void 0, s = c.length - 1, a; s >= 0; s--)
    (a = c[s]) && (n = a(r, i, n) || n);
  return n && D(r, i, n), n;
};
class o extends u {
  constructor() {
    super(), this.disabled = !1, this.name = void 0, this.center = void 0, this.collegiate = void 0, this.infoLabel = "Les meves dades", this.collegiateLabel = "Col·legiat nº", this.preferencesLabel = "Preferences de treball", this.detailsLabel = "Veure més detalls", this.detailsHref = void 0, this.detailsIcon = "info", this.detailsIconPosition = "left", this.showLogout = !1, this.logoutLabel = "Tancar sessió", this.exitLabel = "Sortir", this.hideViewDetails = !1, this.hideDropdownDetails = !1, this.hideDropdownPreferences = !1, this.jcef = !1, this._showDropdown = !1, this._toggleIcon = "expand_more", this._toggleLabel = "Obrir", this._handleDocumentClickBound = this._handleDocumentClick.bind(this);
  }
  static get styles() {
    return [h(y), h(w), h(_)];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleDocumentClickBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleDocumentClickBound);
  }
  _toggleDropdown() {
    this._showDropdown = !this._showDropdown, this._toggleIcon = this._showDropdown ? "expand_less" : "expand_more", this._toggleLabel = this._showDropdown ? "Tancar" : "Obrir", this._showDropdown && setTimeout(() => {
      this._updatePreferencesDropdownPosition();
    }, 100), this.requestUpdate();
  }
  _handleLogout() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("logout", { bubbles: !1, composed: !1 }));
  }
  _handleExit() {
    this._toggleDropdown(), this.dispatchEvent(new CustomEvent("exit", { bubbles: !1, composed: !1 }));
  }
  _handleDocumentClick(r) {
    this._clickedOutside(this, r);
  }
  _handleViewDetails() {
    this._toggleDropdown(), this.dispatchEvent(
      new CustomEvent("view-details", {
        bubbles: !1,
        composed: !1
      })
    );
  }
  _clickedOutside(r, i) {
    const l = i.composedPath(), s = g().querySelector(`dss-select-options${m()}`);
    if (s && l.includes(s) || l.includes(r)) return;
    const d = i.target?.closest?.("dss-tooltip");
    d && d.classList.contains("header-menu-professional-tooltip") || this._showDropdown && this._toggleDropdown();
  }
  _updatePreferencesDropdownPosition() {
    const r = this.shadowRoot?.querySelector(".dss-header-menu-professional-dropdown"), i = this.shadowRoot?.querySelector(
      ".dss-header-menu-professional-dropdown__preferences__options"
    ), l = i?.querySelector("slot");
    if (i && l) {
      const n = l.assignedElements({ flatten: !0 });
      for (const s of n) {
        const a = i.offsetLeft, d = r.offsetTop, f = s.offsetTop - d + 44;
        s.setAttribute("dropdownOffsetX", a.toString()), s.setAttribute("dropdownOffsetY", f.toString());
      }
    }
  }
  render() {
    return b(this);
  }
}
t([
  e(p)
], o.prototype, "disabled");
t([
  e({ type: String })
], o.prototype, "name");
t([
  e({ type: String })
], o.prototype, "center");
t([
  e({ type: String })
], o.prototype, "collegiate");
t([
  e({ type: String })
], o.prototype, "infoLabel");
t([
  e({ type: String })
], o.prototype, "collegiateLabel");
t([
  e({ type: String })
], o.prototype, "preferencesLabel");
t([
  e({ type: String })
], o.prototype, "detailsLabel");
t([
  e({ type: String })
], o.prototype, "detailsHref");
t([
  e({ type: String })
], o.prototype, "detailsIcon");
t([
  e({ type: String })
], o.prototype, "detailsIconPosition");
t([
  e(p)
], o.prototype, "showLogout");
t([
  e({ type: String })
], o.prototype, "logoutLabel");
t([
  e({ type: String })
], o.prototype, "exitLabel");
t([
  e(p)
], o.prototype, "hideViewDetails");
t([
  e(p)
], o.prototype, "hideDropdownDetails");
t([
  e(p)
], o.prototype, "hideDropdownPreferences");
t([
  e(p)
], o.prototype, "jcef");
export {
  o as HeaderMenuProfessional
};
//# sourceMappingURL=header-menu-professional.js.map
