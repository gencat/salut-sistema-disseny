import { classMap as l } from "lit/directives/class-map.js";
import { when as t } from "lit/directives/when.js";
import { unsafeStatic as e, literal as b, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const s = b`dss-icon${e(r())}`, d = b`dss-tooltip${e(r())}`, $ = (i) => a`
  ${t(
  i.label && !i.hideTooltip,
  () => a`
      <${d} 
        position="${i.tooltipPosition}"
        delay="400"
        ?interactive=${i.tooltipInteractive}
        aria-hidden="true">
        ${i.label}
      </${d}>
    `
)}
`, z = (i) => a`
  ${t(
  i.ariaExpanded !== void 0,
  () => a`
    <button
      type=${i.type}
      class=${l({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
      ?disabled=${i.disabled}
      ?hidden=${i.hidden}
      aria-expanded=${i.ariaExpanded}
      aria-label="${i.ariaLabel ?? i.label}"
      tabindex="${i.disableTabindex ? "-1" : "0"}"
      @click=${i._handleClick}
    >
      <${s} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}" ?fill=${i.fill}></${s}>
      ${$(i)}
    </button>
  `,
  () => a`
      <button
        type=${i.type}
        class=${l({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
        ?disabled=${i.disabled}
        ?hidden=${i.hidden}
        aria-label="${i.label}"
        tabindex="${i.disableTabindex ? "-1" : "0"}"
        @click=${i._handleClick}
      >
        <${s} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}" ?fill=${i.fill}></${s}>
        ${$(i)}
      </button>
    `
)}
`;
export {
  z as template
};
//# sourceMappingURL=icon-button.template.js.map
