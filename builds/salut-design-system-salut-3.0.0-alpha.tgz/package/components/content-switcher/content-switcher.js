import { LitElement as n, unsafeCSS as h } from "lit";
import { property as d, state as p } from "lit/decorators.js";
import c from "../../shared/elevation.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as b } from "../../utils/property-types.js";
import u from "./content-switcher.style.css.js";
import { template as m } from "./content-switcher.template.js";
var _ = Object.defineProperty, i = (a, t, e, S) => {
  for (var s = void 0, r = a.length - 1, o; r >= 0; r--)
    (o = a[r]) && (s = o(t, e, s) || s);
  return s && _(t, e, s), s;
};
class l extends n {
  constructor() {
    super(...arguments), this.fullWidth = !1, this.size = "md", this.tabs = [], this._isFirstUpdate = !0, this._tabs = [];
  }
  connectedCallback() {
    super.connectedCallback(), this._initializeSelectedTab();
  }
  static get styles() {
    return [h(f), h(c), h(u)];
  }
  _onSelect(t) {
    t.selected = !0, this.tabSelected = t, this._tabs = this._tabs.map((e) => ({ ...e, selected: e.label === this.tabSelected?.label })), this.dispatchEvent(new CustomEvent("change", { detail: this.tabSelected.label })), this.requestUpdate();
  }
  _checkFullWidth() {
    this.fullWidth ? this.classList.add("full-width") : this.classList.remove("full-width");
  }
  _initializeSelectedTab() {
    this._tabs = this.tabs.map((t) => ({ ...t })), this.tabSelected = this._tabs.find((t) => t.selected) || this._tabs.find((t) => !t.disabled);
  }
  willUpdate(t) {
    if (t.has("tabs")) {
      if (this._isFirstUpdate) {
        this._isFirstUpdate = !1;
        return;
      }
      const e = t.get("tabs");
      if (JSON.stringify(e) === JSON.stringify(this.tabs))
        return;
      this._initializeSelectedTab();
    }
  }
  updated(t) {
    t.has("fullWidth") && this._checkFullWidth();
  }
  render() {
    return m(this);
  }
}
i([
  d(b)
], l.prototype, "fullWidth");
i([
  d({ type: String })
], l.prototype, "size");
i([
  d({ type: Array })
], l.prototype, "tabs");
i([
  p()
], l.prototype, "tabSelected");
export {
  l as ContentSwitcher
};
//# sourceMappingURL=content-switcher.js.map
