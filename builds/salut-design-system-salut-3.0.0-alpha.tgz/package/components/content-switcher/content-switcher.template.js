import { nothing as c, html as i } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { repeat as o } from "lit/directives/repeat.js";
const h = (l) => i`
  <div class=${t({
  "dss-content-switcher": !0,
  "dss-content-switcher--full-width": l.fullWidth
})}
    role="radiogroup" 
    aria-orientation="horizontal">
    ${o(
  l._tabs,
  (e) => e.label,
  (e, s) => {
    const a = {
      "dss-elevation--md": !!e.selected
    }, d = {
      "dss-content-switcher__item": !0,
      "dss-content-switcher__item--selected": !!e.selected,
      [`dss-content-switcher__item--${l.size}`]: !!l.size
    };
    return i`
          <div class=${t(d)}>
            <input
              id="radio-${s}"
              type="radio"
              tabindex=${e.selected || e.label === l.tabSelected?.label ? "0" : "-1"}
              name="tab"
              ?checked=${e.selected || e.label === l.tabSelected?.label}
              ?disabled=${e.disabled}
              @change=${() => l._onSelect(e)}
              aria-labelledby="label-${s}"
            />
            <label id="label-${s}" class=${t(a)}>
              ${e.icon ? i`
                <dss-icon icon="${e.icon}" size="${l.size === "lg" ? "md" : "sm"}" class="tab-icon"></dss-icon>
              ` : c}
              ${e.label}
            </label>
          </div>
        `;
  }
)}
  </div>
`;
export {
  h as template
};
//# sourceMappingURL=content-switcher.template.js.map
