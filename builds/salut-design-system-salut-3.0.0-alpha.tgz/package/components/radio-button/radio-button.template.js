import { nothing as d } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
import { html as i } from "lit/static-html.js";
const b = (a) => i`
  <div class="${e({
  "dss-radio-wrapper": !0,
  "dss-radio-wrapper--required": a.required,
  "dss-radio-wrapper--disabled": a.disabled,
  "dss-radio-wrapper--hidden-label": a.hideLabel
})}">
  	<div class="dss-radio-container">
      <input
        class="dss-radio-input"
        type="radio"
        name="${a.name ?? d}"
        id="${a._getEffectiveId()}"
        .value="${a.value}"
        ?disabled="${a.disabled}"
        ?readonly="${a.readonly}"
        ?required="${a.required}"
        .checked="${a.checked}"
        .tabIndex="${a.tabIndex}"
        aria-label="${a.hideLabel ? a.label : d}"
        @change=${a._handleChange}
      />
    </div>
    <label for="${a._getEffectiveId()}" class="dss-radio-label" aria-hidden="${a.hideLabel}">
      ${a.hideLabel ? d : a.label}
    </label>
  </div>  
`;
export {
  b as template
};
//# sourceMappingURL=radio-button.template.js.map
