import { LitElement as c, unsafeCSS as h } from "lit";
import { query as u, property as s } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as m, booleanConverter as a } from "../../utils/property-types.js";
import y from "./radio-button.style.css.js";
import { template as b } from "./radio-button.template.js";
var v = Object.defineProperty, t = (n, r, p, _) => {
  for (var i = void 0, o = n.length - 1, d; o >= 0; o--)
    (d = n[o]) && (i = d(r, p, i) || i);
  return i && v(r, p, i), i;
};
const l = class l extends c {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.checked = !1, this.tabIndex = 0, this._defaultId = `dss-radio-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [h(f), h(y)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  updated(r) {
    r.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(r) {
    this.disabled = r;
  }
  formResetCallback() {
    this._input.checked = !1, this.checked = !1;
  }
  formStateRestoreCallback(r) {
    this.value = r ?? "";
  }
  focusInput() {
    this._input?.focus();
  }
  render() {
    return b(this);
  }
  _handleChange(r) {
    this.checked = r.target.checked, this._emitChange();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
};
l.formAssociated = !0;
let e = l;
t([
  u("input.dss-radio-input")
], e.prototype, "_input");
t([
  s({ type: String })
], e.prototype, "label");
t([
  s(m)
], e.prototype, "hideLabel");
t([
  s({ type: String })
], e.prototype, "name");
t([
  s({ type: String })
], e.prototype, "id");
t([
  s({ type: String })
], e.prototype, "value");
t([
  s({ converter: a, reflect: !0 })
], e.prototype, "disabled");
t([
  s({ converter: a, reflect: !0 })
], e.prototype, "readonly");
t([
  s({ converter: a, reflect: !0 })
], e.prototype, "required");
t([
  s({ converter: a, reflect: !0 })
], e.prototype, "checked");
t([
  s({ type: Number })
], e.prototype, "tabIndex");
export {
  e as RadioButton
};
//# sourceMappingURL=radio-button.js.map
