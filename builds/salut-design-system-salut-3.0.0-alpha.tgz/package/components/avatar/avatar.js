import { LitElement as y, unsafeCSS as u } from "lit";
import { property as s } from "lit/decorators.js";
import h from "../../foundations/icon/icon.style.css.js";
import l from "./avatar.style.css.js";
import { template as f } from "./avatar.template.js";
var c = Object.defineProperty, i = (m, t, e, o) => {
  for (var r = void 0, a = m.length - 1, p; a >= 0; a--)
    (p = m[a]) && (r = p(t, e, r) || r);
  return r && c(t, e, r), r;
};
class n extends y {
  constructor() {
    super(...arguments), this.name = "", this.surname = "", this.imageUrl = "", this.size = "md", this._acronym = "";
  }
  static get styles() {
    return [u(h), u(l)];
  }
  willUpdate(t) {
    const e = t.has("name"), o = t.has("surname");
    (e || o) && this.formatAcronym();
  }
  formatAcronym() {
    let t = this.name?.trim().substring(0, 1).toUpperCase();
    this.name && this.surname ? t += this.surname.trim().substring(0, 1).toUpperCase() : t = this.name?.trim().substring(0, 2).toUpperCase(), this._acronym = t, this.requestUpdate("acronym", t);
  }
  render() {
    return f(this);
  }
}
i([
  s({ type: String })
], n.prototype, "name");
i([
  s({ type: String })
], n.prototype, "surname");
i([
  s({ type: String })
], n.prototype, "imageUrl");
i([
  s({ type: String })
], n.prototype, "size");
export {
  n as Avatar
};
//# sourceMappingURL=avatar.js.map
