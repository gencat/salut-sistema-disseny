import { LitElement as u, unsafeCSS as c } from "lit";
import { property as s, state as d } from "lit/decorators.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as i } from "../../utils/property-types.js";
import f from "./alert.style.css.js";
import { alertTemplate as y } from "./alert.template.js";
var b = Object.defineProperty, t = (n, o, a, l) => {
  for (var r = void 0, p = n.length - 1, h; p >= 0; p--)
    (h = n[p]) && (r = h(o, a, r) || r);
  return r && b(o, a, r), r;
};
class e extends u {
  constructor() {
    super(...arguments), this.state = "info", this.size = "md", this.message = "Your message. short and clear.", this.buttonLabel = "Label", this.showMoreLabel = "Mostrar més", this.showLessLabel = "Mostrar menys", this.hasCloseIcon = !1, this.hasButton = !1, this.fullWidth = !1, this.buttonBottom = !1, this.expanded = !1, this.isOverflowing = !1, this._stateIcon = "info";
  }
  static get styles() {
    return [c(m), c(f)];
  }
  _handleButtonClick() {
    this.dispatchEvent(new CustomEvent("button-click", { bubbles: !0, composed: !0 }));
  }
  _handleClose() {
    this.dispatchEvent(new CustomEvent("close", { bubbles: !0, composed: !0 }));
  }
  updated(o) {
    o.has("state") && this.setStateIcon();
  }
  async firstUpdated() {
    await this.updateComplete;
    const o = this.renderRoot.querySelector(".dss-alert__text");
    if (o) {
      const { scrollHeight: a, clientHeight: l } = o;
      this.isOverflowing = a > l;
    }
  }
  setStateIcon() {
    switch (this.state) {
      case "error":
        this._stateIcon = "cancel";
        break;
      case "warning":
        this._stateIcon = "report";
        break;
      case "success":
        this._stateIcon = "check_circle";
        break;
      default:
        this._stateIcon = "info";
    }
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  toggleExpand() {
    this.expanded = !this.expanded;
  }
  render() {
    return y(this);
  }
}
t([
  s({ type: String })
], e.prototype, "state");
t([
  s({ type: String })
], e.prototype, "size");
t([
  s({ type: String })
], e.prototype, "message");
t([
  s({ type: String })
], e.prototype, "buttonLabel");
t([
  s({ type: String })
], e.prototype, "showMoreLabel");
t([
  s({ type: String })
], e.prototype, "showLessLabel");
t([
  s(i)
], e.prototype, "hasCloseIcon");
t([
  s(i)
], e.prototype, "hasButton");
t([
  s(i)
], e.prototype, "fullWidth");
t([
  s(i)
], e.prototype, "buttonBottom");
t([
  d(i)
], e.prototype, "expanded");
t([
  d(i)
], e.prototype, "isOverflowing");
export {
  e as Alert
};
//# sourceMappingURL=alert.js.map
