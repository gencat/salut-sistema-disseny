import { nothing as s } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
import { ifDefined as p } from "lit/directives/if-defined.js";
import { unsafeStatic as d, literal as e, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const r = e`dss-icon${d(u())}`, $ = e`dss-tooltip${d(u())}`, h = e`dss-timepicker-options${d(u())}`, t = (i) => a`
      <div class="${l({
  "dss-input-group": !0,
  [`dss-input-group--${i.size}`]: !!i.size,
  "dss-input-group--invalid": i.invalid,
  "dss-input-group--required": i.required,
  "dss-input-group--disabled": i.disabled,
  "dss-input-group--focused": i.value || i._input?.value || i.placeholder || i._isFocused,
  "dss-input-group--read-only": i.readonly,
  "dss-input-group--no-label": i.hideLabel,
  "dss-input-group--numeric": i.type === "number",
  "dss-input-group--read-only-empty": i._input?.readOnly && i._input?.placeholder === "" && !i._input?.value
})}">
      ${i.icon ? a`
        <${r} icon="${i.icon}" class="dss-input-icon"></${r}>
        ` : s}
      <div class="dss-input-field">
        ${i.size !== "sm" && !i.hideLabel ? a`
          <label class="dss-label" for=${i._getEffectiveId()} @mousedown=${i._handleLabelClick}>${i.label}</label>
          ` : s}
        <input
          class="dss-input"
          .type="${i.type}"
          .name="${i.name ?? s}"
          id="${i._getEffectiveId()}"
          .placeholder=${i.placeholder}
          .value=${i.value}
          ?disabled=${i.disabled}
          ?readonly=${i.readonly}
          ?required=${i.required}
          ?autofocus=${i.autofocus}
          spellcheck=${i.spellcheck ? "true" : "false"}
          autocorrect=${i.autocorrect ? "on" : "off"}
          autocomplete=${i.autocomplete}
          autocapitalize=${i.autocapitalize}
          min=${i.min ?? s}
          max=${i.max ?? s}
          step=${i.step ?? s}
          minlength=${i.minLength ?? s}
          maxlength=${i.maxLength ?? s}
          pattern=${i.pattern ?? s}
          inputmode=${i.inputmode ?? s}
          aria-label="${i.hideLabel ? i.label : s}"
          @click=${i._handleClick}
          @input=${i._handleInput}
          @focusin=${i._handleFocusin}
          @focusout=${i._handleFocusout}
          @keydown=${i._handleKeyDown}
        />
      </div>
      ${i._isTruncated ? a`
        <${$} aria-hidden="true">${i._input?.value}</${$}>
        ` : s}
    </div>
  `, w = (i) => a`
  <div class="${l({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": i.required,
  "dss-input-wrapper--disabled": i.disabled,
  [`dss-input-wrapper--${i.size}`]: !!i.size,
  "dss-input-wrapper--no-label": i.hideLabel
})}">

    ${i.size === "sm" && !i.hideLabel ? a`
      <div class="dss-wrapper-label">
        <label class="dss-label" for=${i._getEffectiveId()} @mousedown=${i._handleLabelClick}>${i.label}</label>
      </div>
      ` : s}

    ${i.dropdown === "" ? a`
        ${t(i)}
      ` : a`
        <div class="dss-input-dropdown-wrapper"
          role="combobox"
          aria-controls="timepicker-options"
          aria-expanded=${p(i.showDropdown)}
        >
          ${t(i)}

          <${h}
            class="combobox ${i._getEffectiveId()}-options"
            .open=${i.showDropdown}
            .variant=${i.dropdown}
            .value=${i.value}
            .timeListOptions=${i._timeListOptions}
            .customTimeListOptions=${i._customTimeListOptions}
            .timeManualHourOptions=${i._timeManualHourOptions}
            .timeManualMinutesOptions=${i._timeManualMinutesOptions}
            @option-changed=${i._handleOptionChanged}
            @option-cancelled=${i._handleOptionCancelled}
            @option-focusout=${i._handleOptionFocusout}
            @focusout=${i._handleOptionFocusout}
          />
        </div>
      `}

    ${i._helpText ? a`
      <div class="${l({
  "dss-input-help": !0,
  "dss-input-help--invalid": i.invalid,
  "dss-input-help--disabled": i.disabled
})}">
        <span>${i._helpText}</span>
      </div>
      ` : s}
  </div>  
`;
export {
  w as template
};
//# sourceMappingURL=timepicker.template.js.map
