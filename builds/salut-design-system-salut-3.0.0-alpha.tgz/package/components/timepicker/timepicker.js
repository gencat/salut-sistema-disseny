import { LitElement as b, unsafeCSS as u } from "lit";
import { query as d, property as s, state as c } from "lit/decorators.js";
import { getPortalContainer as v } from "../../api/portal-manager/portal-manager.js";
import g from "../../shared/reset.style.css.js";
import { booleanType as h, booleanConverter as p } from "../../utils/property-types.js";
import x from "../input/input.style.css.js";
import w from "./timepicker.style.css.js";
import { template as T } from "./timepicker.template.js";
var O = Object.defineProperty, i = (m, t, o, r) => {
  for (var n = void 0, a = m.length - 1, l; a >= 0; a--)
    (l = m[a]) && (n = l(t, o, n) || n);
  return n && O(t, o, n), n;
};
const _ = class _ extends b {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.maxLength = 5, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "schedule", this.showDropdown = !1, this.dropdown = "", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.customTimeListOptions = [], this.errorTimeFormatText = "Format d'hora no vàlid", this.errorTimeOptionText = "Opció de temps no disponible", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this._defaultId = `dss-timepicker-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._timePattern = /^\d{0,4}$/g, this._timeSeparator = ":", this._timeInputOldValue = "", this._placeholder = "", this._helpText = "", this._oldHelpText = "", this._manualHourSelector = "", this._manualMinuteSelector = "", this._timeListOptions = [], this._customTimeListOptions = [], this._timeManualHourOptions = [], this._timeManualMinutesOptions = [], this._inputValidity = !0, this._isFirstUpdated = !0, this._portalManager = null, this._labelClicked = !1, this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [u(g), u(x), u(w)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeDropdownListener();
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _checkClickOutside(t) {
    if (!this.showDropdown) return;
    const o = t.composedPath(), r = `${this._getEffectiveId()}-options`, n = this._portalManager?.querySelector(`.${r}`);
    !o.includes(this) && !o.includes(n) && this._closeDropdown();
  }
  _checkFocusOut(t) {
    const o = t.relatedTarget, r = this._getPortalCombobox();
    o !== null && o !== this && o !== this._input && o !== this._label && o !== this._combobox && o !== r && (this.showDropdown && this._closeDropdown(), this.requestUpdate());
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && this._input.classList.add("dss-input-skip-native"), this._portalManager = v(), this._enableAnimations(), this._updateTimeOptions(), this._isFirstUpdated = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value), t.has("placeholder") && (this._placeholder = this.placeholder), t.has("helpText") && (this._helpText = this.helpText ?? "", this._oldHelpText = this.helpText ?? ""), !this._isFirstUpdated && (t.has("minHour") || t.has("maxHour")) && this._updateTimeOptions();
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  render() {
    return T(this);
  }
  _enableAnimations() {
    this._combobox.classList.add("animation-enabled");
  }
  _disableAnimations() {
    this._getPortalCombobox()?.classList.remove("animation-enabled");
  }
  _getPortalCombobox() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-options`);
  }
  /* Handle Input Events */
  _handleClick() {
    this.showDropdown = !0, this._addDropdownListener(), setTimeout(() => {
      this._disableAnimations();
    }, 240);
  }
  _handleKeyDown(t) {
    this._input && (this._timeInputOldValue = this._input.value, t?.key === "Enter" || t?.key === " " ? (this.showDropdown = !0, this._addDropdownListener(), this.requestUpdate()) : t?.key === "Escape" ? this._closeDropdown() : t?.key === "Tab" && this.showDropdown && (t.preventDefault(), t.stopPropagation(), this._getPortalCombobox()._focusFirstElement()));
  }
  _handleInput() {
    if (!this._input) return;
    let t = this._input.value;
    t = this._timeUnmask(t), t.match(this._timePattern) ? (t = this._timeMask(t, 2, this._timeSeparator), this._input.value = t) : this._input.value = this._timeInputOldValue, this._input.value.length === 5 && (this._timeValidate(this._input.value), this._handleValidity()), this._onInput();
  }
  _onInput() {
    this.value = this._input.value, this.dispatchEvent(new Event("input", { bubbles: !1, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    let t = {}, o = "";
    this.invalid ? (t = { customError: !0, valid: !1 }, o = this._helpText) : (this.invalid = !this._input?.checkValidity(), t = this._input.validity, o = this._input.validationMessage), this.internals.setValidity(t, o, this._input);
  }
  _handleFocusin() {
    this._input && (this._isFocused = !0, this._placeholder = "00:00", this._input.setAttribute("placeholder", this._placeholder));
  }
  _handleLabelClick(t) {
    t.preventDefault(), this._input.focus(), this._labelClicked = !0, setTimeout(() => {
      this._labelClicked = !1;
    }, 50);
  }
  _handleFocusout() {
    !this._input || this._labelClicked || (this._isFocused = !1, this._placeholder = "", this._input.removeAttribute("placeholder"), this._checkInputOverflow(), this.requestUpdate());
  }
  _focusInput() {
    this.disabled || (this._input?.focus(), this._handleClick());
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), o = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, n = document.createElement("canvas").getContext("2d");
    if (!n) return;
    n.font = o;
    const a = n.measureText(this._input.value).width;
    this._isTruncated = a > this._input.offsetWidth;
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _dispatchValueChange() {
    if (!this._input) return;
    const t = {
      detail: {
        value: this._input.value,
        invalid: this.invalid,
        status: this.invalid ? "INVALID" : "VALID"
      },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("value-changed", t)), this.value !== this._input.value && (this.value = this._input.value), this._emitChange();
  }
  _closeDropdown() {
    this._removeDropdownListener(), this.showDropdown = !1, this._input?.blur(), setTimeout(() => {
      this._enableAnimations();
    }, 400);
  }
  /* Hamdle Timepicker Validations */
  _timeMask(t, o, r) {
    const n = [];
    for (let a = 0; a < t.length; a += 1)
      a !== 0 && a % o === 0 && n.push(r), n.push(t[a]);
    return n.join("");
  }
  _timeUnmask(t) {
    return t.replace(/[^\d]/g, "");
  }
  _timeValidate(t) {
    const o = t.slice(0, 2), r = t.slice(3, 5);
    this._input && +o >= 0 && +o <= 23 && +r >= 0 && +r <= 59 ? (this.invalid = !1, this._helpText = this._oldHelpText, this.dropdown && this.dropdown === "list" && !this._timeListOptions.includes(this._input.value) ? (this._helpText = this.errorTimeOptionText, this.invalid = !0) : this.dropdown && this.dropdown === "manual" && (!this._timeManualHourOptions.includes(o) || !this._timeManualMinutesOptions.includes(r)) ? (this._helpText = this.errorTimeOptionText, this.invalid = !0) : this._closeDropdown()) : (this._helpText = this.errorTimeFormatText, this.invalid = !0), this._dispatchValueChange(), this.requestUpdate();
  }
  // Timepicker specific methods
  _updateTimeOptions() {
    this.dropdown && (this._timeListOptions = this._generateTimeListOptions(), this._timeManualHourOptions = this._generateTimeManualHoursOptions(), this._timeManualMinutesOptions = this._generateTimeManualMinutesOptions());
  }
  _generateTimeListOptions() {
    const t = [], o = +this.minHour, r = +this.maxHour, n = +this.minutesRange;
    for (let a = o; a < r; a += 1)
      for (let l = 0; l < 60; l += n) {
        const f = a.toString().padStart(2, "0"), y = l.toString().padStart(2, "0");
        t.push(`${f}:${y}`);
      }
    return t;
  }
  _generateTimeManualHoursOptions() {
    const t = [], o = +this.minHour, r = +this.maxHour;
    for (let n = o; n < r; n += 1) {
      const a = n.toString().padStart(2, "0");
      t.push(a);
    }
    return t;
  }
  _generateTimeManualMinutesOptions() {
    const t = [], o = +this.minutesRange;
    for (let r = 0; r < 60; r += o) {
      const n = r.toString().padStart(2, "0");
      t.push(n);
    }
    return t;
  }
  _handleOptionChanged(t) {
    if (!this._input) return;
    const o = t.detail.value;
    this._input.value = o, this._helpText = this._oldHelpText, this.invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange();
  }
  _handleOptionCancelled() {
    this._helpText = this._oldHelpText, this.invalid = !1, this._handleValidity(), this._closeDropdown();
  }
  _handleOptionFocusout(t) {
    t.stopPropagation(), t.preventDefault(), !(this.readonly || this.disabled) && this.showDropdown && (this._closeDropdown(), setTimeout(() => {
      this._input?.focus();
    }, 100));
  }
};
_.formAssociated = !0;
let e = _;
i([
  d("input.dss-input")
], e.prototype, "_input");
i([
  d("label.dss-label")
], e.prototype, "_label");
i([
  d(".combobox")
], e.prototype, "_combobox");
i([
  s({ type: String })
], e.prototype, "label");
i([
  s(h)
], e.prototype, "hideLabel");
i([
  s({ type: String })
], e.prototype, "name");
i([
  s({ type: String })
], e.prototype, "id");
i([
  s({ type: String })
], e.prototype, "type");
i([
  s({ type: String })
], e.prototype, "placeholder");
i([
  s({ type: String })
], e.prototype, "value");
i([
  s({ converter: p, reflect: !0 })
], e.prototype, "disabled");
i([
  s({ converter: p, reflect: !0 })
], e.prototype, "readonly");
i([
  s({ converter: p, reflect: !0 })
], e.prototype, "required");
i([
  s({ converter: p, reflect: !0 })
], e.prototype, "invalid");
i([
  s({ type: Number })
], e.prototype, "step");
i([
  s({ type: Number })
], e.prototype, "min");
i([
  s({ type: Number })
], e.prototype, "max");
i([
  s({ type: Number })
], e.prototype, "minLength");
i([
  s({ type: Number })
], e.prototype, "maxLength");
i([
  s({ type: String })
], e.prototype, "pattern");
i([
  s({ type: String })
], e.prototype, "inputmode");
i([
  s({ type: String })
], e.prototype, "autocapitalize");
i([
  s({ type: String })
], e.prototype, "autocomplete");
i([
  s(h)
], e.prototype, "autocorrect");
i([
  s(h)
], e.prototype, "autofocus");
i([
  s(h)
], e.prototype, "spellcheck");
i([
  s({ type: String })
], e.prototype, "size");
i([
  s({ type: String })
], e.prototype, "icon");
i([
  s({ type: String })
], e.prototype, "helpText");
i([
  s(h)
], e.prototype, "showDropdown");
i([
  s({ type: String })
], e.prototype, "dropdown");
i([
  s({ type: String })
], e.prototype, "dropdownPlacement");
i([
  s(h)
], e.prototype, "dropdownFixed");
i([
  s({ type: Array })
], e.prototype, "customTimeListOptions");
i([
  s({ type: String })
], e.prototype, "errorTimeFormatText");
i([
  s({ type: String })
], e.prototype, "errorTimeOptionText");
i([
  s({ type: Number })
], e.prototype, "minHour");
i([
  s({ type: Number })
], e.prototype, "maxHour");
i([
  s({ type: Number })
], e.prototype, "minutesRange");
i([
  c()
], e.prototype, "_isFocused");
i([
  c()
], e.prototype, "_isTruncated");
i([
  c()
], e.prototype, "_labelClicked");
export {
  e as Timepicker
};
//# sourceMappingURL=timepicker.js.map
