const i = ".dss-timepicker-help{font-family:var(--font-family)}.dss-timepicker-help{font-family:inherit;font-size:12px;color:var(--color-neutral-700);padding:var(--dss-spacing-xxs) var(--dss-spacing-sm)}.dss-timepicker-help--disabled{color:var(--color-neutral-500)}.dss-timepicker-help--invalid{color:var(--color-red-500)}.dss-input-group--dropdown input{min-width:289px}";
export {
  i as default
};
//# sourceMappingURL=timepicker.style.css.js.map
