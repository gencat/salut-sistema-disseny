import { LitElement as c, unsafeCSS as n } from "lit";
import { property as t } from "lit/decorators.js";
import p from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import b from "./chip.style.css.js";
import { template as f } from "./chip.template.js";
var u = Object.defineProperty, s = (o, e, d, y) => {
  for (var l = void 0, r = o.length - 1, h; r >= 0; r--)
    (h = o[r]) && (l = h(e, d, l) || l);
  return l && u(e, d, l), l;
};
class i extends c {
  constructor() {
    super(...arguments), this.size = "lg", this.icon = "", this.label = "", this.hasDelete = !1, this.disabled = !1, this.selected = !1, this.disableSelect = !1, this._isLabelTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [n(p), n(b)];
  }
  handleToggle() {
    this.disableSelect || this.disabled || (this.selected = !this.selected, this.dispatchEvent(
      new CustomEvent("toggle", {
        detail: {
          text: this.label,
          selected: this.selected
        }
      })
    ));
  }
  handleKeydown(e) {
    e.stopPropagation(), (e.key === "Enter" || e.key === "Space") && this.handleToggle();
  }
  handleDelete(e) {
    e.stopPropagation(), this.dispatchEvent(
      new CustomEvent("delete", {
        detail: {
          text: this.label
        },
        bubbles: !0,
        composed: !0
      })
    );
  }
  async firstUpdated() {
    await this.updateComplete, this._checkLabelTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(e) {
    !this._isFirstUpdated && e.has("label") && this._checkLabelTruncated();
  }
  _checkLabelTruncated() {
    const e = this.shadowRoot?.querySelector(".dss-chip__label");
    e && (this._isLabelTruncated = e.scrollWidth > e.offsetWidth, this.requestUpdate());
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("keydown", this.onKeyDown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("keydown", this.onKeyDown);
  }
  onKeyDown(e) {
    (e.code === "Enter" || e.code === "NumpadEnter" || e.code === "Space") && this.handleToggle(), (e.code === "Backspace" && this.hasDelete || e.code === "Delete" && this.hasDelete) && this.handleDelete(e);
  }
  render() {
    return f(this);
  }
}
s([
  t({ type: String })
], i.prototype, "size");
s([
  t({ type: String })
], i.prototype, "icon");
s([
  t({ type: String })
], i.prototype, "label");
s([
  t(a)
], i.prototype, "hasDelete");
s([
  t(a)
], i.prototype, "disabled");
s([
  t(a)
], i.prototype, "selected");
s([
  t(a)
], i.prototype, "disableSelect");
export {
  i as Chip
};
//# sourceMappingURL=chip.js.map
