import { LitElement as n, unsafeCSS as o } from "lit";
import { property as p } from "lit/decorators.js";
import a from "../../shared/reset.style.css.js";
import l from "./breadcrumb-bar.style.css.js";
import { template as u } from "./breadcrumb-bar.template.js";
var f = Object.defineProperty, c = (s, t, r, v) => {
  for (var e = void 0, i = s.length - 1, m; i >= 0; i--)
    (m = s[i]) && (e = m(t, r, e) || e);
  return e && f(t, r, e), e;
};
class d extends n {
  constructor() {
    super(...arguments), this.items = [];
  }
  static get styles() {
    return [o(a), o(l)];
  }
  handleItemClick(t, r) {
    t.preventDefault(), t.currentTarget?.blur(), this.dispatchEvent(new CustomEvent("item-click", { detail: r.href, bubbles: !0, composed: !0 }));
  }
  render() {
    return u(this);
  }
}
c([
  p({ type: Array })
], d.prototype, "items");
export {
  d as BreadcrumbBar
};
//# sourceMappingURL=breadcrumb-bar.js.map
