import { LitElement as y, unsafeCSS as _ } from "lit";
import { query as v, property as i, state as p } from "lit/decorators.js";
import f from "../../shared/reset.style.css.js";
import { lazyLoading as m } from "../../utils/lazy-loading.js";
import { deleteSeparatorMask as g, applyMask as b } from "../../utils/mask.js";
import { booleanType as r, booleanConverter as u } from "../../utils/property-types.js";
import k from "./input.style.css.js";
import { template as S } from "./input.template.js";
var C = Object.defineProperty, e = (d, s, a, n) => {
  for (var l = void 0, o = d.length - 1, c; o >= 0; o--)
    (c = d[o]) && (l = c(s, a, l) || l);
  return l && C(s, a, l), l;
};
const h = class h extends y {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.hasActions = !1, this._defaultId = `dss-input-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._previousValue = null, this._labelClicked = !1, this._lastValue = null, this.internals = this.attachInternals();
  }
  static get styles() {
    return [_(f), _(k)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._stopHold();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(s) {
    s.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(s) {
    this.disabled = s;
  }
  formResetCallback() {
    this.value = "", this._input.value = "", this._lastValue = "";
  }
  formStateRestoreCallback(s) {
    this.value = s ?? "", this._input.value = s ?? "", this._lastValue = s ?? "";
  }
  render() {
    return S(this);
  }
  _handleFocusin() {
    this._isFocused = !0;
  }
  _handleLabelClick(s) {
    s.preventDefault(), this._input.focus(), this._labelClicked = !0, setTimeout(() => {
      this._labelClicked = !1;
    }, 50);
  }
  _handleFocusout() {
    this._labelClicked || (this._isFocused = !1, this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value));
  }
  _onInput(s) {
    const a = s.target;
    if (this.maskRegex && this.maskReplace) {
      this._previousValue && this._previousValue.length > a?.value.length && (a.value = g(this._previousValue, a.value, this.maskReplace));
      const n = b(a.value, this.maskRegex, this.maskReplace, this.allowedChars);
      n !== a.value && (a.value = n);
    }
    this._previousValue = a.value, this.value = a.value, this._handleValidity(), this.dispatchEvent(new Event("input", { bubbles: !1, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    const s = this._input?.checkValidity();
    this.invalid = !s, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _stepUp() {
    this._input?.stepUp(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _stepDown() {
    this._input?.stepDown(), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _onHold(s) {
    this._onHoldInterval = window.setInterval(() => {
      s === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this._onHoldInterval !== null && (clearInterval(this._onHoldInterval), this._onHoldInterval = null);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _handleMouseOver() {
    this._input?.value !== this._lastValue && (this._checkInputOverflow(), this._lastValue = this._input?.value || null);
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const s = window.getComputedStyle(this._input), a = `${s.fontWeight} ${s.fontSize} ${s.fontFamily}`, l = document.createElement("canvas").getContext("2d");
    if (!l) return;
    l.font = a;
    const o = l.measureText(this._input.value).width;
    this._isTruncated = o > this._input.offsetWidth;
  }
  async firstUpdated() {
    await this.updateComplete, this._input.value && m(this, () => {
      this._checkInputOverflow(), this._lastValue = this._input.value;
    });
  }
};
h.formAssociated = !0;
let t = h;
e([
  v("input.dss-input")
], t.prototype, "_input");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i(r)
], t.prototype, "hideLabel");
e([
  i({ type: String })
], t.prototype, "name");
e([
  i({ type: String })
], t.prototype, "id");
e([
  i({ type: String })
], t.prototype, "type");
e([
  i({ type: String })
], t.prototype, "placeholder");
e([
  i({ type: String })
], t.prototype, "value");
e([
  i({ converter: u, reflect: !0 })
], t.prototype, "disabled");
e([
  i({ converter: u, reflect: !0 })
], t.prototype, "readonly");
e([
  i({ converter: u, reflect: !0 })
], t.prototype, "required");
e([
  i({ converter: u, reflect: !0 })
], t.prototype, "invalid");
e([
  i({ type: Number })
], t.prototype, "step");
e([
  i({ type: Number })
], t.prototype, "min");
e([
  i({ type: Number })
], t.prototype, "max");
e([
  i({ type: Number })
], t.prototype, "minLength");
e([
  i({ type: Number })
], t.prototype, "maxLength");
e([
  i({ type: String })
], t.prototype, "pattern");
e([
  i({ type: String })
], t.prototype, "inputmode");
e([
  i({ type: String })
], t.prototype, "autocapitalize");
e([
  i({ type: String })
], t.prototype, "autocomplete");
e([
  i(r)
], t.prototype, "autocorrect");
e([
  i(r)
], t.prototype, "autofocus");
e([
  i(r)
], t.prototype, "spellcheck");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "helpText");
e([
  i({ type: String })
], t.prototype, "maskRegex");
e([
  i({ type: String })
], t.prototype, "maskReplace");
e([
  i({ type: String })
], t.prototype, "allowedChars");
e([
  i({ type: String })
], t.prototype, "unit");
e([
  i({ type: String })
], t.prototype, "inputPrefix");
e([
  i(r)
], t.prototype, "hasActions");
e([
  p()
], t.prototype, "_isFocused");
e([
  p()
], t.prototype, "_isTruncated");
e([
  p()
], t.prototype, "_onHoldInterval");
e([
  p()
], t.prototype, "_previousValue");
e([
  p()
], t.prototype, "_labelClicked");
export {
  t as Input
};
//# sourceMappingURL=input.js.map
