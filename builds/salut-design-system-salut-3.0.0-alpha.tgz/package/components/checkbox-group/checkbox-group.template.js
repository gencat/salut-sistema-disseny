import { html as l } from "lit";
import { classMap as s } from "lit/directives/class-map.js";
const r = (e) => l`
  <div class="${s({
  "dss-checkbox-group": !0,
  [`dss-checkbox-group--${e.orientation}`]: !0
})}"
    role="radiogroup"
    aria-labelledby="checkbox-group-label"
  >
    <div id="checkbox-group-label" class="${s({
  "dss-checkbox-group__label": !0,
  "dss-checkbox-group__label--sr-only": e.hideLabel
})}">
      ${e.label}
    </div>
    <div class="dss-checkbox-group__options">
       <input 
        type="hidden" 
        class="dss-hidden-value" 
        .name=${e.name} 
      />
      <slot></slot>
    </div>
  </div>  
`;
export {
  r as template
};
//# sourceMappingURL=checkbox-group.template.js.map
