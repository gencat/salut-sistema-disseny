import { LitElement as f, unsafeCSS as l } from "lit";
import { property as d } from "lit/decorators.js";
import "../../index.js";
import p from "../../foundations/icon/icon.style.css.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as m } from "../../utils/property-types.js";
import b from "./sidemenu-list.style.css.js";
import { sidemenuListTemplate as C } from "./sidemenu-list.template.js";
import { getCustomElementSuffix as _ } from "../../api/custom-element-scope.js";
var g = Object.defineProperty, x = Object.getOwnPropertyDescriptor, u = (a, t, s, i) => {
  for (var e = x(t, s), n = a.length - 1, o; n >= 0; n--)
    (o = a[n]) && (e = o(t, s, e) || e);
  return e && g(t, s, e), e;
};
class c extends f {
  constructor() {
    super(...arguments), this._disabled = !1, this._expanded = !1, this._scrollContainerClass = "dss-layout-sidebar";
  }
  static get styles() {
    return [l(h), l(p), l(b)];
  }
  set expanded(t) {
    const s = this._expanded;
    this._expanded = t, this.requestUpdate("expanded", s);
  }
  get expanded() {
    return this._expanded;
  }
  set disabled(t) {
    const s = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", s);
  }
  get disabled() {
    return this._disabled;
  }
  set scrollContainerClass(t) {
    const s = this._scrollContainerClass;
    this._scrollContainerClass = t, this.requestUpdate("scrollContainerClass", s);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((s) => {
      s.assignedElements().forEach((e) => {
        this._expanded ? e.setAttribute("expanded", "true") : e.removeAttribute("expanded"), this._scrollContainerClass ? e.setAttribute("scrollContainerClass", this._scrollContainerClass) : e.removeAttribute("scrollContainerClass");
      });
    });
  }
  _handleItemFocus(t) {
    const s = t.target, i = this.shadowRoot?.querySelector("slot");
    if (i) {
      const e = i.assignedElements({ flatten: !0 }).filter((o) => !o._disabled), n = e.findIndex((o) => o._focusEnabled);
      e[n] !== s && (s.setAttribute("focusEnabled", "true"), e[n].removeAttribute("focusEnabled"));
    }
  }
  _handleNavigate(t) {
    const s = this.shadowRoot?.querySelector("slot");
    if (s) {
      const e = s.assignedElements({ flatten: !0 }).filter((r) => !r._disabled).filter((r) => !r.classList.contains("hidden")), n = e.findIndex((r) => r._focusEnabled);
      let o = n;
      t.detail.direction === "next" ? o = (n + 1) % e.length : t.detail.direction === "previous" && (o = (n - 1 + e.length) % e.length), n !== o && (this._checkActionMenuClose(e[n]), e[n].blurItem(), e[n].removeAttribute("focusEnabled"), e[o].focusItem(), e[o].setAttribute("focusEnabled", "true"), this.dispatchEvent(new CustomEvent("onSlotFocus", { bubbles: !0, composed: !0 })));
    }
  }
  _checkActionMenuClose(t) {
    const s = t.shadowRoot?.querySelector("slot");
    if (!s) return;
    const e = `dss-action-menu${_()}`, o = s.assignedElements({ flatten: !0 }).find((r) => r.tagName.toLowerCase() === e);
    o && o.classList.contains("visible") && o._closeMenu();
  }
  async firstUpdated() {
    await this.updateComplete;
    const t = this.shadowRoot?.querySelector("slot");
    if (t) {
      const i = t.assignedElements({ flatten: !0 }).find((e) => e.tagName.toLowerCase() === "dss-sidemenu-list-item");
      i && i.setAttribute("focusEnabled", "true"), this._propagateProperties();
    }
  }
  updated(t) {
    super.updated(t), (t.has("expanded") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return C(this);
  }
}
u([
  d(m)
], c.prototype, "expanded");
u([
  d(m)
], c.prototype, "disabled");
u([
  d({ type: String })
], c.prototype, "scrollContainerClass");
export {
  c as SidemenuList
};
//# sourceMappingURL=sidemenu-list.js.map
