import { LitElement as d, unsafeCSS as c } from "lit";
import { property as i, state as h, query as m } from "lit/decorators.js";
import f from "../../api/marker/marker.style.css.js";
import { getPortalContainer as y } from "../../api/portal-manager/portal-manager.js";
import _ from "../../shared/reset.style.css.js";
import S from "../../shared/scrollbar.style.css.js";
import { scheduleShow as b, executeShow as v, hideFloating as A, updateFloatingCombobox as g, updateFloatingPosition as w } from "../../utils/floating-combobox.js";
import { booleanType as n } from "../../utils/property-types.js";
import E from "./select-options.style.css.js";
import { template as k } from "./select-options.template.js";
var T = Object.defineProperty, l = (p, e, t, r) => {
  for (var o = void 0, a = p.length - 1, u; a >= 0; a--)
    (u = p[a]) && (o = u(e, t, o) || o);
  return o && T(e, t, o), o;
};
class s extends d {
  constructor() {
    super(...arguments), this.isOpen = !1, this.openByDefault = !1, this.elements = null, this.value = null, this._value = null, this.type = "default", this.filter = null, this.multiple = !1, this.tick = !0, this.deselectable = !1, this.selectAll = !1, this.readonly = !1, this.disabled = !1, this.boxShadow = !1, this.advancedFilter = !1, this.searchThreshold = 1, this.filterThreshold = 1, this.boxStyle = "", this.selectedCounter = 0, this.ariaLabel = null, this.labelSelectAll = "Seleccionar-ho tot", this.labelDeselectAll = "Deseleccionar-ho tot", this.emptySelectorLabel = "Sense resultats per", this.emptyFilterLabel = "Escriu per cercar.", this._elementId = `dss-selector-${(/* @__PURE__ */ new Date()).getTime()}`, this._elementSelectAll = [], this._style = null, this._isAllSelected = !1, this._isFirstUpdated = !0, this.delay = 0, this._initialParent = null, this._portalManager = null, this._isTabbingOut = !1, this._toggle = () => {
      this.openByDefault || (this.isOpen ? this.show() : this.hide());
    }, this._syncSelectedValue = !1;
  }
  static get styles() {
    return [c(_), c(S), c(f), c(E)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0;
  }
  show() {
    b({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (e) => {
        this._showTimeout = e;
      },
      onExecuteShow: () => this._executeShow()
    });
  }
  _executeShow() {
    v({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (e) => {
        this._initialParent = e;
      },
      onUpdateFloating: () => this.updateFloatingCombobox()
    });
  }
  hide() {
    A({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (e) => {
        this._hideTimeout = e;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (e) => {
        this._cleanupAutoUpdate = e;
      },
      resetPosition: !0
    });
  }
  updateFloatingCombobox() {
    g({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (e) => {
        this._cleanupAutoUpdate = e;
      }
    });
  }
  async _updatePosition() {
    this._parent && await w(this._parent, this);
  }
  // LIT LIFECYCLE
  updated(e) {
    e.has("isOpen") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    }), e.has("openByDefault") && queueMicrotask(() => {
      this.openByDefault ? this.classList.add("keep-open") : this.classList.remove("keep-open");
    }), e.has("value") && queueMicrotask(() => {
      this._updateSelectedValues();
    }), e.has("elements") && queueMicrotask(() => {
      this._checkElements();
    }), e.has("boxStyle") && queueMicrotask(() => {
      this._style = this.boxStyle;
    }), e.has("filter") && this.selectAll && queueMicrotask(() => {
      this._areAllElementsSelected();
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = y(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement), this._elementSelectAll = [this.labelSelectAll], this._areAllElementsSelected();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  // METHODS
  _checkElements() {
    this._syncSelectedValue || this.elements?.length && (!this.value || this.value.length === 0 || (this._updateSelectedValues(), this._syncSelectedValue = !0));
  }
  _updateSelectedValues() {
    if (!this.elements?.length) return;
    if (!this.value || this.value.length === 0) {
      this._value = null;
      return;
    }
    this.multiple && setTimeout(() => {
      this._value = this.elements?.filter((t) => this.value.includes(t.value)) || null;
    }, 0);
    const e = this.elements?.find((t) => t.value === this.value[0]);
    this._value = e ? [e] : null;
  }
  _areAllElementsSelected() {
    if (!this.elements || !this._value) {
      this._elementSelectAll = [this.labelSelectAll], this._isAllSelected = !1;
      return;
    }
    const e = this._value.map((r) => r.value), t = this.elements.map((r) => r.value);
    this._isAllSelected = e.length === t.length && e.every((r) => t.includes(r)), this._isAllSelected ? this._elementSelectAll = [this.labelDeselectAll] : this._elementSelectAll = [this.labelSelectAll];
  }
  _valueIsSelected(e) {
    return this._value?.some((t) => t.value === e) || !1;
  }
  _manuallySelect(e, t) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly) return;
    const r = this._valueIsSelected(t);
    if (!this.multiple && !this.deselectable && r) return;
    const o = e.target, a = o.className.includes("dss-mark") ? o.parentElement : o;
    a && a.className.includes("dss-form-field") ? a.querySelector("input").checked = !r : a && (a.parentElement.querySelector("input").checked = !r), this._returnSelectedValues(t), this._areAllElementsSelected();
  }
  _manuallySelectAll(e) {
    if (e.preventDefault(), e.stopPropagation(), this.disabled || this.readonly || !this.multiple && !this.deselectable && this._isAllSelected) return;
    const t = e.target;
    t.className.includes("dss-form-field") ? (t.querySelector("input").checked = !t.querySelector("input").checked, this._returnSelecteAllValues(t.querySelector("input").checked)) : (t.parentElement.querySelector("input").checked = !t.parentElement.querySelector("input").checked, this._returnSelecteAllValues(t.parentElement.querySelector("input").checked)), this._areAllElementsSelected();
  }
  _returnSelecteAllValues(e) {
    e ? this._value = this.elements?.filter((o) => o.value) || [] : this._value = [];
    const r = {
      detail: this._value?.map((o) => o.value) || null,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", r)), this.requestUpdate();
  }
  _returnSelectedValues(e) {
    const t = Array.from(this.shadowRoot?.querySelectorAll("input:checked") || []).map((u) => u.getAttribute("value")).filter((u) => u == null ? !1 : this.multiple ? !0 : u === e), r = t.indexOf(this._elementSelectAll[0]);
    r !== -1 && t.splice(r, 1), this._value = this.elements?.filter((u) => t.includes(u.value)) || [];
    let o;
    this.multiple ? o = t : o = t[0] || null;
    const a = {
      detail: o,
      bubbles: !1,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("option-changed", a)), this.requestUpdate();
  }
  selectFirstMatch() {
    const e = this.shadowRoot?.querySelectorAll(".dss-form-field");
    let t = null;
    for (const r of e || []) {
      const o = r.getAttribute("data-label");
      if (o && this.filter && o.toLowerCase() === this.filter.toLowerCase()) {
        t = r;
        break;
      }
    }
    t && t.click();
  }
  moveFocus() {
    const e = this.shadowRoot?.querySelectorAll(".dss-form-field");
    if (!e || e.length === 0) return;
    const r = e[0].querySelector("input");
    r && r.focus();
  }
  _focusEvent(e) {
    e.target.closest(".dss-form-field")?.classList.add("dss-form-field__focus");
  }
  _blurEvent(e) {
    e.target.closest(".dss-form-field")?.classList.remove("dss-form-field__focus");
  }
  _handleKeyDown(e) {
    e.key === "Tab" && (this._isTabbingOut = !0), (e.key === "ArrowDown" || e.key === "ArrowUp") && e.preventDefault();
  }
  _handleFocusOut(e) {
    const t = e.relatedTarget;
    t && this.contains(t) || (this._isTabbingOut && this.dispatchEvent(
      new CustomEvent("options-focusout", {
        bubbles: !0,
        composed: !0
      })
    ), this._isTabbingOut = !1);
  }
  _focusSentinel() {
    this.dispatchEvent(
      new CustomEvent("options-focusout", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    return k(this);
  }
}
l([
  i(n)
], s.prototype, "isOpen");
l([
  i(n)
], s.prototype, "openByDefault");
l([
  i({ type: Array })
], s.prototype, "elements");
l([
  i({ type: Array })
], s.prototype, "value");
l([
  h()
], s.prototype, "_value");
l([
  i({ type: String })
], s.prototype, "type");
l([
  i({
    type: String,
    converter: (p) => p?.toLowerCase() ?? null
  })
], s.prototype, "filter");
l([
  i(n)
], s.prototype, "multiple");
l([
  i(n)
], s.prototype, "tick");
l([
  i(n)
], s.prototype, "deselectable");
l([
  i(n)
], s.prototype, "selectAll");
l([
  i(n)
], s.prototype, "readonly");
l([
  i(n)
], s.prototype, "disabled");
l([
  i(n)
], s.prototype, "boxShadow");
l([
  i(n)
], s.prototype, "advancedFilter");
l([
  i({ type: Number })
], s.prototype, "searchThreshold");
l([
  i({ type: Number })
], s.prototype, "filterThreshold");
l([
  i({ type: String })
], s.prototype, "boxStyle");
l([
  i({ type: Number })
], s.prototype, "selectedCounter");
l([
  i({ type: String })
], s.prototype, "ariaLabel");
l([
  i({ type: String })
], s.prototype, "labelSelectAll");
l([
  i({ type: String })
], s.prototype, "labelDeselectAll");
l([
  i({ type: String })
], s.prototype, "emptySelectorLabel");
l([
  i({ type: String })
], s.prototype, "emptyFilterLabel");
l([
  h()
], s.prototype, "_elementId");
l([
  h()
], s.prototype, "_elementSelectAll");
l([
  h()
], s.prototype, "_style");
l([
  h()
], s.prototype, "_isAllSelected");
l([
  h()
], s.prototype, "_isFirstUpdated");
l([
  m(".dss-select-options")
], s.prototype, "_floatingCombobox");
l([
  i({ type: Number })
], s.prototype, "delay");
l([
  h()
], s.prototype, "_syncSelectedValue");
export {
  s as SelectOptions
};
//# sourceMappingURL=select-options.js.map
