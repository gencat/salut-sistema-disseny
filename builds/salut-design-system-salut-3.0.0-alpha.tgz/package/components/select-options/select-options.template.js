import { classMap as f } from "lit/directives/class-map.js";
import { ifDefined as E } from "lit/directives/if-defined.js";
import { unsafeHTML as v } from "lit/directives/unsafe-html.js";
import { unsafeStatic as h, literal as o, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as S } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as x, highlightText as n } from "../../api/marker/marker.js";
const k = o`dss-icon${h(S())}`, A = o`dss-spinner${h(S())}`, C = (s) => s.elements?.map((e, r) => {
  const c = e.label.trim().replace(/\s+/g, "-"), y = e.value.trim().replace(/\s+/g, "-"), u = `selector-${c}-${y}`, a = s._valueIsSelected(e.value), l = s.tick && !s.multiple, $ = f({
    disabled: s.disabled,
    "dss-disabled": s.disabled,
    "dss-form-field": !0,
    "dss-form-field--simple": s.tick && !s.multiple,
    "dss-form-field--multiple": s.multiple,
    "dss-form-field--readonly": s.readonly,
    "dss-form-field--no-tick": !s.tick,
    "dss-type--default": s.type === "default",
    "dss-type--green": s.type === "green",
    "dss-ticked": l,
    "dss-selected": a && l,
    "dss-form-field--selected": a,
    "dss-first-unselected": r && r > 0 && r === s.selectedCounter,
    "dss-form-field--match": e.label.toLowerCase() === s.filter?.toLowerCase()
  }), b = f({
    "dss-checkbox": s.multiple,
    "dss-radio": !s.multiple,
    "dss-disabled": s.disabled,
    hidden: l
  }), _ = t`
      <input
        id="${u}"
        name="${u}"
        type="checkbox"
        class="${b}"
        .value="${e.value}"
        .checked="${a}"
        @focus="${s._focusEvent}"
        @blur="${s._blurEvent}"
        ?disabled="${s.disabled || s.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `, g = t`<span
      class="dss-icon--checked"
      style="visibility: ${s.isOpen && l && a ? "visible" : "hidden"}"
    ></span>`;
  return t`
      <div
        class="${$}"
        @keydown="${(i) => {
    i.key === "Enter" || i.key === " " ? s._manuallySelect(i, e.value) : i.key === "ArrowUp" ? i.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : i.key === "ArrowDown" && i.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
  }}"
        @click="${(i) => {
    s._manuallySelect(i, e.value);
  }}"
        data-label="${e.label}"
      >
        ${_}
        <label for=${u}>
          ${s.advancedFilter ? v(x(e.label, s.filter || "", s.searchThreshold)) : v(n(e.label, s.filter || ""))}
        </label>
        ${g}
      </div>
    `;
}), T = (s) => s._elementSelectAll?.map((e) => {
  const r = f({
    disabled: s.disabled || s.readonly,
    "dss-form-field": !0,
    "dss-type--default": s.type === "default",
    "dss-type--green": s.type === "green",
    "dss-selectAll": !0,
    "dss-disabled": s.disabled || s.readonly,
    "dss-form-field--match": e.toLowerCase() === s.filter?.toLowerCase()
  }), c = f({
    "dss-checkbox": s.multiple
  }), y = t`
      <input
        id="${s._elementId}"
        name="${s._elementId}"
        type="checkbox"
        class="${c}"
        .value="${e}"
        .checked="${s._isAllSelected}"
        @focus="${s._focusEvent}"
        @blur="${s._blurEvent}"
        ?disabled="${s.disabled || s.readonly}"
      />
      <div class="dss-check-overlay"></div>
    `;
  return t`
      <div
        class="${r}"
        @keydown="${(l) => {
    l.key === "Enter" || l.key === " " ? s._manuallySelectAll(l) : l.key === "ArrowUp" ? l.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : l.key === "ArrowDown" && l.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
  }}"
        @click="${(l) => {
    s._manuallySelectAll(l);
  }}"
        data-label="${e}"
      >
        ${y}
        <label for="${s._elementId}">${e}</label>
      </div>
    `;
}), K = (s) => {
  let d = C(s);
  const e = T(s);
  return s.multiple && s.selectAll && (d?.unshift(e[0]), d = d?.length === 1 ? [] : d), t`
    ${s.elements && s.elements.length > 0 ? t`
        <div
          aria-label="${E(s.ariaLabel)}"
          part="selector"
          class="dss-select-options list dss-selector-list-wrapper ${s.boxShadow ? "dss-selector-list-wrapper--box-shadow" : ""}"
			  @keydown=${s._handleKeyDown}
			  @focusout=${s._handleFocusOut}
          style="${s._style}"
        >
          ${d}
        </div>
      ` : t`
        <div
          part="selector"
          class="dss-select-options list dss-selector-list-wrapper"
			  @keydown=${s._handleKeyDown}
			  @focusout=${s._handleFocusOut}
          style="${s._style}"
        >
          ${s.filter && s.filter.length >= s.filterThreshold ? t`
                <div class="dss-selector-empty">
                  <${k} icon="info" size="sm"></${k}>
                  <span class="text">
                    ${s.filter || s.filter === "" ? t` ${s.emptySelectorLabel}: ${s.filter} ` : t`${s.emptyFilterLabel}`}
                  </span>
                </div>
              ` : t`
                <div class="dss-selector-empty">
                  <${A} size="md"/>
                </div>
              `}
        </div>
      `}
		<button
			class="dss-select-options__sentinel"
			type="button"
			aria-hidden="true"
			@focus=${s._focusSentinel}
		>
			Focus Sentinel
		</button>
  `;
};
export {
  K as template
};
//# sourceMappingURL=select-options.template.js.map
