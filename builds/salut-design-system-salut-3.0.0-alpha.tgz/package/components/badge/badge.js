import { LitElement as p, unsafeCSS as a } from "lit";
import { property as e } from "lit/decorators.js";
import _ from "../../foundations/icon/icon.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import u from "./badge.states.css.js";
import f from "./badge.style.css.js";
import { template as m } from "./badge.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, i = (l, t, o, c) => {
  for (var r = c > 1 ? void 0 : c ? g(t, o) : t, h = l.length - 1, d; h >= 0; h--)
    (d = l[h]) && (r = (c ? d(t, o, r) : d(r)) || r);
  return c && r && y(t, o, r), r;
};
class s extends p {
  constructor() {
    super(...arguments), this.text = "", this.disabled = !1, this.outlined = !1, this.dot = !1, this.hideIcon = !1, this.tooltipPosition = "top", this.width = void 0, this.forceViewport = !1, this._icon = "warning", this._iconSize = "sm", this._iconFill = !1, this._size = "sm", this._state = "", this._isIconDefined = !1, this._isFirstUpdated = !0, this._isTextTruncated = !1;
  }
  static get styles() {
    return [a(_), a(f), a(u)];
  }
  get _tooltip() {
    const t = this.shadowRoot?.querySelector('slot[name="tooltip"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set icon(t) {
    const o = this._icon;
    this._icon = t, this._isIconDefined = !0, this.requestUpdate("icon", o);
  }
  get icon() {
    return this._icon;
  }
  set size(t) {
    const o = this._size;
    this._size = t, t === "xl" ? this._iconSize = "md" : this._iconSize = "sm", this.requestUpdate("size", o);
  }
  get size() {
    return this._size;
  }
  set state(t) {
    const o = this._state;
    this._state = t, this._generateDefaultIcon(t), this.requestUpdate("state", o);
  }
  get state() {
    return this._state;
  }
  async firstUpdated() {
    if (await this.updateComplete, this.width) {
      const t = this.shadowRoot?.querySelector(".dss-badge");
      t && (t.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("text") && this._checkTextTruncated(), !this._isFirstUpdated && t.has("state") && (this._iconFill = !1, this._generateDefaultIcon(this.state));
  }
  _checkTextTruncated() {
    const t = this.shadowRoot?.querySelector(".dss-badge__text");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  _updateIconFill(t) {
    this._iconFill = !t.includes("low") || t === "correct";
  }
  _generateDefaultIcon(t) {
    t && !this._isIconDefined && (t.includes("danger") ? (this._icon = "warning", this._updateIconFill(t)) : t.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(t)) : t.includes("slight") ? (this._icon = "error", this._updateIconFill(t)) : t.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(t)) : t.includes("undeterminated") ? this._icon = "circle" : t.includes("undetermined") ? this._icon = "circle" : t.includes("critic") ? this._icon = "cancel" : t.includes("alert") ? this._icon = "report" : t.includes("ideal") ? this._icon = "check_circle" : t.includes("info") ? this._icon = "info" : t.includes("neutral") && (this._icon = "circle"));
  }
  _isInformativeState() {
    return ["ideal", "critical", "critic", "alert", "info", "info-alt", "neutral"].includes(this._state);
  }
  render() {
    return m(this);
  }
}
i([
  e({ type: String })
], s.prototype, "icon", 1);
i([
  e({ type: String })
], s.prototype, "size", 1);
i([
  e({ type: String })
], s.prototype, "text", 2);
i([
  e({ type: String })
], s.prototype, "state", 1);
i([
  e(n)
], s.prototype, "disabled", 2);
i([
  e(n)
], s.prototype, "outlined", 2);
i([
  e(n)
], s.prototype, "dot", 2);
i([
  e(n)
], s.prototype, "hideIcon", 2);
i([
  e({ type: String })
], s.prototype, "tooltipPosition", 2);
i([
  e({ type: String })
], s.prototype, "width", 2);
i([
  e(n)
], s.prototype, "forceViewport", 2);
export {
  s as Badge
};
//# sourceMappingURL=badge.js.map
