import { nothing as l } from "lit";
import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as r, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
const i = r`dss-button${t(d())}`, $ = (s) => e`
    <header
      class=${a({
  "dss-custom-table-header": !0,
  "dss-custom-table-header--hide-title": !s.tableTitle || s.tableTitle === "",
  "dss-custom-table-header--jcef": s.jcef,
  "dss-custom-table-header--inner-filters": s._innerFilters,
  "dss-custom-table-header--hide-expand-divider": s.tableTitle !== "" && !s.showConfig && !s.showActionFilters && !s.tableInfo && !s.customActions,
  "dss-custom-table-header--only-inner-expand": s.tableTitle === "" && !s.showConfig && !s.showActionFilters && !s.tableInfo,
  "dss-custom-table-header--empty-filters": !s._filters && !s._innerFilters,
  "dss-custom-table-header--deleted-filters": !s._innerFilters && (!s._filters || s._filters?.length === 0)
})}
    >
      <div class="dss-custom-table-header__main">
          
        ${s.tableTitle ? e`
            <div class="dss-custom-table-header__main-title">
              ${s.tableTitle}
            </div>
          ` : l}

        <div class="dss-custom-table-header__main-actions">
        
          <div class="dss-custom-table-header__main-actions__config">

            ${s.tableInfo ? e`
              <div class="main-actions__config-info">
                ${s.tableInfo}
              </div>
              ` : l}

            ${s.customActions ? e`
                <div class="dss-custom-table-header__main-actions__custom">
                  <slot name="header-custom-actions"></slot>
                </div>
              ` : l}

            

            ${s.showConfig ? e`
              <${i}
                variant="subtle"
                size="md"
                icon="settings"
                label="${s.configTableLabel}"
                @onClick=${s._emitConfigTable}
              ></${i}>
              ` : l}

            ${s.showActionFilters ? e`
              <div style="position: relative;">
                <${i}
                variant="secondary"
                size="md"
                icon="filter_list"
                label="${s._openFiltersLabel}"
                @onClick=${s._emitOpenFilters}
                ></${i}>
              </div>
              ` : l}

          </div>

          ${s.hideActionExpand ? l : e`
            <div class="dss-custom-table-header__main-actions__expand">
              <${i}
                variant="link"
                label="${s._expandTable ? s._collapseLabel : s._expandLabel}"
                icon="${s._expandTable ? "fullscreen_exit" : "fullscreen"}"
                size="md"
                @click="${s._emitExpandAction}"
              ></${i}>
            </div>`}
    
        </div>
      </div>

      <div class=${a({
  "dss-custom-table-header__filters": !0,
  "dss-custom-table-header__filters--inner": s._innerFilters,
  "dss-custom-table-header__filters--chips": !s._innerFilters,
  "dss-custom-table-header__filters--has-content": !!s._filters && s._filters.length > 0,
  "dss-custom-table-header__filters--expanded": s._filtersExpanded
})}>
        ${s._innerFilters ? e` 
              <slot name="filters"></slot>
            ` : e`
           
              <div class="filters-label">${s._filtersLabel}:</div>
        
              <div class="filters-wrapper" id="filtersWrapper">
                <div class="filters-list hide" id="filtersList">
                  ${s._generateFilterChips(s._visibleFilters)}
                  ${s._hiddenFilters.length > 0 && s._filtersShowMore && !s._filtersExpanded ? e`
                      <${i}
                        class="filters-show-more"
                        variant="info"
                        size="sm"
                        label="Més (${s._hiddenFilters.length})"
                        @onClick=${s._filtersToggleMore}
                      ></${i}>
                    ` : l}

                  ${s._filtersExpanded ? e`
                    ${s._generateFilterChips(s._hiddenFilters)}
                  ` : l}

                  ${s._filtersShowMore && s._filtersExpanded ? e`
                      <${i}
                        variant="info"
                        size="sm"
                        label="Menys"
                        @onClick=${s._filtersToggleMore}
                      ></${i}>
                    ` : l}

                  <${i}
                    id="filtersClean"
                    class="filters-clean"
                    variant="subtle"
                    size="sm"
                    icon="filter_list_off"
                    label="${s._cleanFiltersLabel}"
                    @onClick=${s._clearFilters}
                  ></${i}>
                  
                </div>
              </div>
           
          `}
      </div>
    </header>

  `;
export {
  $ as template
};
//# sourceMappingURL=custom-table-header.template.js.map
