import { LitElement, unsafeCSS, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { unsafeHTML } from "lit/directives/unsafe-html.js";
import { booleanType } from "../../utils/property-types.js";
import styles from "./stepper.style.css.js";
var __defProp = Object.defineProperty, __getOwnPropDesc = Object.getOwnPropertyDescriptor, __decorateClass = (e, s, l, t) => {
  for (var i = __getOwnPropDesc(s, l), r = e.length - 1, a; r >= 0; r--)
    (a = e[r]) && (i = a(s, l, i) || i);
  return i && __defProp(s, l, i), i;
};
class Stepper extends LitElement {
  constructor() {
    super(...arguments), this._steps = [], this._currentStep = 1, this._column = !1, this._circular = !1, this._hideLabel = !1, this._size = "md", this._activeBarWidth = "0", this._isFirstUpdate = !0;
  }
  static get styles() {
    return unsafeCSS(styles);
  }
  set steps(steps) {
    const oldValue = this._steps;
    this._steps = steps, typeof steps == "string" && (this._steps = eval(`(${steps})`)), this.requestUpdate("steps", oldValue);
  }
  get steps() {
    return this._steps;
  }
  set currentStep(e) {
    const s = this._currentStep;
    this._currentStep = e, this.requestUpdate("currentStep", s);
  }
  get currentStep() {
    return this._currentStep;
  }
  set column(e) {
    const s = this._column;
    this._column = e, this.requestUpdate("column", s);
  }
  get column() {
    return this._column;
  }
  set circular(e) {
    const s = this._circular;
    this._circular = e, this.requestUpdate("circular", s);
  }
  get circular() {
    return this._circular;
  }
  set hideLabel(e) {
    const s = this._hideLabel;
    this._hideLabel = e, this.requestUpdate("hideLabel", s);
  }
  get hideLabel() {
    return this._hideLabel;
  }
  set size(e) {
    const s = this._size;
    this._size = e, this.requestUpdate("size", s);
  }
  get size() {
    return this._size;
  }
  async firstUpdated() {
    await this.updateComplete, this._setActiveBarWidth(), this._isFirstUpdate = !1, this.requestUpdate();
  }
  willUpdate(e) {
    this._isFirstUpdate || (e.has("currentStep") || e.has("steps") || e.has("column")) && (this._setActiveBarWidth(), this.requestUpdate());
  }
  _setActiveBarWidth() {
    const e = this._steps.length, l = this.shadowRoot?.querySelector(".dss-stepper")?.getBoundingClientRect(), t = this._column ? l?.height : l?.width;
    if (t) {
      const i = Math.floor(t / (e - 1));
      this._activeBarWidth = `${i}px`;
    }
  }
  _onStepClick(e, s) {
    if (!(e.state === "disabled")) {
      const t = {
        detail: { step: e, stepNumber: s },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("step-click", t));
    }
  }
  render() {
    const e = this._steps?.length, s = Math.round(this._currentStep / e * 100), l = {
      "dss-stepper--vertical": this._column,
      "dss-stepper--sm": this._size === "sm",
      "dss-stepper--md": this._size === "md"
    };
    return html`
      ${this._circular ? html`
            <div class="dss-circular-stepper">
              <div class="dss-circular-stepper__item">
                <svg viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="33" cy="33" r="28" pathLength="100"></circle>
                  <circle
                    cx="33"
                    cy="33"
                    r="28"
                    style="--percent: ${s}"
                    pathLength="100"
                  ></circle>
                </svg>
                <span class="dss-circular-stepper__counter">
                  <b>${this._currentStep}</b>/${e}
                </span>
              </div>
              <span class="dss-circular-stepper__label">
                ${this._steps[this._currentStep - 1].label}
              </span>
            </div>
          ` : html`
            <style>
              :host {
                --active-bar-width: ${this._activeBarWidth};
              }
            </style>
            <ol class="dss-stepper ${classMap(l)}">
              ${this._steps?.map((t, i) => {
      const r = i + 1, a = (n) => {
        n.key === "Enter" && this._onStepClick(t, r);
      }, p = t.state === "disabled", c = {
        "dss-bubble--active": r === this._currentStep,
        "dss-bubble--completed": r < this._currentStep,
        "dss-bubble--checked": t.state === "checked" && r !== this._currentStep,
        "dss-bubble--error": t.state === "error" && r !== this._currentStep,
        "dss-bubble--info": t.state === "info" && r !== this._currentStep,
        "dss-bubble--alert": t.state === "alert" && r !== this._currentStep,
        "dss-bubble--disabled": t.state === "disabled",
        "dss-bubble--icon": !!t?.icon && this._size !== "sm"
      }, o = {
        "dss-bubble-label--disabled": t.state === "disabled",
        "hide-label": this._hideLabel
      };
      return html`
                  <li
                    class="dss-bubble ${classMap(c)}"
                    icon="${t?.icon || ""}"
                    tabindex="${p ? -1 : 0}"
                    aria-label="Step ${t?.state}"
                    @click=${() => this._onStepClick(t, r)}
                    @keydown=${a}
                  >
                    <span class="dss-bubble-label ${classMap(o)}"
                      >${unsafeHTML(t.label)}</span
                    >
                  </li>
                `;
    })}
            </ol>
          `}
    `;
  }
}
__decorateClass([
  property({ type: [] })
], Stepper.prototype, "steps");
__decorateClass([
  property({ type: Number })
], Stepper.prototype, "currentStep");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "column");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "circular");
__decorateClass([
  property(booleanType)
], Stepper.prototype, "hideLabel");
__decorateClass([
  property({ type: String })
], Stepper.prototype, "size");
export {
  Stepper
};
//# sourceMappingURL=stepper.js.map
