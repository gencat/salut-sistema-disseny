import { classMap as D } from "lit/directives/class-map.js";
import { unsafeStatic as _, literal as u, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { MONTH as g, WEEK as S } from "./calendar.js";
const b = u`dss-timepicker${_(o())}`, c = u`dss-icon${_(o())}`, s = u`dss-icon-button${_(o())}`, n = u`dss-button${_(o())}`, A = (e) => d`
  <div
        class="calendar__container"
        @keydown="${e._handleCalendarKeydown}"
      @focusout="${e._handleCalendarFocusOut}"
      >
        <div class="calendar__content">
          <header class="calendar__header">
            <div class="calendar__header-item calendar__header-selector">
              <div
                id="firstCalendarElement"
                class="calendar__header-item calendar__header-item--click calendar__header-month"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderMonthKeyDown}"
                @click="${e._toggleMonthSelector}"
                aria-label="selecciona el mes, actualment ${g[e._currMonth]}"
              >
                ${g[e._currMonth]}
                <${c} icon="expand_more" size="sm"></${c}>
              </div>
              <div
                class="calendar__header-item calendar__header-item--click calendar__header-year"
                tabindex="0"
                role="button"
                @keydown="${e._onHeaderYearKeyDown}"
                @click=${e._toggleYearSelector}
                aria-label="selecciona l'any, actualment ${e._currYear}"
              >
                ${e._currYear}
                <${c} icon="expand_more" size="sm"></${c}>
              </div>
            </div>
            <div class="calendar__header-item calendar__header-buttons">
              <${s} hideTooltip variant="primary" icon="chevron_left" label="Anterior" @click=${e._prev}
                ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
              </${s}>
              <${s} hideTooltip variant="primary" icon="chevron_right" label="Següent" @click=${e._next}
                ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
              </${s}>
            </div>
          </header>

          <div class="calendar__days-content">
            <ul class="calendar__week-names">
              ${S.map((l) => d`<li>${l}</li>`)}
            </ul>
            <div
              class="calendar__days"
              @mouseleave=${e._removeRangeOverDate}
            >
              ${e._days.map((l) => {
  const y = {
    "calendar__day-item--active": e._isToday(l),
    "calendar__day-item--weekend": e._isWeekend(l),
    "calendar__day-item--selected": e._isSelected(l),
    [`calendar__day-item--${e._getCustomType(l)}`]: !!e._getCustomType(l),
    "calendar__day-item--range": e._isBetweenRange(l) || e._isBetweenRangeOnMouseOver(l),
    "calendar__day-item--selected-range-start": e._isSelectedRangeStart(l),
    "calendar__day-item--selected-range-end": e._isSelectedRangeEnd(l) || e._isOverRangeDate(l),
    "calendar__day-item--range-enabled": e._range
  }, k = (t) => {
    const r = t.target;
    if (t.key === "ArrowUp") {
      t.preventDefault();
      const a = f(r, -7);
      a ? a.focus() : v();
    }
    if (t.key === "ArrowDown") {
      t.preventDefault();
      const a = f(r, 7);
      a ? a.focus() : h();
    }
    if (t.key === "ArrowRight") {
      t.preventDefault();
      const a = r.nextElementSibling;
      a ? a.focus() : h();
    }
    if (t.key === "ArrowLeft") {
      t.preventDefault();
      const a = w(r);
      a ? a.focus() : v();
    }
  }, v = () => {
    e._prev(), setTimeout(() => {
      const t = e.shadowRoot?.querySelectorAll(".calendar__day-item"), r = Array.from(t).filter((i) => !i.disabled), a = r[r.length - 1];
      a && (a.setAttribute("tabindex", "0"), a.focus());
    }, 0);
  }, h = () => {
    e._next(), setTimeout(() => {
      const t = e.shadowRoot?.querySelectorAll(".calendar__day-item"), a = Array.from(t).filter((i) => !i.disabled)[0];
      a && (a.setAttribute("tabindex", "0"), a.focus());
    }, 0);
  }, w = (t) => {
    let r = t?.previousElementSibling;
    for (; r; ) {
      if (!r.classList.contains("calendar__day-item")) {
        r = r.previousElementSibling;
        continue;
      }
      if (!r.disabled)
        return r;
      r = r.previousElementSibling;
    }
    return null;
  }, f = (t, r) => {
    const i = Array.from(
      t.closest(".calendar__days")?.querySelectorAll(".calendar__day-item") || []
    ).filter((m) => !m.disabled), $ = i.indexOf(t) + r;
    return $ < 0 || $ >= i.length ? null : i[$];
  };
  return d`
                  <button
                    tabindex="${e._isFocusable(l) ? 0 : -1}"
                    class="calendar__day-item ${D(y)}"
                    @click=${() => e._selectDate(l)}
                    @mouseover=${() => e._selectRangeOverDate(l)}
                    @focus=${() => e._selectRangeOverDate(l)}
                    ?disabled=${e._isInactive(l)}
                    @keydown="${k}"
                  >
                    ${l || null}
                  </button>
                `;
})}
            </div>
          </div>
        </div>
        ${e._showMonthSelector ? d`
              <div class="calendar-selector calendar-selector--month">
                <div class="calendar-selector-title">Selecciona un mes</div>
                <div class="calendar-selector-options">
                  ${e._generateMonthsOptions()}
                </div>
              </div>
            ` : null}
        ${e._showYearSelector ? d`
              <div class="calendar-selector calendar-selector--year">
                <div
                  class="calendar-selector-title calendar-selector-title--years"
                >
                  <div class="calendar-selector-title__years">
                    ${e._yearsRangeStart} - ${e._yearsRangeEnd}
                  </div>
                  <div class="calendar-selector-title__actions">
                    <${s}
                      hideTooltip
                      variant="primary" 
                      label="Anys anteriors"
                      icon="chevron_left"
                      @click=${e._onYearRangeStepDown}
                    ></${s}>
                    <${s}
                      hideTooltip
                      variant="primary" 
                      label="Anys posteriors"
                      icon="chevron_right"
                      @click=${e._onYearRangeStepUp}
                    ></${s}>
                  </div>
                </div>
                <div
                  class="calendar-selector-options calendar-selector-options--4col"
                >
                  ${e._generateYearsRangeOptions()}
                </div>
              </div>
            ` : null}
        ${e._showTime ? d`
              <div class="dss-datepicker__timepicker">
                <${b}
                  label=${e._timepickerLabel}
                  .dropdown="${e._timepicker}"
                  .customTimeListOptions=${e._customTimeListOptions}
                  .minutesRange=${e._minutesRange}
                  .minHour=${e._minHour}
                  .maxHour=${e._maxHour}
                  maxLength="5"
                  @value-changed=${e._onSelectTime}
                  .value="${e._timepickerValue}"
                >
                </${b}>
              </div>
            ` : null}
        ${e._showButtons || e._showTime ? d`
              <div class="calendar__content calendar__content--buttons">
                <div class="calendar__buttons">
                  <${n}
                    variant="secondary"
                    label=${e._leftLabel}
                    @click=${e._onCancel}
                  >
                  </${n}>
                  <${n}
                    variant="primary"
                    label=${e._rightLabel}

                    @click=${e._onAccept}
                    ?disabled=${e._validateSelectedDate()}
                  >
                  </${n}>
                </div>
              </div>
            ` : null}
      </div>

`;
export {
  A as template
};
//# sourceMappingURL=calendar.template.js.map
