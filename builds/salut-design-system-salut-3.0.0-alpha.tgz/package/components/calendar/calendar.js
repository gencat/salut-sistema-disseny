import { scheduleShow as v, executeShow as M, hideFloating as T, updateFloatingCombobox as F, updateFloatingPosition as x } from "../../utils/floating-combobox.js";
import { startOfMonth as O, endOfMonth as Y, eachDayOfInterval as k, getDay as C } from "date-fns";
import { LitElement as U, unsafeCSS as S } from "lit";
import { property as h, query as q, state as L } from "lit/decorators.js";
import { classMap as R } from "lit/directives/class-map.js";
import { html as b } from "lit/static-html.js";
import { getPortalContainer as A } from "../../api/portal-manager/portal-manager.js";
import H from "../../foundations/icon/icon.style.css.js";
import { booleanType as m } from "../../utils/property-types.js";
import $ from "../button/button.style.css.js";
import V from "../icon-button/icon-button.style.css.js";
import P from "./calendar.style.css.js";
import { template as B } from "./calendar.template.js";
var I = Object.defineProperty, K = Object.getOwnPropertyDescriptor, r = (y, t, e, a) => {
  for (var s = a > 1 ? void 0 : a ? K(t, e) : t, u = y.length - 1, c; u >= 0; u--)
    (c = y[u]) && (s = (a ? c(t, e, s) : c(s)) || s);
  return a && s && I(t, e, s), s;
};
const f = [
  "Gener",
  "Febrer",
  "Març",
  "Abril",
  "Maig",
  "Juny",
  "Juliol",
  "Agost",
  "Setembre",
  "Octubre",
  "Novembre",
  "Desembre"
], it = ["dl", "dm", "dc", "dj", "dv", "ds", "dg"];
class i extends U {
  constructor() {
    super(), this.open = !1, this.openByDefault = !1, this.placement = "bottom", this.customCalendar = void 0, this._range = !1, this._isRangeStartFocused = !1, this._isRangeEndFocused = !1, this._rangeStartDate = null, this._rangeEndDate = null, this._rangeOverDate = null, this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._timepickerLabel = "", this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._days = this._getDays(), this._selectedDate = null, this._showTime = !1, this._showButtons = !0, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._minDate = null, this._maxDate = null, this._timepickerValue = "", this._showMonthSelector = !1, this._showYearSelector = !1, this._yearsRangeStart = (/* @__PURE__ */ new Date()).getFullYear() - 18, this._yearsRangeEnd = (/* @__PURE__ */ new Date()).getFullYear() + 1, this._isTimeFormatValid = !1, this.delay = 0, this._initialParent = null, this._portalManager = null, this._isTabbingOut = !1, this._isFirstUpdated = !0, this._focusFirstElementHandler = this._focusFirstElement.bind(this);
  }
  static get styles() {
    return [S(H), S($), S(V), S(P)];
  }
  set range(t) {
    const e = this._range;
    this._range = t, this.requestUpdate("range", e);
  }
  get range() {
    return this._range;
  }
  set isRangeStartFocused(t) {
    const e = this._isRangeStartFocused;
    this._isRangeStartFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeStartFocused() {
    return this._isRangeStartFocused;
  }
  set isRangeEndFocused(t) {
    const e = this._isRangeEndFocused;
    this._isRangeEndFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeEndFocused() {
    return this._isRangeEndFocused;
  }
  set selectedDate(t) {
    const e = this._selectedDate;
    this._selectedDate = this._getDateString(t), this._updateCurrentDate(), this.requestUpdate("selectedDate", e);
  }
  get selectedDate() {
    return this._selectedDate?.toString() || "";
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = this._getDateString(t), this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate?.toString() || "";
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = this._getDateString(t), this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate?.toString() || "";
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set rangeStartDate(t) {
    const e = this._rangeStartDate;
    this._rangeStartDate = this._getDateString(t), this.requestUpdate("rangeStartDate", e);
  }
  get rangeStartDate() {
    return this._rangeStartDate?.toString() || "";
  }
  set rangeEndDate(t) {
    const e = this._rangeEndDate;
    this._rangeEndDate = this._getDateString(t), this.requestUpdate("rangeEndDate", e);
  }
  get rangeEndDate() {
    return this._rangeEndDate?.toString() || "";
  }
  connectedCallback() {
    super.connectedCallback(), this._range && window.addEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0, this._range && window.removeEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = A(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("open") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    }), t.has("openByDefault") && queueMicrotask(() => {
      this.openByDefault ? this.classList.add("keep-open") : this.classList.remove("keep-open");
    });
  }
  _toggle() {
    this.openByDefault || (this.open ? this.show() : this.hide());
  }
  show() {
    v({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    });
  }
  _executeShow() {
    M({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCalendar()
    });
  }
  hide() {
    T({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCalendar() {
    F({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    this._parent && await x(this._parent, this, {
      placement: this.placement,
      matchWidth: !1
    });
  }
  _focusFirstElement() {
    this.shadowRoot?.querySelector("#firstCalendarElement")?.focus();
  }
  _prev() {
    this._currMonth -= 1, this._update();
  }
  _next() {
    this._currMonth += 1, this._update();
  }
  _update() {
    (this._currMonth < 0 || this._currMonth > 11) && (this._date = new Date(this._currYear, this._currMonth, (/* @__PURE__ */ new Date()).getDate()), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth()), this._days = this._getDays(), this.requestUpdate();
  }
  _getDays() {
    const t = [], e = O(new Date(this._currYear, this._currMonth)), a = Y(new Date(this._currYear, this._currMonth)), s = k({ start: e, end: a }), u = C(e);
    for (let c = u === 0 ? 6 : u - 1; c > 0; c -= 1)
      t.push(0);
    for (const c of s)
      t.push(c.getDate());
    return t;
  }
  _getCustomType(t) {
    if (!this.customCalendar) return !1;
    const a = new Date(this._currYear, this._currMonth, t).toLocaleDateString("es-ES"), s = this.customCalendar.find((u) => u.date === a);
    return s ? s.type : !1;
  }
  _isToday(t) {
    const e = /* @__PURE__ */ new Date();
    return t === e.getDate() && this._currMonth === e.getMonth() && this._currYear === e.getFullYear();
  }
  _isWeekend(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return e.getDay() === 0 || e.getDay() === 6;
  }
  _isInactive(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return t ? this._minDate && this._maxDate ? !(e >= this._minDate && e <= this._maxDate) : this._minDate ? !(e >= this._minDate) : this._maxDate ? !(e <= this._maxDate) : !1 : !0;
  }
  _isSelected(t) {
    return this._range ? t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() || this._isSelectedRangeEnd(t) : t === this._selectedDate?.getDate() && this._currMonth === this._selectedDate?.getMonth() && this._currYear === this._selectedDate?.getFullYear();
  }
  _isFocusable(t) {
    return this._range && (this._rangeStartDate || this._rangeEndDate) ? this._isSelectedRangeStart(t) || this._isSelectedRangeEnd(t) : this._selectedDate ? this._isSelected(t) : this._isToday(t);
  }
  _isSelectedRangeStart(t) {
    return this._range && this._rangeStartDate && this._rangeEndDate ? !this._compareSelectedRangeDates() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() : this._range && this._rangeStartDate && !this._rangeEndDate ? this._rangeOverDate !== null && this._rangeStartDate?.getTime() < this._rangeOverDate?.getTime() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : (this._range && this._rangeStartDate === this._rangeEndDate, !1);
  }
  _isSelectedRangeEnd(t) {
    return !this._compareSelectedRangeDates() && t === this._rangeEndDate?.getDate() && this._currMonth === this._rangeEndDate?.getMonth() && this._currYear === this._rangeEndDate?.getFullYear();
  }
  _isOverRangeDate(t) {
    const e = t === this._rangeOverDate?.getDate() && this._currMonth === this._rangeOverDate?.getMonth() && this._currYear === this._rangeOverDate?.getFullYear();
    return this._range && this._rangeOverDate && this._rangeStartDate && !this._rangeEndDate ? e && this._rangeOverDate.getTime() > this._rangeStartDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _compareSelectedRangeDates() {
    return this._rangeStartDate && this._rangeEndDate ? this._rangeStartDate.getFullYear() === this._rangeEndDate.getFullYear() && this._rangeStartDate.getMonth() === this._rangeEndDate.getMonth() && this._rangeStartDate.getDate() === this._rangeEndDate.getDate() : !0;
  }
  _isBetweenRange(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return !this._isInactive(t) && this._rangeStartDate && this._rangeEndDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() : !1;
  }
  _isBetweenRangeOnMouseOver(t) {
    const e = new Date(this._currYear, this._currMonth, t), a = this._isInactive(t);
    return !a && this._rangeStartDate && !this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !a && this._rangeStartDate && this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _selectDate(t) {
    this._selectedDate = new Date(this._currYear, this._currMonth, t), this._range && !this._showButtons && (this._rangeStartDate && this._rangeEndDate && !this._isRangeEndFocused && this._selectedDate.getTime() >= this._rangeEndDate.getTime() && (this._rangeStartDate = null, this._rangeEndDate = null), this._isRangeStartFocused || !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this._range && this._showButtons && (this._rangeStartDate && this._rangeEndDate && (this._rangeStartDate = null, this._rangeEndDate = null), !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this.requestUpdate(), !this._showButtons && (this._range ? this._emitRange() : this._emitDate());
  }
  _selectRangeOverDate(t) {
    this._range && (this._rangeOverDate = new Date(this._currYear, this._currMonth, t), this.requestUpdate());
  }
  _removeRangeOverDate() {
    this._rangeOverDate = null, this.requestUpdate();
  }
  _onCancel() {
    const t = new CustomEvent("onCancel", {
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(t);
  }
  _onAccept() {
    this._range ? this._emitRange() : this._emitDate();
  }
  _emitDate() {
    const t = this._selectedDate?.getDate()?.toString().padStart(2, "0"), e = (this._currMonth + 1).toString().padStart(2, "0");
    let a = `${t}/${e}/${this._currYear}`;
    if (this._showTime) {
      const u = this._currHour?.toString().padStart(2, "0"), c = this._currMin?.toString().padStart(2, "0");
      a += ` ${u}:${c}`;
    }
    const s = new CustomEvent("onDateChange", {
      detail: a,
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(s);
  }
  _emitRange() {
    let t = null;
    if (this._rangeStartDate?.getDate() != null && this._rangeStartDate?.getMonth() != null && this._rangeStartDate?.getFullYear() != null) {
      const u = this._rangeStartDate.getDate()?.toString().padStart(2, "0"), p = (this._rangeStartDate?.getMonth() + 1).toString().padStart(2, "0");
      t = `${u}/${p}/${this._rangeStartDate?.getFullYear()}`;
    }
    let e = null;
    if (this._rangeEndDate?.getDate() != null && this._rangeEndDate?.getMonth() != null && this._rangeEndDate?.getFullYear()) {
      const u = this._rangeEndDate.getDate()?.toString().padStart(2, "0"), p = (this._rangeEndDate?.getMonth() + 1).toString().padStart(2, "0");
      e = `${u}/${p}/${this._rangeEndDate?.getFullYear()}`;
    }
    const a = new CustomEvent("onRangeChange", {
      detail: {
        rangeStart: t,
        rangeEnd: e
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(a);
    const s = new CustomEvent("range-changed", {
      detail: {
        rangeStart: t,
        rangeEnd: e
      },
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(s);
  }
  _updateCurrentDate() {
    if (!this._selectedDate) {
      this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth();
      return;
    }
    if (this._currMonth = this._selectedDate.getMonth(), this._currYear = this._selectedDate.getFullYear(), this._currHour = this._selectedDate.getHours(), this._currMin = this._selectedDate.getMinutes(), this._days = this._getDays(), this._currHour !== void 0 && this._currMin !== void 0) {
      const t = String(this._currHour).padStart(2, "0"), e = String(this._currMin).padStart(2, "0");
      this._timepickerValue = `${t}:${e}`, this._isTimeFormatValid = this._currHour >= 0 && this._currHour <= 23 && this._currMin >= 0 && this._currMin <= 59;
    }
  }
  _getDateString(t) {
    const e = t?.replace(/(\d+[/])(\d+[/])/, "$2$1"), a = this._showTime ? 14 : 8;
    return e?.length > a ? new Date(e) : null;
  }
  _onSelectTime(t) {
    if (this._isTimeFormatValid = !1, t.detail.status === "VALID") {
      this._isTimeFormatValid = !0;
      const e = t.detail.value;
      this._currHour = +e.substring(0, 2), this._currMin = +e.substring(3, 5);
    }
    this.requestUpdate();
  }
  _toggleMonthSelector() {
    this._showMonthSelector = !0, this.requestUpdate();
  }
  _onMonthSelectorClick(t) {
    const e = f.indexOf(t);
    this._currMonth = e, this._update(), this._showMonthSelector = !1, this.requestUpdate();
  }
  _toggleYearSelector() {
    this._showYearSelector = !0, this.requestUpdate();
  }
  _onYearSelectorClick(t) {
    this._currYear = t, this._update(), this._showYearSelector = !1, this.requestUpdate();
  }
  _generateYearsRangeOptions() {
    const t = [];
    for (let a = this._yearsRangeStart; a <= this._yearsRangeEnd; a += 1)
      t.push(a);
    return t.map((a) => {
      const s = (n) => {
        n && n.focus();
      }, u = (n) => {
        let l = 0;
        const o = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = o.length - 1;
        n === o[0] ? s(o[d]) : (o.forEach((g, D) => {
          g === n && (l = D);
        }), s(o[l - 1]));
      }, c = (n) => {
        let l = 0;
        const o = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = o.length - 1;
        n === o[d] ? s(o[0]) : (o.forEach((g, D) => {
          g === n && (l = D);
        }), s(o[l + 1]));
      }, p = (n) => {
        const l = n.currentTarget, o = n;
        let d = !1;
        switch (o.key) {
          case "ArrowUp":
          case "ArrowLeft":
            u(l), d = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            c(l), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
            const g = n.target;
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--year[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), n.target.setAttribute("tabindex", "0"), g.click(), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), d = !0;
            break;
        }
        d && (n.stopPropagation(), n.preventDefault());
      }, E = (/* @__PURE__ */ new Date()).getFullYear(), _ = {
        "calendar-selector-options__item--current": a === E,
        "calendar-selector-options__item--selected": a === this._currYear
      };
      return b`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--year ${R(_)}"
          tabindex="${a === this._currYear ? 0 : -1}"
          role="button"
          @keydown=${p}
          @click=${() => this._onYearSelectorClick(a)}
        >
          ${a}
        </div>
      `;
    });
  }
  _generateMonthsOptions() {
    return f.map((e) => {
      const a = (_) => {
        _ && _.focus();
      }, s = (_) => {
        let n = 0;
        const l = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), o = l.length - 1;
        _ === l[0] ? a(l[o]) : (l.forEach((d, g) => {
          d === _ && (n = g);
        }), a(l[n - 1]));
      }, u = (_) => {
        let n = 0;
        const l = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), o = l.length - 1;
        _ === l[o] ? a(l[0]) : (l.forEach((d, g) => {
          d === _ && (n = g);
        }), a(l[n + 1]));
      }, c = (_) => {
        const n = _.currentTarget, l = _;
        let o = !1;
        switch (l.key) {
          case "ArrowUp":
          case "ArrowLeft":
            s(n), o = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            u(n), o = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
            const d = _.target;
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--month[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), _.target.setAttribute("tabindex", "0"), d.click(), o = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), o = !0;
            break;
        }
        o && (_.stopPropagation(), _.preventDefault());
      }, w = (/* @__PURE__ */ new Date()).getMonth(), E = {
        "calendar-selector-options__item--current": f.indexOf(e) === w,
        "calendar-selector-options__item--selected": f.indexOf(e) === this._currMonth
      };
      return b`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--month ${R(E)}"
          tabindex="${f.indexOf(e) === this._currMonth ? 0 : -1}"
          role="button"
          @keydown=${c}
          @click=${() => this._onMonthSelectorClick(e)}
        >
          ${e.length <= 4 ? b`${e}` : b`${e.slice(0, 3)}.`}
        </div>
      `;
    });
  }
  _onYearRangeStepUp() {
    this._yearsRangeStart += 20, this._yearsRangeEnd += 20, this.requestUpdate();
  }
  _onYearRangeStepDown() {
    this._yearsRangeStart -= 20, this._yearsRangeEnd -= 20, this.requestUpdate();
  }
  _onHeaderMonthKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--month[tabindex="0"]').focus();
    }, 50));
  }
  _onHeaderYearKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--year[tabindex="0"]').focus();
    }, 50));
  }
  _validateSelectedDate() {
    return !!(!this._range && !this._selectedDate || !this._range && this._showTime && !this._isTimeFormatValid || this._range && (!this._rangeStartDate || !this._rangeEndDate));
  }
  _handleCalendarKeydown(t) {
    if (t?.key === "Escape" && this._onCancel(), t?.key === "Tab") {
      const e = this._getFocusableElements(), s = this.renderRoot?.activeElement ?? document.activeElement;
      if (!e.length || !s) {
        t.preventDefault(), t.stopPropagation(), this.dispatchEvent(
          new CustomEvent("calendar-focusout", {
            bubbles: !0,
            composed: !0
          })
        );
        return;
      }
      const u = e[0], c = e[e.length - 1];
      (t.shiftKey && s === u || !t.shiftKey && s === c) && (t.preventDefault(), t.stopPropagation(), this.dispatchEvent(
        new CustomEvent("calendar-focusout", {
          bubbles: !0,
          composed: !0
        })
      ));
    }
  }
  _getFocusableElements() {
    const t = this.renderRoot;
    return t ? Array.from(t.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')).filter((s) => s.hasAttribute("disabled") || s.getAttribute("aria-disabled") === "true" ? !1 : s.tabIndex >= 0) : [];
  }
  _handleCalendarFocusOut(t) {
    const e = t.relatedTarget, a = this.renderRoot;
    if (e && a instanceof ShadowRoot && a.contains(e)) {
      this._isTabbingOut = !1;
      return;
    }
    this._isTabbingOut && this.dispatchEvent(
      new CustomEvent("calendar-focusout", {
        bubbles: !0,
        composed: !0
      })
    ), this._isTabbingOut = !1;
  }
  render() {
    return B(this);
  }
}
r([
  h(m)
], i.prototype, "open", 2);
r([
  h(m)
], i.prototype, "openByDefault", 2);
r([
  h({ type: String })
], i.prototype, "placement", 2);
r([
  h({ type: Array })
], i.prototype, "customCalendar", 2);
r([
  h(m)
], i.prototype, "range", 1);
r([
  h(m)
], i.prototype, "isRangeStartFocused", 1);
r([
  h(m)
], i.prototype, "isRangeEndFocused", 1);
r([
  h({ type: String })
], i.prototype, "selectedDate", 1);
r([
  h({ type: String })
], i.prototype, "minDate", 1);
r([
  h({ type: String })
], i.prototype, "maxDate", 1);
r([
  h(m)
], i.prototype, "showTime", 1);
r([
  h(m)
], i.prototype, "showButtons", 1);
r([
  h({ type: String })
], i.prototype, "leftLabel", 1);
r([
  h({ type: String })
], i.prototype, "rightLabel", 1);
r([
  h({ type: String })
], i.prototype, "timepicker", 1);
r([
  h({ type: Number })
], i.prototype, "minutesRange", 1);
r([
  h({ type: Number })
], i.prototype, "minHour", 1);
r([
  h({ type: Number })
], i.prototype, "maxHour", 1);
r([
  h({ type: Array })
], i.prototype, "customTimeListOptions", 1);
r([
  h({ type: String })
], i.prototype, "timepickerLabel", 1);
r([
  h({ type: String })
], i.prototype, "rangeStartDate", 1);
r([
  h({ type: String })
], i.prototype, "rangeEndDate", 1);
r([
  q(".dss-select-options")
], i.prototype, "_floatingCombobox", 2);
r([
  h({ type: Number })
], i.prototype, "delay", 2);
r([
  L()
], i.prototype, "_isFirstUpdated", 2);
export {
  i as Calendar,
  f as MONTH,
  it as WEEK
};
//# sourceMappingURL=calendar.js.map
