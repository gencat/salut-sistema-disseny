import { nothing as d } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as r, literal as n, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { checkTextTruncate as t, checkWebkitTruncate as _ } from "../../utils/helpers.js";
const p = n`dss-icon-button${r(l())}`, u = n`dss-button${r(l())}`, a = n`dss-icon${r(l())}`, $ = n`dss-badge${r(l())}`, i = n`dss-tooltip${r(l())}`, w = (e) => s`
  <div
    class=${o({
  "dss-header-menu-patient": !0,
  "dss-header-menu-patient--jcef": e.jcef,
  [`dss-header-menu-patient--${e.variant}`]: !!e.variant
})}
  >
    <div class="dss-header-menu-patient-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-patient-details">
      <div class="dss-header-menu-patient-details__name">
        ${e.name}
      </div>
      <div class="dss-header-menu-patient-details__info">
        ${e.cip ? s`
            <span class="dss-header-menu-patient-details__info-label dss-header-menu-patient-details__info-label--cip">
              ${e.cip}
            </span>
            <span class="divider-v divider-v--cip"></span>
          ` : null}
        ${e.age ? s`
            <span class="dss-header-menu-patient-details__info-label">
              ${e.age}
            </span>
            <span class="divider-v"></span>
          ` : null}
        ${e.gender ? s`
            <span class="dss-header-menu-patient-details__info-label">
              ${e.gender}
            </span>
          ` : null}
      </div>
    </div>
    <${p}
      class="dss-header-menu-patient__toggle-action"
      icon="${e._toggleIcon}"
      label="${e._toggleLabel}"
      variant="primary"
      @onClick="${e._toggleDropdown}"
      ?disabled=${e.disabled}
      ariaLabel="${e._toggleLabel} menú pacient"
      ariaExpanded="${e._showDropdown ? "true" : "false"}"
      hideTooltip
    ></${p}>
    ${e._showDropdown ? s`
          <div
            id="menu-patient"
            class=${o({
  "dss-header-menu-patient-dropdown": !0,
  "dss-header-menu-patient-dropdown--expanded": !!e._showDropdown
})}
          >
            <div class="dss-header-menu-patient-dropdown__info">
              <div class="dss-header-menu-patient-dropdown__title">
                ${e.infoLabel}
              </div>

              <div class="dss-header-menu-patient-dropdown__content">
                <div class="dss-header-menu-patient-dropdown__subtitle">
                  ${e.name}
                </div>

                ${e.cip ? s`
                  <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--cip">
                    <span class="dss-header-menu-patient-dropdown__description__cip">
                      ${e.cip}
                    </span>
                    ${e.hideCopyCip ? d : s`
                        <${p}
                          icon="content_copy"
                          size="sm"
                          label="Copiar CIP"
                          variant="primary"
                          @onClick="${e._handleCIPClick}"
                          ?disabled=${e.disabled}
                        ></${p}>
                      `}
                   
                  </div>
                  ` : d}

                ${e.age ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="person" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.age}
                      </div>
                    </div>
                  ` : d}

                ${e.gender ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="${e._getGenderIcon()}" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.gender}
                      </div>
                    </div>
                  ` : d}

                ${e.phoneMain ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.phoneMain}
                      </div>
                    </div>
                  ` : d}

                ${e.phoneAlt ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${e.phoneAlt}
                      </div>
                    </div>
                  ` : d}

                ${e.mail ? s`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="mail" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                        
                        ${e.mail}
                        <${i} 
                          class="description-tooltip header-menu-patient-tooltip" 
                          aria-hidden="true" 
                          interactive
                        >
                          ${e.mail}
                        </${i}>
                      </div>
                    </div>
                  ` : d}

                ${e.address ? s`
                    <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--address">
                      <${a} class="address-icon" icon="home_work" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description dss-header-menu-patient-dropdown__description--address" @mouseenter=${_}>
                        <a class="dss-header-menu-patient-dropdown__link" href="${e.addressURL}" target="_blank" rel="noopener">
                          ${e.address}
                        </a>
                        <${i} 
                          class="description-tooltip header-menu-patient-tooltip" 
                          aria-hidden="true" 
                          interactive
                        >
                          ${e.address}
                        </${i}>
                      </div>
                    </div>
                  ` : d}

                ${e.assignments ? s`
                  <div class="dss-header-menu-patient-dropdown__assignments">
                    <div class="dss-header-menu-patient-dropdown__title dss-header-menu-patient-dropdown__title--assigned">
                      ${e.assignedLabel}
                    </div>

                    ${e.assignments.uab ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAB</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${e.assignments.uab}
                          <${i} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.uab}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${e.assignments.ui ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UI</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${e.assignments.ui}
                          <${i} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.ui}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${e.assignments.uas ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAS</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${e.assignments.uas}
                          <${i} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.uas}
                          </${i}>
                        </div>
                      </div>
                      ` : d} 

                    ${e.assignments.center ? s`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${t}>
                          ${e.assignments.center}
                          <${i} 
                            class="description-tooltip header-menu-patient-tooltip" 
                            aria-hidden="true" 
                            interactive
                          >
                            ${e.assignments.center}
                          </${i}>
                        </div>
                        ${e.assignments.up ? s`
                          <${$} size="sm" state="info" outlined text="${e.upLabel}">
                            <${i}
                              class="header-menu-patient-tooltip"
                              slot="tooltip"
                             > 
                              ${e.upMessage} 
                            </${i}>
                          </${$}>
                        ` : d}
                      </div>
                      ` : d} 
                  </div>
                ` : d}
              </div>
            </div>

            ${!e.hideViewDetails || e.edit ? s`
                <div class="dss-header-menu-patient-dropdown__actions">
                  ${e.hideViewDetails ? d : s`
                      <${u}
                        variant="link"
                        size="md"
                        label="${e.detailsLabel}"
                        fullWidth
                        @click="${e._handleViewDetails}"
                      </${u}>
                    `}
                  ${e.edit ? s`
                      <${u}
                        variant="link"
                        size="md"
                        label="${e.editLabel}"
                        icon="open_in_new" 
                        iconPosition="right"
                        fullWidth
                        @click="${e._handleEdit}"
                      </${u}>
                    ` : d}
                </div>` : d}

          </div>
        ` : null}
  </div>
`;
export {
  w as headerMenuPatientTemplate
};
//# sourceMappingURL=header-menu-patient.template.js.map
