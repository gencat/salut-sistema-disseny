import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as r, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
const s = r`dss-button${a(d())}`, p = (i) => e`
 

    ${i.variant === "list" ? e`
          <div
            id="timepicker-options"
            class="${t({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--list": !0
})}"
            role="listbox"
            aria-label="Timepicker Options"
          >
            <div class="dss-timepicker-dropdown__container">
              ${e`${i._generateTimeListOptionsHTML(i.timeListOptions, i.customTimeListOptions)}`}
            </div>
          </div>
        ` : e`
          <div
            id="timepicker-options"
            class="${t({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--manual": !0
})}"
            role="listbox"
            aria-label="Timepicker Options"
          >
            <div class="dss-timepicker-dropdown__manual">
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--hour"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualHour", i.timeManualHourOptions)}
              </div>
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--minute"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualMinutes", i.timeManualMinutesOptions)}
              </div>
            </div>
            <div class="dss-timepicker-dropdown__actions">
              <${s} 
                label="Cancel-lar"
                size="md"
                variant="secondary"
                @onClick=${i._handleManualCancel}
              ></${s}>
              <${s}
                label="Seleccionar"
                size="md"
                variant="primary"
                ?disabled=${i._checkDisableTimeManualSelector()}
                @onClick=${i._handleManualAccept}
              ></${s}>
            </div>
          </div>
          `} 
        <button
          class="dss-timepicker-dropdown__sentinel"
          type="button"
          aria-hidden="true"
          @focus=${i._focusSentinel}
        >
          Focus Sentinel
        </button>
`;
export {
  p as template
};
//# sourceMappingURL=timepicker-options.template.js.map
