import { LitElement as b, unsafeCSS as c } from "lit";
import { query as _, property as s, state as d } from "lit/decorators.js";
import { getPortalContainer as g } from "../../api/portal-manager/portal-manager.js";
import C from "../../shared/reset.style.css.js";
import { booleanType as h, booleanConverter as u } from "../../utils/property-types.js";
import T from "../input/input.style.css.js";
import S from "./datepicker.style.css.js";
import { template as k } from "./datepicker.template.js";
var x = Object.defineProperty, i = (y, t, a, r) => {
  for (var n = void 0, o = y.length - 1, l; o >= 0; o--)
    (l = y[o]) && (n = l(t, a, n) || n);
  return n && x(t, a, n), n;
};
const m = class m extends b {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "calendar_today", this.showCalendar = !1, this.showTime = !1, this.showButtons = !1, this.leftLabel = "Cancel·lar", this.rightLabel = "Seleccionar", this.minDate = "", this.maxDate = "", this.timepicker = "", this.timepickerLabel = "Selecciona una hora", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this.customCalendar = void 0, this.customTimeListOptions = [], this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this._defaultId = `dss-datepicker-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._externalPlaceholder = "", this._previousDate = "", this._inputValidity = !0, this._placeholder = "", this._helpText = "", this._helpTextBackup = "", this._oldHelpText = "", this._isFirstUpdated = !0, this._portalManager = null, this._backFromCalendar = !1, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this.showCalendar && this._closeCalendar();
      },
      {
        root: null,
        threshold: 0
      }
    ), this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [c(C), c(T), c(S)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeCalendarListener(), this.visibleObserver.disconnect();
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.visibleObserver.observe(this._input), this._helpTextBackup = this.helpText ?? "", this._portalManager = g(), this._enableAnimations(), this._input.classList.add("dss-input-skip-native"), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value), t.has("placeholder") && (this._placeholder = this.placeholder, this._externalPlaceholder = this.placeholder), t.has("showTime") && this.showTime && (this.showButtons = !0), t.has("helpText") && queueMicrotask(() => {
      this._helpText = this.helpText ?? "", this._oldHelpText = this.helpText ?? "";
    });
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  render() {
    return k(this);
  }
  /* Handle Input Events */
  _handleInput(t) {
    const a = t.target.value?.replace(/\D/g, "");
    this._input && (this._input.value = this._formatDate(a), this.value = this._formatDate(a), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _handleFocusin() {
    this._backFromCalendar || this._isFocused || this.readonly || (this._externalPlaceholder !== "" ? this._placeholder = this._externalPlaceholder : this._placeholder = this.showTime ? "DD/MM/AAAA HH:MM" : "DD/MM/AAAA", this._input?.setAttribute("placeholder", this._placeholder), this.showCalendar = !0, this._addCalendarListener(), this._isFocused = !0, this._disableAnimations(), this._backFromCalendar = !1);
  }
  _focusInput() {
    !this.disabled && !this.readonly && this._input?.focus();
  }
  _handleKeydown(t) {
    if (t?.key === "Tab" ? (this._isFocused = !0, this._checkInputOverflow(), this.showCalendar && (t.preventDefault(), t.stopPropagation(), this._getPortalCalendar()._focusFirstElement())) : t?.key === "Enter" || t?.key === " " ? (this.showCalendar = !0, this._checkInputOverflow(), this._addCalendarListener(), this._disableAnimations()) : t?.key === "Escape" && this._closeCalendar(), t.key === "Enter" && this._input && this._input.value?.length > 7 && this._input) {
      const a = this._input.value?.replace(/(\d+[/])(\d+[/])/, "$2$1"), r = new Date(a), n = r.getDate()?.toString().padStart(2, "0"), o = (r.getMonth() + 1).toString().padStart(2, "0"), l = r.getFullYear(), p = r.getHours()?.toString().padStart(2, "0"), f = r.getMinutes()?.toString().padStart(2, "0");
      let v = `${n}/${o}/${l}`;
      this.showTime && (v += ` ${p}:${f}`, this._handleValidity()), this._input && (this._input.value = v), this._dispatchValueChange(), this.showCalendar ? this._closeCalendar() : this.requestUpdate();
    }
  }
  _handleCalendarFocusOut() {
    this.readonly || this.disabled || this.showCalendar && (this._backFromCalendar = !0, this._closeCalendar(), setTimeout(() => {
      this._input?.focus();
    }, 0));
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), a = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, n = document.createElement("canvas").getContext("2d");
    if (!n) return;
    n.font = a;
    const o = n.measureText(this._input.value).width;
    this._isTruncated = o > this._input.offsetWidth;
  }
  /* Hamdle Datepicker Validations */
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t), this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _validateDate() {
    const t = this._checkDateFormat(this._input?.value);
    t ? (this._input.setCustomValidity(this._helpText), this.internals.setValidity({ customError: !0 }, this._helpText, this._input)) : (this._input.setCustomValidity(""), this.internals.setValidity({})), this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    const a = this.showTime ? 16 : 10;
    if (t === "")
      return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
    if (t.length < a)
      return this._helpText = this.errorMessageFormat, this.invalid = !0, !0;
    if (this.minDate || this.maxDate) {
      const r = this.showTime ? t.substring(0, 10) : t, n = new Date(this._convertToISO(r)), o = new Date(this._convertToISO(this.minDate)), l = new Date(this._convertToISO(this.maxDate));
      if (o && n < o)
        return this._helpText = this.errorMessageMinDate, this.invalid = !0, !0;
      if (l && n > l)
        return this._helpText = this.errorMessageMaxDate, this.invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this.invalid = !1, !1;
  }
  _convertToISO(t) {
    const [a, r, n] = t.split("/");
    return `${n}-${r}-${a}`;
  }
  _dispatchOnValidate(t) {
    const a = {
      detail: {
        date: this._input?.value,
        invalid: t,
        status: this.invalid ? "INVALID" : "VALID"
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("value-changed", a));
  }
  // Datepicker specific methods
  _formatDate(t) {
    let a = t.substring(0, 2), r = t.substring(2, 4);
    const n = t.substring(4, 8);
    let o = t.substring(8, 10), l = t.substring(10, 12);
    Number(a) > 3 && (a = a?.padStart(2, "0")), Number(r) > 1 && (r = r?.padStart(2, "0")), Number(a) > 31 && (a = "31"), Number(r) > 12 && (r = "12"), r === "02" && Number(a) > 28 && n?.length === 4 && (a = new Date(Number(n), 1, 29).getMonth() === 1 ? "29" : "28");
    let p = `${a}${r ? `/${r}` : ""}${n ? `/${n}` : ""}`;
    return this.showTime && (Number(o) > 2 && (o = o?.padStart(2, "0")), Number(o) > 23 && (o = "23"), Number(l) > 5 && (l = l?.padStart(2, "0")), p = `${p}${o ? ` ${o}` : ""}${l ? `:${l}` : ""}`), p;
  }
  _onDateChange(t) {
    const a = t.detail;
    this._input && (this._input.value = a, this.value = a, this._handleValidity()), this._closeCalendar(), this._dispatchValueChange();
  }
  _onCancel() {
    this._closeCalendar(), this._input && (this._input.value = this._previousDate || "", this._handleValidity()), this.requestUpdate();
  }
  _dispatchValueChange() {
    this._emitInput(), this._emitChange();
  }
  _clearDate() {
    this._input && (this._input.value = "", this._input.setCustomValidity(""), this.internals.setValidity({}), this.value = "", this._handleValidity(), this._helpText = this._helpTextBackup, this.invalid = this._input ? !this._input.checkValidity() : !1, this._dispatchValueChange(), this.requestUpdate());
  }
  _closeCalendar() {
    this._removeCalendarListener(), this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this.showCalendar = !1, this._input?.blur(), this.validate && this._validateDate(), setTimeout(() => {
      this._enableAnimations();
    }, 400), this._checkInputOverflow(), this.requestUpdate();
  }
  _checkClickOutside(t) {
    const a = t.composedPath(), r = `${this._getEffectiveId()}-calendar`, n = this._portalManager?.querySelector(`.${r}`);
    !a.includes(this) && !a.includes(n) && this.showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const a = t.relatedTarget, r = this._getPortalCalendar();
    a !== null && a !== this && a !== this._input && a !== this._label && a !== this._calendar && a !== r && this.showCalendar && this._closeCalendar();
  }
  _getPortalCalendar() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-calendar`);
  }
  _enableAnimations() {
    this._calendar.classList.add("animation-enabled");
  }
  _disableAnimations() {
    setTimeout(() => {
      this._getPortalCalendar()?.classList.remove("animation-enabled");
    }, 240);
  }
};
m.formAssociated = !0;
let e = m;
i([
  _("input.dss-input")
], e.prototype, "_input");
i([
  _("label.dss-label")
], e.prototype, "_label");
i([
  s({ type: String })
], e.prototype, "label");
i([
  s(h)
], e.prototype, "hideLabel");
i([
  s({ type: String })
], e.prototype, "name");
i([
  s({ type: String })
], e.prototype, "id");
i([
  s({ type: String })
], e.prototype, "type");
i([
  s({ type: String })
], e.prototype, "placeholder");
i([
  s({ type: String })
], e.prototype, "value");
i([
  s({ converter: u, reflect: !0 })
], e.prototype, "disabled");
i([
  s({ converter: u, reflect: !0 })
], e.prototype, "readonly");
i([
  s({ converter: u, reflect: !0 })
], e.prototype, "required");
i([
  s({ converter: u, reflect: !0 })
], e.prototype, "invalid");
i([
  s({ type: Number })
], e.prototype, "step");
i([
  s({ type: Number })
], e.prototype, "min");
i([
  s({ type: Number })
], e.prototype, "max");
i([
  s({ type: Number })
], e.prototype, "minLength");
i([
  s({ type: String })
], e.prototype, "pattern");
i([
  s({ type: String })
], e.prototype, "inputmode");
i([
  s({ type: String })
], e.prototype, "autocapitalize");
i([
  s({ type: String })
], e.prototype, "autocomplete");
i([
  s(h)
], e.prototype, "autocorrect");
i([
  s(h)
], e.prototype, "autofocus");
i([
  s(h)
], e.prototype, "spellcheck");
i([
  s({ type: String })
], e.prototype, "size");
i([
  s({ type: String })
], e.prototype, "icon");
i([
  s({ type: String })
], e.prototype, "helpText");
i([
  s(h)
], e.prototype, "showCalendar");
i([
  s(h)
], e.prototype, "showTime");
i([
  s(h)
], e.prototype, "showButtons");
i([
  s({ type: String })
], e.prototype, "leftLabel");
i([
  s({ type: String })
], e.prototype, "rightLabel");
i([
  s({ type: String })
], e.prototype, "minDate");
i([
  s({ type: String })
], e.prototype, "maxDate");
i([
  s({ type: String })
], e.prototype, "timepicker");
i([
  s({ type: String })
], e.prototype, "timepickerLabel");
i([
  s({ type: Number })
], e.prototype, "minHour");
i([
  s({ type: Number })
], e.prototype, "maxHour");
i([
  s({ type: Number })
], e.prototype, "minutesRange");
i([
  s({ type: Array })
], e.prototype, "customCalendar");
i([
  s({ type: Array })
], e.prototype, "customTimeListOptions");
i([
  s(h)
], e.prototype, "validate");
i([
  s(h)
], e.prototype, "errorMessageFormat");
i([
  s(h)
], e.prototype, "errorMessageMinDate");
i([
  s(h)
], e.prototype, "errorMessageMaxDate");
i([
  d()
], e.prototype, "_isFocused");
i([
  d()
], e.prototype, "_isTruncated");
i([
  d()
], e.prototype, "_helpText");
i([
  _(".dss-calendar")
], e.prototype, "_calendar");
i([
  d()
], e.prototype, "_backFromCalendar");
export {
  e as Datepicker
};
//# sourceMappingURL=datepicker.js.map
