const a = ".dss-datepicker-help{font-family:var(--font-family)}.dss-datepicker-help{font-family:inherit;font-size:12px;color:var(--color-neutral-700);padding:var(--dss-spacing-xxs) var(--dss-spacing-sm)}.dss-datepicker-help--disabled{color:var(--color-neutral-500)}.dss-datepicker-help--invalid{color:var(--color-red-500)}";
export {
  a as default
};
//# sourceMappingURL=datepicker.style.css.js.map
