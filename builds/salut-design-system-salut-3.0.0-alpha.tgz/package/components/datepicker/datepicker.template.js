import { nothing as s } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
import { unsafeStatic as e, literal as d, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const u = d`dss-icon${e(r())}`, $ = d`dss-icon-button${e(r())}`, t = d`dss-tooltip${e(r())}`, b = d`dss-calendar${e(r())}`, _ = (a) => i`
  <div class="${l({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": a.required,
  "dss-input-wrapper--disabled": a.disabled,
  [`dss-input-wrapper--${a.size}`]: !!a.size,
  "dss-input-wrapper--no-label": a.hideLabel
})}">
  
      ${a.size === "sm" && !a.hideLabel ? i`
        <div class="dss-wrapper-label">
          <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
        </div>
        ` : s}
  
      <div class="${l({
  "dss-input-group": !0,
  [`dss-input-group--${a.size}`]: !!a.size,
  "dss-input-group--invalid": a.invalid || !a._inputValidity,
  "dss-input-group--required": a.required,
  "dss-input-group--disabled": a.disabled,
  "dss-input-group--focused": a.value || a._input?.value || a.placeholder || a._isFocused,
  "dss-input-group--read-only": a.readonly,
  "dss-input-group--no-label": a.hideLabel,
  "dss-input-group--read-only-empty": a.readonly && a.placeholder === "" && !a.value
})}"
        role="combobox"
        aria-controls="datepicker-calendar"
        aria-expanded=${a.showCalendar ? "true" : "false"}
        aria-haspopup="dialog"
        aria-owns="datepicker-calendar"
      >
  
        ${a.icon ? i`
          <${u} icon="${a.icon}" class="dss-input-icon"></${u}>
          ` : s}
  
        <div class="dss-input-field">
        
          ${a.size !== "sm" && !a.hideLabel ? i`
            <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
            ` : s}
  
          <input
            class="dss-input"
            id=${a._getEffectiveId()}
            .type=${a.type}
            .name="${a.name ?? s}"
            .placeholder=${a.placeholder}
            .value=${a.value}
            ?disabled=${a.disabled}
            ?readonly=${a.readonly}
            ?required=${a.required}
            ?autofocus=${a.autofocus}
            spellcheck=${a.spellcheck ? "true" : "false"}
            autocorrect=${a.autocorrect ? "on" : "off"}
            autocomplete=${a.autocomplete}
            autocapitalize=${a.autocapitalize}
            pattern=${a.pattern ?? s}
            inputmode=${a.inputmode ?? s}
            aria-label="${a.hideLabel ? a.label : s}"
            @input=${a._handleInput}
            @focusin=${a._handleFocusin}
            @keydown=${a._handleKeydown}
          />

          ${!a.showCalendar && a._isTruncated ? i`
              <${t} aria-hidden="true">${a._input?.value}</${t}>
            ` : s}
  
        </div>

        <${$}
          hideTooltip
          label="Netejar"
          size="md"
          icon="close"
          @onClick=${a._clearDate}
          ?hidden=${!a._input?.value || a.readonly || a.disabled}
        ></${$}>

        <${b}
          role="listbox"
          aria-label="Datepicker Calendar"
          id="datepicker-calendar"
          class="${l({
  [`dss-calendar ${a._getEffectiveId()}-calendar`]: !0,
  // 'dss-calendar--visible': component.showCalendar && !component.readonly,
  // 'dss-calendar--disabled': component.disabled,
  "dss-calendar--md": a.size !== "lg"
})}"
          .open=${a.showCalendar && !a.readonly}
          ?disabled=${a.disabled}
          .selectedDate=${a._input?.value}
          .showTime=${a.showTime}
          .showButtons=${a.showButtons}
          .leftLabel=${a.leftLabel}
          .rightLabel=${a.rightLabel}
          .minDate=${a.minDate}
          .maxDate=${a.maxDate}
          timepickerLabel=${a.timepickerLabel}
          .timepicker=${a.timepicker}
          .customCalendar=${a.customCalendar}
          .customTimeListOptions=${a.customTimeListOptions}
          .minutesRange=${a.minutesRange}
          .minHour=${a.minHour}
          .maxHour=${a.maxHour}
          @onDateChange=${a._onDateChange}
          @onCancel=${a._onCancel}
          @calendar-focusout=${a._handleCalendarFocusOut}
        ></${b}>
  
      </div>
      
      ${a._helpText ? i`
        <div class="${l({
  "dss-input-help": !0,
  "dss-input-help--invalid": a.invalid,
  "dss-input-help--disabled": a.disabled
})}">
          <span>${a._helpText}</span>
        </div>
        ` : s}

      
    </div> 


  
`;
export {
  _ as template
};
//# sourceMappingURL=datepicker.template.js.map
