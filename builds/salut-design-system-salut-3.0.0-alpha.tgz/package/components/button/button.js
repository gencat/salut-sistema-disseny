import { LitElement as y, unsafeCSS as h } from "lit";
import { property as i, state as u } from "lit/decorators.js";
import c from "../../shared/reset.style.css.js";
import { booleanType as s } from "../../utils/property-types.js";
import f from "./button.style.css.js";
import { template as m } from "./button.template.js";
var g = Object.defineProperty, t = (n, r, p, l) => {
  for (var o = void 0, a = n.length - 1, d; a >= 0; a--)
    (d = n[a]) && (o = d(r, p, o) || o);
  return o && g(r, p, o), o;
};
class e extends y {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.label = "", this.icon = void 0, this.iconPosition = "left", this.disabled = !1, this.hidden = !1, this.onlyIcon = !1, this.fullWidth = !1, this.size = "md", this.loading = !1, this.loadingIcon = "progress_activity", this._isTextTruncated = !1;
  }
  static get styles() {
    return [h(c), h(f)];
  }
  _handleClick() {
    if (this.disabled || this.loading) return;
    const r = this.closest("form");
    this.type === "submit" && r ? r.requestSubmit() : this.type === "reset" && r && r.reset(), this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  checkTextTruncate(r) {
    if (!r) return;
    if (this.onlyIcon) {
      this._isTextTruncated = !0;
      return;
    }
    const l = r.target.querySelector(".dss-button-text");
    this._isTextTruncated = l.scrollWidth > l.offsetWidth;
  }
  render() {
    return m(this);
  }
}
t([
  i({ type: String })
], e.prototype, "type");
t([
  i({ type: String })
], e.prototype, "variant");
t([
  i({ type: String })
], e.prototype, "label");
t([
  i({ type: String })
], e.prototype, "icon");
t([
  i({ type: String })
], e.prototype, "iconPosition");
t([
  i(s)
], e.prototype, "disabled");
t([
  i(s)
], e.prototype, "hidden");
t([
  i(s)
], e.prototype, "onlyIcon");
t([
  i(s)
], e.prototype, "fullWidth");
t([
  i({ type: String })
], e.prototype, "size");
t([
  i(s)
], e.prototype, "loading");
t([
  u()
], e.prototype, "_isTextTruncated");
export {
  e as Button
};
//# sourceMappingURL=button.js.map
