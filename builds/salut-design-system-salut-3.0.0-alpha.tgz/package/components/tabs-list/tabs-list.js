import { LitElement as _, unsafeCSS as u } from "lit";
import { property as r, state as f } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import g from "../../shared/reset.style.css.js";
import T from "../../shared/scrollbar.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import v from "./tabs-list.style.css.js";
import { tabsListTemplate as E } from "./tabs-list.template.js";
var y = Object.defineProperty, w = Object.getOwnPropertyDescriptor, i = (b, t, e, s) => {
  for (var a = s > 1 ? void 0 : s ? w(t, e) : t, l = b.length - 1, n; l >= 0; l--)
    (n = b[l]) && (a = (s ? n(t, e, a) : n(a)) || a);
  return s && a && y(t, e, a), a;
};
class o extends _ {
  constructor() {
    super(), this.canOrder = !1, this.canEdit = !1, this.canDelete = !1, this.fullHeight = !1, this._isEditing = !1, this._focusedIndex = null, this._dssTabsId = "", this._label = "Tabs component name", this._tabs = [], this._tabsElements = window.document.querySelectorAll("[role='tab']"), this._firstTab = document.createElement("div"), this._lastTab = document.createElement("div"), this._addTabEnabled = !1, this._addTabText = "Afegir Tab", this._ignoreInputFocusout = !1, this.draggedIndex = null, this._lastOverEl = null, this._handleUpdateArrowsBound = this._updateArrows.bind(this);
  }
  static get styles() {
    return [u(g), u(T), u(m), u(v)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleUpdateArrowsBound);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._menu?.removeEventListener("scroll", this._handleUpdateArrowsBound), window.removeEventListener("resize", this._handleUpdateArrowsBound);
  }
  set dssTabsId(t) {
    const e = this._dssTabsId;
    this._dssTabsId = t, this.requestUpdate("dssTabsId", e);
  }
  get dssTabsId() {
    return this._dssTabsId;
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set tabs(t) {
    const e = this._tabs;
    this._tabs = t, this.requestUpdate("tabs", e);
  }
  get tabs() {
    return this._tabs;
  }
  set addTabText(t) {
    const e = this._addTabText;
    this._addTabText = t, this.requestUpdate("addTabText", e);
  }
  get addTabText() {
    return this._addTabText;
  }
  set addTabEnabled(t) {
    const e = this._addTabEnabled;
    this._addTabEnabled = t, this.requestUpdate("addTabEnabled", e);
  }
  get addTabEnabled() {
    return this._addTabEnabled;
  }
  // menuContainer
  get _wrapper() {
    return this.shadowRoot?.querySelector(".dss-tabs") || void 0;
  }
  get _header() {
    return this.shadowRoot?.querySelector(".dss-tabs-header") || void 0;
  }
  // menu
  get _menu() {
    return this.shadowRoot?.querySelector(".dss-tabs-menu") || void 0;
  }
  // leftArrow
  get _prevScroll() {
    return this.shadowRoot?.querySelector(".dss-tabs-scroll-button--prev") || void 0;
  }
  // rightArrow
  get _nextScroll() {
    return this.shadowRoot?.querySelector(".dss-tabs-scroll-button--next") || void 0;
  }
  updated(t) {
    t.has("tabs") && this.changeTabWatch(), t.has("fullHeight") && (this.fullHeight ? (this.classList.add("full-height"), this._wrapper?.classList.add("dss-tabs--full-height")) : (this.classList.remove("full-height"), this._wrapper?.classList.remove("dss-tabs--full-height")));
  }
  async changeTabWatch() {
    this._tabsElements = this.renderRoot.querySelectorAll("[role='tab']"), this._tabsElements.forEach((t) => {
      t.addEventListener("keydown", (e) => {
        this._handleKeydown(e);
      }), t.addEventListener("mousedown", (e) => {
        this.setSelectedTab(e.currentTarget);
      });
    }), this.setFirstAndLastTabs();
  }
  setFirstAndLastTabs() {
    let t = !1;
    this._tabsElements.forEach((e) => {
      t || (this._firstTab = e, t = !0), this._lastTab = e;
    });
  }
  changeTab(t) {
    const e = {
      detail: { selectedPanel: t.panel },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("change", e)), this.updateTabs(t.id), this.updatePanels(t.panel);
  }
  updateTabs(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t ? { ...e, selected: !0 } : { ...e, selected: !1 }
    );
  }
  updatePanels(t) {
    window.document.querySelectorAll("dss-tabs-panel").forEach((s) => {
      const a = s.getAttribute("panelId");
      s.getAttribute("linkedTo") === this._dssTabsId && (a === t ? s.setAttribute("selected", "true") : s.removeAttribute("selected"));
    });
  }
  _handleKeydown(t) {
    const e = t, s = t.currentTarget;
    let a = !1;
    switch (e.key) {
      case "ArrowLeft":
        this.moveFocusToPreviousTab(s), a = !0;
        break;
      case "ArrowRight":
        this.moveFocusToNextTab(s), a = !0;
        break;
      case "Home":
        this.moveFocusToTab(this._firstTab), a = !0;
        break;
      case "End":
        this.moveFocusToTab(this._lastTab), a = !0;
        break;
    }
    a && (t.stopPropagation(), t.preventDefault());
  }
  moveFocusToTab(t) {
    t && t.focus();
  }
  moveFocusToPreviousTab(t) {
    let e = 0;
    t === this._firstTab ? this.moveFocusToTab(this._lastTab) : (this._tabsElements.forEach((s, a) => {
      s === t && (e = a);
    }), this.moveFocusToTab(this._tabsElements[e - 1]));
  }
  moveFocusToNextTab(t) {
    let e = 0;
    t === this._lastTab ? this.moveFocusToTab(this._firstTab) : (this._tabsElements.forEach((s, a) => {
      s === t && (e = a);
    }), this.moveFocusToTab(this._tabsElements[e + 1]));
  }
  setSelectedTab(t) {
    for (let e = 0; e < this._tabsElements.length; e += 1) {
      const s = this._tabsElements[e];
      t === s ? (s.setAttribute("aria-selected", "true"), s.removeAttribute("tabindex"), s.classList.add("dss-tabs-item--selected"), this._centerTabIntoScroll(s)) : (s.setAttribute("aria-selected", "false"), s.setAttribute("tabindex", "-1"), s.classList.remove("dss-tabs-item--selected"));
    }
  }
  selectTab(t) {
    const e = this.renderRoot.querySelector(`[role='tab'][id='${t}']`);
    e && this.setSelectedTab(e);
  }
  _centerTabIntoScroll(t) {
    if (!t || !this._menu) return;
    const e = t.getBoundingClientRect(), s = this._menu.getBoundingClientRect(), a = e.left + e.width / 2, l = s.left + s.width / 2, n = a - l;
    this._menu.scrollBy({ left: n, behavior: "smooth" });
  }
  addNewTab() {
    const t = {
      detail: {},
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("add-tab", t));
  }
  // Scroll behavior
  _updateArrows() {
    if (this._menu && this._prevScroll && this._nextScroll) {
      const t = Math.ceil(this._menu.scrollLeft), e = Math.ceil(this._menu.scrollWidth - this._menu.clientWidth);
      this._prevScroll.style.display = t > 0 ? "block" : "none", this._nextScroll.style.display = t < e ? "block" : "none";
    }
  }
  _scrollMenu(t) {
    this._menu && this._menu.scrollBy({
      left: t * 160,
      behavior: "smooth"
    });
  }
  async firstUpdated() {
    await this.updateComplete, this._menu && this._menu.addEventListener("scroll", this._handleUpdateArrowsBound), this._updateArrows();
  }
  render() {
    return E(this);
  }
  /* Edit and Delete handlers */
  _handleEdit(t) {
    this.tabs = this.tabs.map(
      (e) => e.id === t.id ? { ...e, isEditing: !0 } : { ...e, isEditing: !1 }
    ), setTimeout(() => {
      this._ignoreInputFocusout = !1;
      const e = this.shadowRoot?.querySelector(`#${t.id}-edit`);
      e.focus();
      const s = e.value.length;
      e.setSelectionRange(s, s);
    }, 50);
  }
  _handleDelete(t) {
    const e = {
      detail: { tab: t },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("delete", e));
  }
  _closeInputEdit(t) {
    this.tabs = this.tabs.map((e) => e.id === t.id ? { ...e, isEditing: !1 } : e);
  }
  _handleEditSave(t) {
    this._ignoreInputFocusout = !0;
    const e = (this.shadowRoot?.querySelector(`#${t.id}-edit`)).value;
    this._closeInputEdit(t), e && e.trim() !== "" && e !== t.text && (this.tabs = this.tabs.map((s) => s.id === t.id ? { ...s, text: e } : s), this._dispatchEditTabs());
  }
  _handleEditCancel(t, e) {
    t.preventDefault(), t.stopPropagation(), this._ignoreInputFocusout = !0, this._closeInputEdit(e);
  }
  _handleInputFocusout(t, e) {
    if (this._ignoreInputFocusout) {
      this._ignoreInputFocusout = !1;
      return;
    }
    const s = t.relatedTarget;
    s?.classList.contains("save-edit") || s?.classList.contains("cancel-edit") || this._handleEditSave(e);
  }
  _handleEditCancelFocusout(t, e) {
    const s = t.relatedTarget;
    if (s?.classList.contains("save-edit") || s?.classList.contains("cancel-edit")) return;
    const a = t.currentTarget?.closest(".dss-tabs-item");
    (!s || !a?.contains(s)) && this._handleEditSave(e);
  }
  _handleEditCancelKeydown(t, e) {
    t.key === "Enter" && this._handleEditCancel(t, e);
  }
  _handleEditKeydown(t, e) {
    (t.key === "Enter" || t.key === "Escape") && this._handleEditSave(e);
  }
  _dispatchEditTabs() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("edit", t));
  }
  onDragStart(t, e) {
    this.draggedIndex = e, t.currentTarget.classList.add("dragging");
    try {
      t.dataTransfer?.setData("text/plain", "");
    } catch {
    }
    t.dataTransfer && (t.dataTransfer.effectAllowed = "move", t.dataTransfer.dropEffect = "move");
  }
  onDragEnd(t) {
    t.currentTarget.classList.remove("dragging"), this._lastOverEl && (this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = null), this.draggedIndex = null;
  }
  onDragOver(t) {
    t.preventDefault();
    const e = t.currentTarget;
    this._lastOverEl && this._lastOverEl !== e && this._lastOverEl.classList.remove("over-left", "over-right"), this._lastOverEl = e;
    const s = e.getBoundingClientRect(), a = s.left + s.width / 2, l = (t.clientX ?? 0) < a;
    e.classList.toggle("over-left", l), e.classList.toggle("over-right", !l), t.dataTransfer && (t.dataTransfer.dropEffect = "move");
  }
  onDragLeave(t) {
    const e = t.currentTarget;
    e.classList.remove("over-left", "over-right"), this._lastOverEl === e && (this._lastOverEl = null);
  }
  onDrop(t, e) {
    t.preventDefault();
    const s = t.currentTarget;
    if (s.classList.remove("over-left", "over-right"), this._lastOverEl === s && (this._lastOverEl = null), this.draggedIndex === null) return;
    const a = s.getBoundingClientRect(), l = a.left + a.width / 2, n = (t.clientX ?? 0) >= l;
    let d = e + (n ? 1 : 0);
    const h = [...this.tabs], [p] = h.splice(this.draggedIndex, 1);
    this.draggedIndex < d && d--, d < 0 && (d = 0), d > h.length && (d = h.length), h.splice(d, 0, p), this.tabs = h, this.draggedIndex = null, this.dispatchOrder();
  }
  dispatchOrder() {
    const t = {
      detail: { tabs: this.tabs },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("order", t));
  }
  onItemFocus(t) {
    this.shadowRoot?.activeElement?.matches(":focus-visible") && (this._focusedIndex = t);
  }
  onItemBlur(t) {
    this._focusedIndex === t && (this._focusedIndex = null);
  }
}
i([
  r({ type: String })
], o.prototype, "dssTabsId", 1);
i([
  r({ type: String })
], o.prototype, "label", 1);
i([
  r({ type: Array })
], o.prototype, "tabs", 1);
i([
  r({ type: String })
], o.prototype, "addTabText", 1);
i([
  r(c)
], o.prototype, "addTabEnabled", 1);
i([
  r(c)
], o.prototype, "canOrder", 2);
i([
  r(c)
], o.prototype, "canEdit", 2);
i([
  r(c)
], o.prototype, "canDelete", 2);
i([
  r(c)
], o.prototype, "fullHeight", 2);
i([
  f()
], o.prototype, "_isEditing", 2);
i([
  f()
], o.prototype, "_focusedIndex", 2);
i([
  f()
], o.prototype, "draggedIndex", 2);
export {
  o as TabsList
};
//# sourceMappingURL=tabs-list.js.map
