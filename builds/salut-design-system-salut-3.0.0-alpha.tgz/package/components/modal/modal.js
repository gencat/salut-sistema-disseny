import { LitElement as p, unsafeCSS as h } from "lit";
import { property as s } from "lit/decorators.js";
import m from "../../foundations/icon/icon.style.css.js";
import _ from "../../shared/scrollbar.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import u from "../button/button.style.css.js";
import y from "../icon-button/icon-button.style.css.js";
import f from "./modal.style.css.js";
import { modalTemplate as g } from "./modal.template.js";
var S = Object.defineProperty, w = Object.getOwnPropertyDescriptor, o = (n, e, t, l) => {
  for (var a = l > 1 ? void 0 : l ? w(e, t) : e, r = n.length - 1, c; r >= 0; r--)
    (c = n[r]) && (a = (l ? c(e, t, a) : c(a)) || a);
  return l && a && S(e, t, a), a;
};
const v = 250;
class i extends p {
  constructor() {
    super(), this.fullHeight = !1, this.fullWidth = !1, this.flexBody = !1, this.removeBodyPadding = !1, this.jcef = !1, this._open = !1, this._modalTitle = "Title", this._state = "", this._hideCloseIcon = !1, this._hasScroll = !1, this._modalStyle = void 0, this._modalHeader = null, this._modalFooter = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [
      h(m),
      h(_),
      h(u),
      h(y),
      h(f)
    ];
  }
  set open(e) {
    const t = this._open;
    this._open = e, this.requestUpdate("open", t);
  }
  get open() {
    return this._open;
  }
  set modalTitle(e) {
    const t = this._modalTitle;
    this._modalTitle = e, this.requestUpdate("modalTitle", t);
  }
  get modalTitle() {
    return this._modalTitle;
  }
  set state(e) {
    const t = this._state;
    this._state = e, this.requestUpdate("state", t);
  }
  get state() {
    return this._state;
  }
  set hideCloseIcon(e) {
    const t = this._hideCloseIcon;
    this._hideCloseIcon = e, this.requestUpdate("hideCloseIcon", t);
  }
  get hideCloseIcon() {
    return this._hideCloseIcon;
  }
  set hasScroll(e) {
    const t = this._hasScroll;
    this._hasScroll = e, this.requestUpdate("hasScroll", t);
  }
  get hasScroll() {
    return this._hasScroll;
  }
  set modalStyle(e) {
    const t = this._modalStyle;
    this._modalStyle = e, this.requestUpdate("modalStyle", t);
  }
  get modalStyle() {
    return this._modalStyle || "";
  }
  get _headerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="header"]') || void 0)?.assignedElements()[0];
  }
  get _footerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="footer"]') || void 0)?.assignedElements()[0];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  updated(e) {
    e.has("open") && (this._open ? this._showDialog() : this._hideDialog());
  }
  _showDialog() {
    this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), document.addEventListener("keydown", this._handleKeydown), document.body.style.overflow = "hidden";
  }
  _hideDialog() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      this.classList.remove("hide"), this.style.visibility = "hidden", document.removeEventListener("keydown", this._handleKeydown);
    }, v), document.body.style.overflow = "";
  }
  _close() {
    this.open = !1, this._hideDialog(), this.requestUpdate();
    const e = new Event("close");
    this.dispatchEvent(e);
  }
  _isStateValid() {
    return this._state === "danger" || this._state === "error" || this._state === "warning" || this._state === "alert";
  }
  _getStateIcon() {
    let e = "";
    switch (this._state) {
      case "danger":
        e = "warning";
        break;
      case "error":
        e = "warning";
        break;
      case "warning":
        e = "error";
        break;
      case "alert":
        e = "error";
        break;
      default:
        e = "";
    }
    return e;
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._close();
  }
  _handleOutsideClick(e) {
    if (this._open) {
      const t = this.shadowRoot?.querySelector(".dss-dialog"), l = e.composedPath();
      t && l.includes(this) && !l.includes(t) && this._close();
    }
  }
  fixEmptyFooter() {
    this.shadowRoot?.querySelector(".dss-dialog")?.classList.contains("dss-dialog--footer-empty") && this.requestUpdate();
  }
  _handleScroll(e) {
    const t = e.target;
    t && (t.scrollTop > 0 ? this._modalHeader?.classList.add("dss-dialog-header--scrolled") : this._modalHeader?.classList.remove("dss-dialog-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? this._modalFooter?.classList.add("dss-dialog-footer--scrolled") : this._modalFooter?.classList.remove("dss-dialog-footer--scrolled"));
  }
  async firstUpdated() {
    await this.updateComplete, this._footerSlot && this.fixEmptyFooter();
    const e = this.shadowRoot?.querySelector(".dss-dialog-body");
    if (this._hasScroll && e) {
      e.addEventListener("scroll", this._handleScroll.bind(this)), this._modalHeader = this.shadowRoot?.querySelector(".dss-dialog-header"), this._modalFooter = this.shadowRoot?.querySelector(".dss-dialog-footer");
      const t = this._modalHeader ? this._modalHeader.clientHeight : 0, l = this._modalFooter ? this._modalFooter.clientHeight : 0, r = (this.shadowRoot?.querySelector(".dss-dialog")?.clientHeight || 0) - t - l;
      e.scrollHeight > r && this._modalFooter.classList.add("dss-dialog-footer--scrolled");
    }
  }
  render() {
    return g(this);
  }
}
o([
  s(d)
], i.prototype, "open", 1);
o([
  s({ type: String })
], i.prototype, "modalTitle", 1);
o([
  s({ type: String })
], i.prototype, "state", 1);
o([
  s(d)
], i.prototype, "hideCloseIcon", 1);
o([
  s(d)
], i.prototype, "hasScroll", 1);
o([
  s({ type: String })
], i.prototype, "modalStyle", 1);
o([
  s(d)
], i.prototype, "fullHeight", 2);
o([
  s(d)
], i.prototype, "fullWidth", 2);
o([
  s(d)
], i.prototype, "flexBody", 2);
o([
  s(d)
], i.prototype, "removeBodyPadding", 2);
o([
  s(d)
], i.prototype, "jcef", 2);
export {
  i as Modal
};
//# sourceMappingURL=modal.js.map
