import { unsafeStatic as l, literal as a, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { classMap as x } from "lit/directives/class-map.js";
import { ifDefined as d } from "lit/directives/if-defined.js";
const $ = a`dss-badge${l(o())}`, g = a`dss-icon-badge${l(o())}`, c = a`dss-tooltip${l(o())}`, r = a`dss-chip${l(o())}`, h = a`dss-icon${l(o())}`, p = a`dss-icon-button${l(o())}`, v = a`dss-decorative-icon${l(o())}`, T = (t) => e`
  <div
    class=${x({
  "dss-item-list": !0,
  "dss-item-list--widget": t.widget,
  "dss-item-list--slotted": t.items === void 0
})}
  >
    ${t.items ? f(t) : e`<slot/>`}
  </div>
`, f = (t) => t.items?.map((i) => {
  const u = (s) => {
    const n = s.target, b = n.scrollWidth > n.offsetWidth;
    n.setAttribute("data-truncated", b.toString());
  };
  return e`
      <div class="dss-item-list__item">
        ${t.widget && i.iconBadgeLeftState ? e`
              <div class="item-widget-badge">
                <${g} size="sm"
                  state="${d(i.iconBadgeLeftState)}"
                  icon="${d(i.iconBadgeLeftIcon)}"
                  aria-label="${i.iconBadgeLabel}"
                > 
                  ${i.iconBadgeLabel ? e`
                    <${c} 
                      slot="tooltip" 
                      aria-hidden="true" 
                      ?tooltipFixed="${t.tooltipFixed}"
                      ?forceViewport="${t.forceViewport}"
                      >
                      ${i.iconBadgeLabel}
                      </${c}>` : null}
                </${g}>  
              </div>
            ` : null}

        <div class="item-details">
          ${t.widget && i.date ? e`
                <div class="item-details__date">
                  <span>${i.date}</span>
                </div>
              ` : null}
          <div class="item-details__title">
            ${i.decorativeIcon ? e`
                  <${v} icon=${i.decorativeIcon} size="sm" state=${d(i.decorativeIconType)}
                  >
                  </${v}>
                ` : null}
            <div class="item-details__title-text" @mouseenter=${u}>
              ${i.title}
              <${c} 
                ?forceViewport="${t.forceViewport}"
                ?tooltipFixed="${t.tooltipFixed}" 
                class="title-tooltip" 
                slot="tooltip" 
                aria-hidden="true"
                >${i.title}</${c}>
            </div>
          </div>
          <div class="item-details__subtitle" @mouseenter=${u}>
            ${i.subtitle}
            <${c} 
              ?forceViewport="${t.forceViewport}"
              ?tooltipFixed="${t.tooltipFixed}" 
              class="title-tooltip" 
              slot="tooltip" 
              aria-hidden="true"
              >${i.subtitle}</${c}>
          </div>
        </div>

        ${i.id ? e`
          <slot name="item-custom-${i.id}"></slot>
        ` : e`
          ${i.badgeText && !t.widget ? i.badgeIcon ? e`
                  <div class="item-action">
                    <${$}
                      text="${i.badgeText}"
                      icon="${i.badgeIcon}"
                      size="${i.badgeSize ? i.badgeSize : "sm"}"
                      state="${i.badgeState ? i.badgeState : "undeterminated"}"
                    >
                    </${$}>
                  </div>
                ` : e`
                  <div class="item-action">
                    <${$}
                      text="${i.badgeText}"
                      size="${i.badgeSize ? i.badgeSize : "sm"}"
                      state="${i.badgeState ? i.badgeState : "undeterminated"}"
                    >
                    </${$}>
                  </div>
                ` : null}
          
          ${i.chipText && !t.widget ? e`
                
                <${r} 
                  size="${i.chipSize ? i.chipSize : "xs"}" 
                  icon=${d(i.chipIcon)}
                  label="${i.chipText}" 
                  disableSelect
                  ?selected=${i.chipSelected}
                  @click=${() => t._dispatchItemChip(i)}></${r}>
              
              ` : null}

          ${i.actionIcon && !t.widget ? e`
                <div class="item-action">
                  <${p} 
                    size="md" 
                    icon=${i.actionIcon} 
                    label="${i.actionLabel}" 
                    variant=${i.actionIconType ? i.actionIconType : "primary"} 
                    ?tooltipFixed=${t.tooltipFixed}
                    ?forceViewport="${t.forceViewport}"
                    tooltipPosition="${t.tooltipPosition}"
                    @click=${() => t._dispatchItemAction(i)}>
                  </${p}>
                </div>
              ` : null}
          ${t.widget ? e`
                <div class="item-widget">
                  ${i.description ? e`
                        <div class="item-widget-description">
                          ${i.description}
                        </div>
                      ` : null}
                  ${i.icons?.length ? e`
                        ${i.icons.map(
    (s) => e`
                            <${h} size="md" icon="${s.icon}"></${h}>
                          `
  )}
                      ` : null}
                  ${i.iconBadgeRightState ? e`
                        <${g}
                          size="sm"
                          state="${d(i.iconBadgeRightState)}"
                          icon="${d(i.iconBadgeRightIcon)}"
                        />
                      ` : null}
                  ${i.chipText ? e`
                        <${r} 
                          size="${i.chipSize ? i.chipSize : "xs"}" 
                          icon=${d(i.chipIcon)}
                          label="${i.chipText}" 
                          disableSelect
                          ?selected=${i.chipSelected}
                          @click=${() => t._dispatchItemChip(i)}></${r}>
                      ` : null}
                  ${i.actions?.length ? e`
                        ${i.actions.map(
    (s) => e`
                            <${p}
                              label="${s.label}"
                              icon="${s.icon}"
                              variant="${s.type}"
                              ?tooltipFixed=${t.tooltipFixed}
                              ?forceViewport="${t.forceViewport}"
                              tooltipPosition="${t.tooltipPosition}"
                              ?hideTooltip="${t.hideTooltip}"
                              @onClick=${() => t._dispatchWidgetAction(i, s.action)}
                            />
                          `
  )}
                      ` : null}
                </div>
              ` : null}
        `}
      </div>
    `;
});
export {
  T as itemListTemplate
};
//# sourceMappingURL=item-list.template.js.map
