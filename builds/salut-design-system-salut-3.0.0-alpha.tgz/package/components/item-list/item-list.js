import { LitElement as f, unsafeCSS as m } from "lit";
import { property as s } from "lit/decorators.js";
import { itemListTemplate as c } from "./item-list.template.js";
import u from "../../foundations/icon/icon.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import h from "../decorative-icon/decorative-icon.style.css.js";
import y from "./item-list.style.css.js";
import { getCustomElementSuffix as v } from "../../api/custom-element-scope.js";
var g = Object.defineProperty, r = (l, t, e, p) => {
  for (var o = void 0, i = l.length - 1, d; i >= 0; i--)
    (d = l[i]) && (o = d(t, e, o) || o);
  return o && g(t, e, o), o;
};
class n extends f {
  constructor() {
    super(...arguments), this.items = void 0, this.widget = !1, this.hideTooltip = !1, this.tooltipFixed = !1, this.forceViewport = !1, this.tooltipPosition = "top", this.variant = "default";
  }
  static get styles() {
    return [m(u), m(h), m(y)];
  }
  // 'checkbox' | 'radio' | 'default'
  /* METHODS */
  _dispatchItemAction(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItem", e));
  }
  _dispatchItemChip(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItemChip", e));
  }
  _dispatchWidgetAction(t, e) {
    const p = {
      detail: { item: t, action: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickWidgetAction", p));
  }
  _applyDivider() {
    if (this.items?.length) return;
    const t = this.shadowRoot?.querySelectorAll("slot");
    if (!t || t.length === 0) return;
    let e = !0;
    t.forEach((p) => {
      p.assignedElements({ flatten: !0 }).forEach((i) => {
        i instanceof HTMLElement && i.tagName.toLowerCase() === `dss-item-list-base${v()}` && (e ? (i.setAttribute("first", ""), e = !1) : i.removeAttribute("first"));
      });
    });
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    await this.updateComplete, this._applyDivider();
  }
  render() {
    return c(this);
  }
}
r([
  s({ type: Array })
], n.prototype, "items");
r([
  s(a)
], n.prototype, "widget");
r([
  s(a)
], n.prototype, "hideTooltip");
r([
  s(a)
], n.prototype, "tooltipFixed");
r([
  s(a)
], n.prototype, "forceViewport");
r([
  s({ type: String })
], n.prototype, "tooltipPosition");
r([
  s({ type: String })
], n.prototype, "variant");
export {
  n as ItemList
};
//# sourceMappingURL=item-list.js.map
