import { LitElement as y, unsafeCSS as d } from "lit";
import { query as f, property as i, state as c } from "lit/decorators.js";
import _ from "../../shared/reset.style.css.js";
import { booleanType as r, booleanConverter as l } from "../../utils/property-types.js";
import m from "./textarea.style.css.js";
import { template as g } from "./textarea.template.js";
var v = Object.defineProperty, e = (u, s, o, b) => {
  for (var a = void 0, p = u.length - 1, n; p >= 0; p--)
    (n = u[p]) && (a = n(s, o, a) || a);
  return a && v(s, o, a), a;
};
const h = class h extends y {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.rows = 1, this.wrap = "soft", this.autoHeight = !1, this.icon = void 0, this.size = "md", this.helpText = null, this._isTextareaFocused = !1, this._isGroupFocusedVisible = !1, this._lastValue = null, this._defaultId = `dss-textarea-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [d(_), d(m)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(s) {
    s.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(s) {
    this.disabled = s;
  }
  formResetCallback() {
    this.value = "", this._textarea.value = "", this._lastValue = "";
  }
  formStateRestoreCallback(s) {
    this.value = s ?? "", this._textarea.value = s ?? "", this._lastValue = s ?? "";
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.autoHeight && this._updateHeight();
    } catch (s) {
      console.error("ERROR OCURRED", s);
    }
  }
  _updateHeight() {
    this._textarea.style.height = "auto", this._textarea.style.height = `${this._textarea.scrollHeight}px`;
  }
  _handleInput(s) {
    const o = s.target;
    this.value = o.value, this._handleValidity(), this._emitInput(), this._emitChange(), this.autoHeight && this._updateHeight();
  }
  _handleValidity() {
    const s = this._textarea?.checkValidity();
    this.invalid = !s, this.internals.setValidity(this._textarea.validity, this._textarea.validationMessage, this._textarea);
  }
  _handleFocus() {
    this._isGroupFocusedVisible = !0, this._isTextareaFocused = !0;
  }
  _handleFocusOut() {
    this._isGroupFocusedVisible = !1, this._isTextareaFocused = !1;
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  render() {
    return g(this);
  }
};
h.formAssociated = !0;
let t = h;
e([
  f("textarea.dss-textarea")
], t.prototype, "_textarea");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i(r)
], t.prototype, "hideLabel");
e([
  i({ type: String })
], t.prototype, "name");
e([
  i({ type: String })
], t.prototype, "id");
e([
  i({ type: String })
], t.prototype, "placeholder");
e([
  i({ type: String })
], t.prototype, "value");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "disabled");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "readonly");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "required");
e([
  i({ converter: l, reflect: !0 })
], t.prototype, "invalid");
e([
  i({ type: Number })
], t.prototype, "minLength");
e([
  i({ type: Number })
], t.prototype, "maxLength");
e([
  i({ type: String })
], t.prototype, "inputmode");
e([
  i({ type: String })
], t.prototype, "autocapitalize");
e([
  i({ type: String })
], t.prototype, "autocomplete");
e([
  i(r)
], t.prototype, "autocorrect");
e([
  i(r)
], t.prototype, "autofocus");
e([
  i(r)
], t.prototype, "spellcheck");
e([
  i({ type: Number })
], t.prototype, "rows");
e([
  i({ type: String })
], t.prototype, "wrap");
e([
  i(r)
], t.prototype, "autoHeight");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i({ type: String })
], t.prototype, "helpText");
e([
  c()
], t.prototype, "_isTextareaFocused");
e([
  c()
], t.prototype, "_isGroupFocusedVisible");
export {
  t as Textarea
};
//# sourceMappingURL=textarea.js.map
