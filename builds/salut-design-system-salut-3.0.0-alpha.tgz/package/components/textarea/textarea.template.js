import { nothing as e } from "lit";
import { classMap as l } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as i, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const r = i`dss-icon${d(t())}`, h = (a) => s`
  <div class="dss-textarea ${l({
  "dss-textarea--invalid": a.invalid,
  "dss-textarea--auto-height": a.autoHeight,
  "dss-textarea--disabled": a.disabled,
  "dss-textarea--gap": a.maxLength || !!a.helpText || a.size !== "sm",
  "dss-textarea--gap-sm": a.size === "sm",
  "dss-textarea--required": a.required,
  "dss-textarea--empty-description": !a.maxLength && !a.helpText,
  [`dss-textarea--${a.size}`]: !!a.size
})}">

    ${a.size === "sm" ? s`
        <div class="dss-textarea-label">
          <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
        </div>
      ` : e}

    <div class="dss-textarea__group ${l({
  "dss-textarea__group--focused": a._textarea?.value || a.value || a._isTextareaFocused || a.placeholder,
  // 'dss-textarea__group--focused-visible': true,
  "dss-textarea__group--focused-visible": a._isGroupFocusedVisible,
  [`dss-textarea__group--${a.size}`]: !!a.size,
  "dss-textarea__group--has-label": !a.hideLabel && !!a.label,
  "dss-textarea__group--required": a.required,
  "dss-textarea__group--readOnly": a.readonly,
  "dss-textarea__group--read-only-empty": a.readonly && a.placeholder === "" && !a._textarea?.value
})}">

      ${a.icon ? s`
          <${r} icon="${a.icon}" class="dss-textarea-icon"></${r}>
        ` : e}

      <div class="dss-textarea__content">
        ${a.size !== "sm" ? s`
            <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
          ` : e}
        <textarea
          class="dss-textarea"
          id="${a._getEffectiveId()}"
          rows=${a.rows ?? 3}
          wrap=${a.wrap ?? "soft"}
          .placeholder=${a.placeholder}
          .value=${a.value ?? ""} 
          ?disabled=${a.disabled}
          ?readonly=${a.readonly}
          ?required=${a.required}
          ?autofocus=${a.autofocus}
          spellcheck=${a.spellcheck ? "true" : "false"}
          autocorrect=${a.autocorrect ? "on" : "off"}
          autocomplete=${a.autocomplete}
          autocapitalize=${a.autocapitalize}
          minlength=${a.minLength ?? e}
          maxlength=${a.maxLength ?? e}
          inputmode=${a.inputmode ?? e}
          aria-label="${a.hideLabel ? a.label : e}"
          @input=${a._handleInput}
          @focusin=${a._handleFocus}
          @focusout=${a._handleFocusOut}
        ></textarea>
      </div>

    </div>

    ${a.helpText || a.maxLength ? s`
      <div class="dss-textarea__help">
        <div class="dss-textarea__description">
          ${a.helpText}
        </div>
        ${a.maxLength ? s`
            <span>${a._textarea?.value?.length ?? 0}/${a.maxLength}</span>` : e}
      </div>
      ` : e}
  </div>
`;
export {
  h as template
};
//# sourceMappingURL=textarea.template.js.map
