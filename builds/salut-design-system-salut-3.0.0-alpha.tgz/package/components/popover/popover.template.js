import { nothing as r } from "lit";
import { classMap as i } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as d, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const o = d`dss-icon-button${a(l())}`, $ = (s) => e`
  <div
    class=${i({
  "dss-popover": !0,
  "dss-popover--filter": s.variant === "filter",
  "dss-popover--open": !!s.open,
  "dss-popover--has-widget": s.hasWidget,
  "dss-popover--max-height": s.hasMaxHeight,
  "dss-popover--hide-header": s.hideHeader,
  "dss-popover--empty-footer": !s._hasFooterSlot,
  "dss-popover--header-empty": s.titleText === "" && !!s.hideCloseIcon,
  "dss-popover--remove-max-height": s.removeMaxHeight,
  "dss-popover--full-width": s.fullWidth,
  [`dss-popover--${s.position}`]: !!s.position
})}
  >
    <div class="dss-popover-box">
      ${s.hideHeader ? r : e`
        <div class="dss-popover-header">
          <div class="dss-popover-header-box">
            <div class="dss-popover-header__title">${s.titleText}</div>
            ${s.actionIcon ? e`
                  <${o}
                    icon="${s.actionIcon}"
                    label="${s.actionLabel}"
                    size="md"
                    variant="primary"
                    ?hideTooltip=${s.hideTooltip}
                    tooltipPosition="${s.tooltipPosition}"
                    ?forceViewport="${s.forceViewport}"
                    @onClick="${s._handleAction}"
                  ></${o}>
                ` : null}
            ${s.hideCloseIcon ? null : e`
                  <${o}
                    icon="close"
                    label="Tancar"
                    size="md"
                    variant="default"
                    hideTooltip
                    @onClick="${s._handleClose}"
                  ></${o}>
                `}
          </div>
        </div>
      `}
      <div 
        class=${i({
  "dss-popover-content": !0,
  "dss-popover-content--max-height": s.hasMaxHeight
})}
      >
        <slot name="body" class="dss-scrollable-content"></slot>
        <slot name="item-list"></slot>
      </div>
      ${s.variant === "filter" ? e`
        <div class="dss-popover-footer-wrapper">
          <slot name="footer"></slot>
        </div>
        ` : null}
    </div>
    <div class="dss-popover-arrow" data-popper-arrow></div>
  </div>
`;
export {
  $ as popoverTemplate
};
//# sourceMappingURL=popover.template.js.map
