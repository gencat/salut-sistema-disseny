import { LitElement as z, unsafeCSS as D } from "lit";
import { query as L, property as i, state as f } from "lit/decorators.js";
import { classMap as F } from "lit/directives/class-map.js";
import { unsafeHTML as x } from "lit/directives/unsafe-html.js";
import { unsafeStatic as E, literal as I, html as b } from "lit/static-html.js";
import { getCustomElementSuffix as A } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as O, highlightText as q } from "../../api/marker/marker.js";
import B from "../../api/marker/marker.style.css.js";
import { normalizeText as _ } from "../../utils/helpers.js";
import { booleanType as d, booleanConverter as g } from "../../utils/property-types.js";
import V from "./searchbar.style.css.js";
import { template as U } from "./searchbar.template.js";
var M = Object.defineProperty, s = (T, t, n, o) => {
  for (var l = void 0, p = T.length - 1, u; p >= 0; p--)
    (u = T[p]) && (l = u(t, n, l) || l);
  return l && M(t, n, l), l;
};
const k = I`dss-icon${E(A())}`, $ = I`dss-chip${E(A())}`, C = class C extends z {
  constructor() {
    super(), this.value = "", this.multiple = !1, this.icon = "search", this.size = "lg", this.helpText = void 0, this.innerFocus = !1, this.threshold = 3, this.searchTerms = [], this.catalog = [], this.emptyDropdownText = "Sense resultats per", this.recentSearchesLabel = "Últimes cerques", this.recentSearches = !1, this.isCatalogLoading = !1, this.dropdownStyle = "", this.catalogStyle = "", this.advancedFilter = !1, this.placeholder = "Escriu per cercar", this._filter = "", this._isFocused = !1, this._showClearButton = !1, this._filteredCatalog = [], this._showAllChips = !1, this._showDropdown = !1, this._dropdownStyle = "", this.id = "", this.name = "", this.label = "Cercador", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this._defaultId = `dss-input-${crypto.randomUUID()}`, this.internals = this.attachInternals();
  }
  static get styles() {
    return [D(B), D(V)];
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value);
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  _getSearchStyle() {
    return `top: ${this.renderRoot.querySelectorAll(".dss-search-bar")[0].offsetHeight + 4}px; ${this.dropdownStyle}`;
  }
  get _inputValidity() {
    return this._input && this._input.value !== "" ? this._input?.checkValidity() : !0;
  }
  _handleInput() {
    this.multiple || this._handleValidity(), this.value = this._input.value, this._filter = this._input.value;
    let t = this._input.value;
    t.length >= this.threshold ? (this._showDropdown = !0, this._filteredCatalog = this._getFilterCatalog(t), this.multiple && t.endsWith(",") && (t = t.slice(0, -1), this.searchTerms.push(t), this._input.value = "", this.searchTerms.length && this._dispatchSearchChange()), this._dropdownStyle = this._getSearchStyle()) : this._hideDropdown(), this._emitInput();
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0;
  }
  _handleFocusOut() {
    this._isFocused = !1, this._showClearButton = !1;
  }
  _handleKeyDown(t) {
    t?.key === "Enter" ? (this._showDropdown = !0, !this.multiple && this._input.value !== "" && (this.searchTerms = [], this.searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1), this._dropdownStyle = this._getSearchStyle()) : t?.key === "Escape" && (this._showDropdown = !1);
  }
  _focusInput() {
    this._input?.focus();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    this.invalid = !t, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus()), this.searchTerms = [], this._dispatchSearchChange(), this._hideDropdown();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedFilter(t) : this._applyDefaultFilter(t);
  }
  _applyDefaultFilter(t) {
    const n = _(t);
    return this.catalog.filter((o) => _(o.value).includes(n));
  }
  _applyAdvancedFilter(t) {
    if (!_(t.trim())) return this.catalog;
    const o = _(t).split(/\s+/).filter((l) => l.length >= this.threshold);
    return o.length === 0 ? this.catalog : this.catalog.filter((l) => {
      const p = _(l.value);
      return o.every((u) => p.includes(u));
    });
  }
  _generateSearchChips() {
    let t = 0;
    return this.searchTerms.map((o) => {
      const l = (v) => {
        const S = v.detail.text;
        this.searchTerms = this.searchTerms.filter((w) => w !== S), this._dispatchSearchChange();
      };
      t += 1;
      const p = {
        disabled: this.disabled || this.readonly,
        "dss-chip--selected": !this.disabled && !this.readonly,
        "dss-chip--hide": t > 5
      };
      return b`
				<${$}
 					class="${F(p)}"
					size="sm" 
					label="${o}" 
					selected 
					disableSelect
					hasdelete 
					?disabled=${this._input?.disabled}
					@onDelete="${l}">
				</${$}>
      `;
    });
  }
  _generateFilterCatalog() {
    let t = !0;
    return this._filteredCatalog.map((o) => {
      const l = (r) => {
        const a = r.target.getAttribute("value");
        a && (this.multiple ? this.searchTerms.includes(a) ? this.searchTerms = this.searchTerms.filter((c) => c !== a) : this.searchTerms.push(a) : (this._input.value = a, this._showDropdown = !1, this.searchTerms = [], this.searchTerms.push(a)), this._dispatchSearchChange());
      }, p = (r) => {
        r && r.focus();
      }, u = (r) => {
        let a = 0;
        const h = this.renderRoot.querySelectorAll(".dss-catalog-item"), c = h.length - 1;
        r === h[0] ? p(h[c]) : (h.forEach((y, m) => {
          y === r && (a = m);
        }), p(h[a - 1]));
      }, v = (r) => {
        let a = 0;
        const h = this.renderRoot.querySelectorAll(".dss-catalog-item"), c = h.length - 1;
        r === h[c] ? p(h[0]) : (h.forEach((y, m) => {
          y === r && (a = m);
        }), p(h[a + 1]));
      }, S = (r) => {
        const a = r.currentTarget, h = r;
        let c = !1;
        switch (h.key) {
          case "ArrowUp":
            u(a), c = !0;
            break;
          case "ArrowDown":
            v(a), c = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const y = r.target;
            this.renderRoot.querySelector('.dss-catalog-item[tabindex="0"]')?.setAttribute("tabindex", "-1"), r.target.setAttribute("tabindex", "0"), y.click(), c = !0;
            break;
          }
        }
        c && (r.stopPropagation(), r.preventDefault());
      }, w = {
        "dss-catalog-item--selected": this.searchTerms.includes(o.value)
        // 'disabled': this._input?.disabled,
        // 'dss-chip--selected': !this._input?.disabled,
      }, R = b`
        <div
					role="option"
          class="dss-catalog-item ${F(w)}"
          value="${o.value}"
          tabindex="${t ? 0 : -1}"
          @click="${l}"
          @keydown=${S}
        >
          ${o.icon ? b`
								<${k}
									class="dss-catalog-item__icon"
									icon="${o.icon}"
									size="md"
									value="${o.value}"
								></${k}>
              ` : null}
          <div class="dss-catalog-item__text" value="${o.value}">
            ${this.advancedFilter ? x(O(o.value, this._filter, this.threshold)) : x(q(o.value, this._filter))}
					</div>
        </div>
      `;
      return t = !1, R;
    });
  }
  _dispatchSearchChange() {
    const t = {
      detail: this.searchTerms,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("search", t)), this.multiple ? this.value = this.searchTerms.toString() : this.value = this.searchTerms[0] || "", this._emitChange();
  }
  _emitInput() {
    !this._input || this.multiple || (this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 })), this._handleChange());
  }
  _handleChange() {
    !this._input || this.multiple || this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _closeDropdown() {
    document.addEventListener("mousedown", (t) => {
      t.target !== this && t.target !== this._input && (this._showDropdown = !1);
    }), document.addEventListener("focusout", (t) => {
      const n = t.relatedTarget;
      n !== null && n !== this && n !== this._input && (this._showDropdown = !1);
    });
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._closeDropdown(), this._dropdownStyle = this._getSearchStyle());
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return U(this);
  }
};
C.formAssociated = !0;
let e = C;
s([
  L("input.dss-input")
], e.prototype, "_input");
s([
  i({ type: String })
], e.prototype, "value");
s([
  i(d)
], e.prototype, "multiple");
s([
  i({ type: String })
], e.prototype, "icon");
s([
  i({ type: String })
], e.prototype, "size");
s([
  i({ type: String })
], e.prototype, "helpText");
s([
  i(d)
], e.prototype, "innerFocus");
s([
  i({ type: Number })
], e.prototype, "threshold");
s([
  i({ type: Array })
], e.prototype, "searchTerms");
s([
  i({ type: Array })
], e.prototype, "catalog");
s([
  i({ type: String })
], e.prototype, "emptyDropdownText");
s([
  i({ type: String })
], e.prototype, "recentSearchesLabel");
s([
  i(d)
], e.prototype, "recentSearches");
s([
  i(d)
], e.prototype, "isCatalogLoading");
s([
  i({ type: String })
], e.prototype, "dropdownStyle");
s([
  i({ type: String })
], e.prototype, "catalogStyle");
s([
  i(d)
], e.prototype, "advancedFilter");
s([
  i({ type: String })
], e.prototype, "placeholder");
s([
  f()
], e.prototype, "_filter");
s([
  f()
], e.prototype, "_isFocused");
s([
  f()
], e.prototype, "_showClearButton");
s([
  f()
], e.prototype, "_filteredCatalog");
s([
  f()
], e.prototype, "_showAllChips");
s([
  f()
], e.prototype, "_showDropdown");
s([
  f()
], e.prototype, "_dropdownStyle");
s([
  i({ type: String })
], e.prototype, "id");
s([
  i({ type: String })
], e.prototype, "name");
s([
  i({ type: String })
], e.prototype, "label");
s([
  i({ converter: g, reflect: !0 })
], e.prototype, "disabled");
s([
  i({ converter: g, reflect: !0 })
], e.prototype, "readonly");
s([
  i({ converter: g, reflect: !0 })
], e.prototype, "required");
s([
  i({ converter: g, reflect: !0 })
], e.prototype, "invalid");
s([
  i({ type: String })
], e.prototype, "pattern");
s([
  i({ type: String })
], e.prototype, "inputmode");
s([
  i({ type: String })
], e.prototype, "autocapitalize");
s([
  i({ type: String })
], e.prototype, "autocomplete");
s([
  i(d)
], e.prototype, "autocorrect");
s([
  i(d)
], e.prototype, "autofocus");
s([
  i(d)
], e.prototype, "spellcheck");
export {
  e as SearchBar
};
//# sourceMappingURL=searchbar.js.map
