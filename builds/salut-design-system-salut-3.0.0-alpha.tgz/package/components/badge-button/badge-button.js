import { LitElement as p, unsafeCSS as d } from "lit";
import { property as e } from "lit/decorators.js";
import _ from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import u from "./badge-button.states.css.js";
import f from "./badge-button.style.css.js";
import { template as m } from "./badge-button.template.js";
var y = Object.defineProperty, g = Object.getOwnPropertyDescriptor, i = (l, t, o, c) => {
  for (var n = c > 1 ? void 0 : c ? g(t, o) : t, a = l.length - 1, h; a >= 0; a--)
    (h = l[a]) && (n = (c ? h(t, o, n) : h(n)) || n);
  return c && n && y(t, o, n), n;
};
class s extends p {
  constructor() {
    super(...arguments), this.type = "button", this.label = "", this.disabled = !1, this.hidden = !1, this.hideIcon = !1, this.outlined = !1, this.forceViewport = !1, this.width = void 0, this._size = "sm", this._action = "dropdown", this._actionIcon = "expand_more", this._state = "", this._icon = "", this._isIconDefined = !1, this._iconSize = "sm", this._iconFill = !1, this._isTextTruncated = !1, this._isFirstUpdated = !0;
  }
  static get styles() {
    return [d(_), d(f), d(u)];
  }
  get _tooltip() {
    const t = this.shadowRoot?.querySelector('slot[name="tooltip"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set size(t) {
    const o = this._size;
    this._size = t, t === "xl" ? this._iconSize = "md" : this._iconSize = "sm", this.requestUpdate("size", o);
  }
  get size() {
    return this._size;
  }
  set action(t) {
    const o = this._action;
    switch (this._action = t, t) {
      case "details":
        this._actionIcon = "visibility";
        break;
      case "external":
        this._actionIcon = "open_in_new";
        break;
      default:
        this._actionIcon = "expand_more";
    }
    this.requestUpdate("action", o);
  }
  get action() {
    return this._action;
  }
  set state(t) {
    const o = this._state;
    this._state = t, this._generateDefaultIcon(t), this.requestUpdate("state", o);
  }
  get state() {
    return this._state;
  }
  set icon(t) {
    const o = this._icon;
    this._icon = t, this._isIconDefined = !0, this.requestUpdate("icon", o);
  }
  get icon() {
    return this._icon;
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !1, composed: !1 }));
  }
  _updateIconFill(t) {
    this._iconFill = !t.includes("low") || t === "correct";
  }
  _generateDefaultIcon(t) {
    t && !this._isIconDefined && (t.includes("danger") ? (this._icon = "warning", this._updateIconFill(t)) : t.includes("moderate") ? (this._icon = "emergency_home", this._updateIconFill(t)) : t.includes("slight") ? (this._icon = "error", this._updateIconFill(t)) : t.includes("correct") ? (this._icon = "check_circle", this._updateIconFill(t)) : t.includes("undeterminated") ? this._icon = "circle" : t.includes("undetermined") ? this._icon = "circle" : t.includes("critic") ? this._icon = "cancel" : t.includes("alert") ? this._icon = "report" : t.includes("ideal") ? this._icon = "check_circle" : t.includes("info") ? this._icon = "info" : t.includes("neutral") && (this._icon = "circle"));
  }
  _isInformativeState() {
    return ["ideal", "critical", "critic", "alert", "info", "info-alt", "neutral"].includes(this._state);
  }
  _checkTextTruncated() {
    const t = this.shadowRoot?.querySelector(".dss-badge-button__label");
    t && (this._isTextTruncated = t.scrollWidth > t.offsetWidth, this.requestUpdate());
  }
  willUpdate(t) {
    !this._isFirstUpdated && t.has("label") && this._checkTextTruncated(), !this._isFirstUpdated && t.has("state") && (this._iconFill = !1, this._generateDefaultIcon(this.state));
  }
  async firstUpdated() {
    if (await this.updateComplete, this.width) {
      const t = this.shadowRoot?.querySelector(".dss-badge-button");
      t && (t.style.width = this.width);
    }
    this._tooltip && setTimeout(() => {
      this._tooltip.updateTooltip();
    }, 200), this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  render() {
    return m(this);
  }
}
i([
  e({ type: String })
], s.prototype, "type", 2);
i([
  e({ type: String })
], s.prototype, "label", 2);
i([
  e(r)
], s.prototype, "disabled", 2);
i([
  e(r)
], s.prototype, "hidden", 2);
i([
  e(r)
], s.prototype, "hideIcon", 2);
i([
  e(r)
], s.prototype, "outlined", 2);
i([
  e(r)
], s.prototype, "forceViewport", 2);
i([
  e({ type: String })
], s.prototype, "width", 2);
i([
  e({ type: String })
], s.prototype, "size", 1);
i([
  e({ type: String })
], s.prototype, "action", 1);
i([
  e({ type: String })
], s.prototype, "state", 1);
i([
  e({ type: String })
], s.prototype, "icon", 1);
export {
  s as BadgeButton
};
//# sourceMappingURL=badge-button.js.map
