import { autoUpdate as u, computePosition as d, offset as _, flip as m, shift as c } from "@floating-ui/dom";
import { LitElement as f, unsafeCSS as l } from "lit";
import { property as o, query as v } from "lit/decorators.js";
import { getPortalContainer as E } from "../../api/portal-manager/portal-manager.js";
import y from "../../foundations/icon/icon.style.css.js";
import { booleanType as h } from "../../utils/property-types.js";
import L from "./tooltip.style.css.js";
import { template as w } from "./tooltip.template.js";
var T = Object.defineProperty, i = (r, t, e, b) => {
  for (var n = void 0, a = r.length - 1, p; a >= 0; a--)
    (p = r[a]) && (n = p(t, e, n) || n);
  return n && T(t, e, n), n;
};
class s extends f {
  constructor() {
    super(...arguments), this.position = "top", this.align = "left", this.hidden = !1, this.noHeightLimit = !1, this.delay = 0, this.interactive = !1, this._initialParent = null, this._portalManager = null, this._onFocusIn = () => this.show(), this._onFocusOut = () => this.hide(), this._onTooltipMouseEnter = () => {
      window.clearTimeout(this._hideTimeout);
    }, this._onMouseEnter = () => {
      this.show();
    }, this._onMouseLeave = (t) => {
      const e = t.relatedTarget;
      this.contains(e) || this._parent?.contains(e) || (this._hideTimeout = window.setTimeout(() => {
        this.hide();
      }, 160));
    };
  }
  static get styles() {
    return [l(y), l(L)];
  }
  connectedCallback() {
    super.connectedCallback(), this._portalManager = E(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement), this._parent && (this._setEventListeners(), this._setAccessibility());
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._destroyEventListeners(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0;
  }
  _setEventListeners() {
    this._parent?.addEventListener("mouseenter", this._onMouseEnter), this._parent?.addEventListener("mouseleave", this._onMouseLeave), this._parent?.addEventListener("focusin", this._onFocusIn), this._parent?.addEventListener("focusout", this._onFocusOut), this.addEventListener("mouseenter", this._onTooltipMouseEnter), this.addEventListener("mouseleave", this._onMouseLeave);
  }
  _destroyEventListeners() {
    this._parent?.removeEventListener("mouseenter", this._onMouseEnter), this._parent?.removeEventListener("mouseleave", this._onMouseLeave), this._parent?.removeEventListener("focusin", this._onFocusIn), this._parent?.removeEventListener("focusout", this._onFocusOut), this.removeEventListener("mouseenter", this._onTooltipMouseEnter), this.removeEventListener("mouseleave", this._onMouseLeave);
  }
  _setAccessibility() {
    this._parent && (this.id || (this.id = `dss-tooltip-${crypto.randomUUID()}`), this._parent.hasAttribute("aria-describedby") || this._parent.setAttribute("aria-describedby", this.id));
  }
  _selfMouseEnter(t) {
    this.interactive || (t.stopPropagation(), t.preventDefault(), this.hide(), this.style.pointerEvents = "none");
  }
  show() {
    this.hidden || this.parentElement?.getAttribute("data-truncated") !== "false" && (window.clearTimeout(this._hideTimeout), window.clearTimeout(this._showTimeout), this._showTimeout = window.setTimeout(() => {
      this._executeShow();
    }, this.delay));
  }
  _executeShow() {
    this._initialParent || (this._initialParent = this.parentElement), this._portalManager && this.parentElement !== this._portalManager && this._portalManager.appendChild(this), setTimeout(() => {
      this.classList.add("visible"), this._tooltipEl.setAttribute("aria-hidden", "false");
    }, 0), this._parent && (this._cleanupAutoUpdate = u(this._parent, this, () => this._updatePosition()));
  }
  hide() {
    window.clearTimeout(this._showTimeout), this.classList.remove("visible"), this._tooltipEl.setAttribute("aria-hidden", "true"), this._hideTimeout = window.setTimeout(() => {
      this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0, this._initialParent && this.parentElement !== this._initialParent && this._initialParent.appendChild(this);
    }, 240);
  }
  updateTooltip() {
    this._parent && (this._cleanupAutoUpdate = u(this._parent, this, () => this._updatePosition()));
  }
  async _updatePosition() {
    if (this.hidden || !this._parent) return;
    const { x: t, y: e } = await d(this._parent, this, {
      placement: this.position,
      strategy: "fixed",
      middleware: [_(8), m(), c({ padding: 8 })]
    });
    Object.assign(this.style, {
      left: `${t}px`,
      top: `${e}px`
    });
  }
  render() {
    return w(this);
  }
}
i([
  o({ type: String })
], s.prototype, "position");
i([
  o({ type: String })
], s.prototype, "align");
i([
  o(h)
], s.prototype, "hidden");
i([
  o(h)
], s.prototype, "noHeightLimit");
i([
  o({ type: Number })
], s.prototype, "delay");
i([
  o(h)
], s.prototype, "interactive");
i([
  v(".dss-tooltip")
], s.prototype, "_tooltipEl");
export {
  s as Tooltip
};
//# sourceMappingURL=tooltip.js.map
