import { classMap as t } from "lit/directives/class-map.js";
import { html as l } from "lit/static-html.js";
const d = (i) => l`
	<div 
		role="tooltip"
		aria-hidden="${i.ariaHidden || "false"}"
		class="${t({
  "dss-tooltip": !0,
  [`dss-tooltip--align-${i.align}`]: !!i.align,
  "dss-tooltip--hidden": i.hidden,
  "dss-tooltip--no-height-limit": i.noHeightLimit
})}"
		@mouseenter="${i._selfMouseEnter}"
	>
		<slot></slot>
	</div>
`;
export {
  d as template
};
//# sourceMappingURL=tooltip.template.js.map
