const r = ".dss-input-group:has(dss-chip:focus-within){outline:0;border-color:var(--color-neutral-100)}.dss-input-group.dss-input-group--read-only:has(dss-chip:focus-within){outline:0;border-top-color:transparent;border-left-color:transparent;border-right-color:transparent;border-radius:0}";
export {
  r as default
};
//# sourceMappingURL=select.style.css.js.map
