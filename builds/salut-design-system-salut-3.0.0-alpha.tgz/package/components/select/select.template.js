import { nothing as s } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as d, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const h = d`dss-icon${a(i())}`, r = d`dss-icon-button${a(i())}`, t = d`dss-tooltip${a(i())}`, b = d`dss-select-options${a(i())}`, g = d`dss-chip${a(i())}`, w = (l) => e`
  <${b}
    ariaLabel="Llista d'elements"
    class="combobox ${l._getEffectiveId()}-options"
    .openByDefault=${l.openWithSearch}
    .isOpen=${l.showDropdown}
    .multiple=${l.multiple}
    .tick=${l.tick}
    .deselectable=${l.deselectable}
    .disabled=${l.disabled}
    .elements=${l._filteredElements}
    .filter=${l._input?.value}
    .filterThreshold=${l.filterThreshold}
    .searchThreshold=${l.searchThreshold}
    .value=${l.selectedValue}
    .type=${l.type}
    .labelSelectAll=${l.labelSelectAll}
    .labelDeselectAll=${l.labelDeselectAll}
    .selectAll=${l.selectAll}
    selectedCounter=${l._selectElements}
    boxStyle=${l.dropdownStyle}
    boxShadow
    @option-changed="${l._handleSelectorChange}"
    @options-focusout="${l._handleOptionsFocusOut}"
    @keydown="${($) => {
  $.key === "Escape" && l._handleBlurSelector(void 0, $);
}}"
    @focusout=${l._handleFocusOut}
    ?readonly=${l.readonly}
    .advancedFilter=${l.advancedFilter}
  >
  </${b}>
`, p = (l) => e`
  <input 
    type="hidden" 
    class="dss-hidden-value" 
    .name=${l.name} 
    .value=${l.value}
    @change=${l._onChange} 
  />

  <div class="${u({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": l.required,
  "dss-input-wrapper--disabled": l.disabled,
  [`dss-input-wrapper--${l.size}`]: !!l.size,
  "dss-input-wrapper--no-label": l.hideLabel
})}">

    ${l.size === "sm" && !l.hideLabel ? e`
      <div class="dss-wrapper-label">
        <label class="dss-label" for="${l._getEffectiveId()}">${l.label}</label>
      </div>
      ` : s}

    <div class="${u({
  "dss-input-group": !0,
  [`dss-input-group--${l.size}`]: !!l.size,
  "dss-input-group--invalid": l.invalid && !l.showDropdown,
  // 'dss-input-group--invalid': component.invalid || !component._inputValidity,
  "dss-input-group--required": l.required,
  "dss-input-group--disabled": l.disabled,
  "dss-input-group--focused": l.value || l._input?.value || l.placeholder || l._isFocused,
  "dss-input-group--read-only": l.readonly,
  "dss-input-group--no-label": l.hideLabel,
  "dss-input-group--numeric": l.type === "number",
  "dss-input-group--read-only-empty": l.readonly && l.placeholder === "" && !l._input?.value
})}">

      ${l.icon ? e`
        <${h} icon="${l.icon}" class="dss-input-icon"></${h}>
        ` : s}

      <div 
        class="dss-input-field"
        data-truncated="${!l.showDropdown && l._isTruncated && l.selectedValue && l.selectedValue?.length === 1}"
        @mouseover=${l._handleInputMouseOver}
      >
      
        ${l.size !== "sm" && !l.hideLabel ? e`
          <label class="dss-label" for="${l._getEffectiveId()}">${l.label}</label>
          ` : s}

        ${l.inputPrefix ? e`
           <span class="dss-input-inputPrefix">${l.inputPrefix}</span>
          ` : s}

        <input
          class="dss-input"
          id="${l._getEffectiveId()}"
          .type="text"
          .name="${l.name ?? s}"
          .placeholder=${l._placeholder}
          ?disabled=${l.disabled}
          ?readonly=${l.readonly}
          ?required=${l.required}
          ?autofocus=${l.autofocus}
          spellcheck=${l.spellcheck ? "true" : "false"}
          autocorrect=${l.autocorrect ? "on" : "off"}
          autocomplete=${l.autocomplete}
          autocapitalize=${l.autocapitalize}
          min=${l.min ?? s}
          max=${l.max ?? s}
          step=${l.step ?? s}
          minlength=${l.minLength ?? s}
          maxlength=${l.maxLength ?? s}
          pattern=${l.pattern ?? s}
          inputmode=${l.inputmode ?? s}
          aria-label="${l.hideLabel ? l.label : s}"
          @input=${l._handleInput}
          @focusin=${l._handleFocusIn}
          @focusout=${l._handleFocusOut}
          @keydown=${l._handleKeyDown}
          @click=${l._handleClick}
        />

        <${t} ?hidden=${l.showDropdown} aria-hidden="true">${l._input?.value}</${t}>
      </div>


      ${l.multiple && l._isTruncated && l.selectedValue && l.selectedValue?.length > 1 ? e`
          <${g}
            label="${l._multipleSelectedCounter}"
            size="xs"
            ?selected=${l.showDropdown}
            @onToggle=${l._toggleDropdown}>
          </${g}>
        ` : s}

      ${!l.openWithSearch && !l.readonly ? e`
            <${r}
              class="dss-icon-button dss-input-dropdown__toggle"
              size="md"
              icon="${l.showDropdown ? "keyboard_arrow_up" : "keyboard_arrow_down"}"
              label="${l.showDropdown ? "Tancar dropdown" : "Obrir dropdown"}"
              hideTooltip
              ariaExpanded="${l.showDropdown}"
              variant="primary"
              ?disabled=${l.disabled}
              disableTabindex
              @onClick=${l._toggleDropdown}
            ></${r}>
        ` : l.openWithSearch ? e`
          <${r}
            class="dss-icon-button dss-input-dropdown__toggle"
            size="md"
            label="Esborra la selecció"
            hideTooltip
            icon="close"
            variant="primary"
            ?disabled=${l.disabled || l.readonly}
            disableTabindex
            @onClick=${l._cleanInput}
          ></${r}>
        ` : s}

      ${l.openWithSearch ? s : e`${w(l)}`}

      
    </div>

    ${l.helpText && !l.openWithSearch ? e`
      <div class="${u({
  "dss-input-help": !0,
  "dss-input-help--invalid": l.invalid && !l.showDropdown,
  "dss-input-help--disabled": l.disabled
})}">
        <span>${l.helpText}</span>
        ${l.maxLength ? e`
          <span>
            ${l._input?.value?.length ?? 0}/${l.maxLength}
          </span>` : s}
      </div>
      ` : s}

    ${l.openWithSearch ? e`${w(l)}` : s}
  </div>  
`;
export {
  p as template
};
//# sourceMappingURL=select.template.js.map
