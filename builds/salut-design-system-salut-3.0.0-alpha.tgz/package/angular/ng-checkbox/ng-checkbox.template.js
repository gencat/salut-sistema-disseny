import { classMap as e } from "lit/directives/class-map.js";
import { html as c } from "lit/static-html.js";
const d = (s) => {
  const a = {
    "dss-checkbox-wrapper--checked": s._checked,
    "dss-checkbox-wrapper--disabled": s._disabled,
    "dss-checkbox-wrapper--has-label": !!s._label,
    "dss-checkbox-wrapper--validate": s.variant === "validation"
  };
  return c`
    <div class="dss-checkbox-wrapper ${e(a)}">
			<div class="dss-checkbox-container">
      	<slot name="input"></slot>
			</div>
      <slot name="label"></slot>
    </div>
  `;
};
export {
  d as template
};
//# sourceMappingURL=ng-checkbox.template.js.map
