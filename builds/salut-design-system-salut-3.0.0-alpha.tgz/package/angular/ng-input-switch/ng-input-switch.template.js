import { classMap as i } from "lit/directives/class-map.js";
import { html as l } from "lit/static-html.js";
const c = (s) => {
  const d = {
    "dss-switch--sm": s._size === "sm",
    "dss-switch--md": s._size === "md",
    "dss-switch--lg": s._size === "lg",
    "dss-switch--checked": s._checked,
    "dss-switch--disabled": s._disabled
  };
  return l`
    <div class="dss-switch ${i(d)}">
      <div
        class="dss-switch__slider"
        tabindex="${s._disabled ? -1 : 0}"
        @keydown="${s._handleKeydown}"
        @click="${s._handleClick}"
      ></div>
      <slot name="input"></slot>
      <slot name="label" @click="${s._handleClick}"></slot>
    </div>
  `;
};
export {
  c as template
};
//# sourceMappingURL=ng-input-switch.template.js.map
