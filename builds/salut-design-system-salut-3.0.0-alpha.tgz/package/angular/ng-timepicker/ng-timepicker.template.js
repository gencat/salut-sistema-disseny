import { nothing as r } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { ifDefined as v } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as a, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const u = a`dss-icon${l(t())}`, e = a`dss-button${l(t())}`, o = a`dss-tooltip${l(t())}`, f = (i) => {
  const n = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": i._required,
    [`dss-input-wrapper--${i.inputSize}`]: !!i.inputSize,
    "dss-input-wrapper--no-label": !i._label
  }, _ = {
    "dss-input-group": !0,
    [`dss-input-group--${i.inputSize}`]: !!i.inputSize,
    "dss-input-group--invalid": i._invalid || !i._inputValidity,
    "dss-input-group--required": i._required,
    "dss-input-group--disabled": i._disabled,
    "dss-input-group--focused": i._input?.value || i._placeholder,
    "dss-input-group--read-only": i._readonly,
    "dss-input-group--no-label": !i._label
  }, w = {
    "dss-input-help": !0,
    "dss-input-help--invalid": i._invalid,
    "dss-input-help--disabled": i._disabled
  }, $ = {
    "dss-timepicker-dropdown--open": i._showDropdown,
    "dss-timepicker-dropdown--lg": i.inputSize === "lg",
    "dss-timepicker-dropdown--md": i.inputSize !== "lg",
    "dss-timepicker-dropdown--list--visible": i._showDropdown && i._dropdown === "list"
  }, c = {
    "dss-timepicker-dropdown--open": i._showDropdown,
    "dss-timepicker-dropdown--lg": i.inputSize === "lg",
    "dss-timepicker-dropdown--md": i.inputSize !== "lg",
    "dss-timepicker-dropdown--manual--visible": i._showDropdown && i._dropdown === "manual"
  }, p = () => s`
      <div class="${d(_)}">
        ${i.icon && i.icon !== "" ? s`
          <${u} icon="${i.icon}" class="dss-input-icon"></${u}>
          ` : r}
        <div class="dss-input-field">
          ${i.inputSize !== "sm" ? s`
            <slot name="label" @click=${i._focusInput}></slot>
            ` : r}
          <slot name="input"
            @click=${i._handleClick}
            @input=${i._handleInput}
            @focusin=${i._handleFocus}
            @focusout=${i._handleBlur}
            @keydown=${i._handleKeyDown}
          ></slot>

          ${!i._showDropdown && i._isTruncated ? s`
              <${o}>${i._input?.value}</${o}>
            ` : null}
        </div>
      </div>
      `;
  return s`
  
      <div class="${d(n)}">
  
        ${i.inputSize === "sm" ? s`
          <div class="dss-wrapper-label">
            <slot name="label" @click=${i._focusInput}></slot>
          </div>
          ` : r}

        ${i._dropdown === "" ? s`
            ${p()}
          ` : s`
            <div class="dss-input-dropdown-wrapper"
              role="combobox"
              aria-controls="timepicker-options"
              aria-expanded=${v(i._showDropdown)}
            >
              ${p()}
      
              <div
                id="timepicker-options"
                class="dss-timepicker-dropdown dss-timepicker-dropdown--list ${d($)}"
                role="listbox"
                aria-label="Timepicker Options"
              >
                <div class="dss-timepicker-dropdown__container">
                  ${s`${i._generateTimeListOptionsHTML(i._timeListOptions, i._customTimeListOptions)}`}
                </div>
              </div>

              <div
                id="timepicker-options"
                class="dss-timepicker-dropdown dss-timepicker-dropdown--manual ${d(c)}"
                role="listbox"
                aria-label="Timepicker Options"
              >
                <div class="dss-timepicker-dropdown__manual">
                  <div
                    class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--hour"
                  >
                    ${i._generateTimeManualOptionsHTML("timepickerManualHour", i._timeManualHourOptions)}
                  </div>
                  <div
                    class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--minute"
                  >
                    ${i._generateTimeManualOptionsHTML("timepickerManualMinutes", i._timeManualMinutesOptions)}
                  </div>
                </div>
                <div class="dss-timepicker-dropdown__actions">
                  <${e} 
                    label="Cancel-lar"
                    size="md"
                    variant="secondary"
                    @onClick=${i._timeManualSelectorCancel}
                  ></${e}>
                  <${e}
                    label="Seleccionar"
                    size="md"
                    variant="primary"
                    ?disabled=${i._checkDisableTimeManualSelector()}
                    @onClick=${i._timeManualSelectorAccept}
                  ></${e}>
                </div>
              </div>
      
            </div>
          `}

        ${i._helpText ? s`
              <div class="${d(w)}">
                <span>${i._helpText}</span>
              </div>
            ` : null}
  
      </div>
    `;
};
export {
  f as template
};
//# sourceMappingURL=ng-timepicker.template.js.map
