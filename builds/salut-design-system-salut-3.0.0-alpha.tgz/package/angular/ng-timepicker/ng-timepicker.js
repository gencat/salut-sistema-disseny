import { autoUpdate as M, computePosition as L, offset as E, flip as q, shift as F, size as V } from "@floating-ui/dom";
import { LitElement as U, unsafeCSS as k } from "lit";
import { property as h } from "lit/decorators.js";
import { classMap as R } from "lit/directives/class-map.js";
import { unsafeStatic as $, literal as A, html as D } from "lit/static-html.js";
import { getCustomElementSuffix as I } from "../../api/custom-element-scope.js";
import { booleanType as S } from "../../utils/property-types.js";
import { template as C } from "./ng-timepicker.template.js";
import P from "../../shared/scrollbar.style.css.js";
import j from "../ng-input/ng-input.style.css.js";
import z from "./ng-timepicker.style.css.js";
var W = Object.defineProperty, K = Object.getOwnPropertyDescriptor, p = (T, t, e, i) => {
  for (var s = i > 1 ? void 0 : i ? K(t, e) : t, o = T.length - 1, u; o >= 0; o--)
    (u = T[o]) && (s = (i ? u(t, e, s) : u(s)) || s);
  return i && s && W(t, e, s), s;
};
const H = A`dss-icon${$(I())}`;
class d extends U {
  constructor() {
    super(), this.inputSize = "lg", this.icon = "schedule", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this._value = "", this._placeholder = "", this._inputSize = "lg", this._dropdown = "", this._required = !1, this._disabled = !1, this._readonly = !1, this._invalid = !1, this._showDropdown = !1, this._helpText = "", this._oldHelpText = "", this._errorTimeFormatText = "Format d'hora no vàlid", this._errorTimeOptionText = "Opció de temps no disponible", this._manualHourSelector = "", this._manualMinuteSelector = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._timeListOptions = [], this._customTimeListOptions = [], this._timeManualHourOptions = [], this._timeManualMinutesOptions = [], this._inputValidity = !0, this._isFirstUpdated = !0, this._cleanupFloatingList = null, this._cleanupFloatingManual = null, this._referenceEl = null, this._floatingListEl = null, this._floatingManualEl = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showDropdown && this._closeDropdown();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._timePattern = /^\d{0,4}$/g, this._timeSeparator = ":", this._timeInputOldValue = "", this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [k(j), k(P), k(z)];
  }
  get _input() {
    const t = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  get _label() {
    const t = this.shadowRoot?.querySelector('slot[name="label"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set value(t) {
    const e = this._value;
    this._value = t, this._input && (this._input.value = t), this.requestUpdate("value", e);
  }
  get value() {
    return this._value;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this._oldHelpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set errorTimeFormatText(t) {
    const e = this._errorTimeFormatText;
    this._errorTimeFormatText = t, this.requestUpdate("errorTimeFormatText", e);
  }
  get errorTimeFormatText() {
    return this._errorTimeFormatText;
  }
  set errorTimeOptionText(t) {
    const e = this._errorTimeOptionText;
    this._errorTimeOptionText = t, this.requestUpdate("errorTimeOptionText", e);
  }
  get errorTimeOptionText() {
    return this._errorTimeOptionText;
  }
  set dropdown(t) {
    const e = this._dropdown;
    this._dropdown = t, this.requestUpdate("dropdown", e);
  }
  get dropdown() {
    return this._dropdown;
  }
  set showDropdown(t) {
    const e = this._showDropdown;
    this._showDropdown = t, this.requestUpdate("showDropdown", e);
  }
  get showDropdown() {
    return this._showDropdown;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.observer.disconnect(), this.visibleObserver.disconnect(), this._cleanupFloatingList?.(), this._cleanupFloatingManual?.(), this._cleanupFloatingList = null, this._cleanupFloatingManual = null;
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._createPopperList(), this._createPopperManual(), this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input)), this._updateTimeOptions(), this._isFirstUpdated = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _createPopperList() {
    const t = this.shadowRoot?.querySelector(".dss-input-group"), e = this.shadowRoot?.querySelector(".dss-timepicker-dropdown--list");
    !t || !e || (this._referenceEl = t, this._floatingListEl = e, this._cleanupFloatingList?.(), this._cleanupFloatingList = M(this._referenceEl, this._floatingListEl, () => this._updatePopperList()));
  }
  async _updatePopperList() {
    if (!this._referenceEl || !this._floatingListEl) return;
    const { x: t, y: e, strategy: i } = await L(this._referenceEl, this._floatingListEl, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        E(4),
        q(),
        F({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        }),
        V({
          apply: ({ rects: s }) => {
            Object.assign(this._floatingListEl.style, {
              width: `${s.reference.width}px`
            });
          }
        })
      ]
    });
    Object.assign(this._floatingListEl.style, {
      position: i,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _createPopperManual() {
    const t = this.shadowRoot?.querySelector(".dss-input-group"), e = this.shadowRoot?.querySelector(".dss-timepicker-dropdown--manual");
    !t || !e || (this._referenceEl = t, this._floatingManualEl = e, this._cleanupFloatingManual?.(), this._cleanupFloatingManual = M(
      this._referenceEl,
      this._floatingManualEl,
      () => this._updatePopperManual()
    ));
  }
  async _updatePopperManual() {
    if (!this._referenceEl || !this._floatingManualEl) return;
    const { x: t, y: e, strategy: i } = await L(this._referenceEl, this._floatingManualEl, {
      placement: "bottom",
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        E(4),
        q(),
        F({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        })
      ]
    });
    Object.assign(this._floatingManualEl.style, {
      position: i,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _updateTimeOptions() {
    this._dropdown && (this._timeListOptions = this._generateTimeListOptions(), this._timeManualHourOptions = this._generateTimeManualHoursOptions(), this._timeManualMinutesOptions = this._generateTimeManualMinutesOptions());
  }
  _checkInputAttributes() {
    const t = this._input?.getAttribute("placeholder");
    t && (this._placeholder = t), this._input?.getAttribute("readonly") !== null && (this._readonly = !0), this._input?.getAttribute("disabled") !== null && (this._disabled = !0), this._input?.getAttribute("required") !== null && (this._required = !0);
    const o = this._input?.getAttribute("value");
    o !== null && (this._value = o), this._input?.value && this._input?.value !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showDropdown && this._closeDropdown();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && (this._showDropdown && this._closeDropdown(), this.requestUpdate());
  }
  _closeDropdown() {
    this._removeDropdownListener(), this._showDropdown = !1, this._input?.blur(), this.requestUpdate();
  }
  _timeMask(t, e, i) {
    const s = [];
    for (let o = 0; o < t.length; o += 1)
      o !== 0 && o % e === 0 && s.push(i), s.push(t[o]);
    return s.join("");
  }
  _timeUnmask(t) {
    return t.replace(/[^\d]/g, "");
  }
  _timeValidate(t) {
    const e = t.slice(0, 2), i = t.slice(3, 5);
    this._input && +e >= 0 && +e <= 23 && +i >= 0 && +i <= 59 ? (this._invalid = !1, this._helpText = this._oldHelpText, this._dropdown && this._dropdown === "list" && !this._timeListOptions.includes(this._input.value) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._dropdown && this._dropdown === "manual" && (!this._timeManualHourOptions.includes(e) || !this._timeManualMinutesOptions.includes(i)) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._closeDropdown()) : (this._helpText = this._errorTimeFormatText, this._invalid = !0), this._dispatchValueChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    if (this._input) {
      const t = {
        detail: {
          value: this._input.value,
          status: this._invalid ? "INVALID" : "VALID"
        },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onTimepickerChange", t));
    }
  }
  _handleClick() {
    if (this._showDropdown = !0, this._addDropdownListener(), this._floatingListEl && this._updatePopperList(), this._floatingManualEl && this._updatePopperManual(), this._value && (this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual")) {
      const t = this._value.slice(0, 2);
      this._timeManualOptionsScrollTo(t), setTimeout(() => {
        this._timeManualOptionsScrollTo();
      }, 500);
    }
    this.requestUpdate();
  }
  _handleInput() {
    if (this._input) {
      let t = this._input.value;
      t = this._timeUnmask(t), t.match(this._timePattern) ? (t = this._timeMask(t, 2, this._timeSeparator), this._input.value = t) : this._input.value = this._timeInputOldValue, this._input.value.length === 5 && (this._timeValidate(this._input.value), this._handleValidity()), this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual" && this._timeManualOptionsScrollTo();
    }
  }
  _handleKeyDown(t) {
    this._input && (this._timeInputOldValue = this._input.value, t?.key === "Enter" || t?.key === " " ? (this._showDropdown = !0, this._addDropdownListener(), this._floatingListEl && this._updatePopperList(), this._floatingManualEl && this._updatePopperManual(), this.requestUpdate()) : t?.key === "Escape" && this._closeDropdown());
  }
  _handleFocus() {
    this._placeholder = "00:00", this._input && this._input.setAttribute("placeholder", this._placeholder), this.requestUpdate();
  }
  _handleBlur() {
    this._placeholder = "", this._input && this._input.removeAttribute("placeholder"), this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    this._disabled || (this._input?.focus(), this._handleClick());
  }
  _generateTimeListOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1)
      for (let i = 0; i < 60; i += this._minutesRange) {
        const s = e.toString().padStart(2, "0"), o = i.toString().padStart(2, "0");
        t.push(`${s}:${o}`);
      }
    return t;
  }
  _generateTimeListOptionsHTML(t, e) {
    let i = !0;
    const s = e && e.length > 0;
    return (s ? e : t).map((c) => {
      const b = (l) => {
        l && l.focus();
      }, m = (l) => {
        let n = 0;
        const r = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), a = r.length - 1;
        l === r[0] ? b(r[a]) : (r.forEach((_, g) => {
          _ === l && (n = g);
        }), b(r[n - 1]));
      }, f = (l) => {
        let n = 0;
        const r = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), a = r.length - 1;
        l === r[a] ? b(r[0]) : (r.forEach((_, g) => {
          _ === l && (n = g);
        }), b(r[n + 1]));
      }, y = (l) => {
        if (this._input) {
          const n = l.target.getAttribute("value");
          n && (this._input.value = n, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
        }
      }, v = (l) => {
        const n = l.currentTarget, r = l;
        let a = !1;
        switch (r.key) {
          case "ArrowUp":
            m(n), a = !0;
            break;
          case "ArrowDown":
            f(n), a = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const _ = l.target.querySelector("input");
            this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]')?.setAttribute("tabindex", "-1"), l.target.setAttribute("tabindex", "0"), _?.click(), a = !0;
            break;
          }
        }
        a && (l.stopPropagation(), l.preventDefault());
      }, w = {
        "option--busy": typeof c == "object" && c.state === "ocupat"
      }, O = D`
        <div class="dss-timepicker-dropdown__option ${R(w)}">
          <label
            class="dss-timepicker-dropdown__label"
            tabindex="${i ? 0 : -1}"
            @keydown=${v}
          >
            ${s && typeof c == "object" ? c.value : c}

            <input
              class="dss-timepicker-dropdown__input-radio"
              name="timeList"
              type="radio"
              @click="${y}"
              .value="${s && typeof c == "object" ? c.value : c}"
            />
						<${H} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${H}>
          </label>
        </div>
      `;
      return i = !1, O;
    });
  }
  _generateTimeManualHoursOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualMinutesOptions() {
    const t = [];
    for (let e = 0; e < 60; e += this._minutesRange) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualOptionsHTML(t, e) {
    let i = !0;
    return e.map((o) => {
      const u = (m) => {
        const f = m.target.getAttribute("value");
        f && (t === "timepickerManualHour" ? this._manualHourSelector = f : t === "timepickerManualMinutes" && (this._manualMinuteSelector = f), this.requestUpdate());
      }, c = (m) => {
        const f = m.currentTarget, y = m;
        let v = !1;
        const w = (n) => {
          n && n.focus();
        }, O = (n) => {
          let r = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), _ = a.length - 1;
          n === a[0] ? w(a[_]) : (a.forEach((g, x) => {
            g === n && (r = x);
          }), w(a[r - 1]));
        }, l = (n) => {
          let r = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), _ = a.length - 1;
          n === a[_] ? w(a[0]) : (a.forEach((g, x) => {
            g === n && (r = x);
          }), w(a[r + 1]));
        };
        switch (y.key) {
          case "ArrowUp":
            O(f), v = !0;
            break;
          case "ArrowDown":
            l(f), v = !0;
            break;
          case "Enter": {
            const r = m.target.parentElement?.querySelector("input");
            if (this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            )?.setAttribute("tabindex", "-1"), m.target.setAttribute("tabindex", "0"), r?.click(), t === "timepickerManualHour") {
              const _ = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              w(_);
            } else if (t === "timepickerManualMinutes") {
              const _ = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                _.focus();
              }, 0);
            }
            v = !0;
            break;
          }
        }
        v && (m.stopPropagation(), m.preventDefault());
      }, b = D`
        <div class="dss-timepicker-manual-item">
          <input
            id="${t + o}"
            class="dss-timepicker-manual-item__input-radio"
            name="${t}"
            type="radio"
            @click="${u}"
            .value="${o}"
          />
          <label
            for="${t + o}"
            class="dss-timepicker-manual-item__label ${t}"
            tabindex="${i ? 0 : -1}"
            @keydown=${c}
          >
            ${o}
          </label>
        </div>
      `;
      return i = !1, b;
    });
  }
  _checkDisableTimeManualSelector() {
    return this._manualHourSelector === "" || this._manualMinuteSelector === "";
  }
  /* eslint no-param-reassign: "off" */
  _timeManualSelectorCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((e) => {
      e.checked = !1;
    }), this._manualHourSelector = "", this._manualMinuteSelector = "", this._handleValidity(), this._closeDropdown();
  }
  _timeManualSelectorAccept() {
    this._input && (this._input.value = `${this._manualHourSelector}:${this._manualMinuteSelector}`, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
  }
  /* eslint no-param-reassign: "off" */
  _timeListOptionsScrollTo() {
    if (this._input) {
      const t = this._input.value.trim(), e = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
      let i = !1;
      e.forEach((s) => {
        const o = s.value;
        if (!i && o.startsWith(t)) {
          const u = s.closest("label");
          i = !0, u && (setTimeout(() => {
            u.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), o === t && (s.checked = !0));
        }
      });
    }
  }
  _timeManualOptionsScrollTo(t) {
    if (this._input) {
      const e = t ? t.trim() : this._input.value.trim();
      if (e.length <= 2) {
        const i = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
        );
        let s = !1;
        i.forEach((o) => {
          const u = o.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !s && u.startsWith(e) && (s = !0, setTimeout(() => {
            o.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), u === e && o.click());
        });
      } else {
        const i = e.slice(3), s = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
        );
        let o = !1;
        s.forEach((u) => {
          const c = u.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !o && c.startsWith(i) && (o = !0, u.scrollIntoView({
            behavior: "smooth",
            block: "center",
            inline: "nearest"
          }), c === i && u.click());
        });
      }
    }
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, s = document.createElement("canvas").getContext("2d");
    if (!s) return;
    s.font = e;
    const o = s.measureText(this._input.value).width;
    this._isTruncated = o > this._input.offsetWidth;
  }
  render() {
    return C(this);
  }
}
p([
  h({ type: String, attribute: !0 })
], d.prototype, "value", 1);
p([
  h(S)
], d.prototype, "invalid", 1);
p([
  h({ type: String })
], d.prototype, "helpText", 1);
p([
  h({ type: String })
], d.prototype, "errorTimeFormatText", 1);
p([
  h({ type: String })
], d.prototype, "errorTimeOptionText", 1);
p([
  h({ type: String })
], d.prototype, "dropdown", 1);
p([
  h(S)
], d.prototype, "showDropdown", 1);
p([
  h({ type: Number })
], d.prototype, "minutesRange", 1);
p([
  h({ type: Number })
], d.prototype, "minHour", 1);
p([
  h({ type: Number })
], d.prototype, "maxHour", 1);
p([
  h({ type: Array })
], d.prototype, "customTimeListOptions", 1);
p([
  h({ type: String })
], d.prototype, "inputSize", 2);
p([
  h({ type: String })
], d.prototype, "icon", 2);
p([
  h({ type: String })
], d.prototype, "dropdownPlacement", 2);
p([
  h(S)
], d.prototype, "dropdownFixed", 2);
export {
  d as NgTimepicker
};
//# sourceMappingURL=ng-timepicker.js.map
