import { nothing as e } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as _, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as x } from "../../api/custom-element-scope.js";
const r = _`dss-icon${l(x())}`, $ = (a) => {
  const d = {
    "dss-textarea--invalid": a._showError,
    "dss-textarea--auto-height": a.autoHeight,
    "dss-textarea--disabled": a._textarea?.disabled,
    "dss-textarea--gap": a._maxLength || !!a._description || a.size !== "sm",
    "dss-textarea--gap-sm": a.size === "sm",
    "dss-textarea--required": a._textarea?.required,
    "dss-textarea--empty-description": !a._maxLength && !a._description,
    [`dss-textarea--${a.size}`]: !!a.size
  }, i = {
    "dss-textarea__group--focused": a._textarea?.value || a._isTextareaFocused || a._textarea?.placeholder,
    // 'dss-textarea__group--focused-visible': true,
    "dss-textarea__group--focused-visible": a._isGroupFocusedVisible,
    [`dss-textarea__group--${a.size}`]: !!a.size,
    "dss-textarea__group--has-label": !!a._label,
    "dss-textarea__group--required": a._textarea?.required,
    "dss-textarea__group--readOnly": a._textarea?.readOnly,
    "dss-textarea__group--read-only-empty": a._textarea?.readOnly && a._textarea?.placeholder === "" && !a._textarea?.value
  };
  return s`
     
    <div class="dss-textarea ${t(d)}">
      ${a.size === "sm" ? s`
          <div class="dss-textarea-label">
            <slot name="label"></slot>
          </div>
        ` : e}

      <div class="dss-textarea__group ${t(i)}">
        ${a.icon ? s`
            <${r} icon="${a.icon}" class="dss-textarea-icon"></${r}>
          ` : e}
        <div class="dss-textarea__content">
          ${a.size !== "sm" ? s`
            <slot name="label"></slot>
            ` : e}
          <slot
            name="textarea"
            @focusin=${a._handleFocus}
            @focusout=${a._handleFocusOut}
          ></slot>
        </div>
      </div>
      <div class="dss-textarea__help">
        <div class="dss-textarea__description">
          <slot
            name="description"
            @slotchange=${a._handleSlotChange}
          ></slot>
        </div>
        ${a._maxLength ? s`<span
              >${a._textarea?.value?.length}/${a._maxLength}</span
            >` : null}
      </div>
    </div>
  `;
};
export {
  $ as template
};
//# sourceMappingURL=ng-textarea.template.js.map
