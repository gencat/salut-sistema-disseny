import { LitElement as l, unsafeCSS as c } from "lit";
import { property as i } from "lit/decorators.js";
import { booleanType as u } from "../../utils/property-types.js";
import _ from "./ng-textarea.style.css.js";
import { template as p } from "./ng-textarea.template.js";
var b = Object.defineProperty, f = Object.getOwnPropertyDescriptor, r = (o, t, e, h) => {
  for (var s = h > 1 ? void 0 : h ? f(t, e) : t, n = o.length - 1, d; n >= 0; n--)
    (d = o[n]) && (s = (h ? d(t, e, s) : d(s)) || s);
  return h && s && b(t, e, s), s;
};
class a extends l {
  constructor() {
    super(...arguments), this.autoHeight = !1, this.size = "lg", this.icon = void 0, this._maxLength = 0, this._isTextareaFocused = !1, this._isGroupFocusedVisible = !1, this._showError = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && this._checkAttributes();
      this.requestUpdate();
    }, this.observer = new MutationObserver(this.callback);
  }
  static get styles() {
    return c(_);
  }
  set value(t) {
    t !== void 0 && this.requestUpdate();
  }
  get value() {
    return this._textarea ? this._textarea.value : "";
  }
  set showError(t) {
    const e = this._showError;
    this._showError = t, this.requestUpdate("showError", e);
  }
  get showError() {
    return this._showError;
  }
  get _label() {
    return (this.shadowRoot?.querySelector('slot[name="label"]') || void 0)?.assignedElements()[0];
  }
  get _textarea() {
    return (this.shadowRoot?.querySelector('slot[name="textarea"]') || void 0)?.assignedElements()[0];
  }
  get _description() {
    return (this.shadowRoot?.querySelector('slot[name="description"]') || void 0)?.assignedElements()[0];
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  _checkAttributes() {
    if (this._textarea) {
      const { maxLength: t } = this._textarea;
      this._maxLength = t > 0 ? t : 0;
    }
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._checkAttributes(), this._addEventListeners(), this.autoHeight && this._updateHeight(), this.requestUpdate(), this.observer.observe(this._textarea, this.observerConfig);
    } catch (t) {
      console.error("ERROR OCURRED", t);
    }
  }
  _addEventListeners() {
    this._textarea.addEventListener("input", this._handleInput.bind(this)), this._textarea.addEventListener("focus", this._handleFocus.bind(this)), this._textarea.addEventListener("focusout", this._handleFocusOut.bind(this)), this._textarea.addEventListener("blur", this._handleBlur.bind(this)), this._label?.addEventListener("click", this._handelLabelClick.bind(this)), this._textarea.addEventListener("keyup", this._handleKeyup.bind(this));
  }
  _updateHeight() {
    this._textarea.style.height = "auto", this._textarea.style.height = `${this._textarea.scrollHeight}px`;
  }
  _handleInput() {
    this.autoHeight && this._updateHeight(), this._showError = !this._textarea.checkValidity(), this.requestUpdate();
  }
  _handleKeyup(t) {
    (t.keyCode ? t.keyCode : t.which) === 9 && this._handleFocus();
  }
  _handleFocus() {
    this._isGroupFocusedVisible = !0, this._isTextareaFocused = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._handleBlur(), this._isGroupFocusedVisible = !1, this._isTextareaFocused = !1, this.requestUpdate();
  }
  _handleBlur() {
    this._isTextareaFocused = !1, this.requestUpdate();
  }
  _handelLabelClick() {
    this._textarea.focus(), this.requestUpdate();
  }
  _handleSlotChange() {
    this.requestUpdate();
  }
  render() {
    return p(this);
  }
}
r([
  i({ type: String })
], a.prototype, "value", 1);
r([
  i(u)
], a.prototype, "showError", 1);
r([
  i(u)
], a.prototype, "autoHeight", 2);
r([
  i({ type: String })
], a.prototype, "size", 2);
r([
  i({ type: String })
], a.prototype, "icon", 2);
export {
  a as NgTextarea
};
//# sourceMappingURL=ng-textarea.js.map
