import { autoUpdate as f, offset as m, shift as y, flip as g, size as w, computePosition as b } from "@floating-ui/dom";
import { LitElement as v, unsafeCSS as c } from "lit";
import { property as i } from "lit/decorators.js";
import S from "../../shared/reset.style.css.js";
import { normalizeText as a } from "../../utils/helpers.js";
import { lazyLoading as E } from "../../utils/lazy-loading.js";
import { booleanType as d } from "../../utils/property-types.js";
import { sort as V } from "../../utils/sorting.js";
import D from "../ng-input/ng-input.style.css.js";
import q from "./ng-input-dropdown.style.css.js";
import { template as F } from "./ng-input-dropdown.template.js";
var O = Object.defineProperty, k = Object.getOwnPropertyDescriptor, l = (p, e, t, o) => {
  for (var s = o > 1 ? void 0 : o ? k(e, t) : e, r = p.length - 1, n; r >= 0; r--)
    (n = p[r]) && (s = (o ? n(e, t, s) : n(s)) || s);
  return o && s && O(e, t, s), s;
};
class h extends v {
  constructor() {
    super(), this.dropdownOffsetX = void 0, this.dropdownOffsetY = void 0, this.icon = "search", this.inputSize = "lg", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.advancedFilter = !1, this._elements = null, this._copyElements = null, this._tick = !0, this._type = "default", this._boxStyle = null, this._selectedValue = null, this._multiple = !1, this._openWithSearch = !1, this._deselectable = !1, this._placeHolder = "", this._showDropdown = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._labelSelectAll = "Seleccionar-ho tot", this._labelDeselectAll = "Deseleccionar-ho tot", this._selectAll = !1, this._selectElements = 0, this._isFocused = !1, this._helpText = "", this._invalid = !1, this._inputValidity = !0, this._filteredElements = [], this._dropdownPlaceholder = "Seleccionar", this._selectorStyle = "", this._isFiltering = !1, this._placeholderEmpty = "Escriu per cercar", this._filterThreshold = 1, this._searchThreshold = 2, this._unorder = !1, this._cleanupFloating = null, this._referenceEl = null, this._floatingEl = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (e) => {
      for (const t of e)
        t.type === "attributes" && (this._input && this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([e]) => {
        e.isIntersecting || this._showDropdown && this._closeDropdown();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._isTruncated = !1, this._isOverflowChecked = !1, this._handleInputMouseOver = () => {
      this._isOverflowChecked || (this._checkInputOverflow(), this._isOverflowChecked = !0);
    }, this._handleOutsideClick = this._handleOutsideClick.bind(this);
  }
  static get styles() {
    return [c(D), c(S), c(q)];
  }
  get _input() {
    const e = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), e?.assignedElements()[0];
  }
  get _label() {
    const e = this.shadowRoot?.querySelector('slot[name="label"]') || void 0;
    return this.requestUpdate(), e?.assignedElements()[0];
  }
  set placeHolder(e) {
    const t = this._placeHolder;
    this._placeHolder = e, this.requestUpdate("placeHolder", t);
  }
  get placeHolder() {
    return this._placeHolder;
  }
  set unorder(e) {
    const t = this._unorder;
    this._unorder = e, this.requestUpdate("unorder", t);
  }
  get unorder() {
    return this._unorder;
  }
  set elements(e) {
    const t = this._elements;
    if (this._unorder)
      this._elements = e;
    else {
      const o = V(e, "label", "asc", "string");
      this._elements = o;
    }
    e && (this._input && !this._isFiltering && (this._input.value = ""), this._filteredElements = this._getFilteredElements(), this._copyElements = [...this._elements], this._initElementsSelected(), this.requestUpdate()), this.requestUpdate("elements", t);
  }
  get elements() {
    return this._elements || [];
  }
  set multiple(e) {
    const t = this._multiple;
    this._multiple = e, this.requestUpdate("multiple", t);
  }
  get multiple() {
    return this._multiple;
  }
  set tick(e) {
    const t = this._tick;
    this._tick = e, this.requestUpdate("tick", t);
  }
  get tick() {
    return this._tick;
  }
  set openWithSearch(e) {
    const t = this._openWithSearch;
    this._openWithSearch = e, e && (this._showDropdown = e, this._updatePopperDropdown(), this._isFocused = !0), this.requestUpdate("openWithSearch", t);
  }
  get openWithSearch() {
    return this._openWithSearch;
  }
  set showDropdown(e) {
    const t = this._showDropdown;
    this._showDropdown = e, this.requestUpdate("showDropdown", t);
  }
  get showDropdown() {
    return this._showDropdown;
  }
  set deselectable(e) {
    const t = this._deselectable;
    this._deselectable = e, this.requestUpdate("deselectable", t);
  }
  get deselectable() {
    return this._deselectable;
  }
  set selectedValue(e) {
    const t = this._selectedValue;
    e && (this._selectedValue = e), this._elements && this._selectedValue && (this._selectedValue.length > 0 && (this._isFocused = !0), this._initElementsSelected()), this.requestUpdate("selectedValue", t);
  }
  get selectedValue() {
    return this._selectedValue || [];
  }
  set type(e) {
    const t = this._type;
    e === "default" || e === "green" ? this._type = e : this._type = "default", this.requestUpdate("type", t);
  }
  get type() {
    return this._type;
  }
  set boxStyle(e) {
    const t = this._boxStyle;
    this._boxStyle = e, this.requestUpdate("boxStyle", t);
  }
  get boxStyle() {
    return this._boxStyle || "";
  }
  set selectorStyle(e) {
    const t = this._selectorStyle;
    this._selectorStyle = e, this.requestUpdate("selectorStyle", t);
  }
  get selectorStyle() {
    return this._selectorStyle || "";
  }
  set labelSelectAll(e) {
    const t = this._labelSelectAll;
    e !== "" && (this._labelSelectAll = e), this.requestUpdate("labelSelectAll", t);
  }
  get labelSelectAll() {
    return this._labelSelectAll;
  }
  set labelDeselectAll(e) {
    const t = this._labelDeselectAll;
    e !== "" && (this._labelDeselectAll = e), this.requestUpdate("labelDeselectAll", t);
  }
  get labelDeselectAll() {
    return this._labelDeselectAll;
  }
  set selectAll(e) {
    const t = this._selectAll;
    this._selectAll = e, this.requestUpdate("selectAll", t);
  }
  get selectAll() {
    return this._selectAll;
  }
  set invalid(e) {
    const t = this._invalid;
    this._invalid = e, this.requestUpdate("invalid", t);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(e) {
    const t = this._helpText;
    this._helpText = e, this.requestUpdate("helpText", t);
  }
  get helpText() {
    return this._helpText;
  }
  set dropdownPlaceholder(e) {
    const t = this._dropdownPlaceholder;
    this._dropdownPlaceholder = e, this.requestUpdate("dropdownPlaceholder", t);
  }
  get dropdownPlaceholder() {
    return this._dropdownPlaceholder;
  }
  set placeholderEmpty(e) {
    const t = this._placeholderEmpty;
    this._placeholderEmpty = e, this.requestUpdate("placeholderEmpty", t);
  }
  get placeholderEmpty() {
    return this._placeholderEmpty;
  }
  set filterThreshold(e) {
    const t = this._filterThreshold;
    this._filterThreshold = e, this.requestUpdate("filterThreshold", t);
  }
  get filterThreshold() {
    return this._filterThreshold;
  }
  set searchThreshold(e) {
    const t = this._searchThreshold;
    this._searchThreshold = e, this.requestUpdate("searchThreshold", t);
  }
  get searchThreshold() {
    return this._searchThreshold;
  }
  set value(e) {
    e !== void 0 && this.requestUpdate();
  }
  get value() {
    return this._input?.value || "";
  }
  disconnectedCallback() {
    this._removeOutsideClickListener(), this.observer.disconnect(), this.visibleObserver.disconnect(), this._cleanupFloating?.(), this._cleanupFloating = null;
  }
  _addOutsideClickListener() {
    document.addEventListener("mousedown", this._handleOutsideClick);
  }
  _removeOutsideClickListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick);
  }
  _handleOutsideClick(e) {
    this._clickedOutsideDropdown(this, e);
  }
  _closeDropdown() {
    this._removeOutsideClickListener(), this._showDropdown = !1, this._isFiltering = !1, this._isFocused = !1, this._input?.blur(), this._checkTruncatedIfMultipleSelection(), this.requestUpdate(), setTimeout(() => {
      this.classList.add("animation-enabled");
    }, 400);
  }
  _getFilteredElements() {
    const e = this._elements?.filter(
      (t) => this._selectedValue?.includes(t.value)
      // Asumiendo que _selectedValue es un array de valores seleccionados
    ) || [];
    if (this._input?.value && this._input.value.length >= this._searchThreshold) {
      const t = a(this._input?.value);
      return this.advancedFilter ? this._applyAdvancedFilter(t, e) : this._applyDefaultFilter(t, e);
    }
    return this._elements;
  }
  _applyDefaultFilter(e, t) {
    if (e) {
      const o = this._elements?.filter(
        (s) => !this._selectedValue?.includes(s.value) && // Excluir elementos ya seleccionados del filtro
        a(s.label).includes(e)
      ) || [];
      return [...t, ...o];
    }
  }
  _applyAdvancedFilter(e, t) {
    const o = a(e).split(/\s+/).filter((r) => r.length >= this._searchThreshold);
    if (o.length === 0)
      return [...t];
    const s = this._elements?.filter(
      (r) => !this._selectedValue?.includes(r.value) && // Excluir seleccionados
      o.every((n) => a(r.label).includes(n))
    ) || [];
    return [...t, ...s];
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this.classList.add("animation-enabled"), this._input && (this._input.classList.add("dss-input-skip-native"), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input), this._checkInputAttributes()), this._elements && (this._filteredElements = this._getFilteredElements(), this._initElementsSelected()), this._openWithSearch && this._input && (this._input.value = "", this._input?.getAttribute("placeholder") || this._input.setAttribute("placeholder", this._dropdownPlaceholder)), E(this, () => {
        this._checkTruncatedIfMultipleSelection();
      }), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _checkTruncatedIfMultipleSelection() {
    this._multiple && this._selectedValue && this._selectedValue.length > 1 && (this._checkInputOverflow(), this._isOverflowChecked = !0);
  }
  _initElementsSelected() {
    this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []), this._isOverflowChecked = !1, (!this._multiple || this._multiple && this._selectedValue && this._selectedValue.length <= 1) && (this._isTruncated = !1);
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const e = window.getComputedStyle(this._input), t = `${e.fontWeight} ${e.fontSize} ${e.fontFamily}`, s = document.createElement("canvas").getContext("2d");
    if (!s) return;
    s.font = t;
    const r = Number.parseFloat(e.paddingLeft), n = Number.parseFloat(e.paddingRight), u = this._input.offsetWidth - r - n, _ = s.measureText(this._input.value).width;
    this._isTruncated = _ > u;
  }
  _clickedOutsideDropdown(e, t) {
    this._showDropdown && (t.composedPath().includes(e) || (this._input && (this._input.value = "", this._isFiltering = !1), this._elements?.length && (this._initElementsSelected(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())), this._elements?.length || (this._input?.removeAttribute("placeholder"), this._placeHolder = ""), this._hidePlaceholder(), this._closeDropdown()));
  }
  _handleInput() {
    this._isFiltering = !0, this._filteredElements = this._getFilteredElements(), this.requestUpdate();
  }
  _handleBlurEsc() {
    this._readonly || this._openWithSearch || this._closeDropdown();
  }
  _handleBlurSelector(e, t) {
    if (e !== t.target) {
      if (this._openWithSearch)
        return;
      this._input?.focus(), this._handleBlurEsc(), this._showSelectValuesInInput(this._selectedValue ? this._selectedValue : []);
    }
  }
  _toggleDropdown() {
    this._elements?.length && this._showDropdown && this._input ? (this._initElementsSelected(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : this._elements?.length && !this._showDropdown && this._input && (this._input.value = "", this._showPlaceholder(), this._input?.focus()), this._showDropdown = !this._showDropdown, this._showDropdown && (this._floatingEl ? this._updatePopperDropdown() : this._createPopperDropdown(), this._addOutsideClickListener()), !this._elements?.length && !this._showDropdown && (this._input?.removeAttribute("placeholder"), this._placeHolder = "", this._isFiltering = !1, this._isFocused = !1), this.requestUpdate();
  }
  _getSelectedItems() {
    return !this._selectedValue || this._selectedValue.length <= 0 ? [] : this._elements?.filter((e) => this._selectedValue?.includes(e.value));
  }
  _dispatchValueChange() {
    if (this._input) {
      const e = {
        detail: {
          inputValue: this._input.value,
          selectedValue: this._selectedValue,
          selectedItems: this._getSelectedItems()
        },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onInputDropdownChange", e));
    }
  }
  _onSelectorChanges(e) {
    !this._multiple && !this._openWithSearch && (this._isFiltering = !1);
    const t = e.detail;
    this._selectedValue = typeof t == "string" ? [e.detail] : e.detail, !this._multiple && !this._disabled && (this._openWithSearch || (this._closeDropdown(), this._initElementsSelected()), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _showSelectValuesInInput(e) {
    !this._multiple && Array.isArray(e) && e.length > 1 && e.splice(1);
    const t = this._elements?.filter((s) => e.includes(s.value));
    if (this._elements = [...this._copyElements], this._openWithSearch ? this._selectElements = 0 : this._selectElements = t?.length ? t.length : 0, t && t.length > 0) {
      const s = this._elements.filter((r) => t.includes(r));
      s.push(...this._elements.filter((r) => !t.includes(r))), this._elements = [...s], this._filteredElements = this._elements;
    }
    if (!this._multiple && this._input && !this._isFiltering) {
      this._input.value = t?.[0]?.label ?? "", this._deselectable && this._input.value === "" && (this._filteredElements = [...this._copyElements]);
      return;
    }
    const o = t?.map((s) => s.label);
    this._input && !this._isFiltering && (this._input.value = o?.join(", ") ?? "");
  }
  _checkInputAttributes() {
    const e = this._input?.getAttribute("placeholder");
    e && (this._placeHolder = e);
    const t = this._input?.getAttribute("readonly");
    this._readonly = t !== null;
    const o = this._input?.getAttribute("disabled");
    this._disabled = o !== null;
    const s = this._input?.getAttribute("required");
    this._required = s !== null, this._input?.value && this._input?.value !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this.requestUpdate();
  }
  _handleFocusOut(e) {
    const t = e.relatedTarget;
    if (t instanceof HTMLElement && t.contains(this)) return;
    const o = this.shadowRoot?.querySelector("dss-selector"), s = this.shadowRoot?.querySelector(".dss-input-dropdown__toggle"), r = this.shadowRoot?.querySelector("dss-chip");
    t !== null && t !== this._input && t !== o && t !== s && t !== r && (this._selectedValue && this._initElementsSelected(), this._hidePlaceholder(), this._closeDropdown()), this.requestUpdate();
  }
  _handleKeyDown(e) {
    e?.key === "Enter" ? this._showDropdown ? this._keyboardFilterMatch() : this._handleClick() : e?.key === "Escape" ? (this._closeDropdown(), this._initElementsSelected(), this._hidePlaceholder(), (!this._selectedValue || this._selectedValue.length <= 0) && (this._filteredElements = this._getFilteredElements())) : e?.key === "ArrowDown" || e?.key === "ArrowUp" ? (e.preventDefault(), e.stopPropagation(), (this.shadowRoot?.querySelector("#dss-selector")).moveFocus()) : e?.key !== "Tab" && (this._showDropdown || this._handleClick()), this.requestUpdate();
  }
  _handleClick() {
    !this._disabled && !this._readonly && (this._input && (!this._openWithSearch && !this._isFiltering && (this._input.value = ""), this._showPlaceholder()), this._isFocused = !0, this._showDropdown = !0, this._floatingEl ? this._updatePopperDropdown() : (this._createPopperDropdown(), this.requestUpdate()), this._addOutsideClickListener(), this.requestUpdate());
  }
  _focusInput() {
    this._input?.focus(), this._handleClick();
  }
  _keyboardFilterMatch() {
    if (!this._filteredElements?.find(
      (o) => o.label.toLowerCase() === this._input?.value.toLowerCase()
    )) return;
    const t = this.shadowRoot?.querySelector("#dss-selector");
    t && t.selectFirstMatch();
  }
  _showPlaceholder() {
    !this._placeHolder && !this._elements?.length ? this._input?.setAttribute("placeholder", this._placeholderEmpty) : !this._placeHolder && this._elements?.length && this._input?.setAttribute("placeholder", this._dropdownPlaceholder);
  }
  _hidePlaceholder() {
    this._placeHolder || this._input?.removeAttribute("placeholder");
  }
  _handleValidity() {
    const e = this._input?.checkValidity();
    e !== void 0 && (this._inputValidity = e);
  }
  _cleanInput() {
    this._input && (this._isFiltering = !1, this._input.value = "", this._filteredElements = this._getFilteredElements(), this.requestUpdate());
  }
  _createPopperDropdown() {
    if (this._openWithSearch) return;
    const e = this.shadowRoot?.querySelector(".dss-input-group"), t = this.shadowRoot?.querySelector(".dss-selector");
    !e || !t || (this._referenceEl = e, this._floatingEl = t, this._cleanupFloating?.(), this._cleanupFloating = f(this._referenceEl, this._floatingEl, () => this._updatePopperDropdown()));
  }
  async _updatePopperDropdown() {
    if (!this._referenceEl || !this._floatingEl) return;
    const e = [];
    !this.dropdownOffsetX && !this.dropdownOffsetY && e.push(m(4)), e.push(y({ padding: 8 })), e.push(g()), e.push(
      w({
        apply: ({ rects: u }) => {
          Object.assign(this._floatingEl.style, {
            width: `${u.reference.width}px`
          });
        }
      })
    );
    const { x: t, y: o, strategy: s } = await b(this._referenceEl, this._floatingEl, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: e
    });
    let r = t, n = o;
    this.dropdownOffsetX !== void 0 && this.dropdownOffsetY !== void 0 && (r = this.dropdownOffsetX, n = this.dropdownOffsetY), Object.assign(this._floatingEl.style, {
      position: s,
      left: `${r}px`,
      top: `${n}px`,
      transform: "none"
    }), setTimeout(() => {
      this.classList.remove("animation-enabled");
    }, 400);
  }
  render() {
    return F(this);
  }
}
l([
  i({ type: Number })
], h.prototype, "dropdownOffsetX", 2);
l([
  i({ type: Number })
], h.prototype, "dropdownOffsetY", 2);
l([
  i({ type: String })
], h.prototype, "icon", 2);
l([
  i({ type: String })
], h.prototype, "placeHolder", 1);
l([
  i(d)
], h.prototype, "unorder", 1);
l([
  i({ type: Array })
], h.prototype, "elements", 1);
l([
  i(d)
], h.prototype, "multiple", 1);
l([
  i(d)
], h.prototype, "tick", 1);
l([
  i(d)
], h.prototype, "openWithSearch", 1);
l([
  i(d)
], h.prototype, "showDropdown", 1);
l([
  i(d)
], h.prototype, "deselectable", 1);
l([
  i({ type: Array })
], h.prototype, "selectedValue", 1);
l([
  i({ type: String })
], h.prototype, "type", 1);
l([
  i({ type: String })
], h.prototype, "boxStyle", 1);
l([
  i({ type: String })
], h.prototype, "selectorStyle", 1);
l([
  i({ type: String })
], h.prototype, "labelSelectAll", 1);
l([
  i({ type: String })
], h.prototype, "labelDeselectAll", 1);
l([
  i(d)
], h.prototype, "selectAll", 1);
l([
  i(d)
], h.prototype, "invalid", 1);
l([
  i({ type: String })
], h.prototype, "inputSize", 2);
l([
  i({ type: String })
], h.prototype, "helpText", 1);
l([
  i({ type: String })
], h.prototype, "dropdownPlaceholder", 1);
l([
  i({ type: String })
], h.prototype, "placeholderEmpty", 1);
l([
  i({ type: Number })
], h.prototype, "filterThreshold", 1);
l([
  i({ type: Number })
], h.prototype, "searchThreshold", 1);
l([
  i({ type: String })
], h.prototype, "value", 1);
l([
  i({ type: String })
], h.prototype, "dropdownPlacement", 2);
l([
  i(d)
], h.prototype, "dropdownFixed", 2);
l([
  i(d)
], h.prototype, "advancedFilter", 2);
export {
  h as NgInputDropdown
};
//# sourceMappingURL=ng-input-dropdown.js.map
