import { nothing as a } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { ifDefined as S } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as d, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const _ = d`dss-icon${e(i())}`, u = d`dss-icon-button${e(i())}`, $ = d`dss-selector${e(i())}`, h = d`dss-chip${e(i())}`, b = d`dss-tooltip${e(i())}`, k = (s) => {
  const p = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s._required,
    "dss-input-wrapper--disabled": s._disabled,
    [`dss-input-wrapper--${s.inputSize}`]: !!s.inputSize
  }, w = {
    "dss-input-group": !0,
    [`dss-input-group--${s.inputSize}`]: !!s.inputSize,
    "dss-input-group--invalid": s._invalid || !s._inputValidity,
    "dss-input-group--required": s._required,
    "dss-input-group--disabled": s._disabled,
    "dss-input-group--focused": s._input?.value || s._placeHolder || s._isFocused,
    "dss-input-group--read-only": s._readonly,
    "dss-input-group--no-label": !s._label,
    "dss-input-group--read-only-empty": s._input?.readOnly && s._input?.placeholder === "" && !s._input?.value
  }, v = {
    "dss-input-help": !0,
    "dss-input-help--invalid": s._invalid,
    "dss-input-help--disabled": s._disabled
  }, g = {
    "dss-selector": !s._openWithSearch,
    "dss-selector--visible": s._showDropdown,
    "dss-selector--open-with-search": s._openWithSearch,
    "dss-selector--disabled": s._disabled,
    "dss-selector-dropdown": !0,
    "dss-selector--md": !s._openWithSearch && s.inputSize === "md",
    "dss-selector--loading": !s._floatingEl && !s.openWithSearch
  };
  return l`

    <div class="${r(p)}" style=${S(s._boxStyle ?? void 0)}>

      ${s.inputSize === "sm" ? l`
        <div class="dss-wrapper-label">
          <slot name="label" @click=${s._focusInput}></slot>
        </div>
        ` : a}

      <div class="dss-input-dropdown-wrapper">
        <div class="${r(w)}">

          ${s.icon && s.icon !== "" ? l`
            <${_} icon="${s.icon}" class="dss-input-icon"></${_}>
            ` : a}

          <div 
            class="dss-input-field"
            data-truncated="${!s.showDropdown && s._isTruncated && s.selectedValue && s.selectedValue?.length === 1}"
          >
            ${s.inputSize !== "sm" ? l`
              <slot name="label" @click=${s._focusInput}></slot>
              ` : a}
            <slot name="input"
              @click=${s._handleClick}
              @input=${s._handleInput}
              @focusin=${s._handleFocusIn}
              @focusout=${s._handleFocusOut}
              @keydown=${s._handleKeyDown}
              @mouseover=${s._handleInputMouseOver}
            ></slot>

             <${b}>${s._input?.value}</${b}>


          </div>

          ${s.multiple && s._isTruncated && s._selectedValue && s._selectedValue?.length > 1 ? l`
              <${h}
                label="${s._selectedValue.length}"
                size="xs"
                ?selected=${s._showDropdown}
                @onToggle=${s._toggleDropdown}>
              </${h}>
            ` : null}

          ${!s._openWithSearch && !s._readonly ? l`
                <${u}
                  class="dss-icon-button dss-input-dropdown__toggle"
                  size="md"
                  icon="${s._showDropdown ? "keyboard_arrow_up" : "keyboard_arrow_down"}"
                  label="${s._showDropdown ? "Tancar dropdown" : "Obrir dropdown"}"
                  hideTooltip
                  ariaExpanded="${s._showDropdown}"
                  variant="primary"
                  ?disabled=${s._disabled}
                  disableTabindex
                  @onClick=${s._toggleDropdown}
                ></${u}>
              ` : s._openWithSearch ? l`
                <${u}
                  class="dss-icon-button dss-input-dropdown__toggle"
                  size="md"
                  label="Esborra la selecció"
                  hideTooltip
                  icon="close"
                  variant="primary"
                  ?disabled=${s._disabled || s._readonly}
                  disableTabindex
                  @onClick=${s._cleanInput}
                ></${u}>
              ` : a}
          </div>

          <${$}
            ariaLabel="Llista d'elements"
            id="dss-selector"
            class="${r(g)}"
            .isOpen=${s._showDropdown || s._openWithSearch}
            .multiple=${s._multiple}
            .tick=${s._tick}
            .deselectable=${s._deselectable}
            .disabled=${s._disabled}
            .elements=${s._filteredElements}
            .filtre=${s._input?.value}
            .filterThreshold=${s._filterThreshold}
            .searchThreshold=${s._searchThreshold}
            .selectedValue=${s._selectedValue}
            .type=${s._type}
            .labelSelectAll=${s._labelSelectAll}
            .labelDeselectAll=${s._labelDeselectAll}
            .selectAll=${s._selectAll}
            ?advancedFilter=${s.advancedFilter}
            isDisplayed=${s._showDropdown}
            elementsSelected=${s._selectElements}
            boxStyle=${s._selectorStyle}
            boxShadow
            @onValueChange="${s._onSelectorChanges}"
            @keydown="${(t) => {
    t.key === "Escape" && s._handleBlurSelector(void 0, t);
  }}"
            @focusout=${s._handleFocusOut}
            ?readonly=${s._readonly}
          >
          </${$}>

      </div>

      ${s._helpText && !s._openWithSearch ? l`
            <div class="${r(v)}">
              <span>${s._helpText}</span>
            </div>
          ` : null}

    </div>
  `;
};
export {
  k as template
};
//# sourceMappingURL=ng-input-dropdown.template.js.map
