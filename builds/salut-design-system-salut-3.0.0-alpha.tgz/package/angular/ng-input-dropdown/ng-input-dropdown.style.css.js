const s = ".dss-selector{opacity:0;visibility:hidden;z-index:999}:host(.animation-enabled) .dss-selector{transition:opacity var(--animation-delay) ease-out,visibility var(--animation-delay) ease-out}.dss-selector--visible{opacity:1;visibility:visible}.dss-selector--open-with-search{display:block;margin-top:var(--dss-spacing-xxs)}.dss-selector--md{top:44px}.dss-input-group:has(dss-chip:focus-within){outline:0;border-color:var(--color-neutral-100)}.dss-input-group.dss-input-group--read-only:has(dss-chip:focus-within){outline:0;border-top-color:transparent;border-left-color:transparent;border-right-color:transparent;border-radius:0}.dss-selector--loading{position:absolute}";
export {
  s as default
};
//# sourceMappingURL=ng-input-dropdown.style.css.js.map
