import { LitElement as d, unsafeCSS as p } from "lit";
import { property as n, state as c } from "lit/decorators.js";
import { deleteSeparatorMask as _, applyMask as v } from "../../utils/mask.js";
import { booleanType as u } from "../../utils/property-types.js";
import { inputActionTemplate as m } from "./ng-input-action.template.js";
import y from "../ng-input/ng-input.style.css.js";
import f from "./ng-input-action.style.css.js";
var g = Object.defineProperty, b = Object.getOwnPropertyDescriptor, i = (r, t, e, o) => {
  for (var a = o > 1 ? void 0 : o ? b(t, e) : t, h = r.length - 1, l; h >= 0; h--)
    (l = r[h]) && (a = (o ? l(t, e, a) : l(a)) || a);
  return o && a && g(t, e, a), a;
};
class s extends d {
  constructor() {
    super(...arguments), this.icon = "add_box", this.inputSize = "lg", this.maskRegex = void 0, this.maskReplace = void 0, this.allowedChars = void 0, this.unit = void 0, this.inputPrefix = void 0, this._label = "Label", this._placeholder = "", this._maxLength = void 0, this._invalid = !1, this._helpText = "", this._isFocused = !1, this._isTypeNumeric = !1, this._inputValidity = !0, this._removeMinWidth = !1, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this._previousValue = void 0, this._isTruncated = !1, this.intervalId = null;
  }
  static get styles() {
    return [p(y), p(f)];
  }
  get _input() {
    const t = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  get _labelSlot() {
    return (this.shadowRoot?.querySelector('slot[name="label"]') || void 0)?.assignedElements()[0];
  }
  get _action() {
    const t = this.shadowRoot?.querySelector('slot[name="action"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  get _secondaryAction() {
    const t = this.shadowRoot?.querySelector('slot[name="secondaryAction"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set label(t) {
    const e = this._label;
    this._label = t, this.requestUpdate("label", e);
  }
  get label() {
    return this._label;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set removeMinWidth(t) {
    const e = this._removeMinWidth;
    this._removeMinWidth = t, this.requestUpdate("removeMinWidth", e);
  }
  get removeMinWidth() {
    return this._removeMinWidth;
  }
  set value(t) {
    t !== void 0 && this.requestUpdate();
  }
  get value() {
    return this._input?.value || "";
  }
  disconnectedCallback() {
    this.observer.disconnect();
  }
  _handleClick() {
    this.requestUpdate();
  }
  _handleInput() {
    if (this._isTypeNumeric && this._maxLength && this._input && (this._input.value = this._input.value.slice(0, this._maxLength)), this.maskRegex && this.maskReplace && this._input) {
      this._previousValue && this._previousValue.length > this._input?.value.length && (this._input.value = _(this._previousValue, this._input.value, this.maskReplace));
      const t = v(this._input.value, this.maskRegex, this.maskReplace, this.allowedChars);
      t !== this._input.value && (this._input.value = t);
    }
    this._previousValue = this._input?.value, this._handleValidity(), this.requestUpdate();
  }
  _handleFocusIn() {
    this._isFocused = !0, this.requestUpdate();
  }
  _handleFocusOut() {
    this._isFocused = !1, this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    this._input?.focus();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _stepUp() {
    this._input?.stepUp(), this._handleValidity(), this._dispatchValueChange(), this.requestUpdate();
  }
  _stepDown() {
    this._input?.stepDown(), this._handleValidity(), this._dispatchValueChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    if (this._input) {
      const t = {
        detail: this._input.value,
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onInputChange", t));
    }
  }
  _checkInputAttributes() {
    const t = this._input?.getAttribute("placeholder");
    t && (this._placeholder = t), this._input?.getAttribute("type") === "number" && (this._isTypeNumeric = !0);
    const e = this._input?.getAttribute("maxlength");
    this._maxLength = e ? +e : void 0, this._input?.value && this._input?.value !== "" && this._handleValidity();
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, a = document.createElement("canvas").getContext("2d");
    if (!a) return;
    a.font = e;
    const h = a.measureText(this._input.value).width;
    this._isTruncated = h > this._input.offsetWidth;
  }
  _onHold(t) {
    this.intervalId = window.setInterval(() => {
      t === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this.intervalId !== null && (clearInterval(this.intervalId), this.intervalId = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig)), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return m(this);
  }
}
i([
  n({ type: String })
], s.prototype, "label", 1);
i([
  n({ type: String })
], s.prototype, "icon", 2);
i([
  n({ type: String })
], s.prototype, "inputSize", 2);
i([
  n({ type: String })
], s.prototype, "helpText", 1);
i([
  n(u)
], s.prototype, "invalid", 1);
i([
  n(u)
], s.prototype, "removeMinWidth", 1);
i([
  n({ type: String })
], s.prototype, "value", 1);
i([
  n({ type: String })
], s.prototype, "maskRegex", 2);
i([
  n({ type: String })
], s.prototype, "maskReplace", 2);
i([
  n({ type: String })
], s.prototype, "allowedChars", 2);
i([
  n({ type: String })
], s.prototype, "unit", 2);
i([
  n({ type: String })
], s.prototype, "inputPrefix", 2);
i([
  c()
], s.prototype, "intervalId", 2);
export {
  s as NgInputAction
};
//# sourceMappingURL=ng-input-action.js.map
