import { classMap as d } from "lit/directives/class-map.js";
import { ifDefined as c } from "lit/directives/if-defined.js";
import { unsafeStatic as i, literal as r, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const l = r`dss-icon${i(e())}`, b = r`dss-spinner${i(e())}`, h = r`dss-tooltip${i(e())}`, t = r`dss-icon-button${i(e())}`, w = (s) => {
  const _ = {
    "dss-search-bar--invalid": s._invalid || !s._inputValidity,
    "dss-search-bar--disabled": s._input?.disabled,
    "dss-search-bar--required": s._input?.required,
    "dss-search-bar--read-only": s._input?.readOnly,
    "dss-search-bar--focused": s._isFocused,
    "dss-search-bar--default": !s._multiple,
    "dss-search-bar--multiple": s._multiple,
    "dss-search-bar--show-chips": s._showAllChips,
    "dss-search-bar--md": s._inputSize === "md",
    "dss-search-bar--inner-focus": s.innerFocus,
    "dss-search-bar--has-value": s._showClearButton || s._input?.value || s._searchTerms.length > 0
  }, u = {}, $ = {};
  return a`
    <div class="dss-search">
        <div
          class="dss-search-bar ${d(_)}"
          role="combobox"
          aria-controls="search-catalog"
          aria-expanded=${c(s._showDropdown)}
        >
          <div class="dss-search-bar__icon">
            <${l} size="md" icon="${s._icon}"  @click=${s._focusInput}></${l}>
          </div>

          <div class="dss-search-bar__container">
            ${s._multiple ? a`
                  <div class="dss-search-bar__chips">
                    ${a`${s._generateSearchChips()}`}
                    ${!s._showAllChips && s._searchTerms.length > 5 ? a`
                          <div class="dss-chip__counter">
                            +${s._searchTerms.length - 5}
                            <${h}
                              class="dss-chip__tooltip"
                              position="bottom"
                              align="left"
                              noHeightLimit
                            >
                              ${s._searchTerms.slice(5, s._searchTerms.length).map(
    (v) => a`<span class="dss-chip__tooltip-item">
                                        ${v}
                                      </span>`
  )}
                            </${h}>
                          </div>
                        ` : null}
                  </div>
                ` : null}

            <div class="dss-search-bar__input">
              <slot name="label" @click=${s._focusInput}></slot>
              <slot
                name="input"
                @click=${s._handleClick}
                @input=${s._handleInput}
                @keydown=${s._handleKeyDown}
                @focusin=${s._handleFocusIn}
                @focusout=${s._handleFocusOut}
              ></slot>
            </div>
          </div>

          <div class="dss-search-bar__clear">
            <${t} 
              icon="cancel" 
              variant="primary" 
              size="md" 
              @click=${s._clearSearch}
              hideTooltip
              label="Esborra la cerca"
            >
            </${t}>
          </div>
        </div>

        ${s._helpText ? a`
              <div class="dss-search-help ${d(u)}">
                <span>${s._helpText}</span>
              </div>
            ` : null}
        ${s._showDropdown && s._catalog?.length > 0 && s._input.value.length >= s._threshold ? a`
              <div
                id="search-catalog"
                class="dss-search-dropdown ${d($)}"
                style=${c(s._searchboxStyle)}
                role="listbox"
                aria-label="Search Catalog"
              >
                ${s._isCatalogLoading ? a`
                      <div class="dss-search-catalog--empty">
											  <${b} size="md"/>
                      </div>
                    ` : a`
                      ${s._filteredCatalog.length > 0 ? a`
                            ${s._recentSearches ? a`
                                  <div class="dss-search-title">
                                    ${s._recentSearchesText}
                                  </div>
                                ` : null}
                            <div class="dss-search-catalog">
                              ${a`${s._generateFilterCatalog()}`}
                            </div>
                          ` : a`
                            <div
                              class="dss-search-catalog dss-search-catalog--empty"
                            >
                              <${l} size="sm" icon="info"></${l}>
                              <span class="text">
                                ${s._emptyDropdownText}: ${s._input.value}
                              </span>
                            </div>
                          `}
                    `}
              </div>
            ` : null}
      </div>
  `;
};
export {
  w as template
};
//# sourceMappingURL=ng-search-bar.template.js.map
