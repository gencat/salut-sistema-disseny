import { LitElement as d, unsafeCSS as c } from "lit";
import { property as s } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import u from "./ng-radio-button.style.css.js";
import { template as m } from "./ng-radio-button.template.js";
var f = Object.defineProperty, o = (i, r, e, v) => {
  for (var t = void 0, l = i.length - 1, n; l >= 0; l--)
    (n = i[l]) && (t = n(r, e, t) || t);
  return t && f(r, e, t), t;
};
class a extends d {
  constructor() {
    super(...arguments), this.label = "", this.value = !1, this.checked = !1, this.disabled = !1;
  }
  static get styles() {
    return [c(h), c(u)];
  }
  handleInput(r) {
    const e = r.target;
    this.checked = e.checked, this.value = e.checked, this.dispatchEvent(
      new CustomEvent("onChange", {
        detail: { value: e.value, checked: this.checked },
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    return m(this);
  }
}
o([
  s({ type: String })
], a.prototype, "label");
o([
  s(p)
], a.prototype, "value");
o([
  s(p)
], a.prototype, "checked");
o([
  s(p)
], a.prototype, "disabled");
export {
  a as NgRadioButton
};
//# sourceMappingURL=ng-radio-button.js.map
