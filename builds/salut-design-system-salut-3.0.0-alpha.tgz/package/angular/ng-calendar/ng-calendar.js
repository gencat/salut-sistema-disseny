import { LitElement as R, unsafeCSS as f } from "lit";
import { html as y } from "lit/static-html.js";
import { property as o } from "lit/decorators.js";
import { classMap as M } from "lit/directives/class-map.js";
import { booleanType as S } from "../../utils/property-types.js";
import { startOfMonth as v, endOfMonth as T, eachDayOfInterval as F, getDay as Y } from "date-fns";
import O from "../../components/button/button.style.css.js";
import x from "../../components/icon-button/icon-button.style.css.js";
import k from "../../foundations/icon/icon.style.css.js";
import q from "./ng-calendar.style.css.js";
import { template as L } from "./ng-calendar.template.js";
var C = Object.defineProperty, U = Object.getOwnPropertyDescriptor, h = (E, t, e, r) => {
  for (var s = r > 1 ? void 0 : r ? U(t, e) : t, _ = E.length - 1, u; _ >= 0; _--)
    (u = E[_]) && (s = (r ? u(t, e, s) : u(s)) || s);
  return r && s && C(t, e, s), s;
};
const p = [
  "Gener",
  "Febrer",
  "Març",
  "Abril",
  "Maig",
  "Juny",
  "Juliol",
  "Agost",
  "Setembre",
  "Octubre",
  "Novembre",
  "Desembre"
], G = ["dl", "dm", "dc", "dj", "dv", "ds", "dg"];
class c extends R {
  constructor() {
    super(), this.customCalendar = void 0, this._range = !1, this._isRangeStartFocused = !1, this._isRangeEndFocused = !1, this._rangeStartDate = null, this._rangeEndDate = null, this._rangeOverDate = null, this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._timepickerLabel = "", this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._days = this._getDays(), this._selectedDate = null, this._showTime = !1, this._showButtons = !0, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._minDate = null, this._maxDate = null, this._timepickerValue = "", this._showMonthSelector = !1, this._showYearSelector = !1, this._yearsRangeStart = (/* @__PURE__ */ new Date()).getFullYear() - 18, this._yearsRangeEnd = (/* @__PURE__ */ new Date()).getFullYear() + 1, this._isTimeFormatValid = !1, this._focusFirstElementHandler = this._focusFirstElement.bind(this);
  }
  static get styles() {
    return [f(k), f(O), f(x), f(q)];
  }
  set range(t) {
    const e = this._range;
    this._range = t, this.requestUpdate("range", e);
  }
  get range() {
    return this._range;
  }
  set isRangeStartFocused(t) {
    const e = this._isRangeStartFocused;
    this._isRangeStartFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeStartFocused() {
    return this._isRangeStartFocused;
  }
  set isRangeEndFocused(t) {
    const e = this._isRangeEndFocused;
    this._isRangeEndFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeEndFocused() {
    return this._isRangeEndFocused;
  }
  set selectedDate(t) {
    const e = this._selectedDate;
    this._selectedDate = this._getDateString(t), this._updateCurrentDate(), this.requestUpdate("selectedDate", e);
  }
  get selectedDate() {
    return this._selectedDate?.toString() || "";
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = this._getDateString(t), this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate?.toString() || "";
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = this._getDateString(t), this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate?.toString() || "";
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set rangeStartDate(t) {
    const e = this._rangeStartDate;
    this._rangeStartDate = this._getDateString(t), this.requestUpdate("rangeStartDate", e);
  }
  get rangeStartDate() {
    return this._rangeStartDate?.toString() || "";
  }
  set rangeEndDate(t) {
    const e = this._rangeEndDate;
    this._rangeEndDate = this._getDateString(t), this.requestUpdate("rangeEndDate", e);
  }
  get rangeEndDate() {
    return this._rangeEndDate?.toString() || "";
  }
  connectedCallback() {
    super.connectedCallback(), this._range && window.addEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._range && window.removeEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  _focusFirstElement() {
    this.shadowRoot?.querySelector("#firstCalendarElement")?.focus();
  }
  _prev() {
    this._currMonth -= 1, this._update();
  }
  _next() {
    this._currMonth += 1, this._update();
  }
  _update() {
    (this._currMonth < 0 || this._currMonth > 11) && (this._date = new Date(this._currYear, this._currMonth, (/* @__PURE__ */ new Date()).getDate()), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth()), this._days = this._getDays(), this.requestUpdate();
  }
  _getDays() {
    const t = [], e = v(new Date(this._currYear, this._currMonth)), r = T(new Date(this._currYear, this._currMonth)), s = F({ start: e, end: r }), _ = Y(e);
    for (let u = _ === 0 ? 6 : _ - 1; u > 0; u -= 1)
      t.push(0);
    for (const u of s)
      t.push(u.getDate());
    return t;
  }
  _getCustomType(t) {
    if (!this.customCalendar) return !1;
    const r = new Date(this._currYear, this._currMonth, t).toLocaleDateString("es-ES"), s = this.customCalendar.find((_) => _.date === r);
    return s ? s.type : !1;
  }
  _isToday(t) {
    const e = /* @__PURE__ */ new Date();
    return t === e.getDate() && this._currMonth === e.getMonth() && this._currYear === e.getFullYear();
  }
  _isWeekend(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return e.getDay() === 0 || e.getDay() === 6;
  }
  _isInactive(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return t ? this._minDate && this._maxDate ? !(e >= this._minDate && e <= this._maxDate) : this._minDate ? !(e >= this._minDate) : this._maxDate ? !(e <= this._maxDate) : !1 : !0;
  }
  _isSelected(t) {
    return this._range ? t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() || this._isSelectedRangeEnd(t) : t === this._selectedDate?.getDate() && this._currMonth === this._selectedDate?.getMonth() && this._currYear === this._selectedDate?.getFullYear();
  }
  _isFocusable(t) {
    return this._range && (this._rangeStartDate || this._rangeEndDate) ? this._isSelectedRangeStart(t) || this._isSelectedRangeEnd(t) : this._selectedDate ? this._isSelected(t) : this._isToday(t);
  }
  _isSelectedRangeStart(t) {
    return this._range && this._rangeStartDate && this._rangeEndDate ? !this._compareSelectedRangeDates() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() : this._range && this._rangeStartDate && !this._rangeEndDate ? this._rangeOverDate !== null && this._rangeStartDate?.getTime() < this._rangeOverDate?.getTime() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : (this._range && this._rangeStartDate === this._rangeEndDate, !1);
  }
  _isSelectedRangeEnd(t) {
    return !this._compareSelectedRangeDates() && t === this._rangeEndDate?.getDate() && this._currMonth === this._rangeEndDate?.getMonth() && this._currYear === this._rangeEndDate?.getFullYear();
  }
  _isOverRangeDate(t) {
    const e = t === this._rangeOverDate?.getDate() && this._currMonth === this._rangeOverDate?.getMonth() && this._currYear === this._rangeOverDate?.getFullYear();
    return this._range && this._rangeOverDate && this._rangeStartDate && !this._rangeEndDate ? e && this._rangeOverDate.getTime() > this._rangeStartDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _compareSelectedRangeDates() {
    return this._rangeStartDate && this._rangeEndDate ? this._rangeStartDate.getFullYear() === this._rangeEndDate.getFullYear() && this._rangeStartDate.getMonth() === this._rangeEndDate.getMonth() && this._rangeStartDate.getDate() === this._rangeEndDate.getDate() : !0;
  }
  _isBetweenRange(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return !this._isInactive(t) && this._rangeStartDate && this._rangeEndDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() : !1;
  }
  _isBetweenRangeOnMouseOver(t) {
    const e = new Date(this._currYear, this._currMonth, t), r = this._isInactive(t);
    return !r && this._rangeStartDate && !this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !r && this._rangeStartDate && this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _selectDate(t) {
    this._selectedDate = new Date(this._currYear, this._currMonth, t), this._range && !this._showButtons && (this._rangeStartDate && this._rangeEndDate && !this._isRangeEndFocused && this._selectedDate.getTime() >= this._rangeEndDate.getTime() && (this._rangeStartDate = null, this._rangeEndDate = null), this._isRangeStartFocused || !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this._range && this._showButtons && (this._rangeStartDate && this._rangeEndDate && (this._rangeStartDate = null, this._rangeEndDate = null), !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this.requestUpdate(), !this._showButtons && (this._range ? this._emitRange() : this._emitDate());
  }
  _selectRangeOverDate(t) {
    this._range && (this._rangeOverDate = new Date(this._currYear, this._currMonth, t), this.requestUpdate());
  }
  _removeRangeOverDate() {
    this._rangeOverDate = null, this.requestUpdate();
  }
  _onCancel() {
    const t = new CustomEvent("onCancel", {
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(t);
  }
  _onAccept() {
    this._range ? this._emitRange() : this._emitDate();
  }
  _emitDate() {
    const t = this._selectedDate?.getDate()?.toString().padStart(2, "0"), e = (this._currMonth + 1).toString().padStart(2, "0");
    let r = `${t}/${e}/${this._currYear}`;
    if (this._showTime) {
      const _ = this._currHour?.toString().padStart(2, "0"), u = this._currMin?.toString().padStart(2, "0");
      r += ` ${_}:${u}`;
    }
    const s = new CustomEvent("onDateChange", {
      detail: r,
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(s);
  }
  _emitRange() {
    let t = null;
    if (this._rangeStartDate?.getDate() != null && this._rangeStartDate?.getMonth() != null && this._rangeStartDate?.getFullYear() != null) {
      const _ = this._rangeStartDate.getDate()?.toString().padStart(2, "0"), D = (this._rangeStartDate?.getMonth() + 1).toString().padStart(2, "0");
      t = `${_}/${D}/${this._rangeStartDate?.getFullYear()}`;
    }
    let e = null;
    if (this._rangeEndDate?.getDate() != null && this._rangeEndDate?.getMonth() != null && this._rangeEndDate?.getFullYear()) {
      const _ = this._rangeEndDate.getDate()?.toString().padStart(2, "0"), D = (this._rangeEndDate?.getMonth() + 1).toString().padStart(2, "0");
      e = `${_}/${D}/${this._rangeEndDate?.getFullYear()}`;
    }
    const r = new CustomEvent("onRangeChange", {
      detail: {
        rangeStart: t,
        rangeEnd: e
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(r);
    const s = new CustomEvent("range-changed", {
      detail: {
        rangeStart: t,
        rangeEnd: e
      },
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(s);
  }
  _updateCurrentDate() {
    if (!this._selectedDate) {
      this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth();
      return;
    }
    if (this._currMonth = this._selectedDate.getMonth(), this._currYear = this._selectedDate.getFullYear(), this._currHour = this._selectedDate.getHours(), this._currMin = this._selectedDate.getMinutes(), this._days = this._getDays(), this._currHour !== void 0 && this._currMin !== void 0) {
      const t = String(this._currHour).padStart(2, "0"), e = String(this._currMin).padStart(2, "0");
      this._timepickerValue = `${t}:${e}`, this._isTimeFormatValid = this._currHour >= 0 && this._currHour <= 23 && this._currMin >= 0 && this._currMin <= 59;
    }
  }
  _getDateString(t) {
    const e = t?.replace(/(\d+[/])(\d+[/])/, "$2$1"), r = this._showTime ? 14 : 8;
    return e?.length > r ? new Date(e) : null;
  }
  _onSelectTime(t) {
    if (this._isTimeFormatValid = !1, t.detail.status === "VALID") {
      this._isTimeFormatValid = !0;
      const e = t.detail.value;
      this._currHour = +e.substring(0, 2), this._currMin = +e.substring(3, 5);
    }
    this.requestUpdate();
  }
  _toggleMonthSelector() {
    this._showMonthSelector = !0, this.requestUpdate();
  }
  _onMonthSelectorClick(t) {
    const e = p.indexOf(t);
    this._currMonth = e, this._update(), this._showMonthSelector = !1, this.requestUpdate();
  }
  _toggleYearSelector() {
    this._showYearSelector = !0, this.requestUpdate();
  }
  _onYearSelectorClick(t) {
    this._currYear = t, this._update(), this._showYearSelector = !1, this.requestUpdate();
  }
  _generateYearsRangeOptions() {
    const t = [];
    for (let r = this._yearsRangeStart; r <= this._yearsRangeEnd; r += 1)
      t.push(r);
    return t.map((r) => {
      const s = (a) => {
        a && a.focus();
      }, _ = (a) => {
        let i = 0;
        const n = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), g = n.length - 1;
        a === n[0] ? s(n[g]) : (n.forEach((d, m) => {
          d === a && (i = m);
        }), s(n[i - 1]));
      }, u = (a) => {
        let i = 0;
        const n = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), g = n.length - 1;
        a === n[g] ? s(n[0]) : (n.forEach((d, m) => {
          d === a && (i = m);
        }), s(n[i + 1]));
      }, D = (a) => {
        const i = a.currentTarget, n = a;
        let g = !1;
        switch (n.key) {
          case "ArrowUp":
          case "ArrowLeft":
            _(i), g = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            u(i), g = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
            const d = a.target;
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--year[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), a.target.setAttribute("tabindex", "0"), d.click(), g = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), g = !0;
            break;
        }
        g && (a.stopPropagation(), a.preventDefault());
      }, b = (/* @__PURE__ */ new Date()).getFullYear(), l = {
        "calendar-selector-options__item--current": r === b,
        "calendar-selector-options__item--selected": r === this._currYear
      };
      return y`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--year ${M(l)}"
          tabindex="${r === this._currYear ? 0 : -1}"
          role="button"
          @keydown=${D}
          @click=${() => this._onYearSelectorClick(r)}
        >
          ${r}
        </div>
      `;
    });
  }
  _generateMonthsOptions() {
    return p.map((e) => {
      const r = (l) => {
        l && l.focus();
      }, s = (l) => {
        let a = 0;
        const i = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = i.length - 1;
        l === i[0] ? r(i[n]) : (i.forEach((g, d) => {
          g === l && (a = d);
        }), r(i[a - 1]));
      }, _ = (l) => {
        let a = 0;
        const i = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = i.length - 1;
        l === i[n] ? r(i[0]) : (i.forEach((g, d) => {
          g === l && (a = d);
        }), r(i[a + 1]));
      }, u = (l) => {
        const a = l.currentTarget, i = l;
        let n = !1;
        switch (i.key) {
          case "ArrowUp":
          case "ArrowLeft":
            s(a), n = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            _(a), n = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
            const g = l.target;
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--month[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), l.target.setAttribute("tabindex", "0"), g.click(), n = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this.renderRoot.querySelector(".calendar-selector-options__item--selected").click(), n = !0;
            break;
        }
        n && (l.stopPropagation(), l.preventDefault());
      }, w = (/* @__PURE__ */ new Date()).getMonth(), b = {
        "calendar-selector-options__item--current": p.indexOf(e) === w,
        "calendar-selector-options__item--selected": p.indexOf(e) === this._currMonth
      };
      return y`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--month ${M(b)}"
          tabindex="${p.indexOf(e) === this._currMonth ? 0 : -1}"
          role="button"
          @keydown=${u}
          @click=${() => this._onMonthSelectorClick(e)}
        >
          ${e.length <= 4 ? y`${e}` : y`${e.slice(0, 3)}.`}
        </div>
      `;
    });
  }
  _onYearRangeStepUp() {
    this._yearsRangeStart += 20, this._yearsRangeEnd += 20, this.requestUpdate();
  }
  _onYearRangeStepDown() {
    this._yearsRangeStart -= 20, this._yearsRangeEnd -= 20, this.requestUpdate();
  }
  _onHeaderMonthKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--month[tabindex="0"]').focus();
    }, 50));
  }
  _onHeaderYearKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--year[tabindex="0"]').focus();
    }, 50));
  }
  _validateSelectedDate() {
    return !!(!this._range && !this._selectedDate || !this._range && this._showTime && !this._isTimeFormatValid || this._range && (!this._rangeStartDate || !this._rangeEndDate));
  }
  _handleCalendarKeydown(t) {
    t?.key === "Escape" && this._onCancel();
  }
  render() {
    return L(this);
  }
}
h([
  o({ type: Array })
], c.prototype, "customCalendar", 2);
h([
  o(S)
], c.prototype, "range", 1);
h([
  o(S)
], c.prototype, "isRangeStartFocused", 1);
h([
  o(S)
], c.prototype, "isRangeEndFocused", 1);
h([
  o({ type: String })
], c.prototype, "selectedDate", 1);
h([
  o({ type: String })
], c.prototype, "minDate", 1);
h([
  o({ type: String })
], c.prototype, "maxDate", 1);
h([
  o(S)
], c.prototype, "showTime", 1);
h([
  o(S)
], c.prototype, "showButtons", 1);
h([
  o({ type: String })
], c.prototype, "leftLabel", 1);
h([
  o({ type: String })
], c.prototype, "rightLabel", 1);
h([
  o({ type: String })
], c.prototype, "timepicker", 1);
h([
  o({ type: Number })
], c.prototype, "minutesRange", 1);
h([
  o({ type: Number })
], c.prototype, "minHour", 1);
h([
  o({ type: Number })
], c.prototype, "maxHour", 1);
h([
  o({ type: Array })
], c.prototype, "customTimeListOptions", 1);
h([
  o({ type: String })
], c.prototype, "timepickerLabel", 1);
h([
  o({ type: String })
], c.prototype, "rangeStartDate", 1);
h([
  o({ type: String })
], c.prototype, "rangeEndDate", 1);
export {
  p as MONTH,
  c as NgCalendar,
  G as WEEK
};
//# sourceMappingURL=ng-calendar.js.map
