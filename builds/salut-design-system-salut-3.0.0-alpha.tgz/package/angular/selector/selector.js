import { LitElement as $, unsafeCSS as _ } from "lit";
import { property as i } from "lit/decorators.js";
import { classMap as f } from "lit/directives/class-map.js";
import { ifDefined as E } from "lit/directives/if-defined.js";
import { unsafeStatic as V, literal as q, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as w } from "../../api/custom-element-scope.js";
import L from "../../foundations/icon/icon.style.css.js";
import U from "../../shared/scrollbar.style.css.js";
import { booleanType as h, selectedType as x } from "../../utils/property-types.js";
import D from "./selector.style.css.js";
import { unsafeHTML as S } from "lit/directives/unsafe-html.js";
import { highlightTextMultiple as C, highlightText as T } from "../../api/marker/marker.js";
import F from "../../api/marker/marker.style.css.js";
var I = Object.defineProperty, O = Object.getOwnPropertyDescriptor, r = (m, t, e, l) => {
  for (var s = l > 1 ? void 0 : l ? O(t, e) : t, c = m.length - 1, o; c >= 0; c--)
    (o = m[c]) && (s = (l ? o(t, e, s) : o(s)) || s);
  return l && s && I(t, e, s), s;
};
const R = q`dss-spinner${V(w())}`;
class a extends $ {
  constructor() {
    super(...arguments), this.isOpen = !1, this.readonly = !1, this.boxShadow = !1, this.advancedFilter = !1, this.searchThreshold = 1, this.isDisplayed = void 0, this._elementId = `dss-selector-${(/* @__PURE__ */ new Date()).getTime()}`, this._elements = null, this._elementSelectAll = [], this._selectedValue = null, this._multiple = !1, this._deselectable = !1, this._disabled = !1, this._tick = !0, this._type = "default", this._style = null, this._filtre = null, this._labelSelectAll = "Seleccionar-ho tot", this._labelDeselectAll = "Deseleccionar-ho tot", this._selectAll = !1, this._isAllSelected = !1, this._elementsSelected = 0, this._emptySelectorLabel = "Sense resultats per", this._emptyFilterLabel = "Escriu per cercar.", this._filterThreshold = 1, this._ariaLabel = void 0;
  }
  static get styles() {
    return [_(L), _(U), _(F), _(D)];
  }
  set multiple(t) {
    const e = this._multiple;
    this._multiple = t, this.requestUpdate("multiple", e);
  }
  get multiple() {
    return this._multiple;
  }
  set tick(t) {
    const e = this._tick;
    this._tick = t, this.requestUpdate("tick", e);
  }
  get tick() {
    return this._tick;
  }
  set deselectable(t) {
    const e = this._deselectable;
    this._deselectable = t, this.requestUpdate("deselectable", e);
  }
  get deselectable() {
    return this._deselectable;
  }
  set disabled(t) {
    const e = this._disabled;
    this._disabled = t, this.requestUpdate("disabled", e);
  }
  get disabled() {
    return this._disabled;
  }
  set elements(t) {
    const e = this._elements;
    this._elements = t, this.requestUpdate("elements", e);
  }
  get elements() {
    return this._elements || [];
  }
  set selectedValue(t) {
    const e = this._selectedValue;
    if (!t || t.length === 0) {
      this._selectedValue = null, this.requestUpdate("selectedValue", e);
      return;
    }
    if (this._multiple) {
      this._selectedValue = this._elements?.filter((s) => t.includes(s.value)) || null, this.requestUpdate("selectedValue", e);
      return;
    }
    const l = this._elements?.find((s) => s.value === t[0]);
    this._selectedValue = l ? [l] : null, this.requestUpdate("selectedValue", e);
  }
  get selectedValue() {
    return this._selectedValue?.map((t) => t.value) || [];
  }
  set type(t) {
    const e = this._type;
    t === "default" || t === "green" ? this._type = t : this._type = "default", this.requestUpdate("type", e);
  }
  get type() {
    return this._type;
  }
  set boxStyle(t) {
    const e = this._style;
    this._style = t, this.requestUpdate("style", e);
  }
  get boxStyle() {
    return this._style || "";
  }
  set filtre(t) {
    if (t) {
      const e = this._filtre;
      this._filtre = t.toLowerCase(), this.requestUpdate("filtre", e);
    } else t === "" && (this._filtre = null);
    this._selectAll && this._areAllElementsSelected();
  }
  get filtre() {
    return this._filtre || "";
  }
  set labelSelectAll(t) {
    const e = this._labelSelectAll;
    t !== "" && (this._labelSelectAll = t), this.requestUpdate("labelSelectAll", e);
  }
  get labelSelectAll() {
    return this._labelSelectAll;
  }
  set labelDeselectAll(t) {
    const e = this._labelDeselectAll;
    t !== "" && (this._labelDeselectAll = t), this.requestUpdate("labelDeselectAll", e);
  }
  get labelDeselectAll() {
    return this._labelDeselectAll;
  }
  set selectAll(t) {
    const e = this._selectAll;
    this._selectAll = t, this.requestUpdate("selectAll", e);
  }
  get selectAll() {
    return this._selectAll;
  }
  set filterThreshold(t) {
    const e = this._filterThreshold;
    this._filterThreshold = t, this.requestUpdate("filterThreshold", e);
  }
  get filterThreshold() {
    return this._filterThreshold;
  }
  set elementsSelected(t) {
    const e = this._elementsSelected;
    this._elementsSelected = t, this.requestUpdate("elementsSelected", e);
  }
  get elementsSelected() {
    return this._elementsSelected;
  }
  set ariaLabel(t) {
    const e = this._ariaLabel;
    this._ariaLabel = t, this.requestUpdate("ariaLabel", e);
  }
  get ariaLabel() {
    return this._ariaLabel || "";
  }
  _valueIsSelected(t) {
    return this._selectedValue?.some((e) => e.value === t) || !1;
  }
  _manuallySelect(t, e) {
    if (t.preventDefault(), t.stopPropagation(), this._disabled || this.readonly) return;
    const l = this._valueIsSelected(e);
    if (!this._multiple && !this._deselectable && l) return;
    const s = t.target, c = s.className.includes("dss-mark") ? s.parentElement : s;
    c && c.className.includes("dss-form-field") ? c.querySelector("input").checked = !l : c && (c.parentElement.querySelector("input").checked = !l), this._returnSelectedValues(e), this._areAllElementsSelected();
  }
  _manuallySelectAll(t) {
    if (t.preventDefault(), t.stopPropagation(), this._disabled || this.readonly || !this._multiple && !this._deselectable && this._isAllSelected) return;
    const e = t.target;
    e.className.includes("dss-form-field") ? (e.querySelector("input").checked = !e.querySelector("input").checked, this._returnSelecteAllValues(e.querySelector("input").checked)) : (e.parentElement.querySelector("input").checked = !e.parentElement.querySelector("input").checked, this._returnSelecteAllValues(e.parentElement.querySelector("input").checked)), this._areAllElementsSelected();
  }
  _returnSelecteAllValues(t) {
    t ? this._selectedValue = this._elements?.filter((s) => s.value) || [] : this._selectedValue = [];
    const l = {
      detail: this._selectedValue?.map((s) => s.value) || null,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", l)), this.requestUpdate();
  }
  _returnSelectedValues(t) {
    const e = Array.from(this.shadowRoot?.querySelectorAll("input:checked") || []).map((o) => o.getAttribute("value")).filter((o) => o == null ? !1 : this._multiple ? !0 : o === t), l = e.indexOf(this._elementSelectAll[0]);
    l !== -1 && e.splice(l, 1), this._selectedValue = this._elements?.filter((o) => e.includes(o.value)) || [];
    let s;
    this._multiple ? s = e : s = e[0] || null;
    const c = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", c)), this.requestUpdate();
  }
  _focusEvent(t) {
    t.target.closest(".dss-form-field")?.classList.add("dss-form-field__focus");
  }
  _blurEvent(t) {
    t.target.closest(".dss-form-field")?.classList.remove("dss-form-field__focus");
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._elementSelectAll = [this._labelSelectAll], this._areAllElementsSelected(), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _areAllElementsSelected() {
    if (!this._elements || !this._selectedValue) {
      this._elementSelectAll = [this._labelSelectAll], this._isAllSelected = !1;
      return;
    }
    const t = this._selectedValue.map((l) => l.value), e = this._elements.map((l) => l.value);
    this._isAllSelected = t.length === e.length && t.every((l) => e.includes(l)), this._isAllSelected ? this._elementSelectAll = [this._labelDeselectAll] : this._elementSelectAll = [this._labelSelectAll], this.requestUpdate();
  }
  selectFirstMatch() {
    const t = this.shadowRoot?.querySelectorAll(".dss-form-field");
    let e = null;
    for (const l of t || []) {
      const s = l.getAttribute("data-label");
      if (s && this._filtre && s.toLowerCase() === this._filtre.toLowerCase()) {
        e = l;
        break;
      }
    }
    e && e.click();
  }
  moveFocus() {
    const t = this.shadowRoot?.querySelectorAll(".dss-form-field");
    if (!t || t.length === 0) return;
    const l = t[0].querySelector("input");
    l && l.focus();
  }
  generateListInputsElements() {
    return this._elements?.map((e, l) => {
      const s = e.label.trim().replace(/\s+/g, "-"), c = e.value.trim().replace(/\s+/g, "-"), o = `selector-${s}-${c}`, p = this._valueIsSelected(e.value), n = this._tick && !this._multiple, y = f({
        disabled: this._disabled,
        "dss-disabled": this._disabled,
        "dss-form-field": !0,
        "dss-form-field--simple": this._tick && !this._multiple,
        "dss-form-field--multiple": this._multiple,
        "dss-form-field--readonly": this.readonly,
        "dss-form-field--no-tick": !this._tick,
        "dss-type--default": this._type === "default",
        "dss-type--green": this._type === "green",
        "dss-ticked": n,
        "dss-selected": p && n,
        "dss-form-field--selected": p,
        "dss-first-unselected": l && l > 0 && l === this._elementsSelected,
        "dss-form-field--match": e.label.toLowerCase() === this._filtre?.toLowerCase()
      }), b = f({
        "dss-checkbox": this._multiple,
        "dss-radio": !this._multiple,
        "dss-disabled": this._disabled,
        hidden: n
      }), v = d`
        <input
          id="${o}"
          name="${o}"
          type="checkbox"
          class="${b}"
          .value="${e.value}"
          .checked="${p}"
          @focus="${this._focusEvent}"
          @blur="${this._blurEvent}"
				 ?disabled="${this._disabled || this.readonly}"
        />
        <div class="dss-check-overlay"></div>
      `, A = d`<span
        class="dss-icon--checked"
        style="visibility: ${this.isOpen && n && p ? "visible" : "hidden"}"
      ></span>`;
      return d`
        <div
          class="${y}"
          @keydown="${(u) => {
        u.key === "Enter" || u.key === " " ? this._manuallySelect(u, e.value) : u.key === "ArrowUp" ? u.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : u.key === "ArrowDown" && u.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
      }}"
          @click="${(u) => {
        this._manuallySelect(u, e.value);
      }}"
          data-label="${e.label}"
        >
          ${v}
          <label for=${o}>
						${this.advancedFilter ? S(C(e.label, this._filtre || "", this.searchThreshold)) : S(T(e.label, this._filtre || ""))}
          </label>
          ${A}
        </div>
      `;
    });
  }
  generatElementSelectAll() {
    return this._elementSelectAll?.map((e) => {
      const l = f({
        disabled: this._disabled || this.readonly,
        "dss-form-field": !0,
        "dss-type--default": this._type === "default",
        "dss-type--green": this._type === "green",
        "dss-selectAll": !0,
        "dss-disabled": this._disabled || this.readonly,
        "dss-form-field--match": e.toLowerCase() === this._filtre?.toLowerCase()
      }), s = f({
        "dss-checkbox": this._multiple
      }), c = d`
        <input
          id="${this._elementId}"
          name="${this._elementId}"
          type="checkbox"
          class="${s}"
          .value="${e}"
          .checked="${this._isAllSelected}"
          @focus="${this._focusEvent}"
          @blur="${this._blurEvent}"
					?disabled="${this._disabled || this.readonly}"
        />
        <div class="dss-check-overlay"></div>
      `;
      return d`
        <div
          class="${l}"
          @keydown="${(n) => {
        n.key === "Enter" || n.key === " " ? this._manuallySelectAll(n) : n.key === "ArrowUp" ? n.target?.closest(".dss-form-field")?.previousElementSibling?.querySelector("input")?.focus() : n.key === "ArrowDown" && n.target?.closest(".dss-form-field")?.nextElementSibling?.querySelector("input")?.focus();
      }}"
          @click="${(n) => {
        this._manuallySelectAll(n);
      }}"
          data-label="${e}"
        >
          ${c}
          <label for="${this._elementId}">${e}</label>
        </div>
      `;
    });
  }
  render() {
    let t = this.generateListInputsElements();
    const e = this.generatElementSelectAll();
    this._multiple && this._selectAll && (t?.unshift(e[0]), t = t?.length === 1 ? [] : t);
    const l = (s) => {
      (s.key === "ArrowDown" || s.key === "ArrowUp") && s.preventDefault();
    };
    return d`
      ${this._elements && this._elements.length > 0 ? d`
            <div
              aria-label="${E(this._ariaLabel)}"
              part="selector"
              class="list dss-selector-list-wrapper ${this.boxShadow ? "dss-selector-list-wrapper--box-shadow" : ""}"
              @keydown=${l}
              style="${this._style}"
            >
              ${t}
            </div>
          ` : d`
            <div
              part="selector"
              class="list dss-selector-list-wrapper"
              @keydown=${l}
              style="${this._style}"
            >
              ${this._filtre && this._filtre.length >= this._filterThreshold ? d`
                    <div class="dss-selector-empty">
                      <span class="dss-icon dss-icon--sm">info</span>
                      <span class="text">
                        ${this._filtre || this._filtre === "" ? d` ${this._emptySelectorLabel}: ${this._filtre} ` : d`${this._emptyFilterLabel}`}
                      </span>
                    </div>
                  ` : d`
                    <div class="dss-selector-empty">
											<${R} size="md"/>
                    </div>
                  `}
            </div>
          `}
    `;
  }
}
r([
  i(h)
], a.prototype, "isOpen", 2);
r([
  i(h)
], a.prototype, "readonly", 2);
r([
  i(h)
], a.prototype, "boxShadow", 2);
r([
  i(h)
], a.prototype, "advancedFilter", 2);
r([
  i({ type: Number })
], a.prototype, "searchThreshold", 2);
r([
  i(h)
], a.prototype, "multiple", 1);
r([
  i(h)
], a.prototype, "tick", 1);
r([
  i(h)
], a.prototype, "deselectable", 1);
r([
  i(h)
], a.prototype, "disabled", 1);
r([
  i({ type: Array })
], a.prototype, "elements", 1);
r([
  i(x)
], a.prototype, "selectedValue", 1);
r([
  i({ type: String })
], a.prototype, "type", 1);
r([
  i({ type: String })
], a.prototype, "boxStyle", 1);
r([
  i({ type: String })
], a.prototype, "filtre", 1);
r([
  i({ type: String })
], a.prototype, "labelSelectAll", 1);
r([
  i({ type: String })
], a.prototype, "labelDeselectAll", 1);
r([
  i(h)
], a.prototype, "selectAll", 1);
r([
  i({ type: Number })
], a.prototype, "filterThreshold", 1);
r([
  i({ type: Number })
], a.prototype, "elementsSelected", 1);
r([
  i({ type: String })
], a.prototype, "ariaLabel", 1);
r([
  i(h)
], a.prototype, "isDisplayed", 2);
export {
  a as Selector
};
//# sourceMappingURL=selector.js.map
