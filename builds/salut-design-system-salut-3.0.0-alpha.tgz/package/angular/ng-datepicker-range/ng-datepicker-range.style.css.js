const i = ":host{display:block;width:100%;min-width:257px}.dss-datepicker-range{font-family:var(--font-family)}.dss-datepicker-range-inputs{display:grid;grid-template-columns:1fr 1fr;gap:var(--dss-spacing-md)}.dss-datepicker-range-help{font-family:var(--font-family)}.dss-datepicker-range-help{font-family:inherit;font-size:12px;color:var(--color-neutral-700);padding:var(--dss-spacing-xxs) var(--dss-spacing-sm)}.dss-datepicker-range-help--disabled{color:var(--color-neutral-500)}.dss-datepicker-range-help--invalid{color:var(--color-red-500)}.dss-calendar{z-index:999;width:-moz-fit-content;width:fit-content;opacity:0;visibility:hidden;transition:opacity var(--animation-delay) ease-out}.dss-calendar--visible{opacity:1;visibility:visible}";
export {
  i as default
};
//# sourceMappingURL=ng-datepicker-range.style.css.js.map
