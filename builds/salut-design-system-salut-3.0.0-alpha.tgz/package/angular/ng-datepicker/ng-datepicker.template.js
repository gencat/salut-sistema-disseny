import { nothing as r } from "lit";
import { classMap as i } from "lit/directives/class-map.js";
import { ifDefined as f } from "lit/directives/if-defined.js";
import { unsafeStatic as l, literal as d, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const u = d`dss-ng-calendar${l(e())}`, t = d`dss-icon${l(e())}`, $ = d`dss-icon-button${l(e())}`, _ = d`dss-tooltip${l(e())}`, k = (s) => {
  const p = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s._required,
    "dss-input-wrapper--disabled": s._disabled,
    [`dss-input-wrapper--${s.inputSize}`]: !!s.inputSize,
    "dss-input-wrapper--no-label": !s._labelSlot
  }, b = {
    "dss-input-group": !0,
    [`dss-input-group--${s.inputSize}`]: !!s.inputSize,
    "dss-input-group--invalid": s._invalid || !s._inputValidity,
    "dss-input-group--required": s._required,
    "dss-input-group--disabled": s._disabled,
    "dss-input-group--focused": s._input?.value || s._placeholder || s._isFocused,
    "dss-input-group--read-only": s._readonly,
    "dss-input-group--no-label": !s._labelSlot
  }, h = {
    "dss-input-help": !0,
    "dss-input-help--invalid": s._invalid,
    "dss-input-help--disabled": s._disabled
  }, v = {
    "dss-calendar": !0,
    "dss-calendar--visible": s._showCalendar && !s._readonly,
    "dss-calendar--disabled": s._disabled,
    "dss-calendar--md": s.inputSize !== "lg"
  };
  return a`
  
      <div class="${i(p)}">
  
        ${s.inputSize === "sm" ? a`
          <div class="dss-wrapper-label">
            <slot name="label" @click=${s._focusInput}></slot>
          </div>
          ` : r}
  
        <div 
          class="dss-input-dropdown-wrapper"
          role="combobox"
          aria-controls="datepicker-calendar"
          aria-expanded=${f(s._showCalendar)}>
          <div class="${i(b)}">
            ${s.icon && s.icon !== "" ? a`
              <${t} icon="${s.icon}" class="dss-input-icon"></${t}>
              ` : r}
            <div class="dss-input-field">
              ${s.inputSize !== "sm" ? a`
                <slot name="label" @click=${s._focusInput}></slot>
                ` : r}
              <slot name="input"
                @click=${s._handleClick}
                @input=${s._handleInput}
                @focusin=${s._handleFocus}
                @focusout=${s._handleBlur}
                @keydown=${s._handleKeyUp}
              ></slot>
              ${!s._showCalendar && s._isTruncated ? a`
                  <${_}>${s._input?.value}</${_}>
                ` : null}
            </div>
            
            <${$}
              size="md"
              icon="close"
              hideTooltip
              label="Netejar data"
              @onClick=${s._clearDate}
              ?hidden=${!s._input?.value || s._readonly || s._disabled}
            ></${$}>

          </div>
  
          <${u}
            role="listbox"
            aria-label="Datepicker Calendar"
            id="datepicker-calendar"
            class="${i(v)}"
            .selectedDate=${s._input?.value}
            .showTime=${s._showTime}
            .showButtons=${s._showButtons}
            .leftLabel=${s._leftLabel}
            .rightLabel=${s._rightLabel}
            .minDate=${s._minDate}
            .maxDate=${s._maxDate}
            timepickerLabel=${s._timepickerLabel}
            .timepicker=${s._timepicker}
            .customCalendar=${s.customCalendar}
            .customTimeListOptions=${s._customTimeListOptions}
            .minutesRange=${s._minutesRange}
            .minHour=${s._minHour}
            .maxHour=${s._maxHour}
            @onDateChange=${s._onDateChange}
            @onCancel=${s._onCancel}
          ></${u}>
        </div>
  
        ${s._helpText ? a`
              <div class="${i(h)}">
                <span>${s._helpText}</span>
              </div>
            ` : null}
      </div>
    `;
};
export {
  k as template
};
//# sourceMappingURL=ng-datepicker.template.js.map
