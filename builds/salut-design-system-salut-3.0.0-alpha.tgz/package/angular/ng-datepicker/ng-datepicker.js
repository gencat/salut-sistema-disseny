import { autoUpdate as m, computePosition as f, offset as g, shift as b, flip as y } from "@floating-ui/dom";
import { LitElement as v, unsafeCSS as d } from "lit";
import { property as a } from "lit/decorators.js";
import { booleanType as l } from "../../utils/property-types.js";
import { template as w } from "./ng-datepicker.template.js";
import x from "../../shared/scrollbar.style.css.js";
import C from "../ng-input/ng-input.style.css.js";
import D from "./ng-datepicker.style.css.js";
var T = Object.defineProperty, L = Object.getOwnPropertyDescriptor, r = (p, t, e, i) => {
  for (var s = i > 1 ? void 0 : i ? L(t, e) : t, h = p.length - 1, o; h >= 0; h--)
    (o = p[h]) && (s = (i ? o(t, e, s) : o(s)) || s);
  return i && s && T(t, e, s), s;
};
class n extends v {
  constructor() {
    super(), this.icon = "calendar_today", this.inputSize = "lg", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.customCalendar = void 0, this.validate = !1, this.errorMessageFormat = "El format de la data no és correcte.", this.errorMessageMinDate = "La data és anterior a la permesa.", this.errorMessageMaxDate = "La data és posterior a la permesa.", this._timepickerLabel = "Seleccionar l'hora", this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._placeholder = "", this._externalPlaceholder = "", this._previousDate = "", this._minDate = "", this._maxDate = "", this._showCalendar = !1, this._showTime = !1, this._invalid = !1, this._showButtons = !1, this._required = !1, this._disabled = !1, this._readonly = !1, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._isFocused = !1, this._helpText = "", this._helpTextBackup = "", this._inputValidity = !0, this._cleanupFloating = null, this._referenceEl = null, this._floatingEl = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showCalendar && this._closeCalendar();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [d(C), d(x), d(D)];
  }
  get _input() {
    const t = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  get _labelSlot() {
    return (this.shadowRoot?.querySelector('slot[name="label"]') || void 0)?.assignedElements()[0];
  }
  get _label() {
    const t = this.shadowRoot?.querySelector('slot[name="label"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this._showButtons = !0, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = t, this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate;
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = t, this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set value(t) {
    t !== void 0 && this.requestUpdate();
  }
  get value() {
    return this._input?.value;
  }
  disconnectedCallback() {
    this._removeCalendarListener(), this.observer.disconnect(), this.visibleObserver.disconnect(), this._cleanupFloating?.(), this._cleanupFloating = null;
  }
  _addCalendarListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeCalendarListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._helpTextBackup = this.helpText, this._createPopperCalendar(), this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input)), this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _createPopperCalendar() {
    const t = this.shadowRoot?.querySelector(".dss-input-group"), e = this.shadowRoot?.querySelector(".dss-calendar");
    !t || !e || (this._referenceEl = t, this._floatingEl = e, this._cleanupFloating?.(), this._cleanupFloating = m(this._referenceEl, this._floatingEl, () => this._updatePopperCalendar()));
  }
  async _updatePopperCalendar() {
    if (!this._referenceEl || !this._floatingEl) return;
    const { x: t, y: e, strategy: i } = await f(this._referenceEl, this._floatingEl, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        g(4),
        // equivale a offset: [0,4]
        b({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        }),
        y()
      ]
    });
    Object.assign(this._floatingEl.style, {
      position: i,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _checkInputAttributes() {
    const t = this._input?.getAttribute("placeholder");
    t && (this._placeholder = t, this._externalPlaceholder = t);
    const e = this._input?.getAttribute("readonly");
    this._readonly = e !== null;
    const i = this._input?.getAttribute("disabled");
    this._disabled = i !== null;
    const s = this._input?.getAttribute("required");
    this._required = s !== null, this._input?.value && this._input?.value !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showCalendar && this._closeCalendar();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && this._showCalendar && this._closeCalendar();
  }
  _closeCalendar() {
    this._removeCalendarListener(), this._input?.removeAttribute("placeholder"), this._placeholder = "", this._isFocused = !1, this._showCalendar = !1, this._input?.blur(), this.validate && this._validateDate(), this.requestUpdate();
  }
  _handleKeyUp(t) {
    if (t?.key === "Tab" ? (this._isFocused = !0, this._handleBlur()) : t?.key === "Enter" || t?.key === " " ? (this._showCalendar = !0, this._updatePopperCalendar(), this._handleBlur(), this._addCalendarListener()) : t?.key === "Escape" && (this._closeCalendar(), this._handleBlur()), t.key === "Enter" && this._input && this._input.value?.length > 7 && this._input) {
      const e = this._input.value?.replace(/(\d+[/])(\d+[/])/, "$2$1"), i = new Date(e), s = i.getDate()?.toString().padStart(2, "0"), h = (i.getMonth() + 1).toString().padStart(2, "0"), o = i.getFullYear(), u = i.getHours()?.toString().padStart(2, "0"), _ = i.getMinutes()?.toString().padStart(2, "0");
      let c = `${s}/${h}/${o}`;
      this._showTime && (c += ` ${u}:${_}`, this._handleValidity()), this._input && (this._input.value = c), this._dispatchValueChange(), this._showCalendar ? this._closeCalendar() : this.requestUpdate();
    }
  }
  _handleInput(t) {
    const e = t.target.value?.replace(/\D/g, "");
    this._input && (this._input.value = this._formatDate(e), this._handleValidity()), this._dispatchValueChange(), this.requestUpdate();
  }
  _formatDate(t) {
    let e = t.substring(0, 2), i = t.substring(2, 4);
    const s = t.substring(4, 8);
    let h = t.substring(8, 10), o = t.substring(10, 12);
    Number(e) > 3 && (e = e?.padStart(2, "0")), Number(i) > 1 && (i = i?.padStart(2, "0")), Number(e) > 31 && (e = "31"), Number(i) > 12 && (i = "12"), i === "02" && Number(e) > 28 && s?.length === 4 && (e = new Date(Number(s), 1, 29).getMonth() === 1 ? "29" : "28");
    let u = `${e}${i ? `/${i}` : ""}${s ? `/${s}` : ""}`;
    return this._showTime && (Number(h) > 2 && (h = h?.padStart(2, "0")), Number(h) > 23 && (h = "23"), Number(o) > 5 && (o = o?.padStart(2, "0")), u = `${u}${h ? ` ${h}` : ""}${o ? `:${o}` : ""}`), u;
  }
  _handleFocus() {
    this._readonly || (this._externalPlaceholder !== "" ? this._placeholder = this._externalPlaceholder : this._placeholder = this._showTime ? "DD/MM/AAAA HH:MM" : "DD/MM/AAAA", this._input?.setAttribute("placeholder", this._placeholder), this.requestUpdate());
  }
  _handleBlur() {
    this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    !this._disabled && !this._readonly && (this._input?.focus(), this._handleClick());
  }
  _handleClick() {
    this._showCalendar = !0, this._updatePopperCalendar(), this._addCalendarListener(), this.requestUpdate();
  }
  _onDateChange(t) {
    const e = t.detail;
    this._input && (this._input.value = e, this._handleValidity()), this._closeCalendar(), this._dispatchValueChange();
  }
  _onCancel() {
    this._closeCalendar(), this._input && (this._input.value = this._previousDate || "", this._handleValidity()), this.requestUpdate();
  }
  _dispatchValueChange() {
    const t = {
      detail: this._input?.value,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onValueChange", t));
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, s = document.createElement("canvas").getContext("2d");
    if (!s) return;
    s.font = e;
    const h = s.measureText(this._input.value).width;
    this._isTruncated = h > this._input.offsetWidth;
  }
  _validateDate() {
    const t = this._checkDateFormat(this._input?.value);
    this._dispatchOnValidate(t);
  }
  _checkDateFormat(t) {
    const e = this._showTime ? 16 : 10;
    if (t === "")
      return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
    if (t.length < e)
      return this._helpText = this.errorMessageFormat, this._invalid = !0, !0;
    if (this._minDate || this._maxDate) {
      const i = this._showTime ? t.substring(0, 10) : t, s = new Date(this._convertToISO(i)), h = new Date(this._convertToISO(this._minDate)), o = new Date(this._convertToISO(this._maxDate));
      if (h && s < h)
        return this._helpText = this.errorMessageMinDate, this._invalid = !0, !0;
      if (o && s > o)
        return this._helpText = this.errorMessageMaxDate, this._invalid = !0, !0;
    }
    return this._helpText = this._helpTextBackup, this._invalid = !1, !1;
  }
  _convertToISO(t) {
    const [e, i, s] = t.split("/");
    return `${s}-${i}-${e}`;
  }
  _dispatchOnValidate(t) {
    const e = {
      detail: {
        date: this._input?.value,
        invalid: t
      },
      bubbles: !1,
      composed: !1
    };
    this.dispatchEvent(new CustomEvent("onValidate", e));
  }
  _clearDate() {
    this._input && (this._input.value = "", this._handleValidity(), this.invalid = this._input ? !this._input.checkValidity() : !1, this._helpText = this._helpTextBackup, this._dispatchValueChange(), this.requestUpdate());
  }
  render() {
    return w(this);
  }
}
r([
  a(l)
], n.prototype, "showTime", 1);
r([
  a(l)
], n.prototype, "showButtons", 1);
r([
  a({ type: String })
], n.prototype, "leftLabel", 1);
r([
  a({ type: String })
], n.prototype, "rightLabel", 1);
r([
  a({ type: String })
], n.prototype, "minDate", 1);
r([
  a({ type: String })
], n.prototype, "maxDate", 1);
r([
  a(l)
], n.prototype, "invalid", 1);
r([
  a({ type: String })
], n.prototype, "icon", 2);
r([
  a({ type: String })
], n.prototype, "inputSize", 2);
r([
  a({ type: String })
], n.prototype, "helpText", 1);
r([
  a({ type: String })
], n.prototype, "timepicker", 1);
r([
  a({ type: Number })
], n.prototype, "minutesRange", 1);
r([
  a({ type: Number })
], n.prototype, "minHour", 1);
r([
  a({ type: Number })
], n.prototype, "maxHour", 1);
r([
  a({ type: Array })
], n.prototype, "customTimeListOptions", 1);
r([
  a({ type: String })
], n.prototype, "timepickerLabel", 1);
r([
  a({ type: String })
], n.prototype, "value", 1);
r([
  a({ type: String })
], n.prototype, "dropdownPlacement", 2);
r([
  a(l)
], n.prototype, "dropdownFixed", 2);
r([
  a({ type: Array })
], n.prototype, "customCalendar", 2);
r([
  a(l)
], n.prototype, "validate", 2);
r([
  a(l)
], n.prototype, "errorMessageFormat", 2);
r([
  a(l)
], n.prototype, "errorMessageMinDate", 2);
r([
  a(l)
], n.prototype, "errorMessageMaxDate", 2);
export {
  n as NgDatepicker
};
//# sourceMappingURL=ng-datepicker.js.map
