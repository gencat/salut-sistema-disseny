import { LitElement as u, unsafeCSS as l } from "lit";
import { property as s } from "lit/decorators.js";
import _ from "../../foundations/icon/icon.style.css.js";
import p from "../../shared/reset.style.css.js";
import { booleanType as a } from "../../utils/property-types.js";
import C from "./sidemenu.style.css.js";
import { sidemenuTemplate as f } from "./sidemenu.template.js";
var b = Object.defineProperty, g = Object.getOwnPropertyDescriptor, o = (n, e, t, h) => {
  for (var i = g(e, t), d = n.length - 1, c; d >= 0; d--)
    (c = n[d]) && (i = c(e, t, i) || i);
  return i && b(e, t, i), i;
};
class r extends u {
  constructor() {
    super(), this._disabled = !1, this._expanded = !1, this._toggleDisabled = !1, this._toggleLabel = "Tancar menú", this._hideCreateMenu = !1, this._createDisabled = !1, this._createLabel = "Crear", this._createMenuPosition = "top", this._createNotifications = 0, this._showCreateDropdown = !1, this._scrollContainerClass = "dss-layout-sidebar", this._dropdown = null, this._handleDocumentClickBound = this._handleDocumentClick.bind(this), this._handleResizeBound = this._handleResize.bind(this), this._handleContainerScrollBound = this._handleContainerScroll.bind(this);
  }
  static get styles() {
    return [l(p), l(_), l(C)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("resize", this._handleResizeBound), document.addEventListener("mousedown", this._handleDocumentClickBound), this._handleResize();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("resize", this._handleResizeBound), document.removeEventListener("mousedown", this._handleDocumentClickBound), this._scrollContainer && this._scrollContainer.removeEventListener("scroll", this._handleContainerScrollBound);
  }
  set expanded(e) {
    const t = this._expanded;
    this._expanded = e, this.requestUpdate("expanded", t);
  }
  get expanded() {
    return this._expanded;
  }
  set disabled(e) {
    const t = this._disabled;
    this._disabled = e, this.requestUpdate("disabled", t);
  }
  get disabled() {
    return this._disabled;
  }
  set toggleLabel(e) {
    const t = this._toggleLabel;
    this._toggleLabel = e, this.requestUpdate("toggleLabel", t);
  }
  get toggleLabel() {
    return this._toggleLabel;
  }
  set createLabel(e) {
    const t = this._createLabel;
    this._createLabel = e, this.requestUpdate("createLabel", t);
  }
  get createLabel() {
    return this._createLabel;
  }
  set createMenuPosition(e) {
    const t = this._createMenuPosition;
    this._createMenuPosition = e, this.requestUpdate("createMenuPosition", t);
  }
  get createMenuPosition() {
    return this._createMenuPosition;
  }
  set createNotifications(e) {
    const t = this._createNotifications;
    this._createNotifications = e, this.requestUpdate("createNotifications", t);
  }
  get createNotifications() {
    return this._createNotifications;
  }
  set createDisabled(e) {
    const t = this._createDisabled;
    this._createDisabled = e, this.requestUpdate("createDisabled", t);
  }
  get createDisabled() {
    return this._createDisabled;
  }
  set hideCreateMenu(e) {
    const t = this._hideCreateMenu;
    this._hideCreateMenu = e, this.requestUpdate("hideCreateMenu", t);
  }
  get hideCreateMenu() {
    return this._hideCreateMenu;
  }
  set scrollContainerClass(e) {
    const t = this._scrollContainerClass;
    this._scrollContainerClass = e, this.requestUpdate("scrollContainerClass", t);
  }
  get scrollContainerClass() {
    return this._scrollContainerClass;
  }
  get _createNotification() {
    return this.shadowRoot?.querySelector("dss-notification-badge") || void 0;
  }
  get _createSection() {
    return this.shadowRoot?.querySelector(".dss-sidemenu-create");
  }
  _propagateProperties() {
    const e = this.shadowRoot?.querySelectorAll("slot");
    e && e.forEach((t) => {
      t.assignedElements().forEach((i) => {
        this._expanded ? i.setAttribute("expanded", "true") : i.removeAttribute("expanded"), this._scrollContainerClass ? i.setAttribute("scrollContainerClass", this._scrollContainerClass) : i.removeAttribute("scrollContainerClass");
      });
    });
  }
  _handleResize() {
    window.innerWidth < 1024 ? (this.removeAttribute("expanded"), this._toggleDisabled = !0) : this._toggleDisabled = !1, this.requestUpdate();
  }
  _clickedOutsideCreateMenu(e, t) {
    t.composedPath().includes(e) || this._closeCreateDropdown();
  }
  _closeCreateDropdown() {
    this._showCreateDropdown && (this._showCreateDropdown = !1, this.requestUpdate());
  }
  _handleDocumentClick(e) {
    this._createSection && this._clickedOutsideCreateMenu(this._createSection, e);
  }
  _toggleCreateMenu() {
    this._showCreateDropdown = !this._showCreateDropdown, this.requestUpdate();
  }
  _toggleSidemenu() {
    this._expanded ? this.removeAttribute("expanded") : this.setAttribute("expanded", "true");
  }
  _handleCreateMouseEnter() {
    this._createNotification && this._createNotification.setAttribute("isHover", "true");
  }
  _handleCreateMouseLeave() {
    this._createNotification && this._createNotification.removeAttribute("isHover");
  }
  _handleCreateMouseDown() {
    this._createNotification && this._createNotification.setAttribute("isActive", "true");
  }
  _handleCreateFocusout(e) {
    if (this._showCreateDropdown) {
      const t = e.relatedTarget;
      t === null && this._closeCreateDropdown(), t && !this._createSection.contains(t) && t.tagName !== "DSS-ACTION-MENU-ITEM" && this._closeCreateDropdown();
    }
  }
  _handleCreateMouseUp() {
    this._createNotification && this._createNotification.removeAttribute("isActive");
  }
  get _scrollContainer() {
    return document.querySelector(`.${this._scrollContainerClass}`);
  }
  _getCreateDropdownFixedPosition() {
    const t = (this.shadowRoot?.querySelector(".dss-sidemenu-create")).getBoundingClientRect();
    this._dropdown && (this._dropdown.style.left = `${t.right + 8}px`, this._dropdown.classList.contains("dss-sidemenu-create__dropdown--top") ? this._dropdown.style.top = `${t.top}px` : this._dropdown.style.top = `${t.bottom - this._dropdown.offsetHeight}px`);
  }
  _handleContainerScroll() {
    this._getCreateDropdownFixedPosition();
  }
  async firstUpdated() {
    await this.updateComplete, this._propagateProperties();
    const e = this.shadowRoot?.querySelector(".dss-sidemenu-create__dropdown");
    e && (this._dropdown = e, this._getCreateDropdownFixedPosition()), this._scrollContainer && this._scrollContainer.addEventListener("scroll", this._handleContainerScrollBound);
  }
  updated(e) {
    super.updated(e), (e.has("expanded") || e.has("disabled")) && (this._propagateProperties(), this._getCreateDropdownFixedPosition());
  }
  render() {
    return f(this);
  }
}
o([
  s(a)
], r.prototype, "expanded");
o([
  s(a)
], r.prototype, "disabled");
o([
  s({ type: String })
], r.prototype, "toggleLabel");
o([
  s({ type: String })
], r.prototype, "createLabel");
o([
  s({ type: String })
], r.prototype, "createMenuPosition");
o([
  s({ type: Number })
], r.prototype, "createNotifications");
o([
  s(a)
], r.prototype, "createDisabled");
o([
  s(a)
], r.prototype, "hideCreateMenu");
o([
  s({ type: String })
], r.prototype, "scrollContainerClass");
export {
  r as Sidemenu
};
//# sourceMappingURL=sidemenu.js.map
