import { LitElement as n, unsafeCSS as i } from "lit";
import { property as p } from "lit/decorators.js";
import l from "../../shared/reset.style.css.js";
import u from "./breadcrumb.style.css.js";
import { template as a } from "./breadcrumb.template.js";
var f = Object.defineProperty, c = (s, t, r, v) => {
  for (var e = void 0, o = s.length - 1, m; o >= 0; o--)
    (m = s[o]) && (e = m(t, r, e) || e);
  return e && f(t, r, e), e;
};
class d extends n {
  constructor() {
    super(...arguments), this.items = [];
  }
  static get styles() {
    return [i(l), i(u)];
  }
  handleItemClick(t, r) {
    t.preventDefault(), t.currentTarget?.blur(), this.dispatchEvent(new CustomEvent("onItemClick", { detail: r.href, bubbles: !0, composed: !0 }));
  }
  render() {
    return a(this);
  }
}
c([
  p({ type: Array })
], d.prototype, "items");
export {
  d as Breadcrumb
};
//# sourceMappingURL=breadcrumb.js.map
