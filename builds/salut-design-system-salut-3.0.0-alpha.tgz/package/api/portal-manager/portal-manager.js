const t = () => {
  let e = document.querySelector(".dss-portal-manager");
  return e || (e = document.createElement("div"), e.className = "dss-portal-manager", Object.assign(e.style, {
    position: "absolute",
    top: "0",
    left: "0",
    width: "100%",
    zIndex: "999",
    pointerEvents: "none"
    // Para que el contenedor no bloquee clicks
  }), document.body.appendChild(e)), e;
};
export {
  t as getPortalContainer
};
//# sourceMappingURL=portal-manager.js.map
