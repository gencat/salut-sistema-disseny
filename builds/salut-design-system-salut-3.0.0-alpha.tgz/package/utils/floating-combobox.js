import { autoUpdate as h, offset as s, flip as E, shift as w, size as x, computePosition as P } from "@floating-ui/dom";
function b(e) {
  e.clearHideTimeout(), e.clearShowTimeout();
  const t = window.setTimeout(() => {
    e.onExecuteShow();
  }, e.delay);
  e.setShowTimeout(t);
}
function o(e) {
  e.initialParent || e.setInitialParent(e.floatingEl.parentElement), e.portalManager && e.floatingEl.parentElement !== e.portalManager && e.portalManager.appendChild(e.floatingEl), setTimeout(() => {
    e.floatingEl.classList.add(e.visibleClass ?? "visible");
  }, 0), e.parentEl && e.onUpdateFloating();
}
function T(e) {
  e.clearShowTimeout(), e.floatingEl.classList.remove(e.visibleClass ?? "visible");
  const t = window.setTimeout(() => {
    e.cleanupAutoUpdate?.(), e.setCleanupAutoUpdate(void 0), e.initialParent && e.floatingEl.parentElement !== e.initialParent && (e.initialParent.appendChild(e.floatingEl), e.resetPosition && (e.floatingEl.style.left = "0", e.floatingEl.style.top = "0"));
  }, e.hideDelay ?? 240);
  e.setHideTimeout(t);
}
function C(e) {
  if (!e.referenceEl) return;
  const t = h(e.referenceEl, e.floatingEl, () => e.onUpdatePosition());
  e.setCleanupAutoUpdate(t);
}
async function v(e, t, l = {}) {
  const { placement: i = "bottom", strategy: n = "fixed", offsetPx: r = 8, paddingPx: d = 8, matchWidth: f = !0 } = l, a = [s(r), E(), w({ padding: d })];
  f && a.push(
    x({
      apply({ rects: g, elements: m }) {
        Object.assign(m.floating.style, {
          width: `${g.reference.width}px`
        });
      }
    })
  );
  const { x: u, y: c } = await P(e, t, {
    placement: i,
    strategy: n,
    middleware: a
  });
  Object.assign(t.style, {
    left: `${u}px`,
    top: `${c}px`
  });
}
export {
  o as executeShow,
  T as hideFloating,
  b as scheduleShow,
  C as updateFloatingCombobox,
  v as updateFloatingPosition
};
//# sourceMappingURL=floating-combobox.js.map
