function i(t) {
  t && t.focus();
}
function r(t, o, c) {
  let n = 0;
  const e = t.querySelectorAll(c), l = e.length - 1;
  o === e[0] ? i(e[l]) : (e.forEach((s, a) => {
    s === o && (n = a);
  }), i(e[n - 1]));
}
function u(t, o, c) {
  let n = 0;
  const e = t.querySelectorAll(c), l = e.length - 1;
  o === e[l] ? i(e[0]) : (e.forEach((s, a) => {
    s === o && (n = a);
  }), i(e[n + 1]));
}
function f(t, o, c) {
  t.querySelector(`${c}[tabindex="0"]`)?.setAttribute("tabindex", "-1"), o.setAttribute("tabindex", "0"), o.click();
}
export {
  u as moveFocusToNextTarget,
  r as moveFocusToPreviousTarget,
  i as moveFocusToTarget,
  f as onKeyboardEnter
};
//# sourceMappingURL=keyboard-navigation.js.map
