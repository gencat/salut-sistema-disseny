import { nothing as e } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as i, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
const h = i`dss-icon${a(d())}`, $ = i`dss-icon-button${a(d())}`, t = i`dss-tooltip${a(d())}`, b = i`dss-select-options${a(d())}`, g = i`dss-chip${a(d())}`, w = (l) => s`
  <${b}
    id="${l._getEffectiveId()}-listbox"
    ariaLabel="Llista d'elements"
    class="combobox ${l._getEffectiveId()}-options"
    .openByDefault=${l.openWithSearch}
    .isOpen=${l.showDropdown}
    .multiple=${l.multiple}
    .tick=${l.tick}
    .deselectable=${l.deselectable}
    .disabled=${l.disabled}
    .elements=${l._filteredElements}
    .filter=${l._input?.value}
    .filterThreshold=${l.filterThreshold}
    .searchThreshold=${l.searchThreshold}
    .value=${l.selectedValue}
    .type=${l.type}
    .labelSelectAll=${l.labelSelectAll}
    .labelDeselectAll=${l.labelDeselectAll}
    .selectAll=${l.selectAll}
    selectedCounter=${l._selectElements}
    boxStyle=${l.dropdownStyle}
    boxShadow
    @option-changed="${l._handleSelectorChange}"
    @options-sentinel="${l._handleOptionsSentinel}"
    @keydown="${(r) => {
  r.key === "Escape" && (r.preventDefault(), r.stopPropagation(), l._handleBlurSelector(void 0, r));
}}"
    @focusout=${l._handleFocusOut}
    ?readonly=${l.readonly}
    .advancedFilter=${l.advancedFilter}
  >
  </${b}>
`, y = (l) => s`
  <input 
    type="hidden" 
    class="dss-hidden-value" 
    .name=${l.name} 
    .value=${l.value}
    @change=${l._onChange} 
  />

  <div class="${u({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": l.required,
  "dss-input-wrapper--disabled": l.disabled,
  [`dss-input-wrapper--${l.size}`]: !!l.size,
  "dss-input-wrapper--no-label": l.hideLabel
})}">

    ${l.size === "sm" && !l.hideLabel ? s`
      <div class="${u({
  "dss-wrapper-label": !0,
  "dss-wrapper-label--invalid": l.invalid
})}"
      >
        <label class="dss-label" for="${l._getEffectiveId()}">${l.label}</label>
      </div>
      ` : e}

    <div class="${u({
  "dss-input-group": !0,
  [`dss-input-group--${l.size}`]: !!l.size,
  "dss-input-group--invalid": l.invalid && !l.showDropdown,
  // 'dss-input-group--invalid': component.invalid || !component._inputValidity,
  "dss-input-group--required": l.required,
  "dss-input-group--disabled": l.disabled,
  "dss-input-group--focused": l.value || l._input?.value || l.placeholder || l._isFocused,
  "dss-input-group--read-only": l.readonly,
  "dss-input-group--no-label": l.hideLabel,
  "dss-input-group--numeric": l.type === "number",
  "dss-input-group--read-only-empty": l.readonly && l.placeholder === "" && !l._input?.value
})}">

      ${l.icon ? s`
        <${h} icon="${l.icon}" class="dss-input-icon"></${h}>
        ` : e}

      <div 
        class="dss-input-field"
        data-truncated="${!l.showDropdown && l._isTruncated && l.selectedValue && l.selectedValue?.length === 1}"
        @mouseover=${l._handleInputMouseOver}
      >
      
        ${l.size !== "sm" && !l.hideLabel ? s`
          <label class="dss-label" for="${l._getEffectiveId()}">${l.label}</label>
          ` : e}

        ${l.inputPrefix ? s`
           <span class="dss-input-inputPrefix">${l.inputPrefix}</span>
          ` : e}

        <input
          class="dss-input"
          id="${l._getEffectiveId()}"
          .type="text"
          .name="${l.name ?? e}"
          .placeholder=${l._placeholder}
          ?disabled=${l.disabled}
          ?readonly=${l.readonly}
          ?required=${l.required}
          ?autofocus=${l.autofocus}
          spellcheck=${l.spellcheck ? "true" : "false"}
          autocorrect=${l.autocorrect ? "on" : "off"}
          autocomplete=${l.autocomplete}
          autocapitalize=${l.autocapitalize}
          min=${l.min ?? e}
          max=${l.max ?? e}
          step=${l.step ?? e}
          minlength=${l.minLength && Number.isFinite(l.minLength) && l.minLength > 0 ? l.minLength : e}
          maxLength=${l.maxLength && Number.isFinite(l.maxLength) && l.maxLength > 0 ? l.maxLength : e}
          pattern=${l.pattern ?? e}
          inputmode=${l.inputmode ?? e}
          aria-label="${l.hideLabel ? l.label : e}"
          @input=${l._handleInput}
          @focusin=${l._handleFocusIn}
          @focusout=${l._handleFocusOut}
          @keydown=${l._handleKeyDown}
          @click=${l._handleClick}
          role="combobox"
          aria-haspopup="listbox"
          aria-controls="${l.showDropdown ? `${l._getEffectiveId()}-listbox` : e}"
          aria-expanded=${l.showDropdown ? "true" : "false"}
        />

        <${t} ?hidden=${l.showDropdown} aria-hidden="true">${l._input?.value}</${t}>
      </div>


      ${l.multiple && l._isTruncated && l.selectedValue && l.selectedValue?.length > 1 ? s`
          <${g}
            label="${l._multipleSelectedCounter}"
            size="xs"
            ?selected=${l.showDropdown}
            @toggle=${l._toggleDropdown}>
          </${g}>
        ` : e}

      ${!l.openWithSearch && !l.readonly ? s`
            <${$}
              class="dss-icon-button dss-input-dropdown__toggle"
              size="md"
              icon="${l.showDropdown ? "keyboard_arrow_up" : "keyboard_arrow_down"}"
              label="${l.showDropdown ? "Tancar dropdown" : "Obrir dropdown"}"
              hideTooltip
              ariaExpanded="${l.showDropdown}"
              variant="primary"
              ?disabled=${l.disabled}
              disableTabindex
              @onClick=${l._toggleDropdown}
            ></${$}>
        ` : l.openWithSearch ? s`
          <${$}
            class="dss-icon-button dss-input-dropdown__toggle"
            size="md"
            label="Esborra la selecció"
            hideTooltip
            icon="close"
            variant="primary"
            ?disabled=${l.disabled || l.readonly}
            disableTabindex
            @onClick=${l._cleanInput}
          ></${$}>
        ` : e}

      ${l.openWithSearch ? e : s`${w(l)}`}

      
    </div>

    ${l.helpText && !l.openWithSearch ? s`
      <div class="${u({
  "dss-input-help": !0,
  "dss-input-help--invalid": l.invalid && !l.showDropdown,
  "dss-input-help--disabled": l.disabled
})}">
        <span>${l.helpText}</span>
        ${l.maxLength && Number.isFinite(l.maxLength) && l.maxLength > 0 ? s`
          <span>
            ${l._input?.value?.length ?? 0}/${l.maxLength}
          </span>` : e}
      </div>
      ` : e}

    ${l.openWithSearch ? s`${w(l)}` : e}
  </div>  
`;
export {
  y as template
};
//# sourceMappingURL=select.template.js.map
