import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as r, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const l = r`dss-icon${d(t())}`, a = r`dss-tooltip${d(t())}`, k = (s) => i`
  <a
    href="${s.disabled ? "javascript:void(0)" : s.href}"
    target="${s.disabled ? "_self" : s.target}"
    ?download="${s.download}"
    class=${e({
  "dss-link": !0,
  "dss-link--standalone": !!s.size && !!s.variant,
  [`dss-link--${s.variant}`]: s.variant,
  [`dss-link--${s.size}`]: !!s.size,
  "dss-link--full-width": !!s.fullWidth,
  "dss-link--disabled": !!s.disabled,
  "dss-link--icon-right": !!s.icon && s.iconPosition === "right",
  [`dss-link--${s.fontWeight}`]: s.fontWeight !== "inherit"
})}
	 @mouseenter=${s.checkTextTruncate}
  >
    ${s.icon ? i`
          <${l} size="${s._getIconSize()}" icon="${s.icon}"></${l}>
        ` : null}
    <span class="dss-link-text">${s.label}</span>
		${s.size && s.variant ? i`
			<${a} 
				class="dss-link__tooltip"
				aria-hidden="true"
			>
				${s.label}
			</${a}>
			` : null}
  </a>
`;
export {
  k as template
};
//# sourceMappingURL=link.template.js.map
