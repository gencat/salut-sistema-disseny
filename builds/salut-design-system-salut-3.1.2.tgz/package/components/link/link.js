import { LitElement as u, unsafeCSS as h } from "lit";
import { property as t } from "lit/decorators.js";
import d from "../../shared/reset.style.css.js";
import { booleanType as l } from "../../utils/property-types.js";
import c from "./link.style.css.js";
import { template as y } from "./link.template.js";
var S = Object.defineProperty, e = (p, r, o, n) => {
  for (var s = void 0, a = p.length - 1, f; a >= 0; a--)
    (f = p[a]) && (s = f(r, o, s) || s);
  return s && S(r, o, s), s;
};
class i extends u {
  constructor() {
    super(...arguments), this.variant = "default", this.href = "#", this.label = "", this.icon = void 0, this.size = void 0, this.iconSize = "sm", this.iconPosition = "left", this.disabled = !1, this.download = !1, this.target = "_self", this.fontWeight = "inherit", this.fontSize = "inherit", this.fullWidth = !1;
  }
  static get styles() {
    return [h(d), h(c)];
  }
  updated(r) {
    r.has("variant") && queueMicrotask(() => {
      this.variant !== "default" && this.size === void 0 && (this.size = "lg");
    }), r.has("fontSize") && queueMicrotask(() => {
      if (this.variant !== "default" || this.size !== void 0) return;
      const o = this.shadowRoot?.querySelector("a.dss-link");
      o && (o.style.fontSize = this.fontSize);
    });
  }
  _getIconSize() {
    return this.size ? this.size === "lg" ? "md" : "sm" : this.iconSize;
  }
  checkTextTruncate(r) {
    if (!r) return;
    const o = r.target;
    let n = !1;
    const s = o.querySelector(".dss-link-text");
    n = s.scrollWidth > s.offsetWidth, o.setAttribute("data-truncated", n.toString());
  }
  focus(r) {
    const o = this.shadowRoot?.querySelector(".dss-link");
    if (!o) return;
    const n = { ...r, focusVisible: !0 };
    o.focus(n);
  }
  render() {
    return y(this);
  }
}
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "href");
e([
  t({ type: String })
], i.prototype, "label");
e([
  t({ type: String })
], i.prototype, "icon");
e([
  t({ type: String })
], i.prototype, "size");
e([
  t({ type: String })
], i.prototype, "iconSize");
e([
  t({ type: String })
], i.prototype, "iconPosition");
e([
  t(l)
], i.prototype, "disabled");
e([
  t(l)
], i.prototype, "download");
e([
  t({ type: String })
], i.prototype, "target");
e([
  t({ type: String })
], i.prototype, "fontWeight");
e([
  t({ type: String })
], i.prototype, "fontSize");
e([
  t(l)
], i.prototype, "fullWidth");
export {
  i as Link
};
//# sourceMappingURL=link.js.map
