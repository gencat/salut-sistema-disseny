import { classMap as l } from "lit/directives/class-map.js";
import { html as s } from "lit/static-html.js";
const d = (i) => s`
	<div 
		role="tooltip"
		aria-hidden="${i.ariaHidden || "false"}"
		class="${l({
  "dss-tooltip": !0,
  [`dss-tooltip--align-${i.align}`]: !!i.align,
  "dss-tooltip--hidden": i.hidden
})}"
		@mouseenter="${i._selfMouseEnter}"
	>
		<slot></slot>
	</div>
`;
export {
  d as template
};
//# sourceMappingURL=tooltip.template.js.map
