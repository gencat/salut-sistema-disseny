import { autoUpdate as l, computePosition as u, offset as _, flip as c, shift as v } from "@floating-ui/dom";
import { LitElement as f, unsafeCSS as m } from "lit";
import { property as o, query as b } from "lit/decorators.js";
import { getPortalContainer as w } from "../../api/portal-manager/portal-manager.js";
import { booleanType as p } from "../../utils/property-types.js";
import y from "./tooltip.style.css.js";
import { template as E } from "./tooltip.template.js";
var g = Object.defineProperty, s = (r, t, e, a) => {
  for (var i = void 0, h = r.length - 1, d; h >= 0; h--)
    (d = r[h]) && (i = d(t, e, i) || i);
  return i && g(t, e, i), i;
};
class n extends f {
  constructor() {
    super(...arguments), this.position = "top", this.align = "left", this.hidden = !1, this.delay = 200, this.interactive = !1, this._initialParent = null, this._portalManager = null, this._isPortaling = !1, this._isOpen = !1, this._onFocusIn = () => this.show(), this._onFocusOut = () => this.hide(), this._onTooltipMouseEnter = () => {
      window.clearTimeout(this._hideTimeout);
    }, this._onMouseEnter = () => {
      this.show();
    }, this._onMouseLeave = (t) => {
      const e = t.relatedTarget;
      this.contains(e) || this._parent?.contains(e) || (this._hideTimeout = window.setTimeout(() => {
        this.hide();
      }, 160));
    };
  }
  static get styles() {
    return [m(y)];
  }
  connectedCallback() {
    super.connectedCallback(), !this._isPortaling && (this._portalManager = w(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement), this._parent && (this._setEventListeners(), this._setAccessibility()));
  }
  disconnectedCallback() {
    super.disconnectedCallback(), !this._isPortaling && (window.clearTimeout(this._showTimeout), window.clearTimeout(this._hideTimeout), this._destroyEventListeners(), this._visibleObserver?.disconnect(), this._visibleObserver = void 0, this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0);
  }
  _setEventListeners() {
    this._parent?.addEventListener("mouseenter", this._onMouseEnter), this._parent?.addEventListener("mouseleave", this._onMouseLeave), this._parent?.addEventListener("focusin", this._onFocusIn), this._parent?.addEventListener("focusout", this._onFocusOut), this.addEventListener("mouseenter", this._onTooltipMouseEnter), this.addEventListener("mouseleave", this._onMouseLeave);
  }
  _destroyEventListeners() {
    this._parent?.removeEventListener("mouseenter", this._onMouseEnter), this._parent?.removeEventListener("mouseleave", this._onMouseLeave), this._parent?.removeEventListener("focusin", this._onFocusIn), this._parent?.removeEventListener("focusout", this._onFocusOut), this.removeEventListener("mouseenter", this._onTooltipMouseEnter), this.removeEventListener("mouseleave", this._onMouseLeave);
  }
  _setAccessibility() {
    this._parent && (this.id || (this.id = `dss-tooltip-${crypto.randomUUID()}`), this._parent.hasAttribute("aria-describedby") || this._parent.setAttribute("aria-describedby", this.id));
  }
  _selfMouseEnter(t) {
    this.interactive || (t.stopPropagation(), t.preventDefault(), this.hide(), this.style.pointerEvents = "none");
  }
  show() {
    this.hidden || this.parentElement?.getAttribute("data-truncated") !== "false" && (window.clearTimeout(this._hideTimeout), window.clearTimeout(this._showTimeout), this._isOpen = !0, this._showTimeout = window.setTimeout(async () => {
      await this._executeShow();
    }, this.delay));
  }
  async _executeShow() {
    if (!this._parent || !this._parent.isConnected) return;
    this._initialParent || (this._initialParent = this.parentElement);
    const t = this._parent.getBoundingClientRect();
    t.top < window.innerHeight && t.bottom > 0 && t.left < window.innerWidth && t.right > 0 && t.width > 0 && t.height > 0 && (this._portalManager && this.parentElement !== this._portalManager && (this._isPortaling = !0, this._portalManager.appendChild(this), this._isPortaling = !1), this._visibleObserver?.disconnect(), this._visibleObserver = new IntersectionObserver(
      ([a]) => {
        a.isIntersecting || this.hide(0);
      },
      { threshold: 0 }
    ), this._visibleObserver.observe(this._parent), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = l(this._parent, this, () => this._updatePosition()), this.style.display = "block", await this._updatePosition(), this._isOpen && (this.classList.add("visible"), this._tooltipEl?.setAttribute("aria-hidden", "false")));
  }
  _finishHide() {
    this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0, this._visibleObserver?.disconnect(), this._visibleObserver = void 0, this._initialParent?.isConnected && this.parentElement !== this._initialParent ? (this._isPortaling = !0, this._initialParent.appendChild(this), this._isPortaling = !1) : this._initialParent?.isConnected || this.remove(), this.style.display = "none", this.style.left = "", this.style.top = "";
  }
  hide(t = 240) {
    if (this._isOpen = !1, window.clearTimeout(this._showTimeout), window.clearTimeout(this._hideTimeout), this._visibleObserver?.disconnect(), this._visibleObserver = void 0, this.classList.remove("visible"), this._tooltipEl.setAttribute("aria-hidden", "true"), t === 0) {
      this._finishHide();
      return;
    }
    this._hideTimeout = window.setTimeout(() => {
      this._finishHide();
    }, t);
  }
  updateTooltip() {
    this._parent && (this._cleanupAutoUpdate = l(this._parent, this, () => this._updatePosition()));
  }
  async _updatePosition() {
    if (this.hidden || !this._parent) return;
    if (!this._parent.isConnected) {
      this.hide(0);
      return;
    }
    const { x: t, y: e } = await u(this._parent, this, {
      placement: this.position,
      strategy: "fixed",
      middleware: [_(8), c(), v({ padding: 8 })]
    });
    if (!this._parent.isConnected) {
      this.hide(0);
      return;
    }
    Object.assign(this.style, {
      left: `${t}px`,
      top: `${e}px`
    });
  }
  updated(t) {
    super.updated(t), t.has("hidden") && this.hidden && this.hide(0);
  }
  render() {
    return E(this);
  }
}
s([
  o({ type: String })
], n.prototype, "position");
s([
  o({ type: String })
], n.prototype, "align");
s([
  o(p)
], n.prototype, "hidden");
s([
  o({ type: Number })
], n.prototype, "delay");
s([
  o(p)
], n.prototype, "interactive");
s([
  b(".dss-tooltip")
], n.prototype, "_tooltipEl");
export {
  n as Tooltip
};
//# sourceMappingURL=tooltip.js.map
