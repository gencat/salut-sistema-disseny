import { unsafeStatic as i, literal as l, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const r = l`dss-icon${i(e())}`, $ = (s) => {
  const t = s.imageUrl ? "" : "dss-avatar--border";
  return a`
      <div class="dss-avatar dss-avatar--${s.size} ${t}">
        ${s.imageUrl ? a`<img
              class="dss-avatar__img"
              src="${s.imageUrl}"
              alt="avatar"
            />` : a`${s._acronym ? a`<span class="dss-avatar__font">${s._acronym}</span>` : a`
                      <${r}
                        class="dss-avatar__icon"
                        size=${s._getIconSize()}
                        icon="person"
                      ></${r}>
                  `}`}
      </div>
    `;
};
export {
  $ as template
};
//# sourceMappingURL=avatar.template.js.map
