import { LitElement as u, unsafeCSS as l } from "lit";
import { property as s } from "lit/decorators.js";
import h from "./avatar.style.css.js";
import { template as c } from "./avatar.template.js";
var y = Object.defineProperty, i = (m, t, r, o) => {
  for (var e = void 0, a = m.length - 1, p; a >= 0; a--)
    (p = m[a]) && (e = p(t, r, e) || e);
  return e && y(t, r, e), e;
};
class n extends u {
  constructor() {
    super(...arguments), this.name = "", this.surname = "", this.imageUrl = "", this.size = "md", this._acronym = "";
  }
  static get styles() {
    return [l(h)];
  }
  _getIconSize() {
    switch (this.size) {
      case "sm":
        return "sm";
      case "md":
        return "sm";
      case "lg":
        return "md";
      case "xl":
        return "lg";
      default:
        return "md";
    }
  }
  willUpdate(t) {
    const r = t.has("name"), o = t.has("surname");
    (r || o) && this.formatAcronym();
  }
  formatAcronym() {
    let t = this.name?.trim().substring(0, 1).toUpperCase();
    this.name && this.surname ? t += this.surname.trim().substring(0, 1).toUpperCase() : t = this.name?.trim().substring(0, 2).toUpperCase(), this._acronym = t, this.requestUpdate("acronym", t);
  }
  render() {
    return c(this);
  }
}
i([
  s({ type: String })
], n.prototype, "name");
i([
  s({ type: String })
], n.prototype, "surname");
i([
  s({ type: String })
], n.prototype, "imageUrl");
i([
  s({ type: String })
], n.prototype, "size");
export {
  n as Avatar
};
//# sourceMappingURL=avatar.js.map
