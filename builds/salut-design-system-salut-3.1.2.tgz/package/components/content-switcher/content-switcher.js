import { LitElement as n, unsafeCSS as h } from "lit";
import { property as d, state as p } from "lit/decorators.js";
import b from "../../shared/elevation.style.css.js";
import f from "../../shared/reset.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import m from "./content-switcher.style.css.js";
import { template as u } from "./content-switcher.template.js";
var _ = Object.defineProperty, i = (l, e, t, y) => {
  for (var s = void 0, r = l.length - 1, o; r >= 0; r--)
    (o = l[r]) && (s = o(e, t, s) || s);
  return s && _(e, t, s), s;
};
class a extends n {
  constructor() {
    super(...arguments), this.fullWidth = !1, this.size = "md", this.tabs = void 0, this._tabs = [];
  }
  static get styles() {
    return [h(f), h(b), h(m)];
  }
  _onSelect(e) {
    e.selected = !0, this.tabSelected = e, this._tabs = this._tabs.map((t) => ({ ...t, selected: t.label === this.tabSelected?.label })), this.dispatchEvent(new CustomEvent("change", { detail: this.tabSelected.label })), this.requestUpdate();
  }
  _checkFullWidth() {
    this.fullWidth ? this.classList.add("full-width") : this.classList.remove("full-width");
  }
  _initializeSelectedTab() {
    if (!this.tabs) return;
    const e = typeof this.tabs == "string" ? JSON.parse(this.tabs) : this.tabs;
    this._tabs = e.map((t) => ({ ...t })), this.tabSelected = this._tabs.find((t) => t.selected) || this._tabs.find((t) => !t.disabled);
  }
  willUpdate(e) {
    e.has("tabs") && this._initializeSelectedTab();
  }
  updated(e) {
    e.has("fullWidth") && this._checkFullWidth();
  }
  render() {
    return u(this);
  }
}
i([
  d(c)
], a.prototype, "fullWidth");
i([
  d({ type: String })
], a.prototype, "size");
i([
  d({ type: Array })
], a.prototype, "tabs");
i([
  p()
], a.prototype, "tabSelected");
i([
  p()
], a.prototype, "_tabs");
export {
  a as ContentSwitcher
};
//# sourceMappingURL=content-switcher.js.map
