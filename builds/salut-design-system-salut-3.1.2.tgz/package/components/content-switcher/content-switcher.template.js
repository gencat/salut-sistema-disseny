import { nothing as c, html as i } from "lit";
import { classMap as t } from "lit/directives/class-map.js";
import { repeat as o } from "lit/directives/repeat.js";
const h = (s) => i`
  <div class=${t({
  "dss-content-switcher": !0,
  "dss-content-switcher--full-width": s.fullWidth
})}
    role="radiogroup" 
    aria-orientation="horizontal">
    ${o(
  s._tabs,
  (e) => e.label,
  (e, l) => {
    const d = {
      "dss-elevation--md": !!e.selected
    }, a = {
      "dss-content-switcher__item": !0,
      "dss-content-switcher__item--selected": !!e.selected,
      "dss-content-switcher__item--disabled": !!e.disabled,
      [`dss-content-switcher__item--${s.size}`]: !!s.size
    };
    return i`
          <div class=${t(a)}>
            <input
              id="radio-${l}"
              type="radio"
              tabindex=${e.selected || e.label === s.tabSelected?.label ? "0" : "-1"}
              name="tab"
              ?checked=${e.selected || e.label === s.tabSelected?.label}
              ?disabled=${e.disabled}
              @change=${() => s._onSelect(e)}
              aria-labelledby="label-${l}"
            />
            <label id="label-${l}" class=${t(d)}>
              ${e.icon ? i`
                <dss-icon icon="${e.icon}" size="${s.size === "lg" ? "md" : "sm"}" class="tab-icon"></dss-icon>
              ` : c}
              ${e.label}
            </label>
          </div>
        `;
  }
)}
  </div>
`;
export {
  h as template
};
//# sourceMappingURL=content-switcher.template.js.map
