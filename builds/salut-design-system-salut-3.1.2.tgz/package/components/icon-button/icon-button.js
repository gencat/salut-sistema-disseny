import { LitElement as h, unsafeCSS as f } from "lit";
import { property as e } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as i } from "../../utils/property-types.js";
import c from "./icon-button.style.css.js";
import { template as m } from "./icon-button.template.js";
var b = Object.defineProperty, o = (l, p, s, d) => {
  for (var r = void 0, a = l.length - 1, y; a >= 0; a--)
    (y = l[a]) && (r = y(p, s, r) || r);
  return r && b(p, s, r), r;
};
const n = class n extends h {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.size = "md", this.label = "", this.icon = void 0, this.fill = !1, this.disabled = !1, this.hidden = !1, this.disableTabindex = !1, this.ariaLabel = null, this.ariaExpanded = void 0, this.tooltipInteractive = !1, this.tooltipPosition = "top", this.hideTooltip = !1;
  }
  static get styles() {
    return [f(u), f(c)];
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  focus(p) {
    const s = this.shadowRoot?.querySelector(".dss-icon-button");
    if (!s) return;
    const d = { ...p, focusVisible: !0 };
    s.focus(d);
  }
  render() {
    return m(this);
  }
};
n.shadowRootOptions = {
  ...h.shadowRootOptions,
  delegatesFocus: !0
};
let t = n;
o([
  e({ type: String })
], t.prototype, "type");
o([
  e({ type: String })
], t.prototype, "variant");
o([
  e({ type: String })
], t.prototype, "size");
o([
  e({ type: String })
], t.prototype, "label");
o([
  e({ type: String })
], t.prototype, "icon");
o([
  e(i)
], t.prototype, "fill");
o([
  e(i)
], t.prototype, "disabled");
o([
  e(i)
], t.prototype, "hidden");
o([
  e(i)
], t.prototype, "disableTabindex");
o([
  e({ type: String })
], t.prototype, "ariaLabel");
o([
  e(i)
], t.prototype, "ariaExpanded");
o([
  e(i)
], t.prototype, "tooltipInteractive");
o([
  e({ type: String })
], t.prototype, "tooltipPosition");
o([
  e(i)
], t.prototype, "hideTooltip");
export {
  t as IconButton
};
//# sourceMappingURL=icon-button.js.map
