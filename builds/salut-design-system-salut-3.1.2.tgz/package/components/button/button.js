import { LitElement as d, unsafeCSS as h } from "lit";
import { property as o, state as f } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as l, booleanConverter as m } from "../../utils/property-types.js";
import b from "./button.style.css.js";
import { template as g } from "./button.template.js";
var S = Object.defineProperty, e = (u, s, r, n) => {
  for (var i = void 0, p = u.length - 1, c; p >= 0; p--)
    (c = u[p]) && (i = c(s, r, i) || i);
  return i && S(s, r, i), i;
};
const a = class a extends d {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.status = "default", this.label = "", this.icon = void 0, this.iconPosition = "left", this.disabled = !1, this.hidden = !1, this.onlyIcon = !1, this.fullWidth = !1, this.size = "md", this.loading = !1, this.hideTooltip = !1, this.loadingIcon = "progress_activity", this._isTextTruncated = !1;
  }
  static get styles() {
    return [h(y), h(b)];
  }
  _handleClick() {
    if (this.disabled || this.loading) return;
    const s = this.closest("form");
    this.type === "submit" && s ? s.requestSubmit() : this.type === "reset" && s && s.reset(), this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  _getIconSize() {
    return this.size === "lg" ? "md" : "sm";
  }
  checkTextTruncate(s) {
    if (!s) return;
    if (this.onlyIcon) {
      this._isTextTruncated = !0;
      return;
    }
    const r = s.target;
    let n = !1;
    if (this.onlyIcon)
      n = !0;
    else {
      const i = r.querySelector(".dss-button-text");
      n = i.scrollWidth > i.offsetWidth;
    }
    r.setAttribute("data-truncated", n.toString());
  }
  focus(s) {
    const r = this.shadowRoot?.querySelector(".dss-button");
    if (!r) return;
    const n = { ...s, focusVisible: !0 };
    r.focus(n);
  }
  render() {
    return g(this);
  }
};
a.shadowRootOptions = {
  ...d.shadowRootOptions,
  delegatesFocus: !0
};
let t = a;
e([
  o({ type: String })
], t.prototype, "type");
e([
  o({ type: String })
], t.prototype, "variant");
e([
  o({ type: String })
], t.prototype, "status");
e([
  o({ type: String })
], t.prototype, "label");
e([
  o({ type: String })
], t.prototype, "icon");
e([
  o({ type: String })
], t.prototype, "iconPosition");
e([
  o(l)
], t.prototype, "disabled");
e([
  o(l)
], t.prototype, "hidden");
e([
  o(l)
], t.prototype, "onlyIcon");
e([
  o({ converter: m, reflect: !0 })
], t.prototype, "fullWidth");
e([
  o({ type: String })
], t.prototype, "size");
e([
  o(l)
], t.prototype, "loading");
e([
  o(l)
], t.prototype, "hideTooltip");
e([
  f()
], t.prototype, "_isTextTruncated");
export {
  t as Button
};
//# sourceMappingURL=button.js.map
