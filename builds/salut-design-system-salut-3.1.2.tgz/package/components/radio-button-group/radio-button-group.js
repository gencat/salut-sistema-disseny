import { LitElement as p, unsafeCSS as c } from "lit";
import { queryAssignedElements as f, property as d } from "lit/decorators.js";
import { getCustomElementSuffix as m } from "../../api/custom-element-scope.js";
import v from "../../shared/reset.style.css.js";
import { booleanType as b } from "../../utils/property-types.js";
import _ from "./radio-button-group.style.css.js";
import { template as y } from "./radio-button-group.template.js";
var g = Object.defineProperty, n = (l, t, e, a) => {
  for (var s = void 0, o = l.length - 1, r; o >= 0; o--)
    (r = l[o]) && (s = r(t, e, s) || s);
  return s && g(t, e, s), s;
};
const C = `dss-radio-button${m()}`, h = class h extends p {
  constructor() {
    super(), this.name = "radio-group-host", this.label = "", this.hideLabel = !1, this.value = "", this.orientation = "vertical", this.disabled = void 0, this._onRadioChange = (t) => {
      this.value = t.target.value, this._emitChange();
    }, this._onKeyDown = (t) => {
      if (!this._radioButtons || this._radioButtons.length === 0) return;
      const e = Array.from(this._radioButtons), a = e.findIndex(
        (u) => u === this.shadowRoot?.activeElement || u === document.activeElement
      );
      if (a === -1) return;
      let s = a;
      switch (t.key) {
        case "ArrowRight":
        case "ArrowDown":
          s = (a + 1) % e.length;
          break;
        case "ArrowLeft":
        case "ArrowUp":
          s = (a - 1 + e.length) % e.length;
          break;
        default:
          return;
      }
      t.preventDefault();
      const o = e[a];
      if (!o) return;
      o.tabIndex = -1;
      const r = e[s];
      r && (r.tabIndex = 0, r.focusInput());
    }, this.internals = this.attachInternals();
  }
  static get styles() {
    return [c(v), c(_)];
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("change", this._onRadioChange), this.addEventListener("keydown", this._onKeyDown);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("change", this._onRadioChange), this.removeEventListener("keydown", this._onKeyDown);
  }
  updated(t) {
    t.has("name") && this._updateNameState(), t.has("value") && (this.internals.setFormValue(this.value), this._updateCheckedState()), t.has("disabled") && this._updateDisabledState();
  }
  formResetCallback() {
    this.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "";
  }
  render() {
    return y(this);
  }
  _emitChange() {
    const t = {
      detail: { value: this.value },
      bubbles: !1,
      composed: !0
    }, e = new CustomEvent("value-changed", t);
    this.dispatchEvent(e);
  }
  _updateCheckedState() {
    if (!this._radioButtons) return;
    let t = !1;
    this._radioButtons.forEach((e) => {
      const a = e.value === this.value;
      e.checked = a, a ? (e.tabIndex = 0, t = !0) : e.tabIndex = -1;
    }), t || (this._radioButtons[0].tabIndex = 0);
  }
  _updateNameState() {
    this._radioButtons && this._radioButtons.forEach((t) => {
      t.name = this.name;
    });
  }
  _updateDisabledState() {
    !this._radioButtons || this.disabled === void 0 || this._radioButtons.forEach((t) => {
      t.disabled = this.disabled;
    });
  }
};
h.formAssociated = !0;
let i = h;
n([
  f({ selector: C.toString() })
], i.prototype, "_radioButtons");
n([
  d({ type: String })
], i.prototype, "name");
n([
  d({ type: String })
], i.prototype, "label");
n([
  d(b)
], i.prototype, "hideLabel");
n([
  d({ type: String })
], i.prototype, "value");
n([
  d({ type: String })
], i.prototype, "orientation");
n([
  d({ type: Boolean, reflect: !0 })
], i.prototype, "disabled");
export {
  i as RadioButtonGroup
};
//# sourceMappingURL=radio-button-group.js.map
