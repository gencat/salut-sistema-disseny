import { nothing as b } from "lit";
import { classMap as g } from "lit/directives/class-map.js";
import { unsafeStatic as _, literal as u, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { MONTH as v, WEEK as D } from "./calendar.js";
const w = u`dss-timepicker${_(o())}`, n = u`dss-icon${_(o())}`, s = u`dss-icon-button${_(o())}`, c = u`dss-button${_(o())}`, Y = (e) => i`
  <div
    role="${e.standalone ? b : "dialog"}"
    aria-label="${e.standalone ? b : "Calendari"}"
    class=${g({
  calendar__container: !0,
  "calendar__container--standalone": e.standalone,
  "calendar__container--show-month-selector": e._showMonthSelector,
  "calendar__container--show-year-selector": e._showYearSelector
})}
    @keydown="${e._handleCalendarKeydown}"
    @focusin="${e._handleCalendarFocusIn}"
    @focusout="${e._handleCalendarFocusOut}"
  >
    <div class="calendar__content">
      <div class="calendar__header">
        <div
          class="calendar__sr-only"
          aria-live="polite"
          aria-atomic="true"
        >
          ${v[e._currMonth]} ${e._currYear}
        </div>
        <div class="calendar__header-item calendar__header-selector">
          <div
            id="firstCalendarElement"
            class="calendar__header-item calendar__header-item--click calendar__header-month"
            tabindex="0"
            role="button"
            @keydown="${e._onShiftTabKeyDown}"
            @click="${e._toggleMonthSelector}"
            aria-label="selecciona el mes, actualment ${v[e._currMonth]}"
          >
            ${v[e._currMonth]}
            <${n} icon="expand_more" size="sm"></${n}>
          </div>
          <div
            class="calendar__header-item calendar__header-item--click calendar__header-year"
            tabindex="0"
            role="button"
            @keydown="${e._onHeaderYearKeyDown}"
            @click=${e._toggleYearSelector}
            aria-label="selecciona l'any, actualment ${e._currYear}"
          >
            ${e._currYear}
            <${n} icon="expand_more" size="sm"></${n}>
          </div>
        </div>
        <div class="calendar__header-item calendar__header-buttons">
          <${s} hideTooltip variant="primary" icon="chevron_left" label="Mes anterior" @click=${e._prev}
            ?disabled=${e._currMonth === e._minDate?.getMonth() && e._currYear === e._minDate?.getFullYear()}>
          </${s}>
          <${s} hideTooltip variant="primary" icon="chevron_right" label="Següent mes" @click=${e._next}
            ?disabled=${e._currMonth === e._maxDate?.getMonth() && e._currYear === e._maxDate?.getFullYear()}>
          </${s}>
        </div>
      </div>

      <div class="calendar__days-content">
        <ul class="calendar__week-names">
          ${D.map((a) => i`<li>${a}</li>`)}
        </ul>
        <div
          class="calendar__days"
          @mouseleave=${e._removeRangeOverDate}
        >
          ${e._days.map((a) => {
  if (!a)
    return i`
                <span class="calendar__day-item calendar__day-item--empty" aria-hidden="true"></span>
              `;
  const k = {
    "calendar__day-item--active": e._isToday(a),
    "calendar__day-item--weekend": e._isWeekend(a),
    "calendar__day-item--selected": e._isSelected(a),
    [`calendar__day-item--${e._getCustomType(a)}`]: !!e._getCustomType(a),
    "calendar__day-item--range": e._isBetweenRange(a) || e._isBetweenRangeOnMouseOver(a),
    "calendar__day-item--selected-range-start": e._isSelectedRangeStart(a),
    "calendar__day-item--selected-range-end": e._isSelectedRangeEnd(a) || e._isOverRangeDate(a),
    "calendar__day-item--range-enabled": e._range
  }, S = (l) => {
    const r = l.target;
    if (l.key === "ArrowUp") {
      l.preventDefault();
      const t = f(r, -7);
      t ? t.focus() : h();
    }
    if (l.key === "ArrowDown") {
      l.preventDefault();
      const t = f(r, 7);
      t ? t.focus() : y();
    }
    if (l.key === "ArrowRight") {
      l.preventDefault();
      const t = r.nextElementSibling;
      t ? t.focus() : y();
    }
    if (l.key === "ArrowLeft") {
      l.preventDefault();
      const t = m(r);
      t ? t.focus() : h();
    }
  }, h = () => {
    e._prev(), setTimeout(() => {
      const l = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), r = Array.from(l).filter((d) => !d.disabled), t = r[r.length - 1];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, y = () => {
    e._next(), setTimeout(() => {
      const l = e.shadowRoot?.querySelectorAll(
        ".calendar__day-item:not(.calendar__day-item--empty)"
      ), t = Array.from(l).filter((d) => !d.disabled)[0];
      t && (t.setAttribute("tabindex", "0"), t.focus());
    }, 0);
  }, m = (l) => {
    let r = l?.previousElementSibling;
    for (; r; ) {
      if (!r.classList.contains("calendar__day-item") || r.classList.contains("calendar__day-item--empty")) {
        r = r.previousElementSibling;
        continue;
      }
      if (!r.disabled)
        return r;
      r = r.previousElementSibling;
    }
    return null;
  }, f = (l, r) => {
    const d = Array.from(
      l.closest(".calendar__days")?.querySelectorAll(".calendar__day-item:not(.calendar__day-item--empty)") || []
    ).filter((x) => !x.disabled), $ = d.indexOf(l) + r;
    return $ < 0 || $ >= d.length ? null : d[$];
  };
  return i`
              <button
                role="option"
                aria-label="${e._getDayAriaLabel(a)}"
                aria-selected="${e._isSelected(a) ? "true" : "false"}"
                tabindex="${e._isFocusable(a) ? 0 : -1}"
                data-day="${a}"
                class="calendar__day-item ${g(k)}"
                @click=${(l) => e._selectDate(a, l.detail === 0)}
                @mouseover=${() => e._selectRangeOverDate(a)}
                @focus=${() => e._selectRangeOverDate(a)}
                ?disabled=${e._isInactive(a)}
                @keydown="${S}"
              >
                ${a || null}
              </button>
            `;
})}
        </div>
      </div>
    </div>
    ${e._showMonthSelector ? i`
          <div class="calendar-selector calendar-selector--month">
            <div class="calendar-selector-title">Selecciona un mes</div>
            <div class="calendar-selector-options">
              ${e._generateMonthsOptions()}
            </div>
          </div>
        ` : null}
    ${e._showYearSelector ? i`
          <div class="calendar-selector calendar-selector--year">
            <div
              class="calendar-selector-title calendar-selector-title--years"
            >
              <div 
                class="calendar-selector-title__years"  
                aria-live="polite"
                aria-atomic="true"
              >
                ${e._yearsRangeStart} - ${e._yearsRangeEnd}
              </div>
              <div class="calendar-selector-title__actions">
                <${s}
                  id="prevYearElement"
                  hideTooltip
                  variant="primary" 
                  label="Anys anteriors"
                  icon="chevron_left"
                  @click=${e._onYearRangeStepDown}
                  @keydown="${e._onShiftTabKeyDown}"
                ></${s}>
                <${s}
                  hideTooltip
                  variant="primary" 
                  label="Anys posteriors"
                  icon="chevron_right"
                  @click=${e._onYearRangeStepUp}
                ></${s}>
              </div>
            </div>
            <div
              class="calendar-selector-options calendar-selector-options--4col"
            >
              ${e._generateYearsRangeOptions()}
            </div>
          </div>
        ` : null}
    ${e._showTime ? i`
          <div class="dss-datepicker__timepicker">
            <${w}
              label=${e._timepickerLabel}
              .dropdown="${e._timepicker}"
              .customTimeListOptions=${e._customTimeListOptions}
              .minutesRange=${e._minutesRange}
              .minHour=${e._minHour}
              .maxHour=${e._maxHour}
              maxLength="5"
              @value-changed=${e._onSelectTime}
              .value="${e._timepickerValue}"
            >
            </${w}>
          </div>
        ` : null}
    ${(e._showButtons || e._showTime) && !e.standalone ? i`
          <div class="calendar__content calendar__content--buttons">
            <div class="calendar__buttons">
              <${c}
                variant="secondary"
                label=${e._leftLabel}
                @click=${e._onCancel}
              >
              </${c}>
              <${c}
                variant="primary"
                label=${e._rightLabel}

                @click=${e._onAccept}
                ?disabled=${e._validateSelectedDate()}
              >
              </${c}>
            </div>
          </div>
        ` : null}
    ${e.standalone ? null : i`
          <button
            class="calendar-focus-sentinel calendar-focus-sentinel--end"
            type="button"
            aria-hidden="true"
            tabindex="0"
            @focus="${e._handleEndSentinelFocus}"
          ></button>
        `}
  </div>
`;
export {
  Y as template
};
//# sourceMappingURL=calendar.template.js.map
