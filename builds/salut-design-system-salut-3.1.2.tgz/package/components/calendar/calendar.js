import { scheduleShow as M, executeShow as R, hideFloating as T, updateFloatingCombobox as F, updateFloatingPosition as Y } from "../../utils/floating-combobox.js";
import { startOfMonth as x, endOfMonth as O, eachDayOfInterval as k, getDay as C } from "date-fns";
import { LitElement as q, unsafeCSS as U } from "lit";
import { property as o, query as A, state as L } from "lit/decorators.js";
import { classMap as v } from "lit/directives/class-map.js";
import { html as S } from "lit/static-html.js";
import { getPortalContainer as H } from "../../api/portal-manager/portal-manager.js";
import { booleanType as p } from "../../utils/property-types.js";
import V from "./calendar.style.css.js";
import { template as P } from "./calendar.template.js";
var $ = Object.defineProperty, I = Object.getOwnPropertyDescriptor, i = (y, t, e, s) => {
  for (var a = s > 1 ? void 0 : s ? I(t, e) : t, h = y.length - 1, c; h >= 0; h--)
    (c = y[h]) && (a = (s ? c(t, e, a) : c(a)) || a);
  return s && a && $(t, e, a), a;
};
const D = [
  "Gener",
  "Febrer",
  "Març",
  "Abril",
  "Maig",
  "Juny",
  "Juliol",
  "Agost",
  "Setembre",
  "Octubre",
  "Novembre",
  "Desembre"
], Z = ["dl", "dm", "dc", "dj", "dv", "ds", "dg"];
class n extends q {
  constructor() {
    super(), this.standalone = !1, this.openByDefault = !1, this.placement = "bottom", this.customCalendar = void 0, this._open = !1, this._range = !1, this._isRangeStartFocused = !1, this._isRangeEndFocused = !1, this._rangeStartDate = null, this._rangeEndDate = null, this._rangeOverDate = null, this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._timepickerLabel = "", this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._days = this._getDays(), this._selectedDate = null, this._showTime = !1, this._showButtons = !1, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._minDate = null, this._maxDate = null, this._timepickerValue = "", this._showMonthSelector = !1, this._showYearSelector = !1, this._yearsRangeStart = (/* @__PURE__ */ new Date()).getFullYear() - 18, this._yearsRangeEnd = (/* @__PURE__ */ new Date()).getFullYear() + 1, this._isTimeFormatValid = !1, this._previouslyFocusedElement = null, this.delay = 0, this._initialParent = null, this._portalManager = null, this._isTabbingOut = !1, this._isFirstUpdated = !0, this._focusFirstElementHandler = this._focusFirstElement.bind(this);
  }
  static get styles() {
    return [U(V)];
  }
  set open(t) {
    const e = this._open;
    this._open = t, e && !t && (this._showMonthSelector = !1, this._showYearSelector = !1), this.requestUpdate("open", e);
  }
  get open() {
    return this._open;
  }
  set range(t) {
    const e = this._range;
    this._range = t, this.requestUpdate("range", e);
  }
  get range() {
    return this._range;
  }
  set isRangeStartFocused(t) {
    const e = this._isRangeStartFocused;
    this._isRangeStartFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeStartFocused() {
    return this._isRangeStartFocused;
  }
  set isRangeEndFocused(t) {
    const e = this._isRangeEndFocused;
    this._isRangeEndFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeEndFocused() {
    return this._isRangeEndFocused;
  }
  set selectedDate(t) {
    const e = this._selectedDate;
    this._selectedDate = this._getDateString(t), this._updateCurrentDate(), this.requestUpdate("selectedDate", e);
  }
  get selectedDate() {
    return this._selectedDate?.toString() || "";
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = this._getDateString(t), this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate?.toString() || "";
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = this._getDateString(t), this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate?.toString() || "";
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set rangeStartDate(t) {
    const e = this._rangeStartDate;
    this._rangeStartDate = this._getDateString(t), this.requestUpdate("rangeStartDate", e);
  }
  get rangeStartDate() {
    return this._rangeStartDate?.toString() || "";
  }
  set rangeEndDate(t) {
    const e = this._rangeEndDate;
    this._rangeEndDate = this._getDateString(t), this.requestUpdate("rangeEndDate", e);
  }
  get rangeEndDate() {
    return this._rangeEndDate?.toString() || "";
  }
  connectedCallback() {
    super.connectedCallback(), this.classList.toggle("standalone", this.standalone), this._range && window.addEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0, this._range && window.removeEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = H(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("open") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    }), t.has("openByDefault") && queueMicrotask(() => {
      this.openByDefault ? this.classList.add("keep-open") : this.classList.remove("keep-open");
    });
  }
  _toggle() {
    this.openByDefault || (this.open ? this.show() : this.hide());
  }
  show() {
    M({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    });
  }
  _executeShow() {
    R({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCalendar()
    });
  }
  hide() {
    T({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCalendar() {
    F({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    this._parent && await Y(this._parent, this, {
      placement: this.placement,
      matchWidth: !1
    });
  }
  _focusFirstElement() {
    if (this._showYearSelector) {
      (this.shadowRoot?.querySelector("#prevYearElement")).focus();
      return;
    }
    if (this._showMonthSelector) {
      (this.shadowRoot?.querySelector(".calendar-selector-options__item--selected")).focus();
      return;
    }
    (this.shadowRoot?.querySelector("#firstCalendarElement")).focus();
  }
  _focusActiveDay() {
    if (this._showMonthSelector || this._showYearSelector) {
      this._focusFirstElement();
      return;
    }
    const t = this.shadowRoot?.querySelector(".calendar__day-item--selected:not(:disabled)") ?? this.shadowRoot?.querySelector(".calendar__day-item--active:not(:disabled)") ?? this.shadowRoot?.querySelector(
      ".calendar__day-item:not(:disabled):not(.calendar__day-item--empty)"
    );
    t?.getAttribute("tabindex") !== "0" && (this.shadowRoot?.querySelectorAll('.calendar__day-item[tabindex="0"]').forEach((e) => {
      e.setAttribute("tabindex", "-1");
    }), t?.setAttribute("tabindex", "0")), t?.focus();
  }
  _handleCalendarFocusIn(t) {
    if (this.standalone) return;
    const e = t.relatedTarget;
    e && !this.shadowRoot?.contains(e) && (this._previouslyFocusedElement = e);
  }
  _handleEndSentinelFocus() {
    if (this.standalone) return;
    const t = this._previouslyFocusedElement;
    if (t && t.isConnected) {
      t.focus();
      return;
    }
    const e = this.getRootNode();
    e instanceof ShadowRoot && e.querySelector("input")?.focus();
  }
  _prev() {
    this._currMonth -= 1, this._update();
  }
  _next() {
    this._currMonth += 1, this._update();
  }
  _update() {
    (this._currMonth < 0 || this._currMonth > 11) && (this._date = new Date(this._currYear, this._currMonth, (/* @__PURE__ */ new Date()).getDate()), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth()), this._days = this._getDays(), this.dispatchEvent(
      new CustomEvent("calendar-updated", {
        detail: {
          year: this._currYear,
          month: this._currMonth
        },
        bubbles: !0,
        composed: !0
      })
    ), this.requestUpdate();
  }
  _getDays() {
    const t = [], e = x(new Date(this._currYear, this._currMonth)), s = O(new Date(this._currYear, this._currMonth)), a = k({ start: e, end: s }), h = C(e);
    for (let c = h === 0 ? 6 : h - 1; c > 0; c -= 1)
      t.push(0);
    for (const c of a)
      t.push(c.getDate());
    return t;
  }
  _getCustomType(t) {
    if (!this.customCalendar) return !1;
    const s = new Date(this._currYear, this._currMonth, t).toLocaleDateString("es-ES"), a = this.customCalendar.find((h) => h.date === s);
    return a ? a.type : !1;
  }
  _isToday(t) {
    const e = /* @__PURE__ */ new Date();
    return t === e.getDate() && this._currMonth === e.getMonth() && this._currYear === e.getFullYear();
  }
  _isWeekend(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return e.getDay() === 0 || e.getDay() === 6;
  }
  _getDayAriaLabel(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return new Intl.DateTimeFormat("ca-ES", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(e);
  }
  _getFirstEnabledDay() {
    return this._days.find((t) => t && !this._isInactive(t)) ?? null;
  }
  _isInactive(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return t ? this._minDate && this._maxDate ? !(e >= this._minDate && e <= this._maxDate) : this._minDate ? !(e >= this._minDate) : this._maxDate ? !(e <= this._maxDate) : !1 : !0;
  }
  _isSelected(t) {
    return this._range ? t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() || this._isSelectedRangeEnd(t) : t === this._selectedDate?.getDate() && this._currMonth === this._selectedDate?.getMonth() && this._currYear === this._selectedDate?.getFullYear();
  }
  _isFocusable(t) {
    return this._range && (this._rangeStartDate || this._rangeEndDate) ? this._isSelectedRangeStart(t) || this._isSelectedRangeEnd(t) : this._selectedDate ? this._isSelected(t) : this._days.some((s) => s && this._isToday(s)) ? this._isToday(t) : t === this._getFirstEnabledDay();
  }
  _isSelectedRangeStart(t) {
    return this._range && this._rangeStartDate && this._rangeEndDate ? !this._compareSelectedRangeDates() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() : this._range && this._rangeStartDate && !this._rangeEndDate ? this._rangeOverDate !== null && this._rangeStartDate?.getTime() < this._rangeOverDate?.getTime() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : (this._range && this._rangeStartDate === this._rangeEndDate, !1);
  }
  _isSelectedRangeEnd(t) {
    return !this._compareSelectedRangeDates() && t === this._rangeEndDate?.getDate() && this._currMonth === this._rangeEndDate?.getMonth() && this._currYear === this._rangeEndDate?.getFullYear();
  }
  _isOverRangeDate(t) {
    const e = t === this._rangeOverDate?.getDate() && this._currMonth === this._rangeOverDate?.getMonth() && this._currYear === this._rangeOverDate?.getFullYear();
    return this._range && this._rangeOverDate && this._rangeStartDate && !this._rangeEndDate ? e && this._rangeOverDate.getTime() > this._rangeStartDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _compareSelectedRangeDates() {
    return this._rangeStartDate && this._rangeEndDate ? this._rangeStartDate.getFullYear() === this._rangeEndDate.getFullYear() && this._rangeStartDate.getMonth() === this._rangeEndDate.getMonth() && this._rangeStartDate.getDate() === this._rangeEndDate.getDate() : !0;
  }
  _isBetweenRange(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return !this._isInactive(t) && this._rangeStartDate && this._rangeEndDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() : !1;
  }
  _isBetweenRangeOnMouseOver(t) {
    const e = new Date(this._currYear, this._currMonth, t), s = this._isInactive(t);
    return !s && this._rangeStartDate && !this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !s && this._rangeStartDate && this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _selectDate(t, e = !1) {
    this._selectedDate = new Date(this._currYear, this._currMonth, t), this._range && !this._showButtons && (this._rangeStartDate && this._rangeEndDate && !this._isRangeEndFocused && this._selectedDate.getTime() >= this._rangeEndDate.getTime() && (this._rangeStartDate = null, this._rangeEndDate = null), this._isRangeStartFocused || !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this._range && this._showButtons && (this._rangeStartDate && this._rangeEndDate && (this._rangeStartDate = null, this._rangeEndDate = null), !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this.requestUpdate(), this._range && this._rangeStartDate && !this._rangeEndDate && e && this._focusNextRangeDay(t), !(this._showButtons && !this.standalone) && (this._range ? this._emitRange(e) : this._emitDate());
  }
  _focusNextRangeDay(t) {
    const e = this._days.includes(t + 1) && !this._isInactive(t + 1) ? t + 1 : t;
    this.updateComplete.then(() => {
      this.shadowRoot?.querySelector(
        `.calendar__day-item[data-day="${e}"]`
      )?.focus();
    });
  }
  _selectRangeOverDate(t) {
    this._range && (this._rangeOverDate = new Date(this._currYear, this._currMonth, t), this.requestUpdate());
  }
  _removeRangeOverDate() {
    this._rangeOverDate = null, this.requestUpdate();
  }
  _onCancel() {
    const t = new CustomEvent("cancel", {
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(t);
  }
  _onAccept() {
    this._range ? this._emitRange() : this._emitDate();
  }
  _emitDate() {
    const t = this._selectedDate?.getDate()?.toString().padStart(2, "0"), e = (this._currMonth + 1).toString().padStart(2, "0");
    let s = `${t}/${e}/${this._currYear}`;
    if (this._showTime) {
      const h = this._currHour?.toString().padStart(2, "0"), c = this._currMin?.toString().padStart(2, "0");
      s += ` ${h}:${c}`;
    }
    const a = new CustomEvent("date-changed", {
      detail: s,
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(a);
  }
  _emitRange(t = !1) {
    let e = null;
    if (this._rangeStartDate?.getDate() != null && this._rangeStartDate?.getMonth() != null && this._rangeStartDate?.getFullYear() != null) {
      const h = this._rangeStartDate.getDate()?.toString().padStart(2, "0"), m = (this._rangeStartDate?.getMonth() + 1).toString().padStart(2, "0");
      e = `${h}/${m}/${this._rangeStartDate?.getFullYear()}`;
    }
    let s = null;
    if (this._rangeEndDate?.getDate() != null && this._rangeEndDate?.getMonth() != null && this._rangeEndDate?.getFullYear()) {
      const h = this._rangeEndDate.getDate()?.toString().padStart(2, "0"), m = (this._rangeEndDate?.getMonth() + 1).toString().padStart(2, "0");
      s = `${h}/${m}/${this._rangeEndDate?.getFullYear()}`;
    }
    const a = new CustomEvent("range-changed", {
      detail: {
        rangeStart: e,
        rangeEnd: s,
        isKeyboardSelection: t
      },
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(a);
  }
  _updateCurrentDate() {
    if (!this._selectedDate) {
      this._resetCalendar();
      return;
    }
    if (this._currMonth = this._selectedDate.getMonth(), this._currYear = this._selectedDate.getFullYear(), this._currHour = this._selectedDate.getHours(), this._currMin = this._selectedDate.getMinutes(), this._days = this._getDays(), this._currHour !== void 0 && this._currMin !== void 0) {
      const t = String(this._currHour).padStart(2, "0"), e = String(this._currMin).padStart(2, "0");
      this._timepickerValue = `${t}:${e}`, this._isTimeFormatValid = this._currHour >= 0 && this._currHour <= 23 && this._currMin >= 0 && this._currMin <= 59;
    }
  }
  _resetCalendar() {
    this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._timepickerValue = "", this._isTimeFormatValid = !1, this._days = this._getDays(), this.requestUpdate();
  }
  _getDateString(t) {
    const e = t?.replace(/(\d+[/])(\d+[/])/, "$2$1"), s = this._showTime ? 14 : 8;
    return e?.length > s ? new Date(e) : null;
  }
  _onSelectTime(t) {
    if (this._isTimeFormatValid = !1, t.detail.status === "VALID") {
      this._isTimeFormatValid = !0;
      const e = t.detail.value;
      this._currHour = +e.substring(0, 2), this._currMin = +e.substring(3, 5);
    }
    this.requestUpdate();
  }
  _toggleMonthSelector() {
    this._showMonthSelector = !0, this.requestUpdate();
  }
  _closeMonthSelector(t = {}) {
    this._showMonthSelector = !1, this.requestUpdate(), t.focusActiveDay && this.updateComplete.then(() => this._focusActiveDay());
  }
  _onMonthSelectorClick(t, e = {}) {
    const s = D.indexOf(t);
    this._currMonth = s, this._update(), this._showMonthSelector = !1, this.requestUpdate(), this._closeMonthSelector(e);
  }
  _toggleYearSelector() {
    this._showYearSelector = !0, this.requestUpdate();
  }
  _closeYearSelector(t = {}) {
    this._showYearSelector = !1, this.requestUpdate(), t.focusActiveDay && this.updateComplete.then(() => this._focusActiveDay());
  }
  _onYearSelectorClick(t, e = {}) {
    this._currYear = t, this._update(), this._showYearSelector = !1, this.requestUpdate(), this._closeYearSelector(e);
  }
  _generateYearsRangeOptions() {
    const t = [];
    for (let a = this._yearsRangeStart; a <= this._yearsRangeEnd; a += 1)
      t.push(a);
    const e = t.includes(this._currYear) ? this._currYear : t[0];
    return t.map((a) => {
      const h = (r) => {
        r && r.focus();
      }, c = (r) => {
        let l = 0;
        const _ = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = _.length - 1;
        r === _[0] ? h(_[d]) : (_.forEach((f, E) => {
          f === r && (l = E);
        }), h(_[l - 1]));
      }, m = (r) => {
        let l = 0;
        const _ = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = _.length - 1;
        r === _[d] ? h(_[0]) : (_.forEach((f, E) => {
          f === r && (l = E);
        }), h(_[l + 1]));
      }, b = (r) => {
        const l = r.currentTarget, _ = r;
        let d = !1;
        switch (_.key) {
          case "ArrowUp":
          case "ArrowLeft":
            c(l), d = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            m(l), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
          case " ":
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--year[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), r.target.setAttribute("tabindex", "0"), this._onYearSelectorClick(a, { focusActiveDay: !0 }), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this._closeYearSelector({ focusActiveDay: !0 }), r.preventDefault(), r.stopPropagation(), d = !0;
            break;
        }
        d && (r.stopPropagation(), r.preventDefault());
      }, u = (/* @__PURE__ */ new Date()).getFullYear(), g = {
        "calendar-selector-options__item--current": a === u,
        "calendar-selector-options__item--selected": a === this._currYear
      };
      return S`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--year ${v(g)}"
					tabindex="${a === e ? 0 : -1}"
          role="button"
          @keydown=${b}
          @click=${() => this._onYearSelectorClick(a)}
        >
          ${a}
        </div>
      `;
    });
  }
  _generateMonthsOptions() {
    return D.map((e) => {
      const s = (u) => {
        u && u.focus();
      }, a = (u) => {
        let g = 0;
        const r = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), l = r.length - 1;
        u === r[0] ? s(r[l]) : (r.forEach((_, d) => {
          _ === u && (g = d);
        }), s(r[g - 1]));
      }, h = (u) => {
        let g = 0;
        const r = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), l = r.length - 1;
        u === r[l] ? s(r[0]) : (r.forEach((_, d) => {
          _ === u && (g = d);
        }), s(r[g + 1]));
      }, c = (u) => {
        const g = u.currentTarget, r = u;
        let l = !1;
        switch (r.key) {
          case "Tab":
            if (r.shiftKey) {
              const d = this._previouslyFocusedElement;
              d && d.isConnected && d.focus(), l = !0;
            }
            break;
          case "ArrowUp":
          case "ArrowLeft":
            a(g), l = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            h(g), l = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
          case " ":
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--month[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), u.target.setAttribute("tabindex", "0"), this._onMonthSelectorClick(e, { focusActiveDay: !0 }), l = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this._closeMonthSelector({ focusActiveDay: !0 }), u.preventDefault(), u.stopPropagation(), l = !0;
            break;
        }
        l && (u.stopPropagation(), u.preventDefault());
      }, b = (/* @__PURE__ */ new Date()).getMonth(), w = {
        "calendar-selector-options__item--current": D.indexOf(e) === b,
        "calendar-selector-options__item--selected": D.indexOf(e) === this._currMonth
      };
      return S`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--month ${v(w)}"
          tabindex="${D.indexOf(e) === this._currMonth ? 0 : -1}"
          role="button"
          @keydown=${c}
          @click=${() => this._onMonthSelectorClick(e)}
        >
          ${e.length <= 4 ? S`${e}` : S`${e.slice(0, 3)}.`}
        </div>
      `;
    });
  }
  _onYearRangeStepUp() {
    this._yearsRangeStart += 20, this._yearsRangeEnd += 20, this.requestUpdate();
  }
  _onYearRangeStepDown() {
    this._yearsRangeStart -= 20, this._yearsRangeEnd -= 20, this.requestUpdate();
  }
  _onShiftTabKeyDown(t) {
    if (t?.key === "Tab" && t.shiftKey) {
      t.preventDefault(), t.stopPropagation();
      const e = this._previouslyFocusedElement;
      if (e && e.isConnected) {
        e.focus();
        return;
      }
    }
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--month[tabindex="0"]').focus();
    }, 50));
  }
  _onHeaderYearKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--year[tabindex="0"]').focus();
    }, 50));
  }
  _validateSelectedDate() {
    return !!(!this._range && !this._selectedDate || !this._range && this._showTime && !this._isTimeFormatValid || this._range && (!this._rangeStartDate || !this._rangeEndDate));
  }
  _handleCalendarKeydown(t) {
    if (t?.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this._onCancel()), t?.key === "Tab") {
      const e = this._getFocusableElements(), a = this.renderRoot?.activeElement ?? document.activeElement;
      if (!e.length || !a) {
        t.preventDefault(), t.stopPropagation(), this.dispatchEvent(
          new CustomEvent("calendar-focusout", {
            bubbles: !0,
            composed: !0
          })
        );
        return;
      }
      const h = e[0], c = e[e.length - 1];
      (t.shiftKey && a === h || !t.shiftKey && a === c) && (t.preventDefault(), t.stopPropagation(), this.dispatchEvent(
        new CustomEvent("calendar-focusout", {
          bubbles: !0,
          composed: !0
        })
      ));
    }
  }
  _getFocusableElements() {
    const t = this.renderRoot;
    return t ? Array.from(t.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')).filter((a) => a.hasAttribute("disabled") || a.getAttribute("aria-disabled") === "true" ? !1 : a.tabIndex >= 0) : [];
  }
  _handleCalendarFocusOut(t) {
    const e = t.relatedTarget, s = this.renderRoot;
    if (e && s instanceof ShadowRoot && s.contains(e)) {
      this._isTabbingOut = !1;
      return;
    }
    this._isTabbingOut && this.dispatchEvent(
      new CustomEvent("calendar-focusout", {
        bubbles: !0,
        composed: !0
      })
    ), this._isTabbingOut = !1;
  }
  render() {
    return P(this);
  }
}
i([
  o(p)
], n.prototype, "standalone", 2);
i([
  o(p)
], n.prototype, "open", 1);
i([
  o(p)
], n.prototype, "openByDefault", 2);
i([
  o({ type: String })
], n.prototype, "placement", 2);
i([
  o({ type: Array })
], n.prototype, "customCalendar", 2);
i([
  o(p)
], n.prototype, "range", 1);
i([
  o(p)
], n.prototype, "isRangeStartFocused", 1);
i([
  o(p)
], n.prototype, "isRangeEndFocused", 1);
i([
  o({ type: String })
], n.prototype, "selectedDate", 1);
i([
  o({ type: String })
], n.prototype, "minDate", 1);
i([
  o({ type: String })
], n.prototype, "maxDate", 1);
i([
  o(p)
], n.prototype, "showTime", 1);
i([
  o(p)
], n.prototype, "showButtons", 1);
i([
  o({ type: String })
], n.prototype, "leftLabel", 1);
i([
  o({ type: String })
], n.prototype, "rightLabel", 1);
i([
  o({ type: String })
], n.prototype, "timepicker", 1);
i([
  o({ type: Number })
], n.prototype, "minutesRange", 1);
i([
  o({ type: Number })
], n.prototype, "minHour", 1);
i([
  o({ type: Number })
], n.prototype, "maxHour", 1);
i([
  o({ type: Array })
], n.prototype, "customTimeListOptions", 1);
i([
  o({ type: String })
], n.prototype, "timepickerLabel", 1);
i([
  o({ type: String })
], n.prototype, "rangeStartDate", 1);
i([
  o({ type: String })
], n.prototype, "rangeEndDate", 1);
i([
  A(".dss-select-options")
], n.prototype, "_floatingCombobox", 2);
i([
  o({ type: Number })
], n.prototype, "delay", 2);
i([
  L()
], n.prototype, "_isFirstUpdated", 2);
export {
  n as Calendar,
  D as MONTH,
  Z as WEEK
};
//# sourceMappingURL=calendar.js.map
