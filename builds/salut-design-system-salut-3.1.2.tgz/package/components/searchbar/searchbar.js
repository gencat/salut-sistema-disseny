import { LitElement as y, unsafeCSS as f } from "lit";
import { query as m, property as r, state as p } from "lit/decorators.js";
import { unsafeStatic as g, literal as v } from "lit/static-html.js";
import { getCustomElementSuffix as S } from "../../api/custom-element-scope.js";
import w from "../../api/marker/marker.style.css.js";
import { getPortalContainer as C } from "../../api/portal-manager/portal-manager.js";
import { normalizeText as o } from "../../utils/helpers.js";
import { lazyLoading as b } from "../../utils/lazy-loading.js";
import { booleanType as n, booleanConverter as u } from "../../utils/property-types.js";
import D from "./searchbar.style.css.js";
import { template as F } from "./searchbar.template.js";
var T = Object.defineProperty, i = (_, t, s, h) => {
  for (var a = void 0, l = _.length - 1, c; l >= 0; l--)
    (c = _[l]) && (a = c(t, s, a) || a);
  return a && T(t, s, a), a;
};
const I = v`dss-chip${g(S())}`, d = class d extends y {
  constructor() {
    super(), this.value = "", this.multiple = !1, this.icon = "search", this.size = "lg", this.helpText = void 0, this.innerFocus = !1, this.threshold = 3, this.maxTermChips = 5, this.searchTerms = [], this.searchItems = [], this.emptyDropdownText = "Sense resultats per", this.catalogLabel = "Resultats de la cerca", this.catalog = [], this.recentSearchesLabel = "Últimes cerques", this.recentSearches = [], this.isCatalogLoading = !1, this.catalogStyle = "", this.advancedFilter = !1, this.placeholder = "Escriu per cercar", this._filter = "", this._isFocused = !1, this._showClearButton = !1, this._filteredCatalog = [], this._filteredRecentSearches = [], this._showAllChips = !1, this._showDropdown = !1, this.serverSideFilter = !1, this.id = "", this.name = "", this.label = "Cercador", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.disableValidation = !1, this._defaultId = `dss-searchbar-input-${crypto.randomUUID()}`, this._isTruncated = !1, this._isCatalogLoaded = !1, this._handleDocumentMouseDown = null, this._portalManager = null, this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showDropdown && (this._closeDropdown(), this._isFocused = !1);
      },
      {
        root: null,
        threshold: 0
      }
    ), this._lastValue = null, this.internals = this.attachInternals(), this._handleClickOutside = this._handleClickOutside.bind(this);
  }
  static get styles() {
    return [f(w), f(D)];
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  _getPortalCombobox() {
    return this._portalManager?.querySelector(`.${this._getEffectiveId()}-catalog`);
  }
  updated(t) {
    t.has("value") && queueMicrotask(() => {
      this.internals.setFormValue(this.value), this.requestUpdate();
    }), (t.has("catalog") || t.has("recentSearches")) && queueMicrotask(() => {
      if (!this._isCatalogLoaded) {
        this._isCatalogLoaded = !0;
        return;
      }
      if (this._filter.length >= this.threshold) {
        this._filteredCatalog = this.serverSideFilter ? this.catalog : this._getFilterCatalog(this._filter), this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(this._filter);
        return;
      }
      if (this._filter.length === 0 && this.recentSearches.length > 0) {
        this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches;
        return;
      }
    });
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeDropdownListeners(), this.visibleObserver.disconnect();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  get _inputValidity() {
    return this._input && this._input.value !== "" ? this._input?.checkValidity() : !0;
  }
  _handleInput() {
    this.multiple || this._handleValidity(), this.value = this._input.value, this._filter = this._input.value;
    const t = this._input.value;
    if (t.length === 0) {
      this.recentSearches.length > 0 ? (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches) : this._hideDropdown(), this._emitInput();
      return;
    }
    if (t.length >= this.threshold)
      if (this._showDropdown = !0, this._filteredCatalog = this.serverSideFilter ? this.catalog : this._getFilterCatalog(t), this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(t), this.multiple) {
        if (t.endsWith(",")) {
          const s = t.slice(0, -1);
          this.searchTerms.push(s), this._input.value = "", this.searchTerms.length && this._dispatchSearchChange();
        }
      } else
        this.searchTerms = [t];
    else this.recentSearches.length > 0 ? (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.serverSideFilter ? this.recentSearches : this._getFilterSearches(t)) : this._hideDropdown();
    this._emitInput();
  }
  _handleClickOutside(t) {
    const s = t.composedPath(), h = `${this._getEffectiveId()}-catalog`, a = this._portalManager?.querySelector(`.${h}`);
    !s.includes(this) && !s.includes(a) && (this._showDropdown && this._closeDropdown(), this._isFocused = !1, this._showClearButton = !1);
  }
  _handleFocusIn() {
    this._isFocused = !0, this._showClearButton = !0, this._input.value.length === 0 && this.recentSearches.length > 0 && (this._showDropdown = !0, this._filteredCatalog = [], this._filteredRecentSearches = this.recentSearches);
  }
  _handleFocusOut(t) {
    const s = t.relatedTarget, h = this._getPortalCombobox();
    s instanceof HTMLElement && s.contains(this) || s !== null && s !== this._input && s !== this._combobox && s !== h && s !== I && (this._isFocused = !1, this._showClearButton = !1, this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value), this._hideDropdown());
  }
  _handleCatalogFocusOut() {
    this.readonly || this.disabled || this._showDropdown && (this._closeDropdown(), this._input?.focus());
  }
  _handleKeyDown(t) {
    t?.key === "Enter" ? (this._showDropdown = !0, !this.multiple && this._input.value !== "" && (this.searchTerms = [], this.searchTerms.push(this._input.value), this._dispatchSearchChange(), this._showDropdown = !1)) : t?.key === "Escape" ? this._showDropdown = !1 : (t?.key === "ArrowDown" || t?.key === "ArrowUp") && (t.preventDefault(), t.stopPropagation(), this._getPortalCombobox().moveFocus(), this._isFocused = !1);
  }
  _focusInput() {
    this._input?.focus();
  }
  _handleValidity() {
    if (this.disableValidation) return;
    const t = this._input?.checkValidity();
    this.invalid = !t, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _clearSearch() {
    this._input && (this._input.value = "", this._input.focus(), this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value)), this.searchTerms = [], this.searchItems = [], this._dispatchSearchChange(), this.recentSearches.length === 0 && this._hideDropdown();
  }
  _hideDropdown() {
    this._showDropdown = !1, this._filteredCatalog = [], this._filteredRecentSearches = [];
  }
  _getFilterCatalog(t) {
    return this.advancedFilter ? this._applyAdvancedCatalogFilter(t) : this._applyDefaultCatalogFilter(t);
  }
  _applyDefaultCatalogFilter(t) {
    const s = o(t);
    return this.catalog.filter((h) => o(h.value).includes(s));
  }
  _applyAdvancedCatalogFilter(t) {
    if (!o(t.trim())) return this.catalog;
    const h = o(t).split(/\s+/).filter((a) => a.length >= this.threshold);
    return h.length === 0 ? this.catalog : this.catalog.filter((a) => {
      const l = o(a.value);
      return h.every((c) => l.includes(c));
    });
  }
  _getFilterSearches(t) {
    return this.advancedFilter ? this._applyAdvancedSearchesFilter(t) : this._applyDefaultSearchesFilter(t);
  }
  _applyDefaultSearchesFilter(t) {
    const s = o(t);
    return this.recentSearches.filter((h) => o(h.value).includes(s));
  }
  _applyAdvancedSearchesFilter(t) {
    if (!o(t.trim())) return this.recentSearches;
    const h = o(t).split(/\s+/).filter((a) => a.length >= this.threshold);
    return h.length === 0 ? this.recentSearches : this.recentSearches.filter((a) => {
      const l = o(a.value);
      return h.every((c) => l.includes(c));
    });
  }
  _handleMultipleTermDelete(t) {
    this.disabled || this.readonly || (this.searchTerms = this.searchTerms.filter((s) => s !== t), this.searchItems = this.searchItems.filter((s, h) => this.searchTerms[h] !== t), this._dispatchSearchChange());
  }
  _dispatchSearchChange(t) {
    let s = {};
    t && t.data ? s = {
      values: this.searchTerms,
      selectedItems: this.searchItems
    } : s = this.searchTerms;
    const h = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("search", h)), this.multiple ? this.value = this.searchTerms.toString() : this.value = this.searchTerms[0] || "", this._emitChange();
  }
  _emitInput() {
    !this._input || this.multiple || (this.dispatchEvent(new Event("input", { bubbles: !1, composed: !1 })), this._handleChange());
  }
  _handleChange() {
    !this._input || this.multiple || this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _closeDropdown() {
    this._addDropdownListeners(), this._hideDropdown();
  }
  _addDropdownListeners() {
    this._removeDropdownListeners(), document.addEventListener("mousedown", this._handleClickOutside);
  }
  _removeDropdownListeners() {
    this._handleDocumentMouseDown && (document.removeEventListener("mousedown", this._handleClickOutside), this._handleDocumentMouseDown = null);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._input && this._closeDropdown(), b(this, () => {
        this.visibleObserver.observe(this._input), this._portalManager = C();
      });
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _handleMouseOver() {
    this._input?.value !== this._lastValue && (this._checkInputOverflow(), this._lastValue = this._input?.value || null);
  }
  _handleCatalogItemSelected(t) {
    const s = t.detail.item;
    !s || s.disabled || (this.multiple ? this.searchTerms.includes(s.value) ? (this.searchTerms = this.searchTerms.filter((a) => a !== s.value), s.data && (this.searchItems = this.searchItems.filter((a) => a !== s.data))) : (this.searchTerms.push(s.value), s.data && this.searchItems.push(s.data)) : (this._input.value = s.value, this._showDropdown = !1, this._isFocused = !1, this.searchTerms = [], this.searchTerms.push(s.value), s.data && (this.searchItems = [], this.searchItems.push(s.data))), this._input.value = this.multiple ? "" : s.value, this._filter = this._input.value, this._dispatchSearchChange());
  }
  _checkInputOverflow() {
    if (this.multiple) {
      this._isTruncated = !1;
      return;
    }
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), s = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, a = document.createElement("canvas").getContext("2d");
    if (!a) return;
    a.font = s;
    const l = a.measureText(this._input.value).width;
    this._isTruncated = l > this._input.offsetWidth, this._isTruncated && (this.shadowRoot?.querySelector(".dss-input-tooltip")).updateTooltip();
  }
  focus(t) {
    if (this._input) {
      this._input.focus(t);
      return;
    }
    this.updateComplete.then(() => {
      this._input?.focus(t);
    });
  }
  render() {
    return F(this);
  }
};
d.formAssociated = !0;
let e = d;
i([
  m("input.dss-input")
], e.prototype, "_input");
i([
  m(".combobox")
], e.prototype, "_combobox");
i([
  r({ type: String })
], e.prototype, "value");
i([
  r(n)
], e.prototype, "multiple");
i([
  r({ type: String })
], e.prototype, "icon");
i([
  r({ type: String })
], e.prototype, "size");
i([
  r({ type: String })
], e.prototype, "helpText");
i([
  r(n)
], e.prototype, "innerFocus");
i([
  r({ type: Number })
], e.prototype, "threshold");
i([
  r({ type: Number })
], e.prototype, "maxTermChips");
i([
  r({ type: Array })
], e.prototype, "searchTerms");
i([
  r({ type: Array })
], e.prototype, "searchItems");
i([
  r({ type: String })
], e.prototype, "emptyDropdownText");
i([
  r({ type: String })
], e.prototype, "catalogLabel");
i([
  r({ type: Array })
], e.prototype, "catalog");
i([
  r({ type: String })
], e.prototype, "recentSearchesLabel");
i([
  r({ type: Array })
], e.prototype, "recentSearches");
i([
  r(n)
], e.prototype, "isCatalogLoading");
i([
  r({ type: String })
], e.prototype, "catalogStyle");
i([
  r(n)
], e.prototype, "advancedFilter");
i([
  r({ type: String })
], e.prototype, "placeholder");
i([
  p()
], e.prototype, "_filter");
i([
  p()
], e.prototype, "_isFocused");
i([
  p()
], e.prototype, "_showClearButton");
i([
  p()
], e.prototype, "_filteredCatalog");
i([
  p()
], e.prototype, "_filteredRecentSearches");
i([
  p()
], e.prototype, "_showAllChips");
i([
  p()
], e.prototype, "_showDropdown");
i([
  r(n)
], e.prototype, "serverSideFilter");
i([
  r({ type: String })
], e.prototype, "id");
i([
  r({ type: String })
], e.prototype, "name");
i([
  r({ type: String })
], e.prototype, "label");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "disabled");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "readonly");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "required");
i([
  r({ converter: u, reflect: !0 })
], e.prototype, "invalid");
i([
  r({ type: String })
], e.prototype, "pattern");
i([
  r({ type: String })
], e.prototype, "inputmode");
i([
  r({ type: String })
], e.prototype, "autocapitalize");
i([
  r({ type: String })
], e.prototype, "autocomplete");
i([
  r(n)
], e.prototype, "autocorrect");
i([
  r(n)
], e.prototype, "autofocus");
i([
  r(n)
], e.prototype, "spellcheck");
i([
  r(n)
], e.prototype, "disableValidation");
i([
  p()
], e.prototype, "_isTruncated");
export {
  e as SearchBar
};
//# sourceMappingURL=searchbar.js.map
