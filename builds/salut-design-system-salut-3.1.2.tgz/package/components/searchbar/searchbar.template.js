import { nothing as i } from "lit";
import { classMap as h } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as e, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const $ = e`dss-icon${l(r())}`, d = e`dss-button${l(r())}`, c = e`dss-chip${l(r())}`, b = e`dss-tooltip${l(r())}`, _ = e`dss-icon-button${l(r())}`, f = e`dss-searchbar-catalog${l(r())}`, g = (s) => (s._showAllChips ? s.searchTerms : s.searchTerms.slice(0, s.maxTermChips)).map(
  (u) => a`
    <${c}
      class="${h({
    "dss-searchbar-multiple-term": !0
  })}"
      size="sm" 
      label="${u}" 
      disableSelect
      hasdelete
      ?disabled=${s.disabled}
      @delete="${() => s._handleMultipleTermDelete(u)}">
    </${c}>
  
  `
), x = (s) => {
  const t = {
    "dss-search-bar--invalid": s.invalid || !s._inputValidity,
    "dss-search-bar--disabled": s.disabled,
    "dss-search-bar--required": s.required,
    "dss-search-bar--read-only": s.readonly,
    "dss-search-bar--focused": s._isFocused,
    "dss-search-bar--default": !s.multiple,
    "dss-search-bar--multiple": s.multiple,
    "dss-search-bar--show-chips": s._showAllChips,
    "dss-search-bar--md": s.size === "md",
    "dss-search-bar--inner-focus": s.innerFocus,
    "dss-search-bar--has-value": s._showClearButton || s._input?.value || s.searchTerms.length > 0
  };
  return a`
    <div class="dss-search">
        <div
          class="dss-search-bar ${h(t)}"
        >
          <div class="dss-search-bar__icon">
            <${$} size="md" icon="${s.icon}"  @click=${s._focusInput}></${$}>
          </div>

          <div class="dss-search-bar__container">
            ${s.multiple ? a`
                    ${g(s)}

                    ${!s._showAllChips && s.searchTerms.length > s.maxTermChips ? a`
                          <${d}
                            class="filters-show-more"
                            variant="info"
                            size="sm"
                            label="Més (${s.searchTerms.length - s.maxTermChips})"
                            @click=${() => s._showAllChips = !0}
                          ></${d}>
                        ` : null}

                    ${s._showAllChips && s.searchTerms.length > s.maxTermChips ? a`
                          <${d}
                            class="filters-show-more"
                            variant="info"
                            size="sm"
                            label="Menys"
                            @click=${() => s._showAllChips = !1}
                          ></${d}>
                        ` : null}
                ` : null}

            <div 
              class="dss-search-bar__input"
              data-truncated="${s._isTruncated}"
              @mouseover=${s._handleMouseOver}
            >
              <label 
                class="dss-label" 
                for="${s._getEffectiveId()}" 
              >
                ${s.label}
              </label>
              <input
                class="dss-input"
                id=${s._getEffectiveId()}
                .type="text"
                .name="${s.name ?? i}"
                .placeholder=${s.placeholder}
                .value=${s.multiple ? "" : s.value}
                ?disabled=${s.disabled}
                ?readonly=${s.readonly}
                ?required=${s.required}
                ?autofocus=${s.autofocus}
                spellcheck=${s.spellcheck ? "true" : "false"}
                autocorrect=${s.autocorrect ? "on" : "off"}
                autocomplete=${s.autocomplete}
                autocapitalize=${s.autocapitalize}
                pattern=${s.pattern ?? i}
                inputmode=${s.inputmode ?? i}
                @input=${s._handleInput}
                @change=${s._handleChange}
                @keydown=${s._handleKeyDown}
                @focusin=${s._handleFocusIn}
                @focusout=${s._handleFocusOut}
                role="combobox"
                aria-haspopup="listbox"
                aria-controls=${s._showDropdown ? `${s._getEffectiveId()}-catalog` : i}
                aria-expanded=${s._showDropdown ? "true" : "false"}
              />

              <${b} 
                class="${h({
    "dss-input-tooltip": !0,
    "dss-input-tooltip--visible": s._isTruncated && !s._isFocused
  })}"
                aria-hidden="true"
              >${s._input?.value}</${b}>
            </div>
          
          </div>

          <div class="dss-search-bar__clear">
            <${_} 
              hideTooltip
              class="dss-searchbar-clear-button"
              icon="cancel"
              variant="primary"
              size="md"
              @click=${s._clearSearch}
              label="Esborra la cerca"
            >
            </${_}>
          </div>

          ${s.isCatalogLoading || s.catalog.length > 0 || s.recentSearches.length > 0 ? a`
              <${f}
                id="${s._getEffectiveId()}-catalog"
                class="combobox ${s._getEffectiveId()}-catalog"
                catalogStyle=${s.catalogStyle}
                isOpen=${s._showDropdown}
                .searchTerms=${s.searchTerms}
                maxTermChips=${s.maxTermChips}
                ?multiple=${s.multiple}
                ?isLoading=${s.isCatalogLoading}
                .filter=${s._filter}
                threshold=${s.threshold}
                catalogTitle=${s.catalogLabel}
                .catalog=${s._filteredCatalog}
                recentSearchesTitle=${s.recentSearchesLabel}
                .recentSearches=${s._filteredRecentSearches}
                resultsEmptyLabel=${s.emptyDropdownText}
                ?advancedFilter=${s.advancedFilter}
                @catalog-item-selected="${s._handleCatalogItemSelected}"
                @catalog-focusout=${s._handleCatalogFocusOut}
              >
              </${f}>
            ` : i}

          
        </div>

        ${s.helpText ? a`
              <div class="dss-search-help">
                <span>${s.helpText}</span>
              </div>
            ` : null}
        
      </div>
  `;
};
export {
  x as template
};
//# sourceMappingURL=searchbar.template.js.map
