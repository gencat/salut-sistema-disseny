import { nothing as $ } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as t, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const i = t`dss-icon${l(u())}`, d = t`dss-tooltip${l(u())}`, h = (s) => {
  const e = {
    "dss-badge": !0,
    [`dss-badge--${s.size}`]: !!s.size,
    [`dss-badge--${s.status}`]: !!s.status && !s.outlined || !!s.status && s.outlined && s._isCriticalStatus() || !!s.status && s.outlined && s.dot,
    [`dss-badge--${s.status}-outlined`]: !!s.status && s.outlined && s._isInformativeStatus() && !s.dot,
    "dss-badge--disabled": s.disabled,
    "dss-badge--dot": s.dot
  };
  return a`
		<div class="${r(e)}">
			${s.hideIcon && s._isInformativeStatus() ? $ : a`
					<${i} 
						class="dss-badge-button__icon" 
						icon="${s._icon}" 
						size="${s._iconSize}" 
						?fill="${s._iconFill}">
					</${i}>
				`}
			<span class="dss-badge__text">${s.label}</span>

			<slot name="tooltip" @slotchange=${s._onSlotChange}></slot>

			<${d} 
				.hidden=${!s._isLabelTruncated || s._hasCustomTooltip}>
				${s.label}
			</${d}>
		</div>	
  `;
};
export {
  h as template
};
//# sourceMappingURL=badge.template.js.map
