import { LitElement as c, unsafeCSS as u } from "lit";
import { property as i, state as d } from "lit/decorators.js";
import { booleanType as l } from "../../utils/property-types.js";
import m from "./badge.states.css.js";
import f from "./badge.style.css.js";
import { template as _ } from "./badge.template.js";
import { getBadgeIcon as y, getBadgeIconFill as g, isCriticalStatus as T, isInformativeStatus as b } from "./badge.utils.js";
var S = Object.defineProperty, C = Object.getOwnPropertyDescriptor, e = (n, t, o, r) => {
  for (var a = r > 1 ? void 0 : r ? C(t, o) : t, p = n.length - 1, h; p >= 0; p--)
    (h = n[p]) && (a = (r ? h(t, o, a) : h(a)) || a);
  return r && a && S(t, o, a), a;
};
class s extends c {
  constructor() {
    super(...arguments), this.icon = void 0, this.size = "sm", this.label = "", this.status = "", this.disabled = !1, this.outlined = !1, this.dot = !1, this.hideIcon = !1, this.width = void 0, this._isFirstUpdated = !0, this._isLabelTruncated = !1, this._hasCustomTooltip = !1;
  }
  static get styles() {
    return [u(f), u(m)];
  }
  set text(t) {
    this.label = t;
  }
  get text() {
    return this.label;
  }
  set state(t) {
    this.status = t;
  }
  get state() {
    return this.status;
  }
  get _iconSize() {
    return this.size === "xl" ? "md" : "sm";
  }
  get _icon() {
    return y(this.icon, this.status);
  }
  get _iconFill() {
    return g(this.status);
  }
  async firstUpdated() {
    if (await this.updateComplete, this.width) {
      const t = this.shadowRoot?.querySelector(".dss-badge");
      t && (t.style.width = this.width);
    }
    this._checkTextTruncated(), this._isFirstUpdated = !1;
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  async updated(t) {
    super.updated(t), (t.has("text") || t.has("label")) && (await this.updateComplete, this._checkTextTruncated());
  }
  _checkTextTruncated() {
    const t = this.shadowRoot?.querySelector(".dss-badge__text");
    if (!t) return;
    const o = t.scrollWidth > t.offsetWidth;
    this._isLabelTruncated !== o && (this._isLabelTruncated = o);
  }
  _isCriticalStatus() {
    return T(this.status);
  }
  _isInformativeStatus() {
    return b(this.status);
  }
  _onSlotChange(t) {
    const r = t.target.assignedElements({ flatten: !0 });
    if (r.length > 0) {
      this._customTooltipEl = r[0], this._hasCustomTooltip = !0;
      return;
    }
    if (this._customTooltipEl && this._customTooltipEl.isConnected) {
      this._hasCustomTooltip = !0;
      return;
    }
    this._customTooltipEl = void 0, this._hasCustomTooltip = !1;
  }
  render() {
    return _(this);
  }
}
e([
  i({ type: String })
], s.prototype, "icon", 2);
e([
  i({ type: String })
], s.prototype, "size", 2);
e([
  i({ type: String })
], s.prototype, "label", 2);
e([
  i({ type: String })
], s.prototype, "status", 2);
e([
  i(l)
], s.prototype, "disabled", 2);
e([
  i(l)
], s.prototype, "outlined", 2);
e([
  i(l)
], s.prototype, "dot", 2);
e([
  i(l)
], s.prototype, "hideIcon", 2);
e([
  i({ type: String })
], s.prototype, "width", 2);
e([
  i({ type: String })
], s.prototype, "text", 1);
e([
  i({ type: String })
], s.prototype, "state", 1);
e([
  d()
], s.prototype, "_isLabelTruncated", 2);
e([
  d()
], s.prototype, "_hasCustomTooltip", 2);
export {
  s as Badge
};
//# sourceMappingURL=badge.js.map
