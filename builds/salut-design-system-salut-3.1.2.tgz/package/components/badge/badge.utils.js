const t = [
  { key: "danger", icon: "warning", hasFill: !0 },
  { key: "moderate", icon: "emergency_home", hasFill: !0 },
  { key: "slight", icon: "error", hasFill: !0 },
  { key: "correct", icon: "check_circle", hasFill: !0 },
  { key: "undeterminated", icon: "circle", hasFill: !1 },
  { key: "undetermined", icon: "circle", hasFill: !1 },
  { key: "critic", icon: "warning", hasFill: !1 },
  { key: "alert", icon: "report", hasFill: !1 },
  { key: "ideal", icon: "check_circle", hasFill: !1 },
  { key: "info", icon: "info", hasFill: !1 },
  { key: "neutral", icon: "circle", hasFill: !1 },
  { key: "above", icon: "arrow_upward", hasFill: !0 },
  { key: "below", icon: "arrow_downward", hasFill: !0 }
], r = (e, n) => {
  if (e) return e;
  const i = t.find((l) => n.includes(l.key));
  return i ? i.icon : "warning";
}, a = (e) => e.includes("-low") ? !1 : !!t.find((i) => e.includes(i.key))?.hasFill, c = (e) => ["danger", "moderate", "slight", "correct", "undeterminated", "undetermined"].some((i) => e.includes(i)), o = (e) => ["ideal", "critical", "critic", "alert", "info", "info-alt", "neutral"].includes(e);
export {
  r as getBadgeIcon,
  a as getBadgeIconFill,
  c as isCriticalStatus,
  o as isInformativeStatus
};
//# sourceMappingURL=badge.utils.js.map
