import { LitElement as l, unsafeCSS as y } from "lit";
import { property as s, state as c } from "lit/decorators.js";
import { booleanType as h } from "../../utils/property-types.js";
import f from "./progress-indicator.style.css.js";
import { template as m } from "./progress-indicator.template.js";
var g = Object.defineProperty, d = Object.getOwnPropertyDescriptor, e = (a, t, o, p) => {
  for (var i = p > 1 ? void 0 : p ? d(t, o) : t, u = a.length - 1, n; u >= 0; u--)
    (n = a[u]) && (i = (p ? n(t, o, i) : n(i)) || i);
  return p && i && g(t, o, i), i;
};
class r extends l {
  constructor() {
    super(...arguments), this.titleText = "", this.description = "", this.status = "default", this.percentage = 0, this.hidePercentage = !1, this.hasFailed = !1, this._currentStatus = "default";
  }
  static get styles() {
    return y(f);
  }
  set state(t) {
    this.status = t;
  }
  get state() {
    return this.status;
  }
  set title(t) {
    this.titleText = t;
  }
  get title() {
    return this.titleText;
  }
  updated(t) {
    t.has("status") && queueMicrotask(() => {
      this._currentStatus = this.status;
    }), t.has("hasFailed") && queueMicrotask(() => {
      this._currentStatus = this.hasFailed ? "error" : this.status;
    });
  }
  render() {
    return m(this);
  }
}
e([
  s({ type: String })
], r.prototype, "titleText", 2);
e([
  s({ type: String })
], r.prototype, "description", 2);
e([
  s({ type: String })
], r.prototype, "status", 2);
e([
  s({ type: Number })
], r.prototype, "percentage", 2);
e([
  s(h)
], r.prototype, "hidePercentage", 2);
e([
  s(h)
], r.prototype, "hasFailed", 2);
e([
  c()
], r.prototype, "_currentStatus", 2);
e([
  s({ type: String })
], r.prototype, "state", 1);
e([
  s({ type: String })
], r.prototype, "title", 1);
export {
  r as ProgressIndicator
};
//# sourceMappingURL=progress-indicator.js.map
