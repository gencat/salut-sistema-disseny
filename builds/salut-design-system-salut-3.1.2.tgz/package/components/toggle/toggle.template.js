import { nothing as e, html as a } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
const b = (l) => a`
  <div class="${d({
  "dss-toggle": !0,
  "dss-toggle--sm": l.size === "sm",
  "dss-toggle--md": l.size === "md",
  "dss-toggle--lg": l.size === "lg",
  "dss-toggle--checked": l.checked,
  "dss-toggle--disabled": l.disabled,
  "dss-toggle--hide-label": l.hideLabel
})}">
    <div
      class="dss-toggle__slider"
      role="switch"
      aria-checked="${l.checked}"
      aria-disabled="${l.disabled ? "true" : e}"
      aria-label="${l.hideLabel ? l.label : e}"
      aria-labelledby="${l.hideLabel ? e : `${l._getEffectiveId()}-label`}"
      tabindex="${l.disabled ? -1 : 0}"
      @keydown="${l._handleKeydown}"
      @click="${l._handleClick}"
    ></div>
    <input
      class="dss-toggle-input"
      type="checkbox"
      .name="${l.name ?? e}"
      id="${l._getEffectiveId()}"
      .value="${l.value ? l.value : null}"
      ?disabled="${l.disabled}"
      ?readonly="${l.readonly}"
      ?required="${l.required}"
      .checked="${l.checked}"
      tabIndex="-1"
      aria-label="${l.hideLabel ? l.label : e}"
      @change=${l._handleChange}
    />
    <label 
      id="${l._getEffectiveId()}-label"
      class="${d({
  "dss-toggle-label": !0,
  "dss-toggle-label--disabled": l.disabled
})}"
      for="${l._getEffectiveId()}" 
      aria-hidden="${l.hideLabel}"  
      @click="${l._handleClick}"
    >
      ${l.hideLabel ? e : l.label}
    </label>
  </div>
`;
export {
  b as template
};
//# sourceMappingURL=toggle.template.js.map
