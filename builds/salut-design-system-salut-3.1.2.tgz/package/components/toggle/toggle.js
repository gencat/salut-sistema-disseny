import { LitElement as c, unsafeCSS as p } from "lit";
import { query as f, property as i, state as y } from "lit/decorators.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as v, booleanConverter as r } from "../../utils/property-types.js";
import b from "./toggle.style.css.js";
import { template as k } from "./toggle.template.js";
var _ = Object.defineProperty, s = (n, e, l, u) => {
  for (var a = void 0, o = n.length - 1, d; o >= 0; o--)
    (d = n[o]) && (a = d(e, l, a) || a);
  return a && _(e, l, a), a;
};
const h = class h extends c {
  constructor() {
    super(), this.size = "md", this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.value = !1, this.disabled = !1, this.readonly = !1, this.required = !1, this.checked = !1, this.tabIndex = 0, this._defaultId = `dss-toggle-${crypto.randomUUID()}`, this.defaultValue = this.value, this.internals = this.attachInternals();
  }
  static get styles() {
    return [p(m), p(b)];
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(e) {
    e.has("value") && typeof this.value == "string" && ((this.value === "" || this.value === "false") && (this._input.checked = !1), this.internals.setFormValue(this._input.checked ? this.value : null)), e.has("checked") && typeof this.value == "boolean" && this.internals.setFormValue(this._input.checked ? "on" : null);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
  formResetCallback() {
    const e = typeof this.defaultValue == "boolean";
    this.value = e ? !1 : this.defaultValue, this._input.checked = !1, this.checked = !1;
  }
  formStateRestoreCallback(e) {
    this.value = e ?? "";
  }
  focusInput() {
    this._input?.focus();
  }
  async firstUpdated() {
    await this.updateComplete, this.defaultValue = this.value, (this.checked || this.value === !0 || this.value === "true") && (this.checked = !0, this._input.checked = !0, this.internals.setFormValue(this._input.checked ? typeof this.value == "string" ? this.value : "on" : null));
  }
  render() {
    return k(this);
  }
  _handleClick() {
    !this.disabled && !this.readonly && this._input && (this.checked = !this.checked, this._handleChange());
  }
  _handleKeydown(e) {
    (e.key === "Enter" || e.key === " ") && (e.stopPropagation(), e.preventDefault(), this._handleClick());
  }
  _handleChange() {
    typeof this.value == "boolean" && (this.value = this.checked), this.internals.setFormValue(this.checked ? typeof this.value == "string" ? this.value : "on" : null), this._emitChange();
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  focus(e) {
    const l = this.shadowRoot?.querySelector(".dss-toggle__slider");
    if (!l) return;
    const u = { ...e, focusVisible: !0 };
    l.focus(u);
  }
};
h.formAssociated = !0;
let t = h;
s([
  f("input.dss-toggle-input")
], t.prototype, "_input");
s([
  i({ type: String })
], t.prototype, "size");
s([
  i({ type: String })
], t.prototype, "label");
s([
  i(v)
], t.prototype, "hideLabel");
s([
  i({ type: String })
], t.prototype, "name");
s([
  i({ type: String })
], t.prototype, "id");
s([
  i({ type: String })
], t.prototype, "value");
s([
  i({ converter: r, reflect: !0 })
], t.prototype, "disabled");
s([
  i({ converter: r, reflect: !0 })
], t.prototype, "readonly");
s([
  i({ converter: r, reflect: !0 })
], t.prototype, "required");
s([
  i({ converter: r, reflect: !0 })
], t.prototype, "checked");
s([
  i({ type: Number })
], t.prototype, "tabIndex");
s([
  y()
], t.prototype, "defaultValue");
export {
  t as Toggle
};
//# sourceMappingURL=toggle.js.map
