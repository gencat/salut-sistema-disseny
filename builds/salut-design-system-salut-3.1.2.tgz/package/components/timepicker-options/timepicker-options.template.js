import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as d, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const s = d`dss-button${t(r())}`, c = (i) => e`
 

    ${i.variant === "list" ? e`
          <div
            class="${a({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--list": !0
})}"
            role="listbox"
            aria-label="Opciones de tiempo"
          >
            <div class="dss-timepicker-dropdown__container">
              ${e`${i._generateTimeListOptionsHTML(i.timeListOptions, i.customTimeListOptions)}`}
            </div>
          </div>
        ` : e`
          <div
            class="${a({
  "dss-timepicker-dropdown": !0,
  "dss-timepicker-dropdown--manual": !0
})}"
            role="dialog"
            aria-label="Selector de tiempo"
          >
            <div class="dss-timepicker-dropdown__manual">
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--hour"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualHour", i.timeManualHourOptions)}
              </div>
              <div
                class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--minute"
              >
                ${i._generateTimeManualOptionsHTML("timepickerManualMinutes", i.timeManualMinutesOptions)}
              </div>
            </div>
            <div class="dss-timepicker-dropdown__actions" @keydown=${i._handleActionsKeyDown}>
              <${s} 
                label="Cancel-lar"
                aria-label="Cancel-lar"
                size="md"
                variant="secondary"
                @onClick=${i._handleManualCancel}
              ></${s}>
              <${s}
                label="Seleccionar"
                aria-label="Seleccionar"
                size="md"
                variant="primary"
                ?disabled=${i._checkDisableTimeManualSelector()}
                @onClick=${i._handleManualAccept}
              ></${s}>
            </div>
          </div>
          `} 
        <button
          class="dss-timepicker-dropdown__sentinel"
          type="button"
          aria-hidden="true"
          @focus=${i._focusSentinel}
        >
        </button>
`;
export {
  c as template
};
//# sourceMappingURL=timepicker-options.template.js.map
