import { LitElement as E, unsafeCSS as O } from "lit";
import { property as S, state as H, query as L } from "lit/decorators.js";
import { classMap as $ } from "lit/directives/class-map.js";
import { unsafeStatic as R, literal as q, html as A } from "lit/static-html.js";
import { getCustomElementSuffix as P } from "../../api/custom-element-scope.js";
import { getPortalContainer as I } from "../../api/portal-manager/portal-manager.js";
import F from "../../shared/reset.style.css.js";
import { scheduleShow as U, executeShow as V, hideFloating as D, updateFloatingCombobox as W, updateFloatingPosition as j } from "../../utils/floating-combobox.js";
import { booleanType as Q } from "../../utils/property-types.js";
import K from "./timepicker-options.style.css.js";
import { template as z } from "./timepicker-options.template.js";
var B = Object.defineProperty, h = (w, t, e, a) => {
  for (var i = void 0, o = w.length - 1, d; o >= 0; o--)
    (d = w[o]) && (i = d(t, e, i) || i);
  return i && B(t, e, i), i;
};
const C = q`dss-icon${R(P())}`;
class _ extends E {
  constructor() {
    super(...arguments), this._manualValueSyncQueued = !1, this.open = !0, this.value = null, this.variant = "list", this.timeListOptions = [], this.customTimeListOptions = void 0, this.timeManualHourOptions = [], this.timeManualMinutesOptions = [], this.manualHourSelector = "", this.manualMinuteSelector = "", this._isFirstUpdated = !0, this.delay = 0, this._initialParent = null, this._portalManager = null, this._toggle = () => {
      this.open ? this.show() : this.hide();
    };
  }
  static get styles() {
    return [O(F), O(K)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupAutoUpdate?.(), this._cleanupAutoUpdate = void 0;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._portalManager = I(), this._initialParent || (this._initialParent = this.parentElement), this._parent || (this._parent = this.parentElement);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    if (t.has("open") && queueMicrotask(() => {
      this._isFirstUpdated ? this._isFirstUpdated = !1 : this._toggle();
    }), t.has("value") && (this.variant === "manual" ? this._scheduleManualValueSync() : setTimeout(() => {
      this._timeListOptionsScrollTo(this.value || void 0);
    }, 240)), t.has("manualHourSelector")) {
      if (!this.open) return;
      setTimeout(() => {
        this._hourManualScrollTo(this.manualHourSelector);
      }, 240);
    }
    if (t.has("manualMinuteSelector")) {
      if (!this.open) return;
      setTimeout(() => {
        this._minutesManualScrollTo(this.manualMinuteSelector);
      }, 240);
    }
  }
  show() {
    U({
      delay: this.delay,
      clearHideTimeout: () => window.clearTimeout(this._hideTimeout),
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setShowTimeout: (t) => {
        this._showTimeout = t;
      },
      onExecuteShow: () => this._executeShow()
    }), this.value && (this.variant === "manual" ? setTimeout(() => {
      this._hourManualScrollTo(this.manualHourSelector), this._minutesManualScrollTo(this.manualMinuteSelector);
    }, 240) : this._timeListOptionsScrollTo(this.value));
  }
  _executeShow() {
    V({
      floatingEl: this,
      parentEl: this._parent,
      portalManager: this._portalManager,
      initialParent: this._initialParent,
      setInitialParent: (t) => {
        this._initialParent = t;
      },
      onUpdateFloating: () => this.updateFloatingCombobox()
    });
  }
  hide() {
    D({
      floatingEl: this,
      initialParent: this._initialParent,
      clearShowTimeout: () => window.clearTimeout(this._showTimeout),
      setHideTimeout: (t) => {
        this._hideTimeout = t;
      },
      cleanupAutoUpdate: this._cleanupAutoUpdate,
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      },
      resetPosition: !0
    });
  }
  updateFloatingCombobox() {
    W({
      referenceEl: this._parent,
      floatingEl: this,
      onUpdatePosition: () => this._updatePosition(),
      setCleanupAutoUpdate: (t) => {
        this._cleanupAutoUpdate = t;
      }
    });
  }
  async _updatePosition() {
    this._parent && await j(this._parent, this, {
      matchWidth: this.variant === "list"
    });
  }
  _generateTimeListOptionsHTML(t, e) {
    if (this._cachedTimeListHTML && this._cachedTimeListOptions === t && this._cachedTimeListCustomOptions === e)
      return this._cachedTimeListHTML;
    let a = !0;
    const i = e && e.length > 0, d = (i ? e : t).map((n) => {
      const f = i && typeof n == "object" ? n.value : n, b = (r) => {
        r && r.focus();
      }, T = (r) => {
        let p = 0;
        const s = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), c = s.length - 1;
        r === s[0] ? b(s[c]) : (s.forEach((l, u) => {
          l === r && (p = u);
        }), b(s[p - 1]));
      }, m = (r) => {
        let p = 0;
        const s = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), c = s.length - 1;
        r === s[c] ? b(s[0]) : (s.forEach((l, u) => {
          l === r && (p = u);
        }), b(s[p + 1]));
      }, k = (r) => {
        const p = r.target.getAttribute("value");
        p && this._emitValueChange(p);
      }, g = (r) => {
        const p = r.currentTarget, s = r;
        let c = !1;
        switch (s.key) {
          case "ArrowUp":
            T(p), c = !0;
            break;
          case "ArrowDown":
            m(p), c = !0;
            break;
          case "Escape":
            r.preventDefault(), r.stopPropagation(), this._emitCancel();
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const l = r.target.querySelector("input"), u = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
            u?.setAttribute("tabindex", "-1"), u?.closest(".dss-timepicker-dropdown__option")?.classList.remove("dss-timepicker-dropdown__option--selected"), r.target.setAttribute("tabindex", "0"), l?.click(), c = !0;
            break;
          }
        }
        c && (r.stopPropagation(), r.preventDefault());
      }, v = {
        "option--busy": typeof n == "object" && n.state === "ocupat",
        "option--selected": typeof n == "object" && n.state === "ocupat"
      }, y = A`
				<div class="dss-timepicker-dropdown__option ${$(v)}">
					<label
						role="option"
						aria-selected="${f === this.value}"
						class="dss-timepicker-dropdown__label"
						tabindex="${a ? 0 : -1}"
						@keydown=${g}
					>
						${f}
						<input
							class="dss-timepicker-dropdown__input-radio"
							name="timeList"
							type="radio"
							@click="${k}"
							.value="${f}"
						/>
						<${C} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${C}>
					</label>
				</div>
			`;
      return a = !1, y;
    });
    return this._cachedTimeListOptions = t, this._cachedTimeListCustomOptions = e, this._cachedTimeListHTML = d, d;
  }
  _generateTimeManualOptionsHTML(t, e) {
    let a = !0;
    return e.map((o) => {
      const d = (m) => {
        const k = m.target.getAttribute("value");
        k && (t === "timepickerManualHour" ? this.manualHourSelector = k : t === "timepickerManualMinutes" && (this.manualMinuteSelector = k));
      }, n = (m) => {
        const k = m.currentTarget, g = m;
        let v = !1;
        const y = (s) => {
          s && s.focus();
        }, r = (s) => {
          let c = 0;
          const l = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), u = l.length - 1;
          s === l[0] ? y(l[u]) : (l.forEach((M, x) => {
            M === s && (c = x);
          }), y(l[c - 1]));
        }, p = (s) => {
          let c = 0;
          const l = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), u = l.length - 1;
          s === l[u] ? y(l[0]) : (l.forEach((M, x) => {
            M === s && (c = x);
          }), y(l[c + 1]));
        };
        switch (g.key) {
          case "ArrowUp":
            r(k), v = !0;
            break;
          case "ArrowDown":
            p(k), v = !0;
            break;
          case "Escape":
            m.preventDefault(), m.stopPropagation(), this._emitCancel();
            break;
          case "Enter": {
            const c = m.target.parentElement?.querySelector("input");
            if (this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            )?.setAttribute("tabindex", "-1"), m.target.setAttribute("tabindex", "0"), c?.click(), t === "timepickerManualHour") {
              const u = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              y(u);
            } else if (t === "timepickerManualMinutes") {
              const u = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                u.focus();
              }, 0);
            }
            v = !0;
            break;
          }
        }
        v && (m.stopPropagation(), m.preventDefault());
      }, f = `${o} ${t === "timepickerManualHour" ? "hores" : "minuts"}`, b = t === "timepickerManualHour" ? o === this.manualHourSelector : o === this.manualMinuteSelector, T = A`
				<div class="dss-timepicker-manual-item">
					<input
						id="${t + o}"
						class="dss-timepicker-manual-item__input-radio"
						name="${t}"
						type="radio"
						@click="${d}"
						.value="${o}"
					/>
					<label
						role="option"
						aria-label="${f}"
						aria-selected="${b ? "true" : "false"}"
						for="${t + o}"
						class="dss-timepicker-manual-item__label ${t}"
						tabindex="${a ? 0 : -1}"
						@keydown=${n}
					>
						${o}
					</label>
				</div>
			`;
      return a = !1, T;
    });
  }
  _handleActionsKeyDown(t) {
    t?.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this._emitCancel());
  }
  _handleManualCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((e) => {
      e.checked = !1;
    }), this.manualHourSelector = "", this.manualMinuteSelector = "", this._emitCancel();
  }
  _handleManualAccept() {
    const t = `${this.manualHourSelector}:${this.manualMinuteSelector}`;
    this._emitValueChange(t);
  }
  _checkDisableTimeManualSelector() {
    return this.manualHourSelector === "" || this.manualMinuteSelector === "";
  }
  _timeListOptionsScrollTo(t) {
    if (!t) return;
    const e = t.trim(), a = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
    let i = !1;
    a.forEach((o) => {
      const d = o.value;
      if (!i && d.startsWith(e)) {
        const n = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
        n?.setAttribute("tabindex", "-1"), n?.closest(".dss-timepicker-dropdown__option")?.classList.remove("dss-timepicker-dropdown__option--selected");
        const b = o.closest("label");
        if (b?.setAttribute("tabindex", "0"), i = !0, b) {
          setTimeout(() => {
            b.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0);
          const T = o.closest(".dss-timepicker-dropdown__option");
          d === e ? (o.checked = !0, T?.classList.add("dss-timepicker-dropdown__option--selected")) : T?.classList.remove("dss-timepicker-dropdown__option--selected");
        }
      }
    });
  }
  _timeManualOptionsScrollTo() {
    if (!this.value) return;
    const t = this.value.trim();
    t.length <= 2 ? this._hourManualScrollTo(t) : this._minutesManualScrollTo(t);
  }
  _updateManualValues() {
    if (!this.value) return;
    const { hour: t, minute: e } = this._parsePartialTime(this.value), a = !!t && t !== this.manualHourSelector, i = !!e && e !== this.manualMinuteSelector;
    !a && !i || (a && (this.manualHourSelector = t), i && (this.manualMinuteSelector = e));
  }
  _scheduleManualValueSync() {
    this._manualValueSyncQueued || (this._manualValueSyncQueued = !0, queueMicrotask(() => {
      this._manualValueSyncQueued = !1, this._updateManualValues();
    }));
  }
  _parsePartialTime(t) {
    if (!t) return {};
    const e = t.trim();
    if (e.length < 2) return {};
    const a = e.slice(0, 2);
    if (!/^\d{2}$/.test(a)) return {};
    if (e.length >= 5) {
      const i = e.slice(3, 5);
      return /^\d{2}$/.test(i) ? { hour: a, minute: i } : { hour: a };
    }
    return { hour: a };
  }
  _hourManualScrollTo(t) {
    if (!t) return;
    let e = !1;
    this.renderRoot.querySelectorAll(
      ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
    ).forEach((i) => {
      const o = i.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
      if (!e && o.startsWith(t)) {
        e = !0, this.renderRoot.querySelector(
          '.dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label[tabindex="0"]'
        )?.setAttribute("tabindex", "-1"), i?.setAttribute("tabindex", "0");
        const n = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--hour");
        if (n) {
          const f = i.offsetTop - n.clientHeight / 2;
          setTimeout(() => {
            n.scrollTo({
              top: f,
              behavior: "smooth"
            });
          }, 0);
        }
        o === t && i.click();
      }
    });
  }
  _minutesManualScrollTo(t) {
    if (!t) return;
    const e = this.renderRoot.querySelectorAll(
      ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
    );
    let a = !1;
    e.forEach((i) => {
      const o = i.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
      if (!a && o.startsWith(t)) {
        a = !0, this.renderRoot.querySelector(
          '.dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label[tabindex="0"]'
        )?.setAttribute("tabindex", "-1"), i?.setAttribute("tabindex", "0");
        const n = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--minute");
        if (n) {
          const f = i.offsetTop - n.clientHeight / 2;
          setTimeout(() => {
            n.scrollTo({
              top: f,
              behavior: "smooth"
            });
          }, 0);
        }
        o === t && i.click();
      }
    });
  }
  _emitValueChange(t) {
    this.dispatchEvent(
      new CustomEvent("option-changed", {
        detail: { value: t },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _emitCancel() {
    this.dispatchEvent(
      new CustomEvent("option-cancelled", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  _focusFirstElement() {
    this.variant === "manual" ? this._focusManualHourItem() : this._focusListItem();
  }
  _focusListItem() {
    const t = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]'), e = this.renderRoot.querySelector(".dss-timepicker-dropdown__label");
    (t || e)?.focus();
  }
  _focusManualHourItem() {
    this.renderRoot.querySelector('.dss-timepicker-manual-item__label[tabindex="0"]').focus();
  }
  _focusSentinel() {
    this.dispatchEvent(
      new CustomEvent("option-focusout", {
        bubbles: !0,
        composed: !0
      })
    );
  }
  render() {
    return z(this);
  }
}
h([
  S(Q)
], _.prototype, "open");
h([
  S({ type: String })
], _.prototype, "value");
h([
  S({ type: String })
], _.prototype, "variant");
h([
  S({ type: Array })
], _.prototype, "timeListOptions");
h([
  S({ type: Array })
], _.prototype, "customTimeListOptions");
h([
  S({ type: Array })
], _.prototype, "timeManualHourOptions");
h([
  S({ type: Array })
], _.prototype, "timeManualMinutesOptions");
h([
  S({ type: String })
], _.prototype, "manualHourSelector");
h([
  S({ type: String })
], _.prototype, "manualMinuteSelector");
h([
  H()
], _.prototype, "_isFirstUpdated");
h([
  L(".dss-timepicker-dropdown")
], _.prototype, "_floatingCombobox");
h([
  S({ type: Number })
], _.prototype, "delay");
export {
  _ as TimepickerOptions
};
//# sourceMappingURL=timepicker-options.js.map
