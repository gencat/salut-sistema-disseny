import { nothing as e } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as r, literal as u, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const $ = u`dss-calendar${r(t())}`, i = u`dss-icon${r(t())}`, l = u`dss-icon-button${r(t())}`, S = (a) => {
  const g = {
    "dss-datepicker-range--sm": a.size !== "lg"
  }, _ = {
    "dss-datepicker-range-help--invalid": a.invalid || !!(a._inputRangeStart && !a._inputRangeStart.validity.valid && a._inputRangeStart.value !== "") || !!(a._inputRangeEnd && !a._inputRangeEnd.validity.valid && a._inputRangeEnd.value !== ""),
    "dss-datepicker-range-help--disabled": a._inputRangeStart?.disabled && a._inputRangeEnd?.disabled
  }, R = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": a._inputRangeStart?.required,
    "dss-input-wrapper--disabled": a._inputRangeStart?.disabled,
    [`dss-input-wrapper--${a.size}`]: !!a.size
  }, v = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": a._inputRangeEnd?.required,
    "dss-input-wrapper--disabled": a._inputRangeEnd?.disabled,
    [`dss-input-wrapper--${a.size}`]: !!a.size
  }, b = {
    "dss-input-group": !0,
    [`dss-input-group--${a.size}`]: !!a.size,
    "dss-input-group--invalid": a.invalid || !!(a._inputRangeStart && !a._inputRangeStart.validity.valid && a._inputRangeStart.value !== ""),
    "dss-input-group--required": a._inputRangeStart?.required,
    "dss-input-group--disabled": a._inputRangeStart?.disabled,
    "dss-input-group--focused": a._inputRangeStart?.value || a._isStartFocused || a._copyInputRangeStartPlaceholder,
    "dss-input-group--read-only": a._inputRangeStart?.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  }, n = {
    "dss-input-group": !0,
    [`dss-input-group--${a.size}`]: !!a.size,
    "dss-input-group--invalid": a.invalid || !!(a._inputRangeEnd && !a._inputRangeEnd.validity.valid && a._inputRangeEnd.value !== ""),
    "dss-input-group--required": a._inputRangeEnd?.required,
    "dss-input-group--disabled": a._inputRangeEnd?.disabled,
    "dss-input-group--focused": a._inputRangeEnd?.value || a._isEndFocused || a._copyInputRangeEndPlaceholder,
    "dss-input-group--read-only": a._inputRangeEnd?.readOnly
    // 'dss-input-group--no-label': Boolean(!component._label),
  };
  return s`
      <div class="dss-datepicker-range ${d(g)}">
        <input 
          type="hidden" 
          class="dss-hidden-value" 
          .name=${a.name}
        />

        <div class="dss-datepicker-range-inputs">

          <div class="dss-datepicker-range-inputs__start ${d(R)}">
            ${a.size === "sm" ? s`
                <div class="${d({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": a.invalid
  })}">
                  <label class="dss-label dss-label--start" for="${a._getEffectiveStartId()}">${a.labelRangeStart}</label>
                </div>
              ` : e}
            <div class="${d(b)}">
              ${a.iconRangeStart && a.iconRangeStart !== "" ? s`
                <${i} icon="${a.iconRangeStart}" class="dss-input-icon"></${i}>
                ` : e}
              <div class="dss-input-field">
                ${a.size !== "sm" && !a.hideLabel ? s`
                      <label class="dss-label dss-label--start" for="${a._getEffectiveStartId()}">${a.labelRangeStart}</label>
                    ` : e}
        
                <input
                  class="dss-input dss-input--start"
                  id=${a._getEffectiveStartId()}
                  .type=${a.type}
                  .name="${a.name ? `${a.name}-start` : e}"
                  .placeholder=${a.placeholderRangeStart}
                  ?disabled=${a.disabled}
                  ?readonly=${a.readonly}
                  ?required=${a.required}
                  ?autofocus=${a.autofocus}
                  spellcheck=${a.spellcheck ? "true" : "false"}
                  autocorrect=${a.autocorrect ? "on" : "off"}
                  autocomplete=${a.autocomplete}
                  autocapitalize=${a.autocapitalize}
                  pattern=${a.pattern ?? e}
                  inputmode=${a.inputmode ?? e}
                  aria-label="${a.hideLabel ? a.labelRangeStart : e}"
                  @click=${a._handleRangeStartClick}
                  @input=${a._handleRangeStartInput}
                  @focusin=${a._handleRangeStartFocusIn}
                  @keydown=${a._handleRangeKeydown}
                  role="combobox"
                  aria-haspopup="dialog"
                  aria-controls="${a.showCalendar ? `${a._getEffectiveId()}-calendar` : e}"
                  aria-expanded=${a.showCalendar ? "true" : "false"}
                />
              </div>
              <${l}
                hideTooltip
                size="md"
                icon="close"
                label="Netejar"
                @onClick=${() => a._clearDate("rangeStart")}
                ?hidden=${!a._inputRangeStart?.value || a._inputRangeStart.readOnly || a._inputRangeStart.disabled}
              ></${l}>
            </div>
          </div>

          <div class="dss-datepicker-range-inputs__end ${d(v)}">
            ${a.size === "sm" ? s`
                 <div class="${d({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": a.invalid
  })}">
                  <label class="dss-label dss-label--end" for="${a._getEffectiveEndId()}">${a.labelRangeEnd}</label>
                </div>
              ` : e}
            <div class="${d(n)}">
              ${a.iconRangeEnd && a.iconRangeEnd !== "" ? s`
                <${i} icon="${a.iconRangeEnd}" class="dss-input-icon"></${i}>
                ` : e}
              <div class="dss-input-field">
                ${a.size !== "sm" && !a.hideLabel ? s`
                      <label class="dss-label dss-label--end" for="${a._getEffectiveEndId()}">${a.labelRangeEnd}</label>
                    ` : e}
        
                <input
                  class="dss-input dss-input--end"
                  id=${a._getEffectiveEndId()}
                  .type=${a.type}
                  .name="${a.name ? `${a.name}-end` : e}"
                  .placeholder=${a.placeholderRangeEnd}
                  ?disabled=${a.disabled}
                  ?readonly=${a.readonly}
                  ?required=${a.required}
                  ?autofocus=${a.autofocus}
                  spellcheck=${a.spellcheck ? "true" : "false"}
                  autocorrect=${a.autocorrect ? "on" : "off"}
                  autocomplete=${a.autocomplete}
                  autocapitalize=${a.autocapitalize}
                  pattern=${a.pattern ?? e}
                  inputmode=${a.inputmode ?? e}
                  aria-label="${a.hideLabel ? a.labelRangeEnd : e}"
                  @click=${a._handleRangeEndClick}
                  @input=${a._handleRangeEndInput}
                  @focusin=${a._handleRangeEndFocusIn}
                  @focusout=${a._handleRangeEndFocusOut}
                  @keydown=${a._handleRangeKeydown}
                  role="combobox"
                  aria-haspopup="dialog"
                  aria-controls="${a.showCalendar ? `${a._getEffectiveId()}-calendar` : e}"
                  aria-expanded=${a.showCalendar ? "true" : "false"}
                />
              </div>
              <${l}
                hideTooltip
                size="md"
                icon="close"
                label="Netejar"
                @onClick=${() => a._clearDate("rangeEnd")}
                ?hidden=${!a._inputRangeEnd?.value || a._inputRangeEnd.readOnly || a._inputRangeEnd.disabled}
              ></${l}>
            </div>
          </div>

          <${$}
            range
            .isRangeStartFocused=${a._isStartFocused}
            .isRangeEndFocused=${a._isEndFocused}
            id="${a._getEffectiveId()}-calendar"
            class="${d({
    [`dss-calendar ${a._getEffectiveId()}-calendar`]: !0,
    "dss-calendar--md": a.size !== "lg"
  })}"
            placement='bottom-start'
            .open=${a.showCalendar && !a.readonly}
            .selectedDate="${a._inputRangeStart?.value}"
            .rangeStartDate="${a._inputRangeStart?.value}"
            .rangeEndDate="${a._inputRangeEnd?.value}"
            .customCalendar=${a.customCalendar}
            .showButtons=${a.showButtons}
            .leftLabel=${a.calendarLeftButtonLabel}
            .rightLabel=${a.calendarRightButtonLabel}
            .minDate=${a.minDate}
            .maxDate=${a.maxDate}
            @range-changed=${a._onCalendarChange}
            @cancel=${a._onCalendarCancel}
            @calendar-focusout=${a._handleCalendarFocusOut}
            @calendar-updated=${a._handleCalendarUpdated}
          ></${$}>
       
        </div>

        ${a._helpText ? s`
              <div class="dss-datepicker-range-help ${d(_)}">
                ${a._helpText}
              </div>
            ` : null}
       
        
      </div>
    `;
};
export {
  S as template
};
//# sourceMappingURL=datepicker-range.template.js.map
