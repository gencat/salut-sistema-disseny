import { LitElement as v, unsafeCSS as m } from "lit";
import { query as f, property as i, state as u } from "lit/decorators.js";
import b from "../../shared/reset.style.css.js";
import { lazyLoading as g } from "../../utils/lazy-loading.js";
import { deleteSeparatorMask as k, applyMask as S } from "../../utils/mask.js";
import { booleanType as n, booleanConverter as h } from "../../utils/property-types.js";
import C from "./input.style.css.js";
import { template as V } from "./input.template.js";
var x = Object.defineProperty, e = (_, s, a, o) => {
  for (var l = void 0, r = _.length - 1, p; r >= 0; r--)
    (p = _[r]) && (l = p(s, a, l) || l);
  return l && x(s, a, l), l;
};
const d = class d extends v {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.hasActions = !1, this.clearable = !1, this.disableValidation = !1, this.maxDecimals = void 0, this._defaultId = `dss-input-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._onHoldInterval = null, this._previousValue = null, this._labelClicked = !1, this._lastValue = null, this.internals = this.attachInternals();
  }
  static get styles() {
    return [m(b), m(C)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._stopHold();
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  updated(s) {
    s.has("value") && this.internals.setFormValue(this.value);
  }
  formDisabledCallback(s) {
    this.disabled = s;
  }
  formResetCallback() {
    this.value = "", this._input.value = "", this._lastValue = "";
  }
  formStateRestoreCallback(s) {
    this.value = s ?? "", this._input.value = s ?? "", this._lastValue = s ?? "";
  }
  render() {
    return V(this);
  }
  _handleFocusin() {
    this._isFocused = !0;
  }
  _handleLabelClick(s) {
    s.preventDefault(), this._input.focus(), this._labelClicked = !0, setTimeout(() => {
      this._labelClicked = !1;
    }, 50);
  }
  _handleFocusout() {
    this._labelClicked || (this._isFocused = !1, this._lastValue !== this._input.value && (this._checkInputOverflow(), this._lastValue = this._input.value));
  }
  _onInput(s) {
    const a = s.target;
    if (this.type === "number" && this.maxDecimals !== void 0) {
      const o = a.value.search(/[.,]/);
      if (o !== -1) {
        const l = a.value.slice(0, o), r = a.value.slice(o + 1, o + 1 + this.maxDecimals);
        a.value = `${l}.${r}`;
      }
    }
    if (this.maskRegex && this.maskReplace) {
      this._previousValue && this._previousValue.length > a?.value.length && (a.value = k(this._previousValue, a.value, this.maskReplace));
      const o = S(a.value, this.maskRegex, this.maskReplace, this.allowedChars);
      o !== a.value && (a.value = o);
    }
    this._previousValue = a.value, this.value = a.value, this._handleValidity(), this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    if (this.disableValidation) return;
    const s = this._input?.checkValidity();
    this.invalid = !s, this.internals.setValidity(this._input.validity, this._input.validationMessage, this._input);
  }
  _roundFloat(s) {
    return Number.parseFloat(s.toPrecision(12));
  }
  _stepWithFallback(s) {
    const a = this._input;
    if (!this._input) return;
    if (a.getAttribute("step")?.toLowerCase() === "any") {
      const r = Number.isFinite(a.valueAsNumber) ? a.valueAsNumber : 0, p = a.hasAttribute("min") ? Number(a.getAttribute("min")) : null, y = a.hasAttribute("max") ? Number(a.getAttribute("max")) : null, c = this._roundFloat(r + s);
      if (p !== null && c < p || y !== null && c > y) return;
      this._input.value = String(c);
      return;
    }
    try {
      s === 1 ? this._input.stepUp() : this._input.stepDown();
    } catch (r) {
      console.error(r);
    }
  }
  _stepUp() {
    this._stepWithFallback(1), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _stepDown() {
    this._stepWithFallback(-1), this.value = this._input.value, this._handleValidity(), this._emitInput(), this._emitChange();
  }
  _onHold(s) {
    this._onHoldInterval = window.setInterval(() => {
      s === "up" ? this._stepUp() : this._stepDown();
    }, 150);
  }
  _stopHold() {
    this._onHoldInterval !== null && (clearInterval(this._onHoldInterval), this._onHoldInterval = null);
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _handleMouseOver() {
    this._input?.value !== this._lastValue && (this._checkInputOverflow(), this._lastValue = this._input?.value || null);
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) {
      this._isTruncated = !1;
      return;
    }
    const s = window.getComputedStyle(this._input), a = `${s.fontWeight} ${s.fontSize} ${s.fontFamily}`, l = document.createElement("canvas").getContext("2d");
    if (!l) return;
    l.font = a;
    const r = l.measureText(this._input.value).width;
    this._isTruncated = r > this._input.offsetWidth;
  }
  async firstUpdated() {
    await this.updateComplete, this._input.value && g(this, () => {
      this._checkInputOverflow(), this._lastValue = this._input.value;
    });
  }
  focus(s) {
    if (this._input) {
      this._input.focus(s);
      return;
    }
    this.updateComplete.then(() => {
      this._input?.focus(s);
    });
  }
  _handleClear() {
    this._input && (this._input.value = "", this.value = "", this._handleValidity(), this._checkInputOverflow(), this._emitInput(), this._emitChange(), this._input.focus());
  }
};
d.formAssociated = !0;
let t = d;
e([
  f("input.dss-input")
], t.prototype, "_input");
e([
  i({ type: String })
], t.prototype, "label");
e([
  i(n)
], t.prototype, "hideLabel");
e([
  i({ type: String })
], t.prototype, "name");
e([
  i({ type: String })
], t.prototype, "id");
e([
  i({ type: String })
], t.prototype, "type");
e([
  i({ type: String })
], t.prototype, "placeholder");
e([
  i({ type: String })
], t.prototype, "value");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "disabled");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "readonly");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "required");
e([
  i({ converter: h, reflect: !0 })
], t.prototype, "invalid");
e([
  i({ type: Number })
], t.prototype, "step");
e([
  i({ type: Number })
], t.prototype, "min");
e([
  i({ type: Number })
], t.prototype, "max");
e([
  i({ type: Number })
], t.prototype, "minLength");
e([
  i({ type: Number })
], t.prototype, "maxLength");
e([
  i({ type: String })
], t.prototype, "pattern");
e([
  i({ type: String })
], t.prototype, "inputmode");
e([
  i({ type: String })
], t.prototype, "autocapitalize");
e([
  i({ type: String })
], t.prototype, "autocomplete");
e([
  i(n)
], t.prototype, "autocorrect");
e([
  i(n)
], t.prototype, "autofocus");
e([
  i(n)
], t.prototype, "spellcheck");
e([
  i({ type: String })
], t.prototype, "size");
e([
  i({ type: String })
], t.prototype, "icon");
e([
  i({ type: String })
], t.prototype, "helpText");
e([
  i({ type: String })
], t.prototype, "maskRegex");
e([
  i({ type: String })
], t.prototype, "maskReplace");
e([
  i({ type: String })
], t.prototype, "allowedChars");
e([
  i({ type: String })
], t.prototype, "unit");
e([
  i({ type: String })
], t.prototype, "inputPrefix");
e([
  i(n)
], t.prototype, "hasActions");
e([
  i(n)
], t.prototype, "clearable");
e([
  i(n)
], t.prototype, "disableValidation");
e([
  i({ type: Number })
], t.prototype, "maxDecimals");
e([
  u()
], t.prototype, "_isFocused");
e([
  u()
], t.prototype, "_isTruncated");
e([
  u()
], t.prototype, "_onHoldInterval");
e([
  u()
], t.prototype, "_previousValue");
e([
  u()
], t.prototype, "_labelClicked");
export {
  t as Input
};
//# sourceMappingURL=input.js.map
