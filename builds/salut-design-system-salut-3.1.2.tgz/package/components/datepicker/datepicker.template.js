import { nothing as s } from "lit";
import { classMap as e } from "lit/directives/class-map.js";
import { unsafeStatic as l, literal as r, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../api/custom-element-scope.js";
const $ = r`dss-icon${l(u())}`, i = r`dss-icon-button${l(u())}`, t = r`dss-tooltip${l(u())}`, h = r`dss-calendar${l(u())}`, g = (a) => d`
  <div class="${e({
  "dss-input-wrapper": !0,
  "dss-input-wrapper--required": a.required,
  "dss-input-wrapper--disabled": a.disabled,
  [`dss-input-wrapper--${a.size}`]: !!a.size,
  "dss-input-wrapper--no-label": a.hideLabel
})}">
  
      ${a.size === "sm" && !a.hideLabel ? d`
        <div class="${e({
  "dss-wrapper-label": !0,
  "dss-wrapper-label--invalid": a.invalid
})}">
          <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
        </div>
        ` : s}
  
      <div class="${e({
  "dss-input-group": !0,
  [`dss-input-group--${a.size}`]: !!a.size,
  "dss-input-group--invalid": a.invalid || !a._inputValidity,
  "dss-input-group--required": a.required,
  "dss-input-group--disabled": a.disabled,
  "dss-input-group--focused": a.value || a._input?.value || a.placeholder || a._isFocused,
  "dss-input-group--read-only": a.readonly,
  "dss-input-group--no-label": a.hideLabel,
  "dss-input-group--read-only-empty": a.readonly && a.placeholder === "" && !a.value
})}"
      >
  
        ${a.icon ? d`
          <${$} icon="${a.icon}" class="dss-input-icon"></${$}>
          ` : s}
  
        <div class="dss-input-field" @mouseover=${a._handleMouseOver}>
        
          ${a.size !== "sm" && !a.hideLabel ? d`
            <label class="dss-label" for="${a._getEffectiveId()}">${a.label}</label>
            ` : s}
  
          <input
            class="dss-input"
            id=${a._getEffectiveId()}
            .type=${a.type}
            .name="${a.name ?? s}"
            .placeholder=${a.placeholder}
            .value=${a.value}
            ?disabled=${a.disabled}
            ?readonly=${a.readonly}
            ?required=${a.required}
            ?autofocus=${a.autofocus}
            spellcheck=${a.spellcheck ? "true" : "false"}
            autocorrect=${a.autocorrect ? "on" : "off"}
            autocomplete=${a.autocomplete}
            autocapitalize=${a.autocapitalize}
            pattern=${a.pattern ?? s}
            inputmode=${a.inputmode ?? s}
            aria-label="${a.hideLabel ? a.label : s}"
            @input=${a._handleInput}
            @click=${a._handleClick}
            @focusin=${a._handleFocusin}
            @focusout=${a._handleFocusout}
            @keydown=${a._handleKeydown}
            role="combobox"
            aria-haspopup="dialog"
            aria-controls="${a.showCalendar ? `${a._getEffectiveId()}-calendar` : s}"
            aria-expanded=${a.showCalendar ? "true" : "false"}
          />

          <${t} 
            aria-hidden="true"
            ?hidden=${a.showCalendar || !a._isTruncated || !a.value}
          >
            ${a.value}
          </${t}>
  
        </div>

        ${!a.hasStepper && a._input?.value ? d`
            <${i}
              class="dss-datepicker-clear-button"
              hideTooltip
              label="Netejar"
              size="md"
              icon="close"
              @onClick=${a._clearDate}
              ?hidden=${!a._input?.value || a.readonly || a.disabled}
            ></${i}>
          ` : s}

        ${a.hasStepper && a._input?.value && a.isValidDate() ? d`
          <div class="${e({
  "dss-datepicker-stepper-divider": !0,
  [`dss-datepicker-stepper-divider--${a.size}`]: !!a.size
})}"
          >
          </div>
          <div class="dss-datepicker-stepper-arrows">
            <${i}
              size="md"
              icon="chevron_left"
              hideTooltip
              label="Data anterior"
              @onClick=${a._prevDate}
              ?disabled=${a._isPrevDateDisabled()}
              ?hidden=${a.readonly || a.disabled}
            ></${i}>

            <${i}
              size="md"
              icon="chevron_right"
              hideTooltip
              label="Següent data"
              @onClick=${a._nextDate}
              ?disabled=${a._isNextDateDisabled()}
              ?hidden=${a.readonly || a.disabled}
            ></${i}>
          
          </div>
          ` : s}

        <${h}
          id="${a._getEffectiveId()}-calendar"
          class="${e({
  [`dss-calendar ${a._getEffectiveId()}-calendar`]: !0,
  "dss-calendar--md": a.size !== "lg"
})}"
          .open=${a.showCalendar && !a.readonly}
          ?disabled=${a.disabled}
          .selectedDate=${a.value}
          .showTime=${a.showTime}
          .showButtons=${a.showButtons}
          .leftLabel=${a.leftLabel}
          .rightLabel=${a.rightLabel}
          .minDate=${a.minDate}
          .maxDate=${a.maxDate}
          timepickerLabel=${a.timepickerLabel}
          .timepicker=${a.timepicker}
          .customCalendar=${a.customCalendar}
          .customTimeListOptions=${a.customTimeListOptions}
          .minutesRange=${a.minutesRange}
          .minHour=${a.minHour}
          .maxHour=${a.maxHour}
          @date-changed=${a._onDateChange}
          @cancel=${a._onCancel}
          @calendar-focusout=${a._handleCalendarFocusOut}
          @calendar-updated=${a._handleCalendarUpdated}
        ></${h}>
  
      </div>
      
      ${a._helpText ? d`
        <div class="${e({
  "dss-input-help": !0,
  "dss-input-help--invalid": a.invalid,
  "dss-input-help--disabled": a.disabled
})}">
          <span>${a._helpText}</span>
        </div>
        ` : s}

      
    </div> 


  
`;
export {
  g as template
};
//# sourceMappingURL=datepicker.template.js.map
