const i = (t) => t.scrollWidth > t.clientWidth, n = (t) => t.scrollHeight > t.clientHeight + 1;
export {
  n as isMultiLineTruncated,
  i as isSingleLineTruncated
};
//# sourceMappingURL=text-truncated.js.map
