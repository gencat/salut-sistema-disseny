import { autoUpdate as D, computePosition as L, offset as F, flip as q, shift as H, size as I } from "@floating-ui/dom";
import { LitElement as V, unsafeCSS as M } from "lit";
import { property as p } from "lit/decorators.js";
import { classMap as R } from "lit/directives/class-map.js";
import { unsafeStatic as U, literal as P, html as A } from "lit/static-html.js";
import { getCustomElementSuffix as C } from "../../api/custom-element-scope.js";
import { booleanType as E } from "../../utils/property-types.js";
import { template as j } from "./ng-timepicker.template.js";
import z from "../../shared/scrollbar.style.css.js";
import W from "../ng-input/ng-input.style.css.js";
import B from "./ng-timepicker.style.css.js";
var K = Object.defineProperty, G = Object.getOwnPropertyDescriptor, h = (y, t, e, i) => {
  for (var o = i > 1 ? void 0 : i ? G(t, e) : t, s = y.length - 1, l; s >= 0; s--)
    (l = y[s]) && (o = (i ? l(t, e, o) : l(o)) || o);
  return i && o && K(t, e, o), o;
};
const $ = P`dss-icon${U(C())}`;
class d extends V {
  constructor() {
    super(), this.inputSize = "lg", this.icon = "schedule", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this._defaultId = `dss-ng-timepicker-${crypto.randomUUID()}`, this._value = "", this._placeholder = "", this._inputSize = "lg", this._dropdown = "", this._required = !1, this._disabled = !1, this._readonly = !1, this._invalid = !1, this._showDropdown = !1, this._helpText = "", this._oldHelpText = "", this._errorTimeFormatText = "Format d'hora no vàlid", this._errorTimeOptionText = "Opció de temps no disponible", this._manualHourSelector = "", this._manualMinuteSelector = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._timeListOptions = [], this._customTimeListOptions = [], this._timeManualHourOptions = [], this._timeManualMinutesOptions = [], this._inputValidity = !0, this._isFirstUpdated = !0, this._cleanupFloatingList = null, this._cleanupFloatingManual = null, this._referenceEl = null, this._floatingListEl = null, this._floatingManualEl = null, this.observerConfig = { attributes: !0, childList: !0, subtree: !0 }, this.callback = (t) => {
      for (const e of t)
        e.type === "attributes" && (this._checkInputAttributes(), this.requestUpdate());
    }, this.observer = new MutationObserver(this.callback), this.visibleObserver = new IntersectionObserver(
      ([t]) => {
        t.isIntersecting || this._showDropdown && this._closeDropdown();
      },
      {
        root: null,
        threshold: 0
      }
    ), this._timePattern = /^\d{0,4}$/g, this._timeSeparator = ":", this._timeInputOldValue = "", this._isTruncated = !1, this._handleOutsideClick = this._handleOutsideClick.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [M(W), M(z), M(B)];
  }
  get _input() {
    const t = this.shadowRoot?.querySelector('slot[name="input"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  get _label() {
    const t = this.shadowRoot?.querySelector('slot[name="label"]') || void 0;
    return this.requestUpdate(), t?.assignedElements()[0];
  }
  set value(t) {
    const e = this._value;
    this._value = t, this._input && (this._input.value = t), this.requestUpdate("value", e);
  }
  get value() {
    return this._value;
  }
  set invalid(t) {
    const e = this._invalid;
    this._invalid = t, this.requestUpdate("invalid", e);
  }
  get invalid() {
    return this._invalid;
  }
  set helpText(t) {
    const e = this._helpText;
    this._helpText = t, this._oldHelpText = t, this.requestUpdate("helpText", e);
  }
  get helpText() {
    return this._helpText;
  }
  set errorTimeFormatText(t) {
    const e = this._errorTimeFormatText;
    this._errorTimeFormatText = t, this.requestUpdate("errorTimeFormatText", e);
  }
  get errorTimeFormatText() {
    return this._errorTimeFormatText;
  }
  set errorTimeOptionText(t) {
    const e = this._errorTimeOptionText;
    this._errorTimeOptionText = t, this.requestUpdate("errorTimeOptionText", e);
  }
  get errorTimeOptionText() {
    return this._errorTimeOptionText;
  }
  set dropdown(t) {
    const e = this._dropdown;
    this._dropdown = t, this.requestUpdate("dropdown", e);
  }
  get dropdown() {
    return this._dropdown;
  }
  set showDropdown(t) {
    const e = this._showDropdown;
    this._updateShowDropdown(t), this.requestUpdate("showDropdown", e);
  }
  get showDropdown() {
    return this._showDropdown;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this._isFirstUpdated || this._updateTimeOptions(), this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  disconnectedCallback() {
    this._removeDropdownListener(), this.observer.disconnect(), this.visibleObserver.disconnect(), this._cleanupFloatingList?.(), this._cleanupFloatingManual?.(), this._cleanupFloatingList = null, this._cleanupFloatingManual = null;
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleOutsideClick), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleOutsideClick), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleOutsideClick(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._createPopperList(), this._createPopperManual(), this._input && (this._input.classList.add("dss-input-skip-native"), this._checkInputAttributes(), this.observer.observe(this._input, this.observerConfig), this.visibleObserver.observe(this._input)), this._updateTimeOptions(), this._isFirstUpdated = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  _createPopperList() {
    const t = this.shadowRoot?.querySelector(".dss-input-group"), e = this.shadowRoot?.querySelector(".dss-timepicker-dropdown--list");
    !t || !e || (this._referenceEl = t, this._floatingListEl = e, this._cleanupFloatingList?.(), this._cleanupFloatingList = D(this._referenceEl, this._floatingListEl, () => this._updatePopperList()));
  }
  async _updatePopperList() {
    if (!this._referenceEl || !this._floatingListEl) return;
    const { x: t, y: e, strategy: i } = await L(this._referenceEl, this._floatingListEl, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        F(4),
        q(),
        H({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        }),
        I({
          apply: ({ rects: o }) => {
            Object.assign(this._floatingListEl.style, {
              width: `${o.reference.width}px`
            });
          }
        })
      ]
    });
    Object.assign(this._floatingListEl.style, {
      position: i,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _createPopperManual() {
    const t = this.shadowRoot?.querySelector(".dss-input-group"), e = this.shadowRoot?.querySelector(".dss-timepicker-dropdown--manual");
    !t || !e || (this._referenceEl = t, this._floatingManualEl = e, this._cleanupFloatingManual?.(), this._cleanupFloatingManual = D(
      this._referenceEl,
      this._floatingManualEl,
      () => this._updatePopperManual()
    ));
  }
  async _updatePopperManual() {
    if (!this._referenceEl || !this._floatingManualEl) return;
    const { x: t, y: e, strategy: i } = await L(this._referenceEl, this._floatingManualEl, {
      placement: "bottom",
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      middleware: [
        F(4),
        q(),
        H({
          padding: { top: 8, bottom: 8, left: 16, right: 16 }
        })
      ]
    });
    Object.assign(this._floatingManualEl.style, {
      position: i,
      left: `${t}px`,
      top: `${e}px`,
      transform: "none"
    });
  }
  _updateTimeOptions() {
    this._dropdown && (this._timeListOptions = this._generateTimeListOptions(), this._timeManualHourOptions = this._generateTimeManualHoursOptions(), this._timeManualMinutesOptions = this._generateTimeManualMinutesOptions());
  }
  _checkInputAttributes() {
    const t = this._input?.getAttribute("placeholder");
    t && (this._placeholder = t), this._input?.getAttribute("readonly") !== null && (this._readonly = !0), this._input?.getAttribute("disabled") !== null && (this._disabled = !0), this._input?.getAttribute("required") !== null && (this._required = !0);
    const s = this._input?.getAttribute("value");
    s !== null && (this._value = s), this._input?.value && this._input?.value !== "" && this._handleValidity(), this.requestUpdate();
  }
  _handleValidity() {
    const t = this._input?.checkValidity();
    t !== void 0 && (this._inputValidity = t);
  }
  _handleInputSlotChange() {
    !this._input || !this._dropdown || (this._input.hasAttribute("role") || this._input.setAttribute("role", "combobox"), this._input.hasAttribute("aria-expanded") || this._input.setAttribute("aria-expanded", String(this._showDropdown)), this._input.hasAttribute("aria-haspopup") || this._input.setAttribute("aria-haspopup", this._dropdown === "manual" ? "dialog" : "listbox"), this._input.hasAttribute("aria-controls") || (this._dropdown === "list" ? this._input.setAttribute("aria-controls", `${this._getEffectiveId()}-list`) : this._dropdown === "manual" && this._input.setAttribute("aria-controls", `${this._getEffectiveId()}-manual`)));
  }
  _updateShowDropdown(t) {
    this._showDropdown = t, this._input?.setAttribute("aria-expanded", String(t));
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this._showDropdown && this._closeDropdown();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && (this._showDropdown && this._closeDropdown(), this.requestUpdate());
  }
  _closeDropdown() {
    this._removeDropdownListener(), this._updateShowDropdown(!1), this._input?.blur(), this.requestUpdate();
  }
  _cancelDropdown() {
    this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._input?.focus();
  }
  _moveFocusBackToInput() {
    setTimeout(() => {
      this._input?.focus();
    }, 0);
  }
  _timeMask(t, e, i) {
    const o = [];
    for (let s = 0; s < t.length; s += 1)
      s !== 0 && s % e === 0 && o.push(i), o.push(t[s]);
    return o.join("");
  }
  _timeUnmask(t) {
    return t.replace(/[^\d]/g, "");
  }
  _timeValidate(t) {
    const e = t.slice(0, 2), i = t.slice(3, 5);
    this._input && +e >= 0 && +e <= 23 && +i >= 0 && +i <= 59 ? (this._invalid = !1, this._helpText = this._oldHelpText, this._dropdown && this._dropdown === "list" && !this._timeListOptions.includes(this._input.value) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._dropdown && this._dropdown === "manual" && (!this._timeManualHourOptions.includes(e) || !this._timeManualMinutesOptions.includes(i)) ? (this._helpText = this._errorTimeOptionText, this._invalid = !0) : this._closeDropdown()) : (this._helpText = this._errorTimeFormatText, this._invalid = !0), this._dispatchValueChange(), this.requestUpdate();
  }
  _dispatchValueChange() {
    if (this._input) {
      const t = {
        detail: {
          value: this._input.value,
          status: this._invalid ? "INVALID" : "VALID"
        },
        bubbles: !0,
        composed: !0
      };
      this.dispatchEvent(new CustomEvent("onTimepickerChange", t));
    }
  }
  _handleClick() {
    if (this._updateShowDropdown(!0), this._addDropdownListener(), this._floatingListEl && this._updatePopperList(), this._floatingManualEl && this._updatePopperManual(), this._value && (this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual")) {
      const t = this._value.slice(0, 2);
      this._timeManualOptionsScrollTo(t), setTimeout(() => {
        this._timeManualOptionsScrollTo();
      }, 500);
    }
    this.requestUpdate();
  }
  _handleInput() {
    if (this._input) {
      let t = this._input.value;
      t = this._timeUnmask(t), t.match(this._timePattern) ? (t = this._timeMask(t, 2, this._timeSeparator), this._input.value = t) : this._input.value = this._timeInputOldValue, this._input.value.length === 5 && (this._timeValidate(this._input.value), this._handleValidity()), this._dropdown && this._dropdown === "list" && this._timeListOptionsScrollTo(), this._dropdown && this._dropdown === "manual" && this._timeManualOptionsScrollTo();
    }
  }
  _handleKeyDown(t) {
    this._input && (this._timeInputOldValue = this._input.value, t?.key === "Enter" || t?.key === " " ? (t.preventDefault(), this._updateShowDropdown(!0), this._addDropdownListener(), this._floatingListEl && this._updatePopperList(), this._floatingManualEl && this._updatePopperManual(), this.requestUpdate(), this.updateComplete.then(() => this._focusFirstDropdownElement())) : t?.key === "Escape" && (this._showDropdown && (t.preventDefault(), t.stopPropagation()), this._closeDropdown()));
  }
  _focusFirstDropdownElement() {
    const t = this._dropdown === "manual" ? ".dss-timepicker-dropdown--manual .dss-timepicker-manual-item__label" : ".dss-timepicker-dropdown--list .dss-timepicker-dropdown__label", e = this.renderRoot.querySelector(`${t}[tabindex="0"]`), i = this.renderRoot.querySelector(t);
    (e || i)?.focus();
  }
  _handleFocus() {
    this._placeholder = "00:00", this._input && this._input.setAttribute("placeholder", this._placeholder), this.requestUpdate();
  }
  _handleBlur() {
    this._placeholder = "", this._input && this._input.removeAttribute("placeholder"), this._checkInputOverflow(), this.requestUpdate();
  }
  _focusInput() {
    this._disabled || (this._input?.focus(), this._handleClick());
  }
  _generateTimeListOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1)
      for (let i = 0; i < 60; i += this._minutesRange) {
        const o = e.toString().padStart(2, "0"), s = i.toString().padStart(2, "0");
        t.push(`${o}:${s}`);
      }
    return t;
  }
  _generateTimeListOptionsHTML(t, e) {
    let i = !0;
    const o = e && e.length > 0;
    return (o ? e : t).map((f) => {
      const b = o && typeof f == "object" ? f.value : f, v = (r) => {
        r && r.focus();
      }, x = (r) => {
        let c = 0;
        const n = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), u = n.length - 1;
        r === n[0] ? v(n[u]) : (n.forEach((a, m) => {
          a === r && (c = m);
        }), v(n[c - 1]));
      }, _ = (r) => {
        let c = 0;
        const n = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), u = n.length - 1;
        r === n[u] ? v(n[0]) : (n.forEach((a, m) => {
          a === r && (c = m);
        }), v(n[c + 1]));
      }, w = (r) => {
        if (this._input) {
          const c = r.target.getAttribute("value");
          c && (this._input.value = c, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange(), this._moveFocusBackToInput());
        }
      }, k = (r) => {
        const c = r.currentTarget, n = r;
        let u = !1;
        switch (n.key) {
          case "ArrowUp":
            x(c), u = !0;
            break;
          case "ArrowDown":
            _(c), u = !0;
            break;
          case "Escape":
            r.preventDefault(), r.stopPropagation(), this._cancelDropdown();
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter": {
            const a = r.target.querySelector("input");
            this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]')?.setAttribute("tabindex", "-1"), r.target.setAttribute("tabindex", "0"), a?.click(), u = !0;
            break;
          }
        }
        u && (r.stopPropagation(), r.preventDefault());
      }, T = {
        "option--busy": typeof f == "object" && f.state === "ocupat",
        "option--selected": b === this._input.value
      }, g = A`
        <div class="dss-timepicker-dropdown__option ${R(T)}">
          <label
						role="option"
						aria-selected="${b === this._input.value}"
            class="dss-timepicker-dropdown__label"
            tabindex="${i ? 0 : -1}"
            @keydown=${k}
          >
						${b}

            <input
              class="dss-timepicker-dropdown__input-radio"
              name="timeList"
              type="radio"
              @click="${w}"
			  .value="${b}"
            />
						<${$} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${$}>
          </label>
        </div>
      `;
      return i = !1, g;
    });
  }
  _generateTimeManualHoursOptions() {
    const t = [];
    for (let e = this._minHour; e < this._maxHour; e += 1) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualMinutesOptions() {
    const t = [];
    for (let e = 0; e < 60; e += this._minutesRange) {
      const i = e.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualOptionsHTML(t, e) {
    let i = !0;
    return e.map((s) => {
      const l = (_) => {
        const w = _.target.getAttribute("value");
        w && (t === "timepickerManualHour" ? this._manualHourSelector = w : t === "timepickerManualMinutes" && (this._manualMinuteSelector = w), this.requestUpdate());
      }, f = (_) => {
        const w = _.currentTarget, k = _;
        let T = !1;
        const g = (n) => {
          n && n.focus();
        }, r = (n) => {
          let u = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), m = a.length - 1;
          n === a[0] ? g(a[m]) : (a.forEach((O, S) => {
            O === n && (u = S);
          }), g(a[u - 1]));
        }, c = (n) => {
          let u = 0;
          const a = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), m = a.length - 1;
          n === a[m] ? g(a[0]) : (a.forEach((O, S) => {
            O === n && (u = S);
          }), g(a[u + 1]));
        };
        switch (k.key) {
          case "ArrowUp":
            r(w), T = !0;
            break;
          case "ArrowDown":
            c(w), T = !0;
            break;
          case "Escape":
            _.preventDefault(), _.stopPropagation(), this._cancelDropdown();
            break;
          case "Enter": {
            const u = _.target.parentElement?.querySelector("input");
            if (this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            )?.setAttribute("tabindex", "-1"), _.target.setAttribute("tabindex", "0"), u?.click(), t === "timepickerManualHour") {
              const m = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              g(m);
            } else if (t === "timepickerManualMinutes") {
              const m = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                m.focus();
              }, 0);
            }
            T = !0;
            break;
          }
        }
        T && (_.stopPropagation(), _.preventDefault());
      }, b = `${s} ${t === "timepickerManualHour" ? "hores" : "minuts"}`, v = t === "timepickerManualHour" ? s === this._manualHourSelector : s === this._manualMinuteSelector, x = A`
        <div class="dss-timepicker-manual-item">
          <input
            id="${t + s}"
            class="dss-timepicker-manual-item__input-radio"
            name="${t}"
            type="radio"
            @click="${l}"
            .value="${s}"
          />
          <label
							role="option"
							aria-label="${b}"
							aria-selected="${v ? "true" : "false"}"
            for="${t + s}"
            class="dss-timepicker-manual-item__label ${t}"
            tabindex="${i ? 0 : -1}"
            @keydown=${f}
          >
            ${s}
          </label>
        </div>
      `;
      return i = !1, x;
    });
  }
  _checkDisableTimeManualSelector() {
    return this._manualHourSelector === "" || this._manualMinuteSelector === "";
  }
  /* eslint no-param-reassign: "off" */
  _timeManualSelectorCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((e) => {
      e.checked = !1;
    }), this._manualHourSelector = "", this._manualMinuteSelector = "", this._handleValidity(), this._closeDropdown(), this._input?.focus();
  }
  _timeManualSelectorAccept() {
    this._input && (this._input.value = `${this._manualHourSelector}:${this._manualMinuteSelector}`, this._helpText = this._oldHelpText, this._invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange(), this._moveFocusBackToInput());
  }
  _handleActionsKeyDown(t) {
    t?.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this._timeManualSelectorCancel());
  }
  _focusSentinel() {
    this._readonly || this._disabled || !this._showDropdown || this._input?.focus();
  }
  /* eslint no-param-reassign: "off" */
  _timeListOptionsScrollTo() {
    if (this._input) {
      const t = this._input.value.trim(), e = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
      let i = !1;
      e.forEach((o) => {
        const s = o.value;
        if (!i && s.startsWith(t)) {
          const l = o.closest("label");
          i = !0, l && (setTimeout(() => {
            l.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), s === t && (o.checked = !0));
        }
      });
    }
  }
  _timeManualOptionsScrollTo(t) {
    if (this._input) {
      const e = t ? t.trim() : this._input.value.trim();
      if (e.length <= 2) {
        const i = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
        );
        let o = !1;
        i.forEach((s) => {
          const l = s.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !o && l.startsWith(e) && (o = !0, setTimeout(() => {
            s.scrollIntoView({
              behavior: "smooth",
              block: "center",
              inline: "nearest"
            });
          }, 0), l === e && s.click());
        });
      } else {
        const i = e.slice(3), o = this.renderRoot.querySelectorAll(
          ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
        );
        let s = !1;
        o.forEach((l) => {
          const f = l.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
          !s && f.startsWith(i) && (s = !0, l.scrollIntoView({
            behavior: "smooth",
            block: "center",
            inline: "nearest"
          }), f === i && l.click());
        });
      }
    }
  }
  _checkInputOverflow() {
    if (!this._input || !this._input.value) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, o = document.createElement("canvas").getContext("2d");
    if (!o) return;
    o.font = e;
    const s = o.measureText(this._input.value).width;
    this._isTruncated = s > this._input.offsetWidth;
  }
  render() {
    return j(this);
  }
}
h([
  p({ type: String, attribute: !0 })
], d.prototype, "value", 1);
h([
  p(E)
], d.prototype, "invalid", 1);
h([
  p({ type: String })
], d.prototype, "helpText", 1);
h([
  p({ type: String })
], d.prototype, "errorTimeFormatText", 1);
h([
  p({ type: String })
], d.prototype, "errorTimeOptionText", 1);
h([
  p({ type: String })
], d.prototype, "dropdown", 1);
h([
  p(E)
], d.prototype, "showDropdown", 1);
h([
  p({ type: Number })
], d.prototype, "minutesRange", 1);
h([
  p({ type: Number })
], d.prototype, "minHour", 1);
h([
  p({ type: Number })
], d.prototype, "maxHour", 1);
h([
  p({ type: Array })
], d.prototype, "customTimeListOptions", 1);
h([
  p({ type: String })
], d.prototype, "inputSize", 2);
h([
  p({ type: String })
], d.prototype, "icon", 2);
h([
  p({ type: String })
], d.prototype, "dropdownPlacement", 2);
h([
  p(E)
], d.prototype, "dropdownFixed", 2);
export {
  d as NgTimepicker
};
//# sourceMappingURL=ng-timepicker.js.map
