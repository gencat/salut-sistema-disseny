import { nothing as l } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as r, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const p = r`dss-icon${a(t())}`, e = r`dss-button${a(t())}`, n = r`dss-tooltip${a(t())}`, g = (i) => {
  const _ = {
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": i._required,
    [`dss-input-wrapper--${i.inputSize}`]: !!i.inputSize,
    "dss-input-wrapper--no-label": !i._label
  }, o = {
    "dss-input-group": !0,
    [`dss-input-group--${i.inputSize}`]: !!i.inputSize,
    "dss-input-group--invalid": i._invalid || !i._inputValidity,
    "dss-input-group--required": i._required,
    "dss-input-group--disabled": i._disabled,
    "dss-input-group--focused": i._input?.value || i._placeholder,
    "dss-input-group--read-only": i._readonly,
    "dss-input-group--no-label": !i._label
  }, w = {
    "dss-input-help": !0,
    "dss-input-help--invalid": i._invalid,
    "dss-input-help--disabled": i._disabled
  }, $ = {
    "dss-timepicker-dropdown--open": i._showDropdown,
    "dss-timepicker-dropdown--lg": i.inputSize === "lg",
    "dss-timepicker-dropdown--md": i.inputSize !== "lg",
    "dss-timepicker-dropdown--list--visible": i._showDropdown && i._dropdown === "list"
  }, v = {
    "dss-timepicker-dropdown--open": i._showDropdown,
    "dss-timepicker-dropdown--lg": i.inputSize === "lg",
    "dss-timepicker-dropdown--md": i.inputSize !== "lg",
    "dss-timepicker-dropdown--manual--visible": i._showDropdown && i._dropdown === "manual"
  }, u = () => s`
      <div class="${d(o)}">
        ${i.icon && i.icon !== "" ? s`
          <${p} icon="${i.icon}" class="dss-input-icon"></${p}>
          ` : l}
        <div class="dss-input-field">
          ${i.inputSize !== "sm" ? s`
            <slot name="label" @click=${i._focusInput}></slot>
            ` : l}
          <slot name="input"
            @click=${i._handleClick}
            @input=${i._handleInput}
            @focusin=${i._handleFocus}
            @focusout=${i._handleBlur}
            @keydown=${i._handleKeyDown}
            @slotchange=${i._handleInputSlotChange}
          ></slot>

          ${!i._showDropdown && i._isTruncated ? s`
              <${n}>${i._input?.value}</${n}>
            ` : null}
        </div>
      </div>
      `;
  return s`
  
      <div class="${d(_)}">
  
        ${i.inputSize === "sm" ? s`
          <div class="${d({
    "dss-wrapper-label": !0,
    "dss-wrapper-label--invalid": i._invalid
  })}"
          >
            <slot name="label" @click=${i._focusInput}></slot>
          </div>
          ` : l}

        ${i._dropdown === "" ? s`
            ${u()}
          ` : s`
            <div class="dss-input-dropdown-wrapper">
              ${u()}
      
              <div
                id="${i._getEffectiveId()}-list"
                class="dss-timepicker-dropdown dss-timepicker-dropdown--list ${d($)}"
                role="listbox"
                aria-label="Selector de temps"
              >
                <div class="dss-timepicker-dropdown__container">
                  ${s`${i._generateTimeListOptionsHTML(i._timeListOptions, i._customTimeListOptions)}`}
                </div>
              </div>

              <div
                id="${i._getEffectiveId()}-manual"
                class="dss-timepicker-dropdown dss-timepicker-dropdown--manual ${d(v)}"
                role="dialog"
                aria-label="Selector de temps"
              >
                <div class="dss-timepicker-dropdown__manual">
                  <div
                    class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--hour"
                  >
                    ${i._generateTimeManualOptionsHTML("timepickerManualHour", i._timeManualHourOptions)}
                  </div>
                  <div
                    class="dss-timepicker-dropdown__items dss-timepicker-dropdown__items--minute"
                  >
                    ${i._generateTimeManualOptionsHTML("timepickerManualMinutes", i._timeManualMinutesOptions)}
                  </div>
                </div>
                <div class="dss-timepicker-dropdown__actions" @keydown=${i._handleActionsKeyDown}>
                  <${e} 
                    label="Cancel-lar"
							aria-label="Cancel-lar"
                    size="md"
                    variant="secondary"
                    @onClick=${i._timeManualSelectorCancel}
                  ></${e}>
                  <${e}
                    label="Seleccionar"
							aria-label="Seleccionar"
                    size="md"
                    variant="primary"
                    ?disabled=${i._checkDisableTimeManualSelector()}
                    @onClick=${i._timeManualSelectorAccept}
                  ></${e}>
                </div>
              </div>
            <button
              tabindex=${i.showDropdown ? 0 : -1}
              class="dss-timepicker-dropdown__sentinel"
              type="button"
              aria-hidden="true"
              @focus=${i._focusSentinel}
            ></button>
      
            </div>
          `}

        ${i._helpText ? s`
              <div class="${d(w)}">
                <span>${i._helpText}</span>
              </div>
            ` : null}
  
      </div>
    `;
};
export {
  g as template
};
//# sourceMappingURL=ng-timepicker.template.js.map
