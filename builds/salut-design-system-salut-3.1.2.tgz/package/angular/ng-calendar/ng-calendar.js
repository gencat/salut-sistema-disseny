import { LitElement as F, unsafeCSS as y } from "lit";
import { html as E } from "lit/static-html.js";
import { property as o } from "lit/decorators.js";
import { classMap as M } from "lit/directives/class-map.js";
import { booleanType as p } from "../../utils/property-types.js";
import { startOfMonth as R, endOfMonth as T, eachDayOfInterval as Y, getDay as x } from "date-fns";
import O from "../../components/button/button.style.css.js";
import k from "../../components/icon-button/icon-button.style.css.js";
import q from "../../foundations/icon/icon.style.css.js";
import C from "./ng-calendar.style.css.js";
import { template as L } from "./ng-calendar.template.js";
var A = Object.defineProperty, U = Object.getOwnPropertyDescriptor, h = (b, t, e, s) => {
  for (var r = s > 1 ? void 0 : s ? U(t, e) : t, i = b.length - 1, l; i >= 0; i--)
    (l = b[i]) && (r = (s ? l(t, e, r) : l(r)) || r);
  return s && r && A(t, e, r), r;
};
const m = [
  "Gener",
  "Febrer",
  "Març",
  "Abril",
  "Maig",
  "Juny",
  "Juliol",
  "Agost",
  "Setembre",
  "Octubre",
  "Novembre",
  "Desembre"
], G = ["dl", "dm", "dc", "dj", "dv", "ds", "dg"];
class c extends F {
  constructor() {
    super(), this.customCalendar = void 0, this._range = !1, this._isRangeStartFocused = !1, this._isRangeEndFocused = !1, this._rangeStartDate = null, this._rangeEndDate = null, this._rangeOverDate = null, this._timepicker = "", this._minutesRange = 1, this._minHour = 0, this._maxHour = 24, this._customTimeListOptions = [], this._timepickerLabel = "", this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._days = this._getDays(), this._selectedDate = null, this._showTime = !1, this._showButtons = !0, this._leftLabel = "Cancel·lar", this._rightLabel = "Seleccionar", this._minDate = null, this._maxDate = null, this._timepickerValue = "", this._showMonthSelector = !1, this._showYearSelector = !1, this._yearsRangeStart = (/* @__PURE__ */ new Date()).getFullYear() - 18, this._yearsRangeEnd = (/* @__PURE__ */ new Date()).getFullYear() + 1, this._isTimeFormatValid = !1, this._rovingFocusDate = null, this._previouslyFocusedElement = null, this._focusFirstElementHandler = this._focusFirstElement.bind(this);
  }
  static get styles() {
    return [y(q), y(O), y(k), y(C)];
  }
  set range(t) {
    const e = this._range;
    this._range = t, this.requestUpdate("range", e);
  }
  get range() {
    return this._range;
  }
  set isRangeStartFocused(t) {
    const e = this._isRangeStartFocused;
    this._isRangeStartFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeStartFocused() {
    return this._isRangeStartFocused;
  }
  set isRangeEndFocused(t) {
    const e = this._isRangeEndFocused;
    this._isRangeEndFocused = t, this.requestUpdate("isRangeStartFocused", e);
  }
  get isRangeEndFocused() {
    return this._isRangeEndFocused;
  }
  set selectedDate(t) {
    const e = this._selectedDate;
    this._selectedDate = this._getDateString(t), this._updateCurrentDate(), this.requestUpdate("selectedDate", e);
  }
  get selectedDate() {
    return this._selectedDate?.toString() || "";
  }
  set minDate(t) {
    const e = this._minDate;
    this._minDate = this._getDateString(t), this.requestUpdate("minDate", e);
  }
  get minDate() {
    return this._minDate?.toString() || "";
  }
  set maxDate(t) {
    const e = this._maxDate;
    this._maxDate = this._getDateString(t), this.requestUpdate("maxDate", e);
  }
  get maxDate() {
    return this._maxDate?.toString() || "";
  }
  set showTime(t) {
    const e = this._showTime;
    this._showTime = t, this.requestUpdate("showTime", e);
  }
  get showTime() {
    return this._showTime;
  }
  set showButtons(t) {
    const e = this._showButtons;
    this._showButtons = t, this.requestUpdate("showButtons", e);
  }
  get showButtons() {
    return this._showButtons;
  }
  set leftLabel(t) {
    const e = this._leftLabel;
    this._leftLabel = t, this.requestUpdate("leftLabel", e);
  }
  get leftLabel() {
    return this._leftLabel;
  }
  set rightLabel(t) {
    const e = this._rightLabel;
    this._rightLabel = t, this.requestUpdate("rightLabel", e);
  }
  get rightLabel() {
    return this._rightLabel;
  }
  set timepicker(t) {
    const e = this._timepicker;
    this._timepicker = t, this.requestUpdate("timepicker", e);
  }
  get timepicker() {
    return this._timepicker;
  }
  set minutesRange(t) {
    const e = this._minutesRange;
    this._minutesRange = t, this.requestUpdate("minutesRange", e);
  }
  get minutesRange() {
    return this._minutesRange;
  }
  set minHour(t) {
    const e = this._minHour;
    this._minHour = t, this.requestUpdate("minHour", e);
  }
  get minHour() {
    return this._minHour;
  }
  set maxHour(t) {
    const e = this._maxHour;
    this._maxHour = t, this.requestUpdate("maxHour", e);
  }
  get maxHour() {
    return this._maxHour;
  }
  set customTimeListOptions(t) {
    const e = this._customTimeListOptions;
    this._customTimeListOptions = t, this.requestUpdate("customTimeListOptions", e);
  }
  get customTimeListOptions() {
    return this._customTimeListOptions;
  }
  set timepickerLabel(t) {
    const e = this._timepickerLabel;
    this._timepickerLabel = t, this.requestUpdate("timepickerLabel", e);
  }
  get timepickerLabel() {
    return this._timepickerLabel;
  }
  set rangeStartDate(t) {
    const e = this._rangeStartDate;
    this._rangeStartDate = this._getDateString(t), this.requestUpdate("rangeStartDate", e);
  }
  get rangeStartDate() {
    return this._rangeStartDate?.toString() || "";
  }
  set rangeEndDate(t) {
    const e = this._rangeEndDate;
    this._rangeEndDate = this._getDateString(t), this.requestUpdate("rangeEndDate", e);
  }
  get rangeEndDate() {
    return this._rangeEndDate?.toString() || "";
  }
  connectedCallback() {
    super.connectedCallback(), this._range && window.addEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._range && window.removeEventListener("range-focus-calendar", this._focusFirstElementHandler);
  }
  _focusFirstElement() {
    if (this._showYearSelector) {
      this.shadowRoot?.querySelector("#prevYearElement")?.focus();
      return;
    }
    if (this._showMonthSelector) {
      this.shadowRoot?.querySelector(".calendar-selector-options__item--selected")?.focus();
      return;
    }
    this.shadowRoot?.querySelector("#firstCalendarElement")?.focus();
  }
  _focusActiveDay() {
    if (this._showMonthSelector || this._showYearSelector) {
      this._focusFirstElement();
      return;
    }
    const t = this.shadowRoot?.querySelector(".calendar__day-item--selected:not(:disabled)") ?? this.shadowRoot?.querySelector(".calendar__day-item--active:not(:disabled)") ?? this.shadowRoot?.querySelector(
      ".calendar__day-item:not(:disabled):not(.calendar__day-item--empty)"
    );
    t?.getAttribute("tabindex") !== "0" && (this.shadowRoot?.querySelectorAll('.calendar__day-item[tabindex="0"]').forEach((e) => {
      e.setAttribute("tabindex", "-1");
    }), t?.setAttribute("tabindex", "0")), t?.focus();
  }
  _handleCalendarFocusIn(t) {
    const e = t.relatedTarget;
    e && !this.shadowRoot?.contains(e) && (this._previouslyFocusedElement = e);
  }
  _handleEndSentinelFocus() {
    const t = this._previouslyFocusedElement;
    if (t && t.isConnected) {
      t.focus();
      return;
    }
    const e = this.getRootNode();
    e instanceof ShadowRoot && e.querySelector("input")?.focus();
  }
  _prev() {
    this._currMonth -= 1, this._update();
  }
  _next() {
    this._currMonth += 1, this._update();
  }
  _update() {
    (this._currMonth < 0 || this._currMonth > 11) && (this._date = new Date(this._currYear, this._currMonth, (/* @__PURE__ */ new Date()).getDate()), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth()), this._rovingFocusDate = null, this._days = this._getDays(), this.requestUpdate();
  }
  _getDays() {
    const t = [], e = R(new Date(this._currYear, this._currMonth)), s = T(new Date(this._currYear, this._currMonth)), r = Y({ start: e, end: s }), i = x(e);
    for (let l = i === 0 ? 6 : i - 1; l > 0; l -= 1)
      t.push(0);
    for (const l of r)
      t.push(l.getDate());
    return t;
  }
  _getCustomType(t) {
    if (!this.customCalendar) return !1;
    const s = new Date(this._currYear, this._currMonth, t).toLocaleDateString("es-ES"), r = this.customCalendar.find((i) => i.date === s);
    return r ? r.type : !1;
  }
  _isToday(t) {
    const e = /* @__PURE__ */ new Date();
    return t === e.getDate() && this._currMonth === e.getMonth() && this._currYear === e.getFullYear();
  }
  _isWeekend(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return e.getDay() === 0 || e.getDay() === 6;
  }
  _getDayAriaLabel(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return new Intl.DateTimeFormat("ca-ES", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(e);
  }
  _getFirstEnabledDay() {
    return this._days.find((t) => t && !this._isInactive(t)) ?? null;
  }
  _isInactive(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return t ? this._minDate && this._maxDate ? !(e >= this._minDate && e <= this._maxDate) : this._minDate ? !(e >= this._minDate) : this._maxDate ? !(e <= this._maxDate) : !1 : !0;
  }
  _isSelected(t) {
    return this._range ? t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() || this._isSelectedRangeEnd(t) : t === this._selectedDate?.getDate() && this._currMonth === this._selectedDate?.getMonth() && this._currYear === this._selectedDate?.getFullYear();
  }
  _isFocusable(t) {
    return this._rovingFocusDate ? t === this._rovingFocusDate.getDate() && this._currMonth === this._rovingFocusDate.getMonth() && this._currYear === this._rovingFocusDate.getFullYear() : this._range && (this._rangeStartDate || this._rangeEndDate) ? this._isSelectedRangeStart(t) || this._isSelectedRangeEnd(t) : this._selectedDate ? this._days.some((r) => r && this._isSelected(r)) ? this._isSelected(t) : t === this._getFirstEnabledDay() : this._days.some((s) => s && this._isToday(s)) ? this._isToday(t) : t === this._getFirstEnabledDay();
  }
  _isSelectedRangeStart(t) {
    return this._range && this._rangeStartDate && this._rangeEndDate ? !this._compareSelectedRangeDates() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() : this._range && this._rangeStartDate && !this._rangeEndDate ? this._rangeOverDate !== null && this._rangeStartDate?.getTime() < this._rangeOverDate?.getTime() && t === this._rangeStartDate?.getDate() && this._currMonth === this._rangeStartDate?.getMonth() && this._currYear === this._rangeStartDate?.getFullYear() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : (this._range && this._rangeStartDate === this._rangeEndDate, !1);
  }
  _isSelectedRangeEnd(t) {
    return !this._compareSelectedRangeDates() && t === this._rangeEndDate?.getDate() && this._currMonth === this._rangeEndDate?.getMonth() && this._currYear === this._rangeEndDate?.getFullYear();
  }
  _isOverRangeDate(t) {
    const e = t === this._rangeOverDate?.getDate() && this._currMonth === this._rangeOverDate?.getMonth() && this._currYear === this._rangeOverDate?.getFullYear();
    return this._range && this._rangeOverDate && this._rangeStartDate && !this._rangeEndDate ? e && this._rangeOverDate.getTime() > this._rangeStartDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _compareSelectedRangeDates() {
    return this._rangeStartDate && this._rangeEndDate ? this._rangeStartDate.getFullYear() === this._rangeEndDate.getFullYear() && this._rangeStartDate.getMonth() === this._rangeEndDate.getMonth() && this._rangeStartDate.getDate() === this._rangeEndDate.getDate() : !0;
  }
  _isBetweenRange(t) {
    const e = new Date(this._currYear, this._currMonth, t);
    return !this._isInactive(t) && this._rangeStartDate && this._rangeEndDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() : !1;
  }
  _isBetweenRangeOnMouseOver(t) {
    const e = new Date(this._currYear, this._currMonth, t), s = this._isInactive(t);
    return !s && this._rangeStartDate && !this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !s && this._rangeStartDate && this._rangeEndDate && this._rangeOverDate ? e.getTime() > this._rangeStartDate.getTime() && e.getTime() < this._rangeEndDate.getTime() && e.getTime() < this._rangeOverDate.getTime() && (!this._isRangeStartFocused || this._showButtons) && (this._isRangeEndFocused || this._rangeStartDate !== null) : !1;
  }
  _selectDate(t, e = !1) {
    this._selectedDate = new Date(this._currYear, this._currMonth, t), this._range && !this._showButtons && (this._rangeStartDate && this._rangeEndDate && !this._isRangeEndFocused && this._selectedDate.getTime() >= this._rangeEndDate.getTime() && (this._rangeStartDate = null, this._rangeEndDate = null), this._isRangeStartFocused || !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this._range && this._showButtons && (this._rangeStartDate && this._rangeEndDate && (this._rangeStartDate = null, this._rangeEndDate = null), !this._rangeStartDate || this._rangeStartDate.getTime() > this._selectedDate.getTime() ? this._rangeStartDate = this._selectedDate : this._rangeEndDate = this._selectedDate), this.requestUpdate(), this._range && (this._rangeStartDate && !this._rangeEndDate ? this._focusNextRangeDay(t, e) : this._rovingFocusDate = this._selectedDate), !this._showButtons && (this._range ? this._emitRange(e) : this._emitDate());
  }
  _focusNextRangeDay(t, e) {
    const s = this._days.includes(t + 1) && !this._isInactive(t + 1) ? t + 1 : t;
    this._rovingFocusDate = new Date(this._currYear, this._currMonth, s), e && this.updateComplete.then(() => {
      this.shadowRoot?.querySelector(
        `.calendar__day-item[data-day="${s}"]`
      )?.focus();
    });
  }
  _selectRangeOverDate(t) {
    this._range && (this._rangeOverDate = new Date(this._currYear, this._currMonth, t), this.requestUpdate());
  }
  _removeRangeOverDate() {
    this._rangeOverDate = null, this.requestUpdate();
  }
  _onCancel() {
    const t = new CustomEvent("onCancel", {
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(t);
  }
  _onAccept() {
    this._range ? this._emitRange() : this._emitDate();
  }
  _emitDate() {
    const t = this._selectedDate?.getDate()?.toString().padStart(2, "0"), e = (this._currMonth + 1).toString().padStart(2, "0");
    let s = `${t}/${e}/${this._currYear}`;
    if (this._showTime) {
      const i = this._currHour?.toString().padStart(2, "0"), l = this._currMin?.toString().padStart(2, "0");
      s += ` ${i}:${l}`;
    }
    const r = new CustomEvent("onDateChange", {
      detail: s,
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(r);
  }
  _emitRange(t = !1) {
    let e = null;
    if (this._rangeStartDate?.getDate() != null && this._rangeStartDate?.getMonth() != null && this._rangeStartDate?.getFullYear() != null) {
      const l = this._rangeStartDate.getDate()?.toString().padStart(2, "0"), D = (this._rangeStartDate?.getMonth() + 1).toString().padStart(2, "0");
      e = `${l}/${D}/${this._rangeStartDate?.getFullYear()}`;
    }
    let s = null;
    if (this._rangeEndDate?.getDate() != null && this._rangeEndDate?.getMonth() != null && this._rangeEndDate?.getFullYear()) {
      const l = this._rangeEndDate.getDate()?.toString().padStart(2, "0"), D = (this._rangeEndDate?.getMonth() + 1).toString().padStart(2, "0");
      s = `${l}/${D}/${this._rangeEndDate?.getFullYear()}`;
    }
    const r = new CustomEvent("onRangeChange", {
      detail: {
        rangeStart: e,
        rangeEnd: s,
        isKeyboardSelection: t
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(r);
    const i = new CustomEvent("range-changed", {
      detail: {
        rangeStart: e,
        rangeEnd: s
      },
      bubbles: !1,
      composed: !1
    });
    this.dispatchEvent(i);
  }
  _updateCurrentDate() {
    if (!this._selectedDate) {
      this._resetCalendar();
      return;
    }
    if (this._currMonth = this._selectedDate.getMonth(), this._currYear = this._selectedDate.getFullYear(), this._currHour = this._selectedDate.getHours(), this._currMin = this._selectedDate.getMinutes(), this._days = this._getDays(), this._currHour !== void 0 && this._currMin !== void 0) {
      const t = String(this._currHour).padStart(2, "0"), e = String(this._currMin).padStart(2, "0");
      this._timepickerValue = `${t}:${e}`, this._isTimeFormatValid = this._currHour >= 0 && this._currHour <= 23 && this._currMin >= 0 && this._currMin <= 59;
    }
  }
  _resetCalendar() {
    this._date = /* @__PURE__ */ new Date(), this._currYear = this._date.getFullYear(), this._currMonth = this._date.getMonth(), this._currHour = void 0, this._currMin = void 0, this._timepickerValue = "", this._isTimeFormatValid = !1, this._rovingFocusDate = null, this._days = this._getDays(), this.requestUpdate();
  }
  _getDateString(t) {
    const e = t?.replace(/(\d+[/])(\d+[/])/, "$2$1"), s = this._showTime ? 14 : 8;
    return e?.length > s ? new Date(e) : null;
  }
  _onSelectTime(t) {
    if (this._isTimeFormatValid = !1, t.detail.status === "VALID") {
      this._isTimeFormatValid = !0;
      const e = t.detail.value;
      this._currHour = +e.substring(0, 2), this._currMin = +e.substring(3, 5);
    }
    this.requestUpdate();
  }
  _toggleMonthSelector() {
    this._showMonthSelector = !0, this.requestUpdate();
  }
  _onMonthSelectorClick(t, e = {}) {
    const s = m.indexOf(t);
    this._currMonth = s, this._update(), this._closeMonthSelector(e);
  }
  _toggleYearSelector() {
    this._showYearSelector = !0, this.requestUpdate();
  }
  _closeMonthSelector(t = {}) {
    this._showMonthSelector = !1, this.requestUpdate(), t.focusActiveDay && this.updateComplete.then(() => this._focusActiveDay());
  }
  _onYearSelectorClick(t, e = {}) {
    this._currYear = t, this._update(), this._closeYearSelector(e);
  }
  _closeYearSelector(t = {}) {
    this._showYearSelector = !1, this.requestUpdate(), t.focusActiveDay && this.updateComplete.then(() => this._focusActiveDay());
  }
  _generateYearsRangeOptions() {
    const t = [];
    for (let r = this._yearsRangeStart; r <= this._yearsRangeEnd; r += 1)
      t.push(r);
    const e = t.includes(this._currYear) ? this._currYear : t[0];
    return t.map((r) => {
      const i = (a) => {
        a && a.focus();
      }, l = (a) => {
        let n = 0;
        const _ = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = _.length - 1;
        a === _[0] ? i(_[d]) : (_.forEach((f, v) => {
          f === a && (n = v);
        }), i(_[n - 1]));
      }, S = (a) => {
        let n = 0;
        const _ = this.renderRoot.querySelectorAll(".calendar-selector-options__item--year"), d = _.length - 1;
        a === _[d] ? i(_[0]) : (_.forEach((f, v) => {
          f === a && (n = v);
        }), i(_[n + 1]));
      }, D = (a) => {
        const n = a.currentTarget, _ = a;
        let d = !1;
        switch (_.key) {
          case "ArrowUp":
          case "ArrowLeft":
            l(n), d = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            S(n), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
          case " ":
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--year[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), a.target.setAttribute("tabindex", "0"), this._onYearSelectorClick(r, { focusActiveDay: !0 }), d = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this._closeYearSelector({ focusActiveDay: !0 }), a.preventDefault(), a.stopPropagation(), d = !0;
            break;
        }
        d && (a.stopPropagation(), a.preventDefault());
      }, u = (/* @__PURE__ */ new Date()).getFullYear(), g = {
        "calendar-selector-options__item--current": r === u,
        "calendar-selector-options__item--selected": r === this._currYear
      };
      return E`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--year ${M(g)}"
						tabindex="${r === e ? 0 : -1}"
          role="button"
          @keydown=${D}
          @click=${() => this._onYearSelectorClick(r)}
        >
          ${r}
        </div>
      `;
    });
  }
  _generateMonthsOptions() {
    return m.map((e) => {
      const s = (u) => {
        u && u.focus();
      }, r = (u) => {
        let g = 0;
        const a = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = a.length - 1;
        u === a[0] ? s(a[n]) : (a.forEach((_, d) => {
          _ === u && (g = d);
        }), s(a[g - 1]));
      }, i = (u) => {
        let g = 0;
        const a = this.renderRoot.querySelectorAll(".calendar-selector-options__item--month"), n = a.length - 1;
        u === a[n] ? s(a[0]) : (a.forEach((_, d) => {
          _ === u && (g = d);
        }), s(a[g + 1]));
      }, l = (u) => {
        const g = u.currentTarget, a = u;
        let n = !1;
        switch (a.key) {
          case "Tab":
            if (a.shiftKey) {
              const d = this._previouslyFocusedElement;
              d && d.isConnected && d.focus(), n = !0;
            }
            break;
          case "ArrowUp":
          case "ArrowLeft":
            r(g), n = !0;
            break;
          case "ArrowDown":
          case "ArrowRight":
            i(g), n = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Enter":
            this.renderRoot.querySelector(
              '.calendar-selector-options__item--month[tabindex="0"]'
            )?.setAttribute("tabindex", "-1"), u.target.setAttribute("tabindex", "0"), this._onMonthSelectorClick(e, { focusActiveDay: !0 }), n = !0;
            break;
          /* eslint no-case-declarations: "off" */
          case "Escape":
            this._closeMonthSelector({ focusActiveDay: !0 }), u.preventDefault(), u.stopPropagation(), n = !0;
            break;
        }
        n && (u.stopPropagation(), u.preventDefault());
      }, D = (/* @__PURE__ */ new Date()).getMonth(), w = {
        "calendar-selector-options__item--current": m.indexOf(e) === D,
        "calendar-selector-options__item--selected": m.indexOf(e) === this._currMonth
      };
      return E`
        <div
          class="calendar-selector-options__item calendar-selector-options__item--month ${M(w)}"
          tabindex="${m.indexOf(e) === this._currMonth ? 0 : -1}"
          role="button"
          @keydown=${l}
          @click=${() => this._onMonthSelectorClick(e)}
        >
          ${e.length <= 4 ? E`${e}` : E`${e.slice(0, 3)}.`}
        </div>
      `;
    });
  }
  _onYearRangeStepUp() {
    this._yearsRangeStart += 20, this._yearsRangeEnd += 20, this.requestUpdate();
  }
  _onYearRangeStepDown() {
    this._yearsRangeStart -= 20, this._yearsRangeEnd -= 20, this.requestUpdate();
  }
  _onShiftTabKeyDown(t) {
    if (t.key === "Tab" && t.shiftKey) {
      t.preventDefault(), t.stopPropagation();
      const e = this._previouslyFocusedElement;
      if (e && e.isConnected) {
        e.focus();
        return;
      }
    }
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--month[tabindex="0"]').focus();
    }, 50));
  }
  _onHeaderYearKeyDown(t) {
    t.key === "Enter" && (t.target.click(), setTimeout(() => {
      this.renderRoot.querySelector('.calendar-selector-options__item--year[tabindex="0"]').focus();
    }, 50));
  }
  _validateSelectedDate() {
    return !!(!this._range && !this._selectedDate || !this._range && this._showTime && !this._isTimeFormatValid || this._range && (!this._rangeStartDate || !this._rangeEndDate));
  }
  _handleCalendarKeydown(t) {
    t?.key === "Escape" && this._onCancel();
  }
  render() {
    return L(this);
  }
}
h([
  o({ type: Array })
], c.prototype, "customCalendar", 2);
h([
  o(p)
], c.prototype, "range", 1);
h([
  o(p)
], c.prototype, "isRangeStartFocused", 1);
h([
  o(p)
], c.prototype, "isRangeEndFocused", 1);
h([
  o({ type: String })
], c.prototype, "selectedDate", 1);
h([
  o({ type: String })
], c.prototype, "minDate", 1);
h([
  o({ type: String })
], c.prototype, "maxDate", 1);
h([
  o(p)
], c.prototype, "showTime", 1);
h([
  o(p)
], c.prototype, "showButtons", 1);
h([
  o({ type: String })
], c.prototype, "leftLabel", 1);
h([
  o({ type: String })
], c.prototype, "rightLabel", 1);
h([
  o({ type: String })
], c.prototype, "timepicker", 1);
h([
  o({ type: Number })
], c.prototype, "minutesRange", 1);
h([
  o({ type: Number })
], c.prototype, "minHour", 1);
h([
  o({ type: Number })
], c.prototype, "maxHour", 1);
h([
  o({ type: Array })
], c.prototype, "customTimeListOptions", 1);
h([
  o({ type: String })
], c.prototype, "timepickerLabel", 1);
h([
  o({ type: String })
], c.prototype, "rangeStartDate", 1);
h([
  o({ type: String })
], c.prototype, "rangeEndDate", 1);
export {
  m as MONTH,
  c as NgCalendar,
  G as WEEK
};
//# sourceMappingURL=ng-calendar.js.map
