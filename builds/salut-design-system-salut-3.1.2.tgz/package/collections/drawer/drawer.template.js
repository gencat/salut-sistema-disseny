import { classMap as r } from "lit/directives/class-map.js";
import { unsafeStatic as s, literal as d, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const t = d`dss-icon-button${s(i())}`, u = (e) => {
  const a = {
    "drawer--filter": e.variant === "filter",
    "drawer--jcef": e.jcef
  };
  return l`
    <div class="drawer ${r(a)}">
      <button 
        class="drawer-focus-sentinel drawer-focus-sentinel--start"
        type="button"
        aria-hidden="true"
        tabindex="0"
        @focus="${e._handleStartSentinelFocus}"
        @keydown="${e._handleStartSentinelKeydown}"
      ></button>
      
      <div class="drawer-header">
        <div class="drawer-header-title">${e.titleText}</div>
        <${t}
          class="drawer-header-close"
          hideTooltip
          variant="default"
          icon="close"
          label="Tancar"
          size="lg"
          @click=${e._handleClose}
        >
        </${t}>
      </div>
      <div class="drawer-body">
        <slot name="drawer-body"></slot>
      </div>
      <div class="drawer-footer">
        <slot name="drawer-footer"></slot>
      </div>
      <button 
        class="drawer-focus-sentinel drawer-focus-sentinel--end"
        type="button"
        aria-hidden="true"
        tabindex="0"
        @focus="${e._handleEndSentinelFocus}"
      ></button>
    </div>
  `;
};
export {
  u as template
};
//# sourceMappingURL=drawer.template.js.map
