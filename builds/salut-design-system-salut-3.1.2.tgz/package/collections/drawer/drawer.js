import { LitElement as u, unsafeCSS as h } from "lit";
import { property as i } from "lit/decorators.js";
import _ from "../../shared/reset.style.css.js";
import { booleanType as c } from "../../utils/property-types.js";
import f from "./drawer.style.css.js";
import { template as w } from "./drawer.template.js";
var y = Object.defineProperty, r = (d, e, t, s) => {
  for (var o = void 0, n = d.length - 1, a; n >= 0; n--)
    (a = d[n]) && (o = a(e, t, o) || o);
  return o && y(e, t, o), o;
};
const p = 250;
class l extends u {
  /* METHODS */
  constructor() {
    super(), this.variant = "default", this.jcef = !1, this.open = !1, this.title = "", this.titleText = "", this._drawerHeader = null, this._drawerFooter = null, this._scrollHandler = null, this._scrollContainer = null, this._previouslyFocusedElement = null, this._closedViaKeyboard = !1, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this), this._scrollHandler = this._handleScroll.bind(this), this._handleStartSentinelFocus = this._handleStartSentinelFocus.bind(this), this._handleStartSentinelKeydown = this._handleStartSentinelKeydown.bind(this), this._handleEndSentinelFocus = this._handleEndSentinelFocus.bind(this);
  }
  static get styles() {
    return [h(_), h(f)];
  }
  _showDrawer() {
    this._previouslyFocusedElement = document.activeElement || null, this._closedViaKeyboard = !1, this.classList.add("show"), this.classList.remove("hide"), document.addEventListener("keydown", this._handleKeydown), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), setTimeout(() => {
      this.shadowRoot?.querySelector(".drawer-focus-sentinel--start")?.focus();
    }, 100), document.body.style.overflow = "hidden";
  }
  _hideDrawer() {
    this.classList.add("hide"), this.classList.remove("show"), document.removeEventListener("keydown", this._handleKeydown), setTimeout(() => {
      if (this.classList.remove("hide"), this.style.visibility = "hidden", this._previouslyFocusedElement && typeof this._previouslyFocusedElement.focus == "function") {
        if (this._closedViaKeyboard)
          this._previouslyFocusedElement.focus();
        else {
          const e = { focusVisible: !1 };
          this._previouslyFocusedElement.focus(e);
        }
        this._previouslyFocusedElement = null;
      }
    }, p), document.body.style.overflow = "";
  }
  _handleClose(e) {
    if (e) {
      if (e instanceof KeyboardEvent)
        this._closedViaKeyboard = !0;
      else if (e instanceof MouseEvent) {
        const s = e.detail === 0 && e.pointerType !== "mouse";
        this._closedViaKeyboard = s;
      }
    }
    this.open = !1, this._hideDrawer(), this.requestUpdate();
    const t = new Event("close");
    this.dispatchEvent(t);
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._handleClose(e);
  }
  _handleOutsideClick(e) {
    if (this.open) {
      const t = this.shadowRoot?.querySelector(".drawer"), s = e.composedPath();
      t && s.includes(this) && !s.includes(t) && this._handleClose(e);
    }
  }
  _handleScroll(e) {
    const t = e.target;
    t && (t.scrollTop > 0 ? this._drawerHeader?.classList.add("drawer-header--scrolled") : this._drawerHeader?.classList.remove("drawer-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? this._drawerFooter?.classList.add("drawer-footer--scrolled") : this._drawerFooter?.classList.remove("drawer-footer--scrolled"));
  }
  _handleStartSentinelFocus(e) {
    const t = e.relatedTarget, s = this.shadowRoot?.querySelector(".dss-dialog-header-close");
    s && (t === s || s.contains(t)) && s.focus();
  }
  _handleStartSentinelKeydown(e) {
    e.key === "Tab" && e.shiftKey && (e.preventDefault(), this.shadowRoot?.querySelector(".dss-dialog-header-close")?.focus());
  }
  _handleEndSentinelFocus() {
    this.shadowRoot?.querySelector(".drawer-header-close")?.focus();
  }
  /* LIT LIFECYCLE */
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick), this._scrollContainer && this._scrollHandler && this._scrollContainer.removeEventListener("scroll", this._scrollHandler), this._scrollContainer = null;
  }
  updated(e) {
    e.has("open") && (this.open ? this._showDrawer() : this._hideDrawer()), e.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  firstUpdated() {
    const e = this.shadowRoot?.querySelector(".drawer");
    e && (this._scrollContainer = e, this._scrollHandler && this._scrollContainer.addEventListener("scroll", this._scrollHandler), this._drawerHeader = this.shadowRoot?.querySelector(".drawer-header"), this._drawerFooter = this.shadowRoot?.querySelector(".drawer-footer"), e.scrollHeight > e.clientHeight && this._drawerFooter.classList.add("drawer-footer--scrolled"));
  }
  render() {
    return w(this);
  }
}
r([
  i({ type: String })
], l.prototype, "variant");
r([
  i(c)
], l.prototype, "jcef");
r([
  i(c)
], l.prototype, "open");
r([
  i({ type: String })
], l.prototype, "title");
r([
  i({ type: String })
], l.prototype, "titleText");
export {
  l as Drawer
};
//# sourceMappingURL=drawer.js.map
