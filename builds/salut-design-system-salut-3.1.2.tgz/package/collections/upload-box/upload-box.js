import { LitElement as m, unsafeCSS as n } from "lit";
import { property as l, state as f } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import _ from "./upload-box.style.css.js";
import { booleanType as p } from "../../utils/property-types.js";
import { template as F } from "./upload-box.template.js";
var c = Object.defineProperty, t = (o, e, i, r) => {
  for (var a = void 0, d = o.length - 1, h; d >= 0; d--)
    (h = o[d]) && (a = h(e, i, a) || a);
  return a && c(e, i, a), a;
};
class s extends m {
  constructor() {
    super(...arguments), this.fileExplorerMessage = "Clica ", this.dragAndDropMessage = "o arrossega arxius aquí", this.dragAndDropIcon = "file_upload", this.filesFormatMessage = "PDF, JPEG o PNG de menys de 5MB", this.buttonLabel = "Buscar arxius", this.filesFormat = ["pdf", "jpeg", "png"], this.maxFileSize = 5242880, this.disableOpenFile = !1, this.helpText = void 0, this.maxUploadFiles = void 0, this.maxUploadFilesMessage = "", this.disabled = !1, this.multiple = !1, this._dragOver = !1, this._files = [], this._hasMaxUploadFilesError = !1, this._fileFormatErrorMessage = "Format d’arxiu incorrecte", this._fileSizeErrorMessage = "Mida d’arxiu incorrecte", this._fileFormatAndSizeErrorMessage = "Format i mida d’arxiu incorrecte", this._fileErrors = {};
  }
  static get styles() {
    return [n(u), n(_)];
  }
  get _input() {
    return this.shadowRoot?.querySelector(".upload-box__input");
  }
  get _allowMultipleFiles() {
    return this.multiple || !!this.maxUploadFiles && this.maxUploadFiles > 1;
  }
  get _acceptFiles() {
    if (!(!Array.isArray(this.filesFormat) || this.filesFormat.length === 0))
      return this.filesFormat.map((e) => e.trim()).filter((e) => e.length > 0).map((e) => e.startsWith(".") ? e : `.${e}`).join(",");
  }
  disconnectedCallback() {
    super.disconnectedCallback();
  }
  /* METHODS */
  _onDragOver(e) {
    e.preventDefault(), !this._dragOver && !this.disabled && (this._dragOver = !0);
  }
  _onDragLeave(e) {
    e.preventDefault(), this._dragOver && !this.disabled && (this._dragOver = !1);
  }
  _onDrop(e) {
    if (e.preventDefault(), !this.disabled) {
      this._dragOver && (this._dragOver = !1);
      const i = e.dataTransfer?.files;
      if (!i) return;
      this._handleUploadedFiles(i);
    }
  }
  _onClick() {
    this._input && !this.disabled && this._input.click();
  }
  _checkMaxUploadFiles(e) {
    if (!this.maxUploadFiles)
      return this._hasMaxUploadFilesError = !1, !0;
    const i = this._files.length + e;
    this._hasMaxUploadFilesError = i > this.maxUploadFiles, this.requestUpdate();
  }
  _isValidFileFormat(e) {
    const i = e.name.split(".").pop()?.toLowerCase();
    return this.filesFormat.includes(i || "");
  }
  _isValidFileSize(e) {
    return e.size <= this.maxFileSize;
  }
  _validateFile(e) {
    let i = !0, r = "";
    return !this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (i = !1, r = this._fileFormatAndSizeErrorMessage) : this._isValidFileSize(e) && !this._isValidFileFormat(e) ? (i = !1, r = this._fileFormatErrorMessage) : !this._isValidFileSize(e) && this._isValidFileFormat(e) && (i = !1, r = this._fileSizeErrorMessage), i || (this._fileErrors[e.name] = r), i;
  }
  _isAlreadyUploaded(e) {
    return this._files.some((i) => i.name === e.name);
  }
  _handleInputFileChange(e) {
    const i = e.target;
    i.files && this._handleUploadedFiles(i.files);
  }
  _handleUploadedFiles(e) {
    if (e && e.length > 0) {
      if (this._checkMaxUploadFiles(e.length), this._hasMaxUploadFilesError) return;
      for (const i of Array.from(e))
        if (!this._isAlreadyUploaded(i)) {
          const r = this._validateFile(i), a = i;
          a.status = r ? "loading" : "invalid", this._files.push(a), this._readFile(i, r);
        }
    }
  }
  _readFile(e, i) {
    const r = new FileReader();
    r.onload = () => {
      this._files.find((a) => a.name === e.name).status = i ? "ready" : "invalid", this.requestUpdate(), this._dispatchUploadFiles();
    }, r.onerror = () => {
      this._files.find((a) => a.name === e.name).status = "error", r.error && (this._fileErrors[e.name] = r.error.message), this.requestUpdate();
    }, r.readAsDataURL(e);
  }
  _removeFile(e) {
    this._files.splice(e, 1), this._dispatchUploadFiles(), this._input && (this._input.value = ""), this._checkMaxUploadFiles(0), this.requestUpdate();
  }
  _reloadFile(e) {
    this._files.find((i) => i.name === e.name).status = "loading", this._fileErrors[e.name] = "", this.requestUpdate(), this._readFile(e);
  }
  /* PUBLIC METHODS */
  resetFiles() {
    this._files = [], this.requestUpdate();
  }
  /* EVENTS */
  _dispatchUploadFiles() {
    const e = {
      detail: this._files,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("upload-files", e));
  }
  _dispatchOpenFile(e) {
    const i = {
      detail: { file: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("open-file", i));
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    try {
      await this.updateComplete, this.maxUploadFiles && this.maxUploadFilesMessage === "" && (this.maxUploadFilesMessage = `S'ha superat el límit d'arxius. S'hi admet un màxim de ${this.maxUploadFiles} arxius`);
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  render() {
    return F(this);
  }
}
t([
  l({ type: String })
], s.prototype, "fileExplorerMessage");
t([
  l({ type: String })
], s.prototype, "dragAndDropMessage");
t([
  l({ type: String })
], s.prototype, "dragAndDropIcon");
t([
  l({ type: String })
], s.prototype, "filesFormatMessage");
t([
  l({ type: String })
], s.prototype, "buttonLabel");
t([
  l({ type: Array })
], s.prototype, "filesFormat");
t([
  l({ type: Number })
], s.prototype, "maxFileSize");
t([
  l(p)
], s.prototype, "disableOpenFile");
t([
  l({ type: String })
], s.prototype, "helpText");
t([
  l({ type: Number })
], s.prototype, "maxUploadFiles");
t([
  l({ type: String })
], s.prototype, "maxUploadFilesMessage");
t([
  l(p)
], s.prototype, "disabled");
t([
  l(p)
], s.prototype, "multiple");
t([
  f()
], s.prototype, "_dragOver");
t([
  f()
], s.prototype, "_files");
export {
  s as UploadBox
};
//# sourceMappingURL=upload-box.js.map
