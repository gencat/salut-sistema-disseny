import { classMap as t } from "lit/directives/class-map.js";
import { ifDefined as _ } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as d, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
import { checkTextTruncate as v } from "../../utils/helpers.js";
const i = d`dss-decorative-icon${e(o())}`, r = d`dss-icon-button${e(o())}`, $ = d`dss-tooltip${e(o())}`, n = (a) => {
  const p = {
    dragover: a._dragOver,
    "upload-box--disabled": a.disabled,
    "upload-box--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  }, c = {
    dragover: a._dragOver,
    "upload-box-help--disabled": a.disabled,
    "upload-box-help--error": a._hasMaxUploadFilesError
    // 'upload-box--error': component._fileFormatError,
    // 'upload-box--has-files': component._files.length >= 2,
  };
  return s`
      <div class="upload-box-wrapper">
        <div
          class="upload-box ${t(p)}"
          @dragover="${a._onDragOver}"
          @dragleave="${a._onDragLeave}"
          @drop="${a._onDrop}"
        >
          <${i} icon=${a.dragAndDropIcon} size="lg" state="${a._hasMaxUploadFilesError ? "error" : "default"}" disabled=${a.disabled}></${i}>
          <div class="upload-box-cta">
            <div class="upload-box-cta__message">
              <span class="action" @click=${a._onClick}>
                ${a.fileExplorerMessage}
              </span>
              ${a.dragAndDropMessage}
            </div>
            <div class="upload-box-cta__requirements">
              ${a.filesFormatMessage}
            </div>
          </div>

          <input
            type="file"
            class="upload-box__input"
            ?disabled=${a.disabled}
            ?multiple=${a._allowMultipleFiles}
            accept=${_(a._acceptFiles)}
            @change=${a._handleInputFileChange}
          />
          
        </div>

        ${a.helpText || a._hasMaxUploadFilesError ? s`
            <div class="upload-box-help ${t(c)}">
              ${a._hasMaxUploadFilesError ? s`${a.maxUploadFilesMessage}` : s`${a.helpText}`}
            </div>
          ` : null}
        
      </div>

      <div class="upload-box-files">
        <ul class="file-list">
          ${a._files.map(
    (l, u) => s`
              <li class="file">
                ${a._fileErrors[l.name] ? s`
                      <${i} icon="error_outline" size="sm" state="error"></${i}>
                    ` : l.status === "loading" ? s`
                      <${i} icon="downloading" size="sm" state="info"></${i}>
                    ` : s`
                      <${i} icon="check" size="sm" state="success"></${i}>
                    `}
                <div class="file-description">
                  <p class="file-description__name" @mouseenter=${v}>

                    ${a._fileErrors[l.name] ? s`
                        ${l.name}
                      ` : l.status === "loading" ? s`${l.name} <span class="dot-flashing"></span>` : a.disableOpenFile ? s`
                            ${l.name}
                          ` : s`
                            <span class="upload-box__file-link" @click="${() => a._dispatchOpenFile(l)}">
                              ${l.name}
                            </span>
                          `}

                    <${$} class="file-description__tooltip" aria-hidden="true">
                      ${l.name}
                    </${$}>

                   
                  </p>
                  ${a._fileErrors[l.name] ? s`
                        <p class="file-description__error">
                          ${a._fileErrors[l.name]}
                        </p>
                      ` : ""}
                </div>
                <div class="file-actions">
                  ${l.status === "loading" ? s`
                        <${r}
                        size="sm"
                        icon="block"
                        variant="danger"
                        label="Cancel·lar"
                        hideTooltip
                        ></${r}>
                      ` : s`
                        ${l.status === "error" ? s`
                              <${r}
                              size="sm"
                              label="Recarregar"
                              icon="restart_alt"
                              variant="primary"
                              hideTooltip
                              @click="${() => a._reloadFile(l)}"
                              ></${r}>
                            ` : s``}
                        <${r}
                        size="sm"
                        icon="delete"
                        label="Eliminar"
                        variant="danger"
                        hideTooltip
                        @click="${() => a._removeFile(u)}"
                        ></${r}>
                      `}
                </div>
              </li>
            `
  )}
        </ul>
      </div>
  `;
};
export {
  n as template
};
//# sourceMappingURL=upload-box.template.js.map
