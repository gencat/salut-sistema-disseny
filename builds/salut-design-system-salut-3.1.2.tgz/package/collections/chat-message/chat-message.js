import { LitElement as m, unsafeCSS as y } from "lit";
import { property as t } from "lit/decorators.js";
import g from "./chat-message.style.css.js";
import { template as S } from "./chat-message.template.js";
var h = Object.defineProperty, e = (p, o, i, v) => {
  for (var a = void 0, s = p.length - 1, n; s >= 0; s--)
    (n = p[s]) && (a = n(o, i, a) || a);
  return a && h(o, i, a), a;
};
class r extends m {
  constructor() {
    super(...arguments), this.username = "", this.message = "", this.date = "", this.who = "", this.avatarName = "", this.avatarSurname = "", this.avatarImageUrl = "", this.avatarSize = "md";
  }
  static get styles() {
    return [y(g)];
  }
  render() {
    return S(this);
  }
}
e([
  t({ type: String })
], r.prototype, "username");
e([
  t({ type: String })
], r.prototype, "message");
e([
  t({ type: String })
], r.prototype, "date");
e([
  t({ type: String })
], r.prototype, "who");
e([
  t({ type: String })
], r.prototype, "avatarName");
e([
  t({ type: String })
], r.prototype, "avatarSurname");
e([
  t({ type: String })
], r.prototype, "avatarImageUrl");
e([
  t({ type: String })
], r.prototype, "avatarSize");
export {
  r as ChatMessage
};
//# sourceMappingURL=chat-message.js.map
