import { LitElement as l, unsafeCSS as p } from "lit";
import { property as n } from "lit/decorators.js";
import a from "../../shared/reset.style.css.js";
import d from "./footer.style.css.js";
import { template as u } from "./footer.template.js";
var y = Object.defineProperty, m = (r, o, s, c) => {
  for (var t = void 0, e = r.length - 1, i; e >= 0; e--)
    (i = r[e]) && (t = i(o, s, t) || t);
  return t && y(o, s, t), t;
};
class f extends l {
  constructor() {
    super(...arguments), this.logo = void 0, this.description = "";
  }
  static get styles() {
    return [p(a), p(d)];
  }
  render() {
    return u(this);
  }
}
m([
  n({ type: String })
], f.prototype, "logo");
m([
  n({ type: String })
], f.prototype, "description");
export {
  f as Footer
};
//# sourceMappingURL=footer.js.map
