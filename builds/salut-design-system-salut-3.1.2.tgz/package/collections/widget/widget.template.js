import { nothing as d } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as a, literal as t, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
const e = t`dss-icon-button${a(l())}`, $ = t`dss-badge${a(l())}`, g = t`dss-icon-badge${a(l())}`, h = t`dss-notification-badge${a(l())}`, f = t`dss-decorative-icon${a(l())}`, r = t`dss-tooltip${a(l())}`, u = t`dss-typography${a(l())}`, x = (s) => {
  const v = {
    "dss-widget": !0,
    [`dss-widget--${s.variant}`]: !!s.variant,
    "dss-widget--scroll": s.hasScroll,
    "dss-widget--folded": s.folded
  };
  return i`
  <div class="${o(v)}">
    <div class="dss-widget-header">
      <div class="dss-widget-header__info">
        <div class="dss-widget-title">
          ${s.icon ? i`
                <${f} icon=${s.icon} state=${s.iconStatus} size="sm"></${f}>
            ` : d}
          <div
            class="dss-widget-title__text" 
            @mouseenter=${s.checkTextTruncate}>
            ${s.title}
            <${r} class="title-tooltip" aria-hidden="true">
              ${s.title}
            </${r}>
          </div>
        </div>
      </div>

      <div class="dss-widget-header__config">
          <div class="dss-widget-header__config-info">
            ${s.helpText ? i`<${u} variant="body-3">${s.helpText}</${u}>` : null}
            ${s.results && s.resultsLabel === "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results}"
                ></${$}>
              ` : s.results && s.resultsLabel !== "" ? i`
                <${$}
                  size="md"
                  state="${s.resultsState}"
                  outlined
                  hideIcon
                  text="${s.results} ${s.resultsLabel}"
                ></${$}>
              ` : d}
  
            ${s.info ? i`
                <${g}  size="md" state="${s.infoBadgeState}" icon="${s.infoBadgeIcon}" ?outlined="${s.infoBadgeOutlined}">
                  <${r} slot="tooltip">
                    <span>${s.info}</span>
                  </${r} >
                </${g} >
              ` : d}

            ${s.notifications ? i`
                <${h}
                  state="${s.notificationsState}"
                  value="${s.notifications}"
                >
                </${h}>
              ` : d}
          </div>

          ${(s.helpText || s.results || s.notifications || s.info) && (s.hasAction || s.hasNext || s.hasClose) ? i`
              <span class="dss-widget-header__divider"></span>
            ` : d}

          <div class="dss-widget-header__config-actions">
              ${s.hasAction ? i`
                  <${e}
                    size="md"
                    icon="${s.actionIcon}"
                    label="${s.actionLabel}"
                    variant="${s.actionVariant}"
                    ?fill=${s.actionFill}
                    ?disabled=${s.actionDisabled}
                    tooltipPosition="${s.tooltipPosition}"
                    ?hideTooltip="${s.hideTooltip}"
                    @onClick=${s.handleAction}
                  ></${e}>
                ` : d}

            ${s.hasNext ? i`
                  <${e}
                    size="md"
                    variant="primary"
                    label="Següent"
                    icon="arrow_forward"
                    hideTooltip
                    @onClick="${s.handleNext}"
                  >
                  </${e}>
                ` : d}
            ${s.hasClose ? i`
                  <${e}
                    size="md"
                    variant="default"
                    icon="close"
                    label="Tancar"
                    hideTooltip
                    @onClick="${s.handleClose}"
                  >
                  </${e}>
                ` : d}
          </div>
      </div>
    </div>
    ${s.folded ? d : i`
      <div class="dss-widget-body">
        <slot></slot> 
      </div>
      `}
  </div>
  `;
};
export {
  x as template
};
//# sourceMappingURL=widget.template.js.map
