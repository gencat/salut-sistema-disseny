import { LitElement as m, unsafeCSS as u } from "lit";
import { property as i } from "lit/decorators.js";
import p from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import l from "./toast.style.css.js";
import { template as f } from "./toast.template.js";
var w = Object.defineProperty, e = (a, t, d, b) => {
  for (var o = void 0, h = a.length - 1, r; h >= 0; h--)
    (r = a[h]) && (o = r(t, d, o) || o);
  return o && w(t, d, o), o;
};
class s extends m {
  constructor() {
    super(), this.isShow = !1, this.text = void 0, this.state = "info", this.position = "bottom-left", this.icon = void 0, this.hasIcon = !0, this.buttonLabel = "Button", this.hasButton = !1, this.hasButtonClose = !1, this.duration = 4e3, this.managed = !1, this._firstTimeRendered_ = !1, this._hasBeenShown_ = !1, this.handleAnimationEnd = this.handleAnimationEnd.bind(this), this.onKeyDown = this.onKeyDown.bind(this);
  }
  static get styles() {
    return [u(p), u(l)];
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("keydown", this.onKeyDown);
  }
  update(t) {
    t.has("isShow") && this.addEventListener("animationend", this.handleAnimationEnd), super.update(t);
  }
  updated(t) {
    this._firstTimeRendered_ || (this._firstTimeRendered_ = !0), t.has("isShow") && this.isShow && (this._hasBeenShown_ = !0), t.has("isShow") && (this.isShow && this.duration > 0 && this._timeoutId_ === void 0 ? this._timeoutId_ = window.setTimeout(() => this.handleClose(), this.duration) : !this.isShow && this.duration > 0 && this._timeoutId_ !== void 0 && (clearTimeout(this._timeoutId_), this._timeoutId_ = void 0)), (t.has("isShow") || t.has("position") || t.has("managed")) && this.updateHostAttributes(), super.updated(t);
  }
  updateHostAttributes() {
    this.removeAttribute("data-position"), this.removeAttribute("data-animation"), this.removeAttribute("data-managed"), this.isShow ? this.setAttribute("data-animation", "show") : this._hasBeenShown_ ? this.setAttribute("data-animation", "hide") : this.setAttribute("data-animation", "hidden"), this.setAttribute("data-position", this.position), this.setAttribute("data-managed", String(this.managed));
  }
  handleAnimationEnd() {
    this.isShow || (this.dispatchEvent(new CustomEvent("close", { bubbles: !0, composed: !0 })), this.remove(), this.removeEventListener("animationend", this.handleAnimationEnd));
  }
  handleClickButton() {
    this.dispatchEvent(new CustomEvent("button-click", { bubbles: !0, composed: !0 }));
  }
  handleClose() {
    this.isShow = !1;
  }
  getText() {
    return this.text?.split(/\\n|\n/).map((t) => t.trim()) || [];
  }
  onKeyDown(t) {
    (t.code === "Enter" || t.code === "NumpadEnter") && this.isShow && this.handleClose();
  }
  render() {
    return f(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._timeoutId_ !== void 0 && clearTimeout(this._timeoutId_), this.removeEventListener("animationend", this.handleAnimationEnd), window.removeEventListener("keydown", this.onKeyDown);
  }
}
e([
  i(n)
], s.prototype, "isShow");
e([
  i({ type: String })
], s.prototype, "text");
e([
  i({ type: String })
], s.prototype, "state");
e([
  i({ type: String })
], s.prototype, "position");
e([
  i({ type: String })
], s.prototype, "icon");
e([
  i(n)
], s.prototype, "hasIcon");
e([
  i({ type: String })
], s.prototype, "buttonLabel");
e([
  i(n)
], s.prototype, "hasButton");
e([
  i(n)
], s.prototype, "hasButtonClose");
e([
  i({ type: Number })
], s.prototype, "duration");
e([
  i(n)
], s.prototype, "managed");
export {
  s as Toast
};
//# sourceMappingURL=toast.js.map
