import { LitElement as d, unsafeCSS as f } from "lit";
import { property as e } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./header-navigation.style.css.js";
import { template as c } from "./header-navigation.template.js";
var u = Object.defineProperty, t = (n, s, p, b) => {
  for (var i = void 0, l = n.length - 1, a; l >= 0; l--)
    (a = n[l]) && (i = a(s, p, i) || i);
  return i && u(s, p, i), i;
};
class o extends d {
  constructor() {
    super(...arguments), this.jcef = !1, this.hideHelp = !1, this.disableHelp = !1, this.helpLabel = "Ajuda", this.configLabel = "Centre de configuració", this.hideConfig = !1, this.disableConfig = !1, this.items = [];
  }
  static get styles() {
    return [f(h), f(m)];
  }
  /* METHODS */
  _dispatchItemAction(s) {
    const p = {
      detail: s,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("link-click", p));
  }
  _handleHelp() {
    this.dispatchEvent(new CustomEvent("help", { bubbles: !0, composed: !0 }));
  }
  _handleConfig() {
    this.dispatchEvent(new CustomEvent("config", { bubbles: !0, composed: !0 }));
  }
  render() {
    return c(this);
  }
}
t([
  e(r)
], o.prototype, "jcef");
t([
  e(r)
], o.prototype, "hideHelp");
t([
  e(r)
], o.prototype, "disableHelp");
t([
  e({ type: String })
], o.prototype, "helpLabel");
t([
  e({ type: String })
], o.prototype, "configLabel");
t([
  e(r)
], o.prototype, "hideConfig");
t([
  e(r)
], o.prototype, "disableConfig");
t([
  e({ type: Array })
], o.prototype, "items");
export {
  o as HeaderNavigation
};
//# sourceMappingURL=header-navigation.js.map
