import { unsafeStatic as s, literal as t, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as d } from "../../api/custom-element-scope.js";
const i = t`dss-button${s(d())}`, u = (l) => a`
  <ul class="dss-header-navigation" role="menu">
    ${l.items.map(
  (e) => a`
        <li class="dss-header-navigation__item" role="menuitem">
          <${i}
            variant="subtle"
            size="lg"
            icon="${e.icon ? e.icon : void 0}"
            label="${e.label}"
            ?disabled=${e.disabled}
            @click=${() => l._dispatchItemAction(e)}
            onlyIcon
          >  
          </${i}>
        </li>
      `
)}
    ${l.hideHelp ? null : a`
          <li class="dss-header-navigation__item" role="menuitem">
            <${i}
              class="dss-header-navigation__button-default"
              variant="subtle"
              size="lg"
              icon="help_outline"
              label="${l.helpLabel}"
              ?disabled=${l.disableHelp}
              @click=${l._handleHelp}
              onlyIcon
            >  
            </${i}>
          </li>
        `}
     ${l.hideConfig ? null : a`
          <li class="dss-header-navigation__item" role="menuitem">
            <${i}
              class="dss-header-navigation__button-default"
              variant="subtle"
              size="lg"
              icon="settings"
              label="${l.configLabel}"
              ?disabled=${l.disableConfig}
              @click=${l._handleConfig}
              onlyIcon
            >  
            </${i}>
          </li>
        `}
  </ul>
`;
export {
  u as template
};
//# sourceMappingURL=header-navigation.template.js.map
