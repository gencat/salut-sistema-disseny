const s = ":host{display:block}.dss-header-navigation{display:flex;align-items:center;gap:var(--dss-spacing-xs)}";
export {
  s as default
};
//# sourceMappingURL=header-navigation.style.css.js.map
