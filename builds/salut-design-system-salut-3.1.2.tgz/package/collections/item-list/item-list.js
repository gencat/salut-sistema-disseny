import { LitElement as d, unsafeCSS as u } from "lit";
import { property as o } from "lit/decorators.js";
import { itemListTemplate as f } from "./item-list.template.js";
import { booleanType as m } from "../../utils/property-types.js";
import c from "./item-list.style.css.js";
import { getCustomElementSuffix as h } from "../../api/custom-element-scope.js";
var v = Object.defineProperty, r = (a, t, e, p) => {
  for (var s = void 0, i = a.length - 1, l; i >= 0; i--)
    (l = a[i]) && (s = l(t, e, s) || s);
  return s && v(t, e, s), s;
};
class n extends d {
  constructor() {
    super(...arguments), this.items = void 0, this.widget = !1, this.hideTooltip = !1, this.tooltipPosition = "top", this.variant = "default";
  }
  static get styles() {
    return [u(c)];
  }
  // 'checkbox' | 'radio' | 'default'
  /* METHODS */
  _dispatchItemAction(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItem", e));
  }
  _dispatchItemChip(t) {
    const e = {
      detail: t,
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickItemChip", e));
  }
  _dispatchWidgetAction(t, e) {
    const p = {
      detail: { item: t, action: e },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onClickWidgetAction", p));
  }
  _applyDivider() {
    if (this.items?.length) return;
    const t = this.shadowRoot?.querySelectorAll("slot");
    if (!t || t.length === 0) return;
    let e = !0;
    t.forEach((p) => {
      p.assignedElements({ flatten: !0 }).forEach((i) => {
        i instanceof HTMLElement && i.tagName.toLowerCase() === `dss-item-list-base${h()}` && (e ? (i.setAttribute("first", ""), e = !1) : i.removeAttribute("first"));
      });
    });
  }
  /* LIT LIFECYCLE */
  async firstUpdated() {
    await this.updateComplete, this._applyDivider();
  }
  render() {
    return f(this);
  }
}
r([
  o({ type: Array })
], n.prototype, "items");
r([
  o(m)
], n.prototype, "widget");
r([
  o(m)
], n.prototype, "hideTooltip");
r([
  o({ type: String })
], n.prototype, "tooltipPosition");
r([
  o({ type: String })
], n.prototype, "variant");
export {
  n as ItemList
};
//# sourceMappingURL=item-list.js.map
