import { unsafeStatic as a, literal as l, html as i } from "lit/static-html.js";
import { getCustomElementSuffix as c } from "../../api/custom-element-scope.js";
import { classMap as S } from "lit/directives/class-map.js";
import { ifDefined as d } from "lit/directives/if-defined.js";
const $ = l`dss-badge${a(c())}`, r = l`dss-icon-badge${a(c())}`, o = l`dss-tooltip${a(c())}`, n = l`dss-chip${a(c())}`, h = l`dss-icon${a(c())}`, p = l`dss-icon-button${a(c())}`, v = l`dss-decorative-icon${a(c())}`, f = (s) => i`
  <div
    class=${S({
  "dss-item-list": !0,
  "dss-item-list--widget": s.widget,
  "dss-item-list--slotted": s.items === void 0
})}
  >
    ${s.items ? I(s) : i`<slot/>`}
  </div>
`, I = (s) => s.items?.map((t) => {
  const u = (e) => {
    const g = e.target, b = g.scrollWidth > g.offsetWidth;
    g.setAttribute("data-truncated", b.toString());
  };
  return i`
      <div class="dss-item-list__item">
        ${s.widget && t.iconBadgeLeftState ? i`
              <div class="item-widget-badge">
                <${r} size="sm"
                  state="${d(t.iconBadgeLeftState)}"
                  icon="${d(t.iconBadgeLeftIcon)}"
                  aria-label="${t.iconBadgeLabel}"
                > 
                  ${t.iconBadgeLabel ? i`
                    <${o} 
                      slot="tooltip" 
                      aria-hidden="true" 
                      >
                      ${t.iconBadgeLabel}
                      </${o}>` : null}
                </${r}>  
              </div>
            ` : null}

        <div class="item-details">
          ${s.widget && t.date ? i`
                <div class="item-details__date">
                  <span>${t.date}</span>
                </div>
              ` : null}
          <div class="item-details__title">
            ${t.decorativeIcon ? i`
                  <${v} icon=${t.decorativeIcon} size="sm" state=${d(t.decorativeIconType)}
                  >
                  </${v}>
                ` : null}
            <div class="item-details__title-text" @mouseenter=${u}>
              ${t.title}
              <${o} 
                class="title-tooltip" 
                slot="tooltip" 
                aria-hidden="true"
                >${t.title}</${o}>
            </div>
          </div>
          <div class="item-details__subtitle" @mouseenter=${u}>
            ${t.subtitle}
            <${o} 
              class="title-tooltip" 
              slot="tooltip" 
              aria-hidden="true"
              >${t.subtitle}</${o}>
          </div>
        </div>

        ${t.id ? i`
          <slot name="item-custom-${t.id}"></slot>
        ` : i`
          ${t.badgeText && !s.widget ? t.badgeIcon ? i`
                  <div class="item-action">
                    <${$}
                      text="${t.badgeText}"
                      icon="${t.badgeIcon}"
                      size="${t.badgeSize ? t.badgeSize : "sm"}"
                      state="${t.badgeState ? t.badgeState : "undeterminated"}"
                    >
                    </${$}>
                  </div>
                ` : i`
                  <div class="item-action">
                    <${$}
                      text="${t.badgeText}"
                      size="${t.badgeSize ? t.badgeSize : "sm"}"
                      state="${t.badgeState ? t.badgeState : "undeterminated"}"
                    >
                    </${$}>
                  </div>
                ` : null}
          
          ${t.chipText && !s.widget ? i`
                
                <${n} 
                  size="${t.chipSize ? t.chipSize : "xs"}" 
                  icon=${d(t.chipIcon)}
                  label="${t.chipText}" 
                  disableSelect
                  ?selected=${t.chipSelected}
                  @click=${() => s._dispatchItemChip(t)}></${n}>
              
              ` : null}

          ${t.actionIcon && !s.widget ? i`
                <div class="item-action">
                  <${p} 
                    size="md" 
                    icon=${t.actionIcon} 
                    label="${t.actionLabel}" 
                    variant=${t.actionIconType ? t.actionIconType : "primary"} 
                    tooltipPosition="${s.tooltipPosition}"
                    @click=${() => s._dispatchItemAction(t)}>
                  </${p}>
                </div>
              ` : null}
          ${s.widget ? i`
                <div class="item-widget">
                  ${t.description ? i`
                        <div class="item-widget-description">
                          ${t.description}
                        </div>
                      ` : null}
                  ${t.icons?.length ? i`
                        ${t.icons.map(
    (e) => i`
                            <${h} size="md" icon="${e.icon}"></${h}>
                          `
  )}
                      ` : null}
                  ${t.iconBadgeRightState ? i`
                        <${r}
                          size="sm"
                          state="${d(t.iconBadgeRightState)}"
                          icon="${d(t.iconBadgeRightIcon)}"
                        />
                      ` : null}
                  ${t.chipText ? i`
                        <${n} 
                          size="${t.chipSize ? t.chipSize : "xs"}" 
                          icon=${d(t.chipIcon)}
                          label="${t.chipText}" 
                          disableSelect
                          ?selected=${t.chipSelected}
                          @click=${() => s._dispatchItemChip(t)}></${n}>
                      ` : null}
                  ${t.actions?.length ? i`
                        ${t.actions.map(
    (e) => i`
                            <${p}
                              label="${e.label}"
                              icon="${e.icon}"
                              variant="${e.type}"
                              tooltipPosition="${s.tooltipPosition}"
                              ?hideTooltip="${s.hideTooltip}"
                              @onClick=${() => s._dispatchWidgetAction(t, e.action)}
                            />
                          `
  )}
                      ` : null}
                </div>
              ` : null}
        `}
      </div>
    `;
});
export {
  f as itemListTemplate
};
//# sourceMappingURL=item-list.template.js.map
