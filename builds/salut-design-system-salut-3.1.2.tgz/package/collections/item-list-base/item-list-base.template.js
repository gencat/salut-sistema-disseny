import { unsafeHTML as l } from "lit/directives/unsafe-html.js";
import { unsafeStatic as d, literal as r, html as t } from "lit/static-html.js";
import { getCustomElementSuffix as g } from "../../api/custom-element-scope.js";
import { highlightTextMultiple as h, highlightText as a } from "../../api/marker/marker.js";
import { nothing as e } from "lit";
import { classMap as T } from "lit/directives/class-map.js";
import { ifDefined as b } from "lit/directives/if-defined.js";
const $ = r`dss-decorative-icon${d(g())}`, v = r`dss-icon-badge${d(g())}`, s = r`dss-tooltip${d(g())}`, k = (i) => t`
  <div
    class=${T({
  "dss-item-list-base": !0,
  "dss-item-list-base--first": i.first
})}
  >
    ${i.selectable ? t`
        <slot name="selector"></slot>
      ` : e}

    ${i.criticity ? t`
          <${v} size="sm"
            state="${i.criticity}"
            label="${i.criticityLabel}"
            ?disabled="${i.disabled || i.criticityDisabled}"
          >
            ${i.criticityLabel ? t`
              <${s} 
                slot="tooltip" 
              >
                ${i.criticityLabel}
              </${s}>` : e}
          </${v}>  
        ` : e}

    <div class="item-details">
      ${i.date ? t`
          <div class="item-details__date"> 
            <span>
              ${i.advancedHighlight ? l(
  h(i.date, i.highlight || "", i.highlightThreshold)
) : l(a(i.date, i.highlight || "", i.highlightThreshold))}
            </span>
          </div>
        ` : e}
      <div class="item-details__title">
        ${i.decorativeIcon ? t`
              <${$} 
                icon=${i.decorativeIcon} 
                size="sm" 
                state=${b(i.decorativeIconState)}
                ?disabled="${i.disabled || i.decorativeIconDisabled}"
                ?fill="${i.decorativeIconFill}"
              >
              </${$}>
            ` : e}
        ${i.interactive ? t`
            <button 
              class="item-details__title-button" 
              @mouseenter=${i._checkTextTruncate} 
              @click=${i._dispatchClickEvent}
              ?disabled="${i.disabled}"
            >
              ${i.advancedHighlight ? l(
  h(
    i.titleText,
    i.highlight || "",
    i.highlightThreshold
  )
) : l(
  a(i.titleText, i.highlight || "", i.highlightThreshold)
)}
              <${s} 
                class="title-tooltip" 
                aria-hidden="true"
                >${i.titleText}</${s}>
            </button>
          ` : t`
            <div class="item-details__title-text" @mouseenter=${i._checkTextTruncate}>
              ${i.advancedHighlight ? l(
  h(
    i.titleText,
    i.highlight || "",
    i.highlightThreshold
  )
) : l(
  a(i.titleText, i.highlight || "", i.highlightThreshold)
)}
              <${s} 
                class="title-tooltip" 
                aria-hidden="true"
                >${i.titleText}</${s}>
            </div>
          `}
      </div>
      
      ${i.subtitle ? t`
          <div class="item-details__subtitle" @mouseenter=${i._checkTextTruncate}>
            ${i.advancedHighlight ? l(
  h(i.subtitle, i.highlight || "", i.highlightThreshold)
) : l(a(i.subtitle, i.highlight || "", i.highlightThreshold))}
            <${s} 
              class="title-tooltip" 
              aria-hidden="true"
              >${i.subtitle}</${s}>
          </div>
        ` : e}
    </div>

    <div class="item-actions">
      <slot/>
    </div>
  </div>
`;
export {
  k as itemListBaseTemplate
};
//# sourceMappingURL=item-list-base.template.js.map
