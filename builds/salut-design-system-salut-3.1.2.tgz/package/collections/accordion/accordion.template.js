import { classMap as h } from "lit/directives/class-map.js";
import { ifDefined as v } from "lit/directives/if-defined.js";
import { unsafeStatic as d, literal as l, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
import { checkTextTruncate as f } from "../../utils/helpers.js";
const a = l`dss-icon-button${d(e())}`, $ = l`dss-decorative-icon${d(e())}`, t = l`dss-badge${d(e())}`, c = l`dss-icon-badge${d(e())}`, r = l`dss-tooltip${d(e())}`, o = l`dss-notification-badge${d(e())}`, u = l`dss-typography${d(e())}`, B = (i) => {
  const g = {
    "dss-accordion--open": i.isOpen,
    [`dss-accordion--${i.accordionStyle}`]: !!i.accordionStyle,
    // 'dss-accordion--box': component._accordionStyle === 'box',
    // 'dss-accordion--inner': component._accordionStyle === 'inner',
    "dss-accordion--widget": i.widget,
    "dss-accordion--show-header-divider": i.showHeaderDivider,
    "dss-accordion--hide-footer-divider": i.hideFooterDivider
  };
  return s`
    <div class="dss-accordion ${h(g)}">
      <div class="dss-accordion-header">
        <div class="dss-accordion-header__info">
          <div class="dss-accordion-title">
            ${i.icon ? s`
                  <${$} icon=${i.icon} state=${i.iconStatus} size="sm"></${$}>
                ` : null}
            ${i.hasCheckbox ? s`
                  <div class="dss-accordion-title__checkbox dss-form-field">
                    <slot
                      name="checkbox"
                      @click=${i._dispatchCheckboxChange}
                    ></slot>
                    <slot name="checkboxLabel"></slot>
                  </div>
                ` : s`
                  <div
                    class="dss-accordion-title__text" @mouseenter=${f}
                    @click="${i._toggleAccordion}"
                  >
                    ${i.titleText ? s` ${i.titleText} ` : s` ${i.type} ${i.index} `}
                    <${r} class="title-tooltip" aria-hidden="true">
                      ${i.titleText ? s` ${i.titleText} ` : s` ${i.type} ${i.index} `}
                    </${r}>


                  </div>
                `}
          </div>
        </div>

        <div class="dss-accordion-header__config">

            <div class="dss-accordion-header__config-info">
              ${i.helpText ? s`<${u} variant="body-3">${i.helpText}</${u}>` : null}

              ${i.mainBadgeLabel ? s`
                    <${t}
                      size="${i.mainBadgeSize}"
                      icon="${v(i.mainBadgeIcon)}"
                      status="${i.mainBadgeStatus}"
                      ?outlined="${i.mainBadgeOutlined}"
                      ?hideIcon="${i.mainBadgeHideIcon}"
                      label="${i.mainBadgeLabel}"
                    ></${t}>
                  ` : null}

              ${i.widgetBadgeLabel ? s`
                    <${t}
                      size="md"
                      status="${i.widgetBadgeStatus}"
                      outlined
                      hideIcon
                      label="${i.widgetBadgeLabel}"
                    ></${t}>
                  ` : null}

              ${i.results ? s`
                  <${t}
                    size="md"
                    status="${i.resultsStatus}"
                    outlined
                    hideIcon
                    label="${i.results} ${i.resultsLabel}"
                  ></${t}>
                ` : null}

              ${i.info ? s`
                  <${c}  
                    size="md" 
                    status="${i.infoBadgeStatus}" 
                    icon="${i.infoBadgeIcon}" 
                    ?outlined="${i.infoBadgeOutlined}"
                  >
                    <${r} slot="tooltip">
                      <span>${i.info}</span>
                    </${r} >
                  </${c} >
                ` : null}

              ${i.notifications ? s`
                  <${o}
                    status="${i.notificationsStatus}"
                    value="${i.notifications}"
                  >
                  </${o}>
                ` : null}

            </div>

            ${i.helpText || i.results || i.notifications || i.info || i.widgetBadgeLabel || i.mainBadgeLabel ? s`
                <span class="dss-accordion-widget__divider"></span>
              ` : null}

           

            <div class="dss-accordion-header__config-actions">
              ${i.hasPrimaryAction ? s`
                  <${a}
                    size="md"
                    label="${i.primaryActionLabel}"
                    icon="${i.primaryActionIcon}"
                    variant="${i.primaryActionStatus}"
                    ?fill=${i.primaryActionFill}
                    ?disabled=${i.primaryActionDisabled}
                    ?hideTooltip="${i.hideTooltip}"
                    @onClick=${i._dispatchPrimaryAction}
                  ></${a}>
                ` : null}

              ${i.hasSecondaryAction ? s`
                  <${a}
                    size="md"
                    label="${i.secondaryActionLabel}"
                    icon="${i.secondaryActionIcon}"
                    variant="${i.secondaryActionStatus}"
                    ?fill=${i.secondaryActionFill}
                    ?disabled=${i.secondaryActionDisabled}
                    ?hideTooltip="${i.hideTooltip}"
                    @onClick=${i._dispatchSecondaryAction}
                  ></${a}>
                ` : null}

              ${i.widgetShowNext ? s`
                    <${a}
                      size="md"
                      variant="primary"
                      label="Següent"
                      icon="arrow_forward"
                      hideTooltip
                      @onClick="${i._dispatchWidgetNext}"
                    >
                    </${a}>
                  ` : null}
              ${i.widgetShowClose ? s`
                    <${a}
                      size="md"
                      variant="default"
                      icon="close"
                      label="Tancar"
                      hideTooltip
                      @onClick="${i._dispatchWidgetClose}"
                    >
                    </${a}>
                  ` : null}
              <${a}
                label="${i.isOpen ? `Obrir ${i.titleText} acordió` : `Tancar ${i.titleText} acordió`}"
                hideTooltip
                ariaExpanded="${i.isOpen}"
                size="md"
                icon="${i.isOpen ? "expand_less" : "expand_more"}"
                variant="primary"
                @onClick=${i._toggleAccordion}
              ></${a}>
            </div>
        </div>
      </div>

      <div class="dss-accordion-panel-wrapper">
        <div class="dss-accordion-panel">
          <slot></slot>
        </div>
      </div>
    </div>
  `;
};
export {
  B as template
};
//# sourceMappingURL=accordion.template.js.map
