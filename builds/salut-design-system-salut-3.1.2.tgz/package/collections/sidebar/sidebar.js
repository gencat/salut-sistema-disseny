import { LitElement as d, unsafeCSS as c } from "lit";
import { property as s, state as g } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanConverter as T } from "../../utils/property-types.js";
import f from "./sidebar.style.css.js";
import { template as u } from "./sidebar.template.js";
var m = Object.defineProperty, e = (n, o, t, p) => {
  for (var r = void 0, l = n.length - 1, a; l >= 0; l--)
    (a = n[l]) && (r = a(o, t, r) || r);
  return r && m(o, t, r), r;
};
class i extends d {
  constructor() {
    super(...arguments), this.titleText = void 0, this.expanded = !1, this.placement = "left", this.iconToggleRight = "keyboard_arrow_right", this.iconToggleLeft = "keyboard_arrow_left", this._iconToggleExpanded = this.iconToggleLeft, this._iconToggleCollapsed = this.iconToggleRight, this._isTruncated = !1;
  }
  static get styles() {
    return [c(h), c(f)];
  }
  _toggle() {
    this.expanded = !this.expanded, this.dispatchEvent(
      new CustomEvent("toggle", {
        detail: { expanded: this.expanded },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _checkTitleTruncated(o) {
    if (!o || this.prevTitleText === this.titleText) return;
    const t = o.currentTarget;
    if (!t) return;
    const p = t.scrollHeight > t.clientHeight || t.scrollWidth > t.clientWidth;
    this._isTruncated = p, this.prevTitleText = this.titleText;
  }
  updated(o) {
    o.has("placement") && queueMicrotask(() => {
      this.placement === "right" ? (this._iconToggleExpanded = this.iconToggleRight, this._iconToggleCollapsed = this.iconToggleLeft) : (this._iconToggleExpanded = this.iconToggleLeft, this._iconToggleCollapsed = this.iconToggleRight);
    });
  }
  render() {
    return u(this);
  }
}
e([
  s({ type: String })
], i.prototype, "titleText");
e([
  s({ converter: T, reflect: !0 })
], i.prototype, "expanded");
e([
  s({ type: String })
], i.prototype, "placement");
e([
  s({ type: String })
], i.prototype, "iconToggleRight");
e([
  s({ type: String })
], i.prototype, "iconToggleLeft");
e([
  g()
], i.prototype, "_iconToggleExpanded");
e([
  g()
], i.prototype, "_iconToggleCollapsed");
e([
  g()
], i.prototype, "_isTruncated");
export {
  i as Sidebar
};
//# sourceMappingURL=sidebar.js.map
