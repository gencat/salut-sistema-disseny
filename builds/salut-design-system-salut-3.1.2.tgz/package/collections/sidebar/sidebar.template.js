import { classMap as a } from "lit/directives/class-map.js";
import { unsafeStatic as d, literal as e, html as o } from "lit/static-html.js";
import { getCustomElementSuffix as i } from "../../api/custom-element-scope.js";
const t = e`dss-icon-button${d(i())}`, l = e`dss-typography${d(i())}`, r = e`dss-tooltip${d(i())}`, p = (s) => o`
	<div class=${a({
  "dss-sidebar": !0,
  "dss-sidebar--expanded": s.expanded,
  [`dss-sidebar--${s.placement}`]: !!s.placement
})}>
		<div class="dss-sidebar-header">
			<div class="dss-sidebar-header__toggle">
				<${t}
					icon=${s.expanded ? s._iconToggleExpanded : s._iconToggleCollapsed}
					size="lg"
					label="${s.expanded ? "col·lapsar sidebar" : "expandir sidebar"}"
					hideTooltip
					@click=${s._toggle}
				></${t}>
			</div>
			<div class="dss-sidebar-header__title" @mouseenter=${s._checkTitleTruncated}>
				<${l} variant="headline-4">
					${s.titleText}
					<${r} 
						class="${a({
  "dss-sidebar-tooltip": !0,
  "dss-sidebar-tooltip--visible": s._isTruncated
})}"
						aria-hidden="true"
					>
						${s.titleText}
					</${r}>
				</${l}>
				
			</div>
		</div>
		<div class="dss-sidebar-content">
			<slot></slot>
		</div>
	</div>
`;
export {
  p as template
};
//# sourceMappingURL=sidebar.template.js.map
