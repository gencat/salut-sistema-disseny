import { nothing as $ } from "lit";
import { classMap as g } from "lit/directives/class-map.js";
import { unsafeHTML as h } from "lit/directives/unsafe-html.js";
import { unsafeStatic as c, literal as T, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as f } from "../../api/custom-element-scope.js";
import { highlightText as u } from "../../api/marker/marker.js";
const o = T`dss-decorative-icon${c(f())}`, t = T`dss-tooltip${c(f())}`, x = (i) => {
  const e = {
    [`dss-tile--${i.type}`]: !!i.type,
    "dss-tile--highlighted": i.type === "informative" && i.highlighted,
    "dss-tile--selected": i.type === "selector" && i.selected,
    "dss-tile--disabled": i.disabled,
    "dss-tile--height-auto": i.heightAuto,
    "dss-tile--widget": i.widget
  }, d = () => s`
      <${o}
        icon="${i.icon}"
        state="default"
        size="lg"
        ?disabled=${i.disabled}
      ></${o}>
    `, a = () => s`
      <div class="dss-tile-logo">
        <img
          class="dss-tile-logo__image"
          src="${i.logoURL}"
          alt="Tile Logo"
        />
      </div>
    `, r = () => s`
      <div class="dss-tile-content">
        <div class="dss-tile-content__text">
          <h4 class="dss-tile-title">
            ${h(u(i.tileTitle, i.marker))}
            ${i.isTitleTruncated ? s`
              <${t} class="dss-tile-title-tooltip" aria-hidden="true">${i.tileTitle}</${t}>
              ` : $}
          </h4>
          <p class="dss-tile-description">
            ${h(u(i.description, i.marker))}
            ${i.isDescriptionTruncated ? s`
              <${t} class="dss-tile-description-tooltip" aria-hidden="true">${i.description}</${t}>
              ` : $}
          </p>
        </div>
        ${i.type === "action" ? s` <slot name="action"></slot> ` : null}
      </div>
    `;
  let l = s``;
  return i.type === "button" || i.type === "selector" ? l = s`
      <div
        class="dss-tile ${g(e)}"
        tabindex="${i.disabled ? -1 : 0}"
        role="button"
        @click=${i._onClick}
      >
        ${i.icon && !i.hasLogo ? d() : null}
        ${i.hasLogo ? a() : null}
        ${r()}
      </div>
    ` : l = s`
      <div class="dss-tile ${g(e)}">
        ${i.icon && !i.hasLogo ? d() : null}
        ${i.hasLogo ? a() : null}
        ${r()}
      </div>
    `, l;
};
export {
  x as template
};
//# sourceMappingURL=tile.template.js.map
