import { LitElement as u, unsafeCSS as d } from "lit";
import { property as s, state as h } from "lit/decorators.js";
import y from "../../api/marker/marker.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import { isSingleLineTruncated as f, isMultiLineTruncated as g } from "../../utils/text-truncated.js";
import m from "./tile.style.css.js";
import { template as T } from "./tile.template.js";
var b = Object.defineProperty, e = (l, t, r, p) => {
  for (var o = void 0, a = l.length - 1, c; a >= 0; a--)
    (c = l[a]) && (o = c(t, r, o) || o);
  return o && b(t, r, o), o;
};
class i extends u {
  constructor() {
    super(...arguments), this.type = "informative", this.icon = "", this.tileTitle = "", this.description = "", this.highlighted = !1, this.selected = !1, this.disabled = !1, this.hasLogo = !1, this.logoURL = "", this.heightAuto = !1, this.widget = !1, this.marker = void 0, this.isTitleTruncated = !0, this.isDescriptionTruncated = !0;
  }
  static get styles() {
    return [d(y), d(m)];
  }
  _setTruncatedAttribute(t, r) {
    if (!t) return;
    const p = r === "single" ? f(t) : g(t);
    t.setAttribute("data-truncated", String(p)), r === "single" ? this.isTitleTruncated = p : this.isDescriptionTruncated = p;
  }
  _syncOverflowState() {
    const t = this.shadowRoot?.querySelector(".dss-tile-title"), r = this.shadowRoot?.querySelector(".dss-tile-description");
    this._setTruncatedAttribute(t, "single"), this._setTruncatedAttribute(r, "multi");
  }
  async firstUpdated() {
    await this.updateComplete, this._syncOverflowState();
    const t = this.shadowRoot?.querySelector(".dss-tile-content__text");
    t && (this._resizeObserver = new ResizeObserver(() => this._syncOverflowState()), this._resizeObserver.observe(t));
  }
  updated(t) {
    this._syncOverflowState();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._resizeObserver?.disconnect();
  }
  _onClick() {
    this.type === "selector" && (this.selected = !this.selected, this.requestUpdate());
    const t = {
      detail: { title: this.tileTitle },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("onTileClick", t));
  }
  render() {
    return T(this);
  }
}
e([
  s({ type: String })
], i.prototype, "type");
e([
  s({ type: String })
], i.prototype, "icon");
e([
  s({ type: String })
], i.prototype, "tileTitle");
e([
  s({ type: String })
], i.prototype, "description");
e([
  s(n)
], i.prototype, "highlighted");
e([
  s(n)
], i.prototype, "selected");
e([
  s(n)
], i.prototype, "disabled");
e([
  s(n)
], i.prototype, "hasLogo");
e([
  s({ type: String })
], i.prototype, "logoURL");
e([
  s(n)
], i.prototype, "heightAuto");
e([
  s(n)
], i.prototype, "widget");
e([
  s({ type: String })
], i.prototype, "marker");
e([
  h()
], i.prototype, "isTitleTruncated");
e([
  h()
], i.prototype, "isDescriptionTruncated");
export {
  i as Tile
};
//# sourceMappingURL=tile.js.map
