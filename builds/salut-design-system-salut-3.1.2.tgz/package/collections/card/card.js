import { LitElement as n, unsafeCSS as f } from "lit";
import { property as s } from "lit/decorators.js";
import m from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import u from "./card.style.css.js";
import { template as b } from "./card.template.js";
var c = Object.defineProperty, o = (i, t, d, h) => {
  for (var e = void 0, l = i.length - 1, p; l >= 0; l--)
    (p = i[l]) && (e = p(t, d, e) || e);
  return e && c(t, d, e), e;
};
class a extends n {
  constructor() {
    super(...arguments), this.selected = !1, this.dragged = !1, this.deleted = !1, this.disabled = !1, this.hasClose = !1, this.hasDetails = !1;
  }
  static get styles() {
    return [f(m), f(u)];
  }
  /* METHODS */
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((d) => {
      d.assignedElements().forEach((e) => {
        this.deleted ? e.setAttribute("deleted", "true") : e.removeAttribute("deleted"), this.disabled ? e.setAttribute("disabled", "true") : e.removeAttribute("disabled");
      });
    });
  }
  /* EVENTS */
  _dispatchClose() {
    this.dispatchEvent(new CustomEvent("close", { bubbles: !0 }));
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), (t.has("deleted") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return b(this);
  }
}
o([
  s(r)
], a.prototype, "selected");
o([
  s(r)
], a.prototype, "dragged");
o([
  s(r)
], a.prototype, "deleted");
o([
  s(r)
], a.prototype, "disabled");
o([
  s(r)
], a.prototype, "hasClose");
o([
  s(r)
], a.prototype, "hasDetails");
export {
  a as Card
};
//# sourceMappingURL=card.js.map
