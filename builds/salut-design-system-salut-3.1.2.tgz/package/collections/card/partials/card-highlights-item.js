import { LitElement as n, unsafeCSS as p, css as m } from "lit";
import { property as i } from "lit/decorators.js";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as f, literal as x, html as a } from "lit/static-html.js";
import _ from "../../../shared/reset.style.css.js";
import { booleanType as g } from "../../../utils/property-types.js";
import { getCustomElementSuffix as v } from "../../../api/custom-element-scope.js";
var b = Object.defineProperty, s = (d, t, o, y) => {
  for (var e = void 0, l = d.length - 1, h; l >= 0; l--)
    (h = d[l]) && (e = h(t, o, e) || e);
  return e && b(t, o, e), e;
};
const c = x`dss-icon${f(v())}`;
class r extends n {
  constructor() {
    super(...arguments), this.deleted = !1, this.disabled = !1, this.icon = "", this.title = "Title", this.titleText = "Title", this.text = "Item";
  }
  static get styles() {
    return [
      p(_),
      m`
        .dss-card-highligth {
					width: 100%;
          background-color: var(--color-blue-50);
          padding: var(--dss-spacing-xxs) var(--dss-spacing-xs);
          border-radius: var(--dss-radius-sm);
        }

        .dss-card-highligth__title {
          font-size: 14px;
          line-height: 24px;
          font-weight: var(--font-semibold);
          color: var(--color-blue-700);
        }

        .dss-card-highligth__item {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-xxs);
          font-size: 14px;
          line-height: 24px;
          color: var(--color-blue-700);
        }

        .dss-card-highligth.deleted {
          background-color: var(--color-red-50);
        }

        .dss-card-highligth.deleted .dss-card-highligth__title,
        .dss-card-highligth.deleted .dss-card-highligth__item {
          color: var(--color-red-700);
        }

        .dss-card-highligth.disabled {
          background-color: var(--color-neutral-50);
        }

        .dss-card-highligth.disabled .dss-card-highligth__title,
        .dss-card-highligth.disabled .dss-card-highligth__item {
          color: var(--color-neutral-700);
        }
      `
    ];
  }
  updated(t) {
    super.updated(t), t.has("title") && queueMicrotask(() => {
      this.title !== "Title" && (this.titleText = this.title);
    });
  }
  render() {
    const t = {
      deleted: this.deleted,
      disabled: this.disabled
    };
    return a`
      <div class="dss-card-highligth ${u(t)}">
        <h5 class="dss-card-highligth__title">${this.titleText}</h5>
        <p class="dss-card-highligth__item">
          ${this.icon ? a`
            <${c} size="sm" icon="${this.icon}"></${c}>
            ` : ""}
          ${this.text}
        </p>
      </div>
    `;
  }
}
s([
  i(g)
], r.prototype, "deleted");
s([
  i(g)
], r.prototype, "disabled");
s([
  i({ type: String })
], r.prototype, "icon");
s([
  i({ type: String })
], r.prototype, "title");
s([
  i({ type: String })
], r.prototype, "titleText");
s([
  i({ type: String })
], r.prototype, "text");
export {
  r as CardHighlightsItem
};
//# sourceMappingURL=card-highlights-item.js.map
