import { LitElement as l, css as a, html as n } from "lit";
import { property as p } from "lit/decorators.js";
import { booleanType as f } from "../../../utils/property-types.js";
var u = Object.defineProperty, m = (r, t, s, o) => {
  for (var e = void 0, i = r.length - 1, d; i >= 0; i--)
    (d = r[i]) && (e = d(t, s, e) || e);
  return e && u(t, s, e), e;
};
class h extends l {
  constructor() {
    super(...arguments), this.disabled = !1;
  }
  static get styles() {
    return [
      a`
        :host {
          display: flex;
          flex-direction: column;
					align-items: flex-start;
          gap: var(--dss-spacing-xxs);
					width: 100%;
        }

				::slotted(*) {
					width: 100%;
				}
      `
    ];
  }
  get _formContent() {
    const t = this.shadowRoot?.querySelector("slot") || void 0;
    return this.requestUpdate(), t?.assignedElements();
  }
  _propagateProperties() {
    if (this._formContent)
      for (const t of this._formContent)
        t.querySelectorAll("input").forEach((o) => {
          this.disabled ? o.setAttribute("disabled", "true") : o.removeAttribute("disabled");
        });
  }
  /* LIT LIFECYCLE */
  updated(t) {
    super.updated(t), t.has("disabled") && this._propagateProperties();
  }
  render() {
    return n` <slot></slot> `;
  }
}
m([
  p(f)
], h.prototype, "disabled");
export {
  h as CardForm
};
//# sourceMappingURL=card-form.js.map
