import { LitElement as p, unsafeCSS as m, css as f } from "lit";
import { property as l } from "lit/decorators.js";
import { unsafeStatic as u, literal as c, html as b } from "lit/static-html.js";
import { getCustomElementSuffix as v } from "../../../api/custom-element-scope.js";
import y from "../../../shared/reset.style.css.js";
import { booleanType as h } from "../../../utils/property-types.js";
var S = Object.defineProperty, a = (e, s, o, g) => {
  for (var t = void 0, r = e.length - 1, i; r >= 0; r--)
    (i = e[r]) && (t = i(s, o, t) || t);
  return t && S(s, o, t), t;
};
const n = c`dss-icon-button${u(v())}`;
class d extends p {
  constructor() {
    super(...arguments), this.position = "right", this.disabled = !1;
  }
  static get styles() {
    return [
      m(y),
      f`
        :host {
          display: block;
        }
      `
    ];
  }
  render() {
    return b`
      <div class="dss-card-menu">
				<${n}
					size="md"
					label="Menú"
					icon="more_vert"
					variant="primary"
					?disabled=${this.disabled}
					hideTooltip
				></${n}>
				<slot></slot>
      </div>
    `;
  }
}
a([
  l({ type: String })
], d.prototype, "position");
a([
  l(h)
], d.prototype, "disabled");
export {
  d as CardMenu
};
//# sourceMappingURL=card-menu.js.map
