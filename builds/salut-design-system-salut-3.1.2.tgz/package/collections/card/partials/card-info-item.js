import { LitElement as l, css as m } from "lit";
import { property as e } from "lit/decorators.js";
import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as h, literal as g, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as u } from "../../../api/custom-element-scope.js";
import { booleanType as y } from "../../../utils/property-types.js";
var v = Object.defineProperty, s = (r, i, c, x) => {
  for (var t = void 0, o = r.length - 1, p; o >= 0; o--)
    (p = r[o]) && (t = p(i, c, t) || t);
  return t && v(i, c, t), t;
};
const f = g`dss-icon${h(u())}`;
class n extends l {
  constructor() {
    super(...arguments), this.icon = "add_box", this.text = "Info", this.critic = !1;
  }
  static get styles() {
    return [
      m`
        :host {
          display: inline-block;
        }

        .info {
          display: flex;
          align-items: center;
          gap: var(--dss-spacing-tiny);
          font-size: 12px;
          line-height: 16px;
          font-weight: var(--font-regular);
        }

        .info--critic {
          color: var(--color-red-500);
        }
      `
    ];
  }
  /* LIT LIFECYCLE */
  render() {
    const i = {
      "info--critic": this.critic
    };
    return a`
      <div class="info ${d(i)}">
        ${this.icon ? a`
           <${f} size="sm" icon="${this.icon}"></${f}>
          ` : ""}
        <span>${this.text}</span>
      </div>
    `;
  }
}
s([
  e({ type: String })
], n.prototype, "icon");
s([
  e({ type: String })
], n.prototype, "text");
s([
  e(y)
], n.prototype, "critic");
export {
  n as CardInfoItem
};
//# sourceMappingURL=card-info-item.js.map
