import { LitElement as c, unsafeCSS as n } from "lit";
import { property as s, state as h } from "lit/decorators.js";
import u from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import f from "./table-cell.style.css.js";
import { template as y } from "./table-cell.template.js";
var g = Object.defineProperty, t = (l, i, o, v) => {
  for (var a = void 0, p = l.length - 1, d; p >= 0; p--)
    (d = l[p]) && (a = d(i, o, a) || a);
  return a && g(i, o, a), a;
};
class e extends c {
  constructor() {
    super(...arguments), this.size = "sm", this.fontWeight = "regular", this.align = "left", this.colSpan = 1, this.maxLines = 1, this.variant = "default", this.hover = !1, this.highlight = !1, this.sortable = !1, this.sortState = "none", this.currentSortedColumn = void 0, this.borderRight = !1, this.borderLeft = !1, this.borderTop = !1, this.reverse = !1, this.valueMaxWidth = !1, this.slotMaxWidth = !1, this.width = void 0, this.icon = void 0, this.iconTooltip = void 0, this.value = void 0, this.divider = "default", this.hideDivider = !1, this.nested = !1, this.hasIndicator = !1, this.srOnly = !1, this.isCurrentFocused = !1, this.isFirstUpdate = !0, this.fontWeightBackup = "regular", this.isValueTruncaded = !1, this.lastValue = void 0;
  }
  static get styles() {
    return [n(u), n(f)];
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "gridcell"), this.setAttribute("tabindex", "-1");
  }
  updated(i) {
    if (i.has("hover") && this.classList.toggle("hover", this.hover), i.has("highlight") && this.classList.toggle("highlight", this.highlight), i.has("borderRight") && this.classList.toggle("has-border-right", this.borderRight), i.has("borderLeft") && this.classList.toggle("has-border-left", this.borderLeft), i.has("borderTop") && this.variant === "header" && this.classList.toggle("has-border-top", this.borderTop), i.has("width") && this.width !== "") {
      if (!this.width) return;
      this.style.width = this.width, this.style.maxWidth = this.width;
    }
    i.has("fontWeight") && this.isFirstUpdate && (this.fontWeightBackup = this.fontWeight, this.isFirstUpdate = !1), i.has("variant") && (this.variant === "header" ? (this.setAttribute("role", "columnheader"), this.classList.add("sticky"), this.classList.add("column-header")) : (this.setAttribute("role", "gridcell"), this.classList.remove("sticky"), this.classList.remove("column-header"))), this.colSpan && this.colSpan > 1 && (this.style.gridColumn = `span ${this.colSpan}`);
  }
  willUpdate(i) {
    this.isFirstUpdate && (this.fontWeightBackup = this.fontWeight, this.isFirstUpdate = !1), i.has("variant") && (this.fontWeight = this.variant === "header" ? "semibold" : this.fontWeightBackup);
  }
  _checkValueTruncated(i) {
    if (this.value === this.lastValue) return;
    this.lastValue = this.value;
    const o = i.currentTarget;
    if (this.maxLines > 1) {
      this.isValueTruncaded = o.scrollHeight > o.clientHeight;
      return;
    }
    this.isValueTruncaded = o.scrollWidth > o.offsetWidth;
  }
  _getSortIcon() {
    let i = "swap_vert";
    switch (this.sortState) {
      case "asc":
        i = "arrow_upward";
        break;
      case "desc":
        i = "arrow_downward";
        break;
      default:
        i = "swap_vert";
        break;
    }
    return i;
  }
  _nextSortState() {
    let i = "none";
    switch (this.sortState) {
      case "none":
        i = "asc";
        break;
      case "asc":
        i = "desc";
        break;
      case "desc":
        i = "none";
        break;
    }
    this.sortState = i, this._dispatchSort();
  }
  _dispatchSort() {
    const i = new CustomEvent("sort", {
      detail: {
        id: this.id,
        value: this.value,
        sortState: this.sortState
      },
      bubbles: !0,
      composed: !0
    });
    this.dispatchEvent(i);
  }
  async firstUpdated() {
    await this.updateComplete;
  }
  render() {
    return y(this);
  }
}
t([
  s()
], e.prototype, "size");
t([
  s({ type: String })
], e.prototype, "fontWeight");
t([
  s()
], e.prototype, "align");
t([
  s({ type: Number })
], e.prototype, "colSpan");
t([
  s({ type: Number })
], e.prototype, "maxLines");
t([
  s()
], e.prototype, "variant");
t([
  s(r)
], e.prototype, "hover");
t([
  s(r)
], e.prototype, "highlight");
t([
  s(r)
], e.prototype, "sortable");
t([
  s()
], e.prototype, "sortState");
t([
  s({ type: String })
], e.prototype, "currentSortedColumn");
t([
  s(r)
], e.prototype, "borderRight");
t([
  s(r)
], e.prototype, "borderLeft");
t([
  s(r)
], e.prototype, "borderTop");
t([
  s(r)
], e.prototype, "reverse");
t([
  s(r)
], e.prototype, "valueMaxWidth");
t([
  s(r)
], e.prototype, "slotMaxWidth");
t([
  s({ type: String })
], e.prototype, "width");
t([
  s({ type: String })
], e.prototype, "icon");
t([
  s({ type: String })
], e.prototype, "iconTooltip");
t([
  s({ type: String })
], e.prototype, "value");
t([
  s()
], e.prototype, "divider");
t([
  s(r)
], e.prototype, "hideDivider");
t([
  s(r)
], e.prototype, "nested");
t([
  s(r)
], e.prototype, "hasIndicator");
t([
  s(r)
], e.prototype, "srOnly");
t([
  s(r)
], e.prototype, "isCurrentFocused");
t([
  h()
], e.prototype, "isFirstUpdate");
t([
  h()
], e.prototype, "fontWeightBackup");
t([
  h()
], e.prototype, "isValueTruncaded");
t([
  h()
], e.prototype, "lastValue");
export {
  e as TableCell
};
//# sourceMappingURL=table-cell.js.map
