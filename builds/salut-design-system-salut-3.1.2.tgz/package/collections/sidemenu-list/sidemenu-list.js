import { LitElement as m, unsafeCSS as d } from "lit";
import { property as l } from "lit/decorators.js";
import { getCustomElementSuffix as p } from "../../api/custom-element-scope.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as u } from "../../utils/property-types.js";
import b from "./sidemenu-list.style.css.js";
import { sidemenuListTemplate as E } from "./sidemenu-list.template.js";
var g = Object.defineProperty, c = (a, t, n, i) => {
  for (var e = void 0, o = a.length - 1, s; o >= 0; o--)
    (s = a[o]) && (e = s(t, n, e) || e);
  return e && g(t, n, e), e;
};
class f extends m {
  constructor() {
    super(...arguments), this.expanded = !1, this.disabled = !1;
  }
  static get styles() {
    return [d(h), d(b)];
  }
  // @property({ type: String }) scrollContainerClass = 'dss-layout-sidebar';
  _propagateProperties() {
    const t = this.shadowRoot?.querySelectorAll("slot");
    t && t.forEach((n) => {
      n.assignedElements().forEach((e) => {
        this.expanded ? e.setAttribute("expanded", "true") : e.removeAttribute("expanded");
      });
    });
  }
  _handleItemFocus(t) {
    const n = t.target, i = this.shadowRoot?.querySelector("slot");
    if (i) {
      const e = i.assignedElements({ flatten: !0 }).filter((s) => !s._disabled), o = e.findIndex((s) => s._focusEnabled);
      e[o] !== n && (n.setAttribute("focusEnabled", "true"), e[o].removeAttribute("focusEnabled"));
    }
  }
  _handleNavigate(t) {
    const n = this.shadowRoot?.querySelector("slot");
    if (n) {
      const e = n.assignedElements({ flatten: !0 }).filter((r) => !r._disabled).filter((r) => !r.classList.contains("hidden")), o = e.findIndex((r) => r._focusEnabled);
      let s = o;
      t.detail.direction === "next" ? s = (o + 1) % e.length : t.detail.direction === "previous" && (s = (o - 1 + e.length) % e.length), o !== s && (this._checkActionMenuClose(e[o]), e[o].blurItem(), e[o].removeAttribute("focusEnabled"), e[s].focusItem(), e[s].setAttribute("focusEnabled", "true"), this.dispatchEvent(new CustomEvent("onSlotFocus", { bubbles: !0, composed: !0 })));
    }
  }
  _checkActionMenuClose(t) {
    const n = t.shadowRoot?.querySelector("slot");
    if (!n) return;
    const e = `dss-action-menu${p()}`, s = n.assignedElements({ flatten: !0 }).find((r) => r.tagName.toLowerCase() === e);
    s && s.classList.contains("visible") && s._closeMenu();
  }
  async firstUpdated() {
    await this.updateComplete;
    const t = this.shadowRoot?.querySelector("slot");
    if (t) {
      const i = t.assignedElements({ flatten: !0 }).find((e) => e.tagName.toLowerCase() === "dss-sidemenu-list-item");
      i && i.setAttribute("focusEnabled", "true"), this._propagateProperties();
    }
  }
  updated(t) {
    super.updated(t), (t.has("expanded") || t.has("disabled")) && this._propagateProperties();
  }
  render() {
    return E(this);
  }
}
c([
  l(u)
], f.prototype, "expanded");
c([
  l(u)
], f.prototype, "disabled");
export {
  f as SidemenuList
};
//# sourceMappingURL=sidemenu-list.js.map
