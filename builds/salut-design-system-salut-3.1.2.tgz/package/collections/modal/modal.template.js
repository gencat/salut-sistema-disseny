import { classMap as a } from "lit/directives/class-map.js";
import { ifDefined as f } from "lit/directives/if-defined.js";
import { unsafeStatic as e, literal as t, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const d = t`dss-icon${e(o())}`, i = t`dss-icon-button${e(o())}`, $ = (s) => {
  const r = {
    "dss-dialog--has-header-slot": !!s._headerSlot,
    "dss-dialog--footer-empty": !s._footerSlot,
    "dss-dialog--has-scroll": s.hasScroll,
    "dss-dialog--full-width": s.fullWidth,
    "dss-dialog--full-height": s.fullHeight,
    "dss-dialog--flex-body": s.flexBody,
    "dss-dialog--no-body-padding": s.removeBodyPadding,
    "dss-dialog--jcef": s.jcef
  }, u = {
    [`dss-dialog-header-status--${s.status}`]: !!s.status
  };
  return l`
    <div
      class="dss-dialog ${a(r)}"
      role="dialog"
      aria-labelledby="dss-dialog-title"
      aria-modal="true"
      style="${f(s.modalStyle)}"
    >
      <button 
        class="modal-focus-sentinel modal-focus-sentinel--start"
        type="button"
        aria-hidden="true"
        tabindex="0"
        @focus="${s._handleStartSentinelFocus}"
        @keydown="${s._handleStartSentinelKeydown}"
      >
      </button>
      <div class="dss-dialog-header">
        ${s.hideCloseIcon ? null : l`
              <${i} 
                class="dss-dialog-header-close" 
                icon="close"
                size="lg" 
                variant="default" 
                label="Tancar modal"
                hideTooltip
                @click="${s._close}">
              </${i}>
            `}
        
        <div id="dss-dialog-title" class="dss-dialog-header-title">
          ${s._isStatusValid() ? l`
                <${d} 
                  class="dss-dialog-header-state ${a(u)}"
                  size="xl" 
                  icon="${s._getStatusIcon()}" 
                  fill>
                </${d}>
              ` : null}
          ${s.modalTitle}
        </div>

        <div class="dss-dialog-header--extra">
          <slot name="header"></slot>
        </div>
      </div>

      <div 
        class="dss-dialog-body"   
        tabindex="${s.hasScroll ? "0" : "-1"}"
        role="region"
        aria-label="${s.modalTitle}"
      >
        <slot name="body"></slot>
      </div>

      <div class="dss-dialog-footer">
        <slot name="footer"></slot>
      </div>

      <button 
        class="modal-focus-sentinel modal-focus-sentinel--end"
        type="button"
        aria-hidden="true"
        tabindex="0"
        @focus="${s._handleEndSentinelFocus}"
      >
      </button>
    </div>
  `;
};
export {
  $ as modalTemplate
};
//# sourceMappingURL=modal.template.js.map
