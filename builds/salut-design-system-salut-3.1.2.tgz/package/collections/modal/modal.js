import { LitElement as u, unsafeCSS as c } from "lit";
import { property as o } from "lit/decorators.js";
import f from "../../shared/scrollbar.style.css.js";
import { booleanType as d } from "../../utils/property-types.js";
import p from "./modal.style.css.js";
import { modalTemplate as y } from "./modal.template.js";
var _ = Object.defineProperty, m = Object.getOwnPropertyDescriptor, i = (n, e, t, s) => {
  for (var a = s > 1 ? void 0 : s ? m(e, t) : e, r = n.length - 1, h; r >= 0; r--)
    (h = n[r]) && (a = (s ? h(e, t, a) : h(a)) || a);
  return s && a && _(e, t, a), a;
};
const g = 250;
class l extends u {
  constructor() {
    super(), this.open = !1, this.modalTitle = "", this.status = "", this.hideCloseIcon = !1, this.hasScroll = !1, this.modalStyle = void 0, this.fullHeight = !1, this.fullWidth = !1, this.flexBody = !1, this.removeBodyPadding = !1, this.jcef = !1, this._scrollHandler = null, this._scrollContainer = null, this._previouslyFocusedElement = null, this._closedViaKeyboard = !1, this._modalHeader = null, this._modalFooter = null, this._handleKeydown = this._handleKeydown.bind(this), this._handleOutsideClick = this._handleOutsideClick.bind(this), this._scrollHandler = this._handleScroll.bind(this), this._handleStartSentinelFocus = this._handleStartSentinelFocus.bind(this), this._handleStartSentinelKeydown = this._handleStartSentinelKeydown.bind(this), this._handleEndSentinelFocus = this._handleEndSentinelFocus.bind(this);
  }
  static get styles() {
    return [c(f), c(p)];
  }
  set state(e) {
    this.status = e;
  }
  get state() {
    return this.status;
  }
  get _headerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="header"]') || void 0)?.assignedElements()[0];
  }
  get _footerSlot() {
    return (this.shadowRoot?.querySelector('slot[name="footer"]') || void 0)?.assignedElements()[0];
  }
  connectedCallback() {
    super.connectedCallback(), document.addEventListener("mousedown", this._handleOutsideClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), document.removeEventListener("mousedown", this._handleOutsideClick), this._scrollContainer && this._scrollHandler && this._scrollContainer.removeEventListener("scroll", this._scrollHandler), this._scrollContainer = null;
  }
  updated(e) {
    e.has("open") && (this.open ? this._showDialog() : this._hideDialog());
  }
  _showDialog() {
    this._previouslyFocusedElement = document.activeElement || null, this._closedViaKeyboard = !1, this.classList.add("show"), this.classList.remove("hide"), setTimeout(() => {
      this.classList.add("show"), this.style.visibility = "visible";
    }, 0), setTimeout(() => {
      this.shadowRoot?.querySelector(".modal-focus-sentinel--start")?.focus();
    }, 100), document.addEventListener("keydown", this._handleKeydown), document.body.style.overflow = "hidden";
  }
  _hideDialog() {
    this.classList.add("hide"), this.classList.remove("show"), setTimeout(() => {
      if (this.classList.remove("hide"), this.style.visibility = "hidden", document.removeEventListener("keydown", this._handleKeydown), this._previouslyFocusedElement && typeof this._previouslyFocusedElement.focus == "function") {
        if (this._closedViaKeyboard)
          this._previouslyFocusedElement.focus();
        else {
          const e = { focusVisible: !1 };
          this._previouslyFocusedElement.focus(e);
        }
        this._previouslyFocusedElement = null;
      }
    }, g), document.body.style.overflow = "";
  }
  _close(e) {
    if (e) {
      if (e instanceof KeyboardEvent)
        this._closedViaKeyboard = !0;
      else if (e instanceof MouseEvent) {
        const s = e.detail === 0 && e.pointerType !== "mouse";
        this._closedViaKeyboard = s;
      }
    }
    this.open = !1, this._hideDialog(), this.requestUpdate();
    const t = new Event("close");
    this.dispatchEvent(t);
  }
  _isStatusValid() {
    return this.status === "danger" || this.status === "error" || this.status === "warning" || this.status === "alert";
  }
  _getStatusIcon() {
    let e = "";
    switch (this.status) {
      case "danger":
        e = "warning";
        break;
      case "error":
        e = "warning";
        break;
      case "warning":
        e = "error";
        break;
      case "alert":
        e = "error";
        break;
      default:
        e = "";
    }
    return e;
  }
  _handleStartSentinelFocus(e) {
    const t = e.relatedTarget, s = this.shadowRoot?.querySelector(".dss-dialog-header-close");
    s && (t === s || s.contains(t)) && s.focus();
  }
  _handleStartSentinelKeydown(e) {
    e.key === "Tab" && e.shiftKey && (e.preventDefault(), this.hideCloseIcon ? this.shadowRoot?.querySelector(".modal-focus-sentinel--end")?.focus() : this.shadowRoot?.querySelector(".dss-dialog-header-close")?.focus());
  }
  _handleEndSentinelFocus() {
    this.hideCloseIcon ? this.shadowRoot?.querySelector(".modal-focus-sentinel--start")?.focus() : this.shadowRoot?.querySelector(".dss-dialog-header-close")?.focus();
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._close(e);
  }
  _handleOutsideClick(e) {
    if (this.open) {
      const t = this.shadowRoot?.querySelector(".dss-dialog"), s = e.composedPath();
      t && s.includes(this) && !s.includes(t) && this._close(e);
    }
  }
  fixEmptyFooter() {
    this.shadowRoot?.querySelector(".dss-dialog")?.classList.contains("dss-dialog--footer-empty") && this.requestUpdate();
  }
  _handleScroll(e) {
    const t = e.target;
    t && (t.scrollTop > 0 ? this._modalHeader?.classList.add("dss-dialog-header--scrolled") : this._modalHeader?.classList.remove("dss-dialog-header--scrolled"), t.scrollHeight - t.scrollTop !== t.clientHeight ? this._modalFooter?.classList.add("dss-dialog-footer--scrolled") : this._modalFooter?.classList.remove("dss-dialog-footer--scrolled"));
  }
  async firstUpdated() {
    await this.updateComplete, this._footerSlot && this.fixEmptyFooter();
    const e = this.shadowRoot?.querySelector(".dss-dialog-body");
    if (this.hasScroll && e) {
      this._scrollContainer = e, this._scrollHandler && this._scrollContainer.addEventListener("scroll", this._scrollHandler), this._modalHeader = this.shadowRoot?.querySelector(".dss-dialog-header"), this._modalFooter = this.shadowRoot?.querySelector(".dss-dialog-footer");
      const t = this._modalHeader ? this._modalHeader.clientHeight : 0, s = this._modalFooter ? this._modalFooter.clientHeight : 0, r = (this.shadowRoot?.querySelector(".dss-dialog")?.clientHeight || 0) - t - s;
      e.scrollHeight > r && this._modalFooter.classList.add("dss-dialog-footer--scrolled");
    }
  }
  render() {
    return y(this);
  }
}
i([
  o(d)
], l.prototype, "open", 2);
i([
  o({ type: String })
], l.prototype, "modalTitle", 2);
i([
  o({ type: String })
], l.prototype, "status", 2);
i([
  o({ type: String })
], l.prototype, "state", 1);
i([
  o(d)
], l.prototype, "hideCloseIcon", 2);
i([
  o(d)
], l.prototype, "hasScroll", 2);
i([
  o({ type: String })
], l.prototype, "modalStyle", 2);
i([
  o(d)
], l.prototype, "fullHeight", 2);
i([
  o(d)
], l.prototype, "fullWidth", 2);
i([
  o(d)
], l.prototype, "flexBody", 2);
i([
  o(d)
], l.prototype, "removeBodyPadding", 2);
i([
  o(d)
], l.prototype, "jcef", 2);
export {
  l as Modal
};
//# sourceMappingURL=modal.js.map
