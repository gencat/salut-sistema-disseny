import { LitElement as h, unsafeCSS as d } from "lit";
import { property as t } from "lit/decorators.js";
import y from "../../shared/reset.style.css.js";
import { booleanType as n } from "../../utils/property-types.js";
import u from "./user-feedback.style.css.js";
import { userFeedbackTemplate as m } from "./user-feedback.template.js";
var f = Object.defineProperty, e = (p, s, a, g) => {
  for (var r = void 0, o = p.length - 1, l; o >= 0; o--)
    (l = p[o]) && (r = l(s, a, r) || r);
  return r && f(s, a, r), r;
};
class i extends h {
  constructor() {
    super(...arguments), this.variant = "default", this.size = "lg", this.imageSrc = "", this.imageAlt = "", this.title = "", this.titleText = "", this.description = "", this.hasDetails = !1, this.detailsLabel = "Veure detalls", this.hideFooter = !1, this.status = "error", this._detailsExpanded = !1;
  }
  static get styles() {
    return [d(y), d(u)];
  }
  _handleDetailsClick() {
    this._detailsExpanded = !this._detailsExpanded, this.requestUpdate();
  }
  updated(s) {
    super.updated(s), s.has("title") && queueMicrotask(() => {
      this.title !== "" && (this.titleText = this.title);
    });
  }
  render() {
    return m(this);
  }
}
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "size");
e([
  t({ type: String })
], i.prototype, "imageSrc");
e([
  t({ type: String })
], i.prototype, "imageAlt");
e([
  t({ type: String })
], i.prototype, "title");
e([
  t({ type: String })
], i.prototype, "titleText");
e([
  t({ type: String })
], i.prototype, "description");
e([
  t(n)
], i.prototype, "hasDetails");
e([
  t({ type: String })
], i.prototype, "detailsLabel");
e([
  t(n)
], i.prototype, "hideFooter");
e([
  t({ type: String })
], i.prototype, "status");
export {
  i as UserFeedback
};
//# sourceMappingURL=user-feedback.js.map
