import { nothing as t } from "lit";
import { classMap as o } from "lit/directives/class-map.js";
import { unsafeStatic as i, literal as r, html as e } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { checkTextTruncate as n } from "../../utils/helpers.js";
const u = r`dss-icon-button${i(l())}`, d = r`dss-button${i(l())}`, f = r`dss-link${i(l())}`, a = r`dss-tooltip${i(l())}`, c = (s) => e`
  <div
    class=${o({
  "dss-header-menu-professional": !0,
  "dss-header-menu-professional--jcef": s.jcef
})}
  >
    <div class="dss-header-menu-professional-avatar">
      <slot name="avatar"></slot>
    </div>

    <div class="dss-header-menu-professional-details">
      <div class="dss-header-menu-professional-details__name">
        ${s.name}
      </div>
      <div class="dss-header-menu-professional-details__info">
        ${s.center ? e`
              <span
                class="dss-header-menu-professional-details__info-label dss-header-menu-professional-details__info-label--center"
                >${s.center}</span
              >
            ` : null}
      </div>
    </div>

    <${u} 
      icon="${s._toggleIcon}"
      label="${s._toggleLabel}"
      variant="primary"
      @onClick="${s._toggleDropdown}"
      ?disabled=${s.disabled}
      ariaLabel="${s._toggleLabel} menú professional"
      ariaExpanded="${s._showDropdown ? "true" : "false"}"
      hideTooltip
      >
    </${u}>
   
    <div
      class=${o({
  "dss-header-menu-professional-dropdown": !0,
  "dss-header-menu-professional-dropdown--expanded": !!s._showDropdown,
  "dss-header-menu-professional-dropdown--hide-details": !!s.hideDropdownDetails
})}
    >
      <div class="dss-header-menu-professional-dropdown__info">
        <div class="dss-header-menu-professional-dropdown__details">
          <div class="dss-header-menu-professional-dropdown__details-title">
            ${s.infoLabel}
          </div>

          <div class="dss-header-menu-professional-dropdown__details-content">
            <div class="dss-header-menu-professional-dropdown__details-subtitle">
              ${s.name}
            </div>

            ${s.center ? e`
                  <div class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${n}>
                    ${s.center}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${s.center}
                    </${a}>
                  </div>
                ` : null}
            ${s.collegiate ? e`
                  <p class="dss-header-menu-professional-dropdown__details-description" @mouseenter=${n}>
                    ${s.collegiateLabel} ${s.collegiate}
                    <${a} 
                      class="description-tooltip header-menu-professional-tooltip" 
                      aria-hidden="true" 
                      interactive
                    >
                      ${s.collegiate}
                    </${a}>
                  </p>
                ` : null}
          </div>

          
        </div>

        ${s.hideViewDetails ? t : e`
            <${f}
              class="dss-header-menu-professional-dropdown__view-details-button"
              variant="default"
              size="md"
              label="${s.detailsLabel}"
              fullWidth
              href='${s.detailsHref}'
              target='${s.detailsTarget}'
            >
            </${f}>
					`}

      <div class=${o({
  "dss-header-menu-professional__divider": !0,
  "dss-header-menu-professional__divider--hide": s.hideViewDetails && s.hideDropdownPreferences
})}>
     </div>

        ${s.hideDropdownPreferences ? null : e`
              <div class="dss-header-menu-professional-dropdown__preferences">
                <div class="dss-header-menu-professional-dropdown__details-title">
                  ${s.preferencesLabel}
                </div>
                <div class="dss-header-menu-professional-dropdown__preferences__options">
                  <slot></slot>
                </div>
              </div>
            `}
      </div>

      <div class="dss-header-menu-professional-dropdown__actions">
        ${s.showSecondaryAction ? e`
          <${d}
            variant="secondary"
            label="${s.secondaryActionLabel}"
            variant="${s.secondaryActionVariant}"
            status="${s.secondaryActionStatus}"
            ?disabled=${s.secondaryActionDisabled}
            fullWidth
            @onClick="${s._handleSecondaryAction}"
          ></${d}>
          ` : t}
        
        <${d}
          label="${s.primaryActionLabel}"
          status="${s.primaryActionStatus}"
          variant="${s.primaryActionVariant}"
          ?disabled=${s.primaryActionDisabled}
          fullWidth
          @onClick="${s._handlePrimaryAction}"
        ></${d}>
      </div>

      
    </div>
    
  </div>
`;
export {
  c as headerMenuProfessionalTemplate
};
//# sourceMappingURL=header-menu-professional.template.js.map
