import { nothing as i } from "lit";
import { classMap as d } from "lit/directives/class-map.js";
import { unsafeStatic as u, literal as e, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const h = e`dss-icon${u(r())}`, l = e`dss-icon-button${u(r())}`, p = e`dss-tooltip${u(r())}`, w = (s) => {
  var $, t, b, v;
  return a`
  <div class="${d({
    "dss-input-wrapper": !0,
    "dss-input-wrapper--required": s.required,
    "dss-input-wrapper--disabled": s.disabled,
    [`dss-input-wrapper--${s.size}`]: !!s.size,
    "dss-input-wrapper--no-label": s.hideLabel
  })}">

    ${s.size === "sm" && !s.hideLabel ? a`
      <div class="dss-wrapper-label">
        <label class="dss-label" for="${s._getEffectiveId()}" @mousedown=${s._handleLabelClick}>${s.label}</label>
      </div>
      ` : i}

    <div class="${d({
    "dss-input-group": !0,
    [`dss-input-group--${s.size}`]: !!s.size,
    "dss-input-group--invalid": s.invalid,
    // 'dss-input-group--invalid': component.invalid || !component._inputValidity,
    "dss-input-group--required": s.required,
    "dss-input-group--disabled": s.disabled,
    "dss-input-group--focused": s.value || (($ = s._input) == null ? void 0 : $.value) || s.placeholder || s._isFocused,
    "dss-input-group--read-only": s.readonly,
    "dss-input-group--no-label": s.hideLabel,
    "dss-input-group--numeric": s.type === "number",
    "dss-input-group--read-only-empty": s.readonly && s.placeholder === "" && !s.value
    // component.readOnly && component.placeholder === '' && !component._input?.value,
  })}">

      ${s.icon ? a`
        <${h} icon="${s.icon}" class="dss-input-icon"></${h}>
        ` : i}

      <div class="dss-input-field">
      
        ${s.size !== "sm" && !s.hideLabel ? a`
          <label class="dss-label" for="${s._getEffectiveId()}" @mousedown=${s._handleLabelClick}>${s.label}</label>
          ` : i}

        ${s.inputPrefix ? a`
           <span class="dss-input-inputPrefix">${s.inputPrefix}</span>
          ` : i}

        <input
          class="dss-input"
          id=${s._getEffectiveId()}
          .type=${s.type}
          .name="${s.name ?? i}"
          .placeholder=${s.placeholder}
          .value=${s.value}
          ?disabled=${s.disabled}
          ?readonly=${s.readonly}
          ?required=${s.required}
          ?autofocus=${s.autofocus}
          spellcheck=${s.spellcheck ? "true" : "false"}
          autocorrect=${s.autocorrect ? "on" : "off"}
          autocomplete=${s.autocomplete}
          autocapitalize=${s.autocapitalize}
          min=${s.min ?? i}
          max=${s.max ?? i}
          step=${s.step ?? i}
          minlength=${s.minLength ?? i}
          maxlength=${s.maxLength ?? i}
          pattern=${s.pattern ?? i}
          inputmode=${s.inputmode ?? i}
          aria-label="${s.hideLabel ? s.label : i}"
          @input=${s._onInput}
          @focusin=${s._handleFocusin}
          @focusout=${s._handleFocusout}
        />

      </div>

      ${s.unit ? a`
         <div class="dss-input-unit">${s.unit}</div>
        ` : i}

      ${s.type === "number" ? a`
          <div class="dss-input-numeric-buttons">
            <${l}
              label="Augmentar"
              hideTooltip
              size="sm"
              icon="keyboard_arrow_up"
              variant="primary"
              ?disabled=${s.disabled || s.readonly}
              disableTabindex
              @onClick=${s._stepUp}
              @mousedown=${() => s._onHold("up")}
              @mouseup=${s._stopHold}
              @mouseleave=${s._stopHold}
            ></${l}>
            <${l}
              label="Disminuir"
              hideTooltip
              size="sm"
              icon="keyboard_arrow_down"
              variant="primary"
              ?disabled=${s.disabled || s.readonly}
              disableTabindex
              @onClick=${s._stepDown}
              @mousedown=${() => s._onHold("down")}
              @mouseup=${s._stopHold}
              @mouseleave=${s._stopHold}
            ></${l}>
          </div>
        ` : i}

      ${s.hasActions ? a`
          <div class="dss-input-actions">
            <slot></slot>
          </div>
          ` : i}

      ${s._isTruncated ? a`
        <${p}>${(t = s._input) == null ? void 0 : t.value}</${p}>
        ` : i}

    </div>

    ${s.helpText ? a`
      <div class="${d({
    "dss-input-help": !0,
    "dss-input-help--invalid": s.invalid,
    "dss-input-help--disabled": s.disabled
  })}">
        <span>${s.helpText}</span>
        ${s.maxLength ? a`
          <span>
            ${((v = (b = s._input) == null ? void 0 : b.value) == null ? void 0 : v.length) ?? 0}/${s.maxLength}
          </span>` : i}
      </div>
      ` : i}
  </div>  
`;
};
export {
  w as template
};
//# sourceMappingURL=form-input.template.js.map
