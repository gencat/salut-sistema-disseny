import { unsafeStatic as l, literal as a, html as d } from "lit/static-html.js";
const r = (s) => {
  const e = a`${l(s.tag)}`;
  return d`
    <header class='dss-module-header'>
      <${e} class='dss-headline--sm'>${s.title}</${e}>
      <div class='dss-module-header__child-container'>
        <p class='dss-legend--sm'>${s.legend}</p>
        <slot></slot>
      </div>
    </header>
`;
};
export {
  r as template
};
//# sourceMappingURL=module-header.template.js.map
