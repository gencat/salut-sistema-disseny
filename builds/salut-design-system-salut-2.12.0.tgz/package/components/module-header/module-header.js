import { LitElement as y, unsafeCSS as o } from "lit";
import { property as p } from "lit/decorators.js";
import a from "../../foundations/typography/typography.css.js";
import f from "../../shared/reset.style.css.js";
import g from "./module-header.style.css.js";
import { template as d } from "./module-header.template.js";
var u = Object.defineProperty, s = (e, n, l, h) => {
  for (var t = void 0, r = e.length - 1, m; r >= 0; r--)
    (m = e[r]) && (t = m(n, l, t) || t);
  return t && u(n, l, t), t;
};
class i extends y {
  constructor() {
    super(...arguments), this.title = "", this.legend = "", this.tag = "h2";
  }
  static get styles() {
    return [o(f), o(g), o(a)];
  }
  render() {
    return d(this);
  }
}
s([
  p({ type: String })
], i.prototype, "title");
s([
  p({ type: String })
], i.prototype, "legend");
s([
  p({ type: String })
], i.prototype, "tag");
export {
  i as ModuleHeader
};
//# sourceMappingURL=module-header.js.map
