import { classMap as u } from "lit/directives/class-map.js";
import { ifDefined as $ } from "lit/directives/if-defined.js";
import { unsafeStatic as t, literal as d, html as s } from "lit/static-html.js";
import { getCustomElementSuffix as o } from "../../api/custom-element-scope.js";
const l = d`dss-icon${t(o())}`, a = d`dss-tooltip${t(o())}`, f = (i) => s`
  <button
    type=${i.type}
    class=${u({
  "dss-button": !0,
  "dss-button--full-width": !!i.fullWidth,
  [`dss-button--${i.variant}`]: !!i.variant,
  [`dss-button--${i.size}`]: !!i.size,
  "dss-button--icon-left": !!i.icon && !i.onlyIcon && i.iconPosition === "left",
  "dss-button--icon-right": !!i.icon && !i.onlyIcon && i.iconPosition === "right",
  "dss-button--only-icon": !!i.onlyIcon,
  "dss-button--loading": !!i.loading
})}
    aria-label="${i.label}"
		aria-busy="${$(i.loading ? "true" : void 0)}"
    ?disabled=${i.disabled}
    ?hidden=${i.hidden}
    @click=${i._handleClick}
	  @mouseenter=${i.checkTextTruncate}
  >
    ${i.icon ? s`
          <${l}
						class="dss-icon"
            size=${i._getIconSize()}
            icon=${i.icon}
            ></${l}>
        ` : null}
    ${i.onlyIcon ? null : s`
					<span class="dss-button-text">
						${i.label}
					</span>
        `}

		${i.loading ? s`
          <${l}
						class="dss-button-loading-icon"
            size=${i._getIconSize()}
            icon=${i.loadingIcon}
						spin
						aria-hidden="true"
            ></${l}>
        ` : null}
		
		<${a} ?tooltipFixed="${i.tooltipFixed}" class="dss-button__tooltip" aria-hidden="true">
			${i.label}
		</${a}>
  </button>
`;
export {
  f as template
};
//# sourceMappingURL=button.template.js.map
