import { createPopper as H } from "@popperjs/core";
import { LitElement as q, unsafeCSS as O } from "lit";
import { classMap as F } from "lit/directives/class-map.js";
import { unsafeStatic as $, literal as R, html as D } from "lit/static-html.js";
import { query as I, property as a, state as M } from "lit/decorators.js";
import { getCustomElementSuffix as A } from "../../api/custom-element-scope.js";
import V from "../../shared/reset.style.css.js";
import { booleanType as k, booleanConverter as g } from "../../utils/property-types.js";
import U from "../form-input/form-input.style.css.js";
import P from "./form-timepicker.style.css.js";
import { template as j } from "./form-timepicker.template.js";
var z = Object.defineProperty, o = (C, t, e, n) => {
  for (var i = void 0, r = C.length - 1, c; r >= 0; r--)
    (c = C[r]) && (i = c(t, e, i) || i);
  return i && z(t, e, i), i;
};
const E = R`dss-icon${$(A())}`, L = class L extends q {
  constructor() {
    super(), this.label = "", this.hideLabel = !1, this.name = "", this.id = "", this.type = "text", this.placeholder = "", this.value = "", this.disabled = !1, this.readonly = !1, this.required = !1, this.invalid = !1, this.maxLength = 5, this.autocapitalize = "none", this.autocomplete = "off", this.autocorrect = !1, this.autofocus = !1, this.spellcheck = !1, this.size = "lg", this.icon = "schedule", this.showDropdown = !1, this.dropdown = "", this.dropdownPlacement = "bottom-start", this.dropdownFixed = !1, this.customTimeListOptions = [], this.errorTimeFormatText = "Format d'hora no vàlid", this.errorTimeOptionText = "Opció de temps no disponible", this.minHour = 0, this.maxHour = 24, this.minutesRange = 1, this._defaultId = `dss-timepicker-${crypto.randomUUID()}`, this._isFocused = !1, this._isTruncated = !1, this._timePattern = /^\d{0,4}$/g, this._timeSeparator = ":", this._timeInputOldValue = "", this._placeholder = "", this._helpText = "", this._oldHelpText = "", this._manualHourSelector = "", this._manualMinuteSelector = "", this._timeListOptions = [], this._customTimeListOptions = [], this._timeManualHourOptions = [], this._timeManualMinutesOptions = [], this._inputValidity = !0, this._isFirstUpdated = !0, this._popperInstanceList = null, this._popperInstanceManual = null, this._labelClicked = !1, this.internals = this.attachInternals(), this._handleClickOut = this._handleClickOut.bind(this), this._handleFocusOut = this._handleFocusOut.bind(this);
  }
  static get styles() {
    return [O(V), O(U), O(P)];
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._removeDropdownListener();
  }
  _addDropdownListener() {
    document.addEventListener("mousedown", this._handleClickOut), this.addEventListener("focusout", this._handleFocusOut);
  }
  _removeDropdownListener() {
    document.removeEventListener("mousedown", this._handleClickOut), this.removeEventListener("focusout", this._handleFocusOut);
  }
  _handleClickOut(t) {
    this._checkClickOutside(t);
  }
  _handleFocusOut(t) {
    this._checkFocusOut(t);
  }
  _checkClickOutside(t) {
    t.composedPath().includes(this) || this.showDropdown && this._closeDropdown();
  }
  _checkFocusOut(t) {
    const e = t.relatedTarget;
    e !== null && e !== this && e !== this._input && e !== this._label && (this.showDropdown && this._closeDropdown(), this.requestUpdate());
  }
  _getEffectiveId() {
    return this.id !== "" ? this.id : this._defaultId;
  }
  async firstUpdated() {
    try {
      await this.updateComplete, this._createPopperList(), this._createPopperManual(), this._input && this._input.classList.add("dss-input-skip-native"), this._updateTimeOptions(), this._isFirstUpdated = !1, this.requestUpdate();
    } catch {
      console.error("ERROR OCURRED");
    }
  }
  updated(t) {
    t.has("value") && this.internals.setFormValue(this.value), t.has("placeholder") && (this._placeholder = this.placeholder), t.has("helpText") && (this._helpText = this.helpText ?? "", this._oldHelpText = this.helpText ?? ""), !this._isFirstUpdated && (t.has("minHour") || t.has("maxHour")) && this._updateTimeOptions();
  }
  formDisabledCallback(t) {
    this.disabled = t;
  }
  formResetCallback() {
    this.value = "", this._input.value = "";
  }
  formStateRestoreCallback(t) {
    this.value = t ?? "", this._input.value = t ?? "";
  }
  render() {
    return j(this);
  }
  /* Handle Input Events */
  _handleClick() {
    if (this.showDropdown = !0, this._addDropdownListener(), this._popperInstanceList && this._popperInstanceList.update(), this._popperInstanceManual && this._popperInstanceManual.update(), this.value && (this.dropdown && this.dropdown === "list" && this._timeListOptionsScrollTo(), this.dropdown && this.dropdown === "manual")) {
      const t = this.value.slice(0, 2);
      this._timeManualOptionsScrollTo(t), setTimeout(() => {
        this._timeManualOptionsScrollTo();
      }, 500);
    }
    this.requestUpdate();
  }
  _handleKeyDown(t) {
    this._input && (this._timeInputOldValue = this._input.value, (t == null ? void 0 : t.key) === "Enter" || (t == null ? void 0 : t.key) === " " ? (this.showDropdown = !0, this._addDropdownListener(), this._popperInstanceList && this._popperInstanceList.update(), this._popperInstanceManual && this._popperInstanceManual.update(), this.requestUpdate()) : (t == null ? void 0 : t.key) === "Escape" && this._closeDropdown());
  }
  _handleInput() {
    if (!this._input) return;
    let t = this._input.value;
    t = this._timeUnmask(t), t.match(this._timePattern) ? (t = this._timeMask(t, 2, this._timeSeparator), this._input.value = t) : this._input.value = this._timeInputOldValue, this._input.value.length === 5 && (this._timeValidate(this._input.value), this._handleValidity()), this.dropdown && this.dropdown === "list" && this._timeListOptionsScrollTo(), this.dropdown && this.dropdown === "manual" && this._timeManualOptionsScrollTo(), this._onInput();
  }
  _onInput() {
    this.value = this._input.value, this.dispatchEvent(new Event("input", { bubbles: !1, composed: !0 })), this._emitChange();
  }
  _handleValidity() {
    var n;
    let t = {}, e = "";
    this.invalid ? (t = { customError: !0, valid: !1 }, e = this._helpText) : (this.invalid = !((n = this._input) != null && n.checkValidity()), t = this._input.validity, e = this._input.validationMessage), this.internals.setValidity(t, e, this._input);
  }
  _handleFocusin() {
    this._input && (this._isFocused = !0, this._placeholder = "00:00", this._input.setAttribute("placeholder", this._placeholder), this.requestUpdate());
  }
  _handleLabelClick(t) {
    t.preventDefault(), this._input.focus(), this._labelClicked = !0, setTimeout(() => {
      this._labelClicked = !1;
    }, 50);
  }
  _handleFocusout() {
    console.log("is label clicked: ", this._labelClicked), !(!this._input || this._labelClicked) && (this._isFocused = !1, this._placeholder = "", this._input.removeAttribute("placeholder"), this._checkInputOverflow(), this.requestUpdate());
  }
  _focusInput() {
    var t;
    this.disabled || ((t = this._input) == null || t.focus(), this._handleClick());
  }
  _checkInputOverflow() {
    if (!this._input) return;
    const t = window.getComputedStyle(this._input), e = `${t.fontWeight} ${t.fontSize} ${t.fontFamily}`, i = document.createElement("canvas").getContext("2d");
    if (!i) return;
    i.font = e;
    const r = i.measureText(this._input.value).width;
    this._isTruncated = r > this._input.offsetWidth;
  }
  _emitInput() {
    this.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
  }
  _emitChange() {
    this.dispatchEvent(new Event("change", { bubbles: !0, composed: !0 }));
  }
  _dispatchValueChange() {
    if (!this._input) return;
    const t = {
      detail: {
        value: this._input.value,
        invalid: this.invalid,
        status: this.invalid ? "INVALID" : "VALID"
      },
      bubbles: !0,
      composed: !0
    };
    this.dispatchEvent(new CustomEvent("value-changed", t)), this.value !== this._input.value && (this.value = this._input.value), this._emitChange();
  }
  /* Handle Popper */
  _createPopperList() {
    var n, i;
    const t = (n = this.shadowRoot) == null ? void 0 : n.querySelector(".dss-input-group"), e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-timepicker-dropdown--list");
    t && e && (this._popperInstanceList = H(t, e, {
      placement: this.dropdownPlacement,
      strategy: this.dropdownFixed ? "fixed" : "absolute",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "flip",
          enabled: !0,
          options: {
            boundary: "viewport",
            rootBoundary: "viewport"
          }
        },
        {
          name: "preventOverflow",
          enabled: !0,
          options: {
            boundary: "viewport",
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        },
        {
          name: "matchWidth",
          enabled: !0,
          phase: "write",
          fn({ state: r }) {
            r.elements.popper.style.width = `${t.offsetWidth}px`;
          },
          effect: ({ state: r }) => {
            r.elements.popper.style.width = `${t.offsetWidth}px`;
          }
        }
      ]
    }));
  }
  _createPopperManual() {
    var n, i;
    const t = (n = this.shadowRoot) == null ? void 0 : n.querySelector(".dss-input-group"), e = (i = this.shadowRoot) == null ? void 0 : i.querySelector(".dss-timepicker-dropdown--manual");
    t && e && (this._popperInstanceManual = H(t, e, {
      placement: "bottom",
      modifiers: [
        {
          name: "offset",
          options: {
            offset: [0, 4]
          }
        },
        {
          name: "flip",
          enabled: !0,
          options: {
            boundary: "viewport",
            rootBoundary: "viewport"
          }
        },
        {
          name: "preventOverflow",
          enabled: !0,
          options: {
            boundary: "viewport",
            padding: { top: 8, bottom: 8, left: 16, right: 16 }
          }
        }
      ]
    }));
  }
  _closeDropdown() {
    var t;
    this._removeDropdownListener(), this.showDropdown = !1, (t = this._input) == null || t.blur(), this.requestUpdate();
  }
  /* Hamdle Timepicker Validations */
  _timeMask(t, e, n) {
    const i = [];
    for (let r = 0; r < t.length; r += 1)
      r !== 0 && r % e === 0 && i.push(n), i.push(t[r]);
    return i.join("");
  }
  _timeUnmask(t) {
    return t.replace(/[^\d]/g, "");
  }
  _timeValidate(t) {
    const e = t.slice(0, 2), n = t.slice(3, 5);
    this._input && +e >= 0 && +e <= 23 && +n >= 0 && +n <= 59 ? (this.invalid = !1, this._helpText = this._oldHelpText, this.dropdown && this.dropdown === "list" && !this._timeListOptions.includes(this._input.value) ? (this._helpText = this.errorTimeOptionText, this.invalid = !0) : this.dropdown && this.dropdown === "manual" && (!this._timeManualHourOptions.includes(e) || !this._timeManualMinutesOptions.includes(n)) ? (this._helpText = this.errorTimeOptionText, this.invalid = !0) : this._closeDropdown()) : (this._helpText = this.errorTimeFormatText, this.invalid = !0), this._dispatchValueChange(), this.requestUpdate();
  }
  // Timepicker specific methods
  _updateTimeOptions() {
    this.dropdown && (this._timeListOptions = this._generateTimeListOptions(), this._timeManualHourOptions = this._generateTimeManualHoursOptions(), this._timeManualMinutesOptions = this._generateTimeManualMinutesOptions());
  }
  _generateTimeListOptions() {
    const t = [], e = +this.minHour, n = +this.maxHour, i = +this.minutesRange;
    for (let r = e; r < n; r += 1)
      for (let c = 0; c < 60; c += i) {
        const l = r.toString().padStart(2, "0"), _ = c.toString().padStart(2, "0");
        t.push(`${l}:${_}`);
      }
    return t;
  }
  _generateTimeListOptionsHTML(t, e) {
    let n = !0;
    const i = e && e.length > 0;
    return (i ? e : t).map((l) => {
      const _ = (d) => {
        d && d.focus();
      }, f = (d) => {
        let p = 0;
        const h = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), u = h.length - 1;
        d === h[0] ? _(h[u]) : (h.forEach((m, y) => {
          m === d && (p = y);
        }), _(h[p - 1]));
      }, v = (d) => {
        let p = 0;
        const h = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__label"), u = h.length - 1;
        d === h[u] ? _(h[0]) : (h.forEach((m, y) => {
          m === d && (p = y);
        }), _(h[p + 1]));
      }, S = (d) => {
        if (this._input) {
          const p = d.target.getAttribute("value");
          p && (this._input.value = p, this._helpText = this._oldHelpText, this.invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
        }
      }, w = (d) => {
        const p = d.currentTarget, h = d;
        let u = !1;
        switch (h.key) {
          case "ArrowUp":
            f(p), u = !0;
            break;
          case "ArrowDown":
            v(p), u = !0;
            break;
          case "Enter": {
            const m = d.target.querySelector("input"), y = this.renderRoot.querySelector('.dss-timepicker-dropdown__label[tabindex="0"]');
            y == null || y.setAttribute("tabindex", "-1"), d.target.setAttribute("tabindex", "0"), m == null || m.click(), u = !0;
            break;
          }
        }
        u && (d.stopPropagation(), d.preventDefault());
      }, b = {
        "option--busy": typeof l == "object" && l.state === "ocupat",
        "option--selected": typeof l == "object" && l.state === "ocupat"
      }, T = D`
				<div class="dss-timepicker-dropdown__option ${F(b)}">
					<label
						class="dss-timepicker-dropdown__label"
						tabindex="${n ? 0 : -1}"
						@keydown=${w}
					>
						${i && typeof l == "object" ? l.value : l}

						<input
							class="dss-timepicker-dropdown__input-radio"
							name="timeList"
							type="radio"
							@click="${S}"
							.value="${i && typeof l == "object" ? l.value : l}"
						/>
						<${E} class="dss-timepicker-dropdown__icon" size="md" icon="check"></${E}>
					</label>
				</div>
			`;
      return n = !1, T;
    });
  }
  _generateTimeManualHoursOptions() {
    const t = [], e = +this.minHour, n = +this.maxHour;
    for (let i = e; i < n; i += 1) {
      const r = i.toString().padStart(2, "0");
      t.push(r);
    }
    return t;
  }
  _generateTimeManualMinutesOptions() {
    const t = [], e = +this.minutesRange;
    for (let n = 0; n < 60; n += e) {
      const i = n.toString().padStart(2, "0");
      t.push(i);
    }
    return t;
  }
  _generateTimeManualOptionsHTML(t, e) {
    let n = !0;
    return e.map((r) => {
      const c = (f) => {
        const v = f.target.getAttribute("value");
        v && (t === "timepickerManualHour" ? this._manualHourSelector = v : t === "timepickerManualMinutes" && (this._manualMinuteSelector = v), this.requestUpdate());
      }, l = (f) => {
        const v = f.currentTarget, S = f;
        let w = !1;
        const b = (p) => {
          p && p.focus();
        }, T = (p) => {
          let h = 0;
          const u = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), m = u.length - 1;
          p === u[0] ? b(u[m]) : (u.forEach((y, x) => {
            y === p && (h = x);
          }), b(u[h - 1]));
        }, d = (p) => {
          let h = 0;
          const u = this.renderRoot.querySelectorAll(`.dss-timepicker-manual-item__label.${t}`), m = u.length - 1;
          p === u[m] ? b(u[0]) : (u.forEach((y, x) => {
            y === p && (h = x);
          }), b(u[h + 1]));
        };
        switch (S.key) {
          case "ArrowUp":
            T(v), w = !0;
            break;
          case "ArrowDown":
            d(v), w = !0;
            break;
          case "Enter": {
            const p = f.target.parentElement, h = p == null ? void 0 : p.querySelector("input"), u = this.renderRoot.querySelector(
              `.dss-timepicker-manual-item__label[tabindex="0"].${t}`
            );
            if (u == null || u.setAttribute("tabindex", "-1"), f.target.setAttribute("tabindex", "0"), h == null || h.click(), t === "timepickerManualHour") {
              const m = this.renderRoot.querySelector(
                '.dss-timepicker-manual-item__label[tabindex="0"].timepickerManualMinutes'
              );
              b(m);
            } else if (t === "timepickerManualMinutes") {
              const m = this.renderRoot.querySelector(".dss-timepicker-dropdown__actions-select");
              setTimeout(() => {
                m.focus();
              }, 0);
            }
            w = !0;
            break;
          }
        }
        w && (f.stopPropagation(), f.preventDefault());
      }, _ = D`
				<div class="dss-timepicker-manual-item">
					<input
						id="${t + r}"
						class="dss-timepicker-manual-item__input-radio"
						name="${t}"
						type="radio"
						@click="${c}"
						.value="${r}"
					/>
					<label
						for="${t + r}"
						class="dss-timepicker-manual-item__label ${t}"
						tabindex="${n ? 0 : -1}"
						@keydown=${l}
					>
						${r}
					</label>
				</div>
			`;
      return n = !1, _;
    });
  }
  _checkDisableTimeManualSelector() {
    return this._manualHourSelector === "" || this._manualMinuteSelector === "";
  }
  _timeManualSelectorCancel() {
    const t = this.renderRoot.querySelectorAll(".dss-timepicker-manual-item__input-radio:checked");
    t.length && t.forEach((e) => {
      e.checked = !1;
    }), this._manualHourSelector = "", this._manualMinuteSelector = "", this._handleValidity(), this._closeDropdown();
  }
  _timeManualSelectorAccept() {
    this._input && (this._input.value = `${this._manualHourSelector}:${this._manualMinuteSelector}`, this._helpText = this._oldHelpText, this.invalid = !1, this._handleValidity(), this._closeDropdown(), this._dispatchValueChange());
  }
  _timeListOptionsScrollTo() {
    if (this._input) {
      const t = this._input.value.trim(), e = this.renderRoot.querySelectorAll(".dss-timepicker-dropdown__input-radio");
      let n = !1;
      e.forEach((i) => {
        const r = i.value;
        if (!n && r.startsWith(t)) {
          const c = i.closest("label");
          if (n = !0, c) {
            setTimeout(() => {
              c.scrollIntoView({
                behavior: "smooth",
                block: "center",
                inline: "nearest"
              });
            }, 0);
            const l = i.closest(".dss-timepicker-dropdown__option");
            r === t ? (i.checked = !0, l == null || l.classList.add("dss-timepicker-dropdown__option--selected")) : l == null || l.classList.remove("dss-timepicker-dropdown__option--selected");
          }
        }
      });
    }
  }
  _timeManualOptionsScrollTo(t) {
    if (!this._input) return;
    const e = t ? t.trim() : this._input.value.trim();
    if (e.length <= 2) {
      const n = this.renderRoot.querySelectorAll(
        ".dss-timepicker-dropdown__items--hour .dss-timepicker-manual-item__label"
      );
      let i = !1;
      n.forEach((r) => {
        const c = r.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
        if (!i && c.startsWith(e)) {
          i = !0;
          const l = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--hour");
          if (l) {
            const _ = r.offsetTop - l.clientHeight / 2;
            setTimeout(() => {
              l.scrollTo({
                top: _,
                behavior: "smooth"
              });
            }, 0);
          }
          c === e && r.click();
        }
      });
    } else {
      const n = e.slice(3), i = this.renderRoot.querySelectorAll(
        ".dss-timepicker-dropdown__items--minute .dss-timepicker-manual-item__label"
      );
      let r = !1;
      i.forEach((c) => {
        const l = c.innerHTML.replace(/<!--[\s\S]*?-->/g, "").trim();
        if (!r && l.startsWith(n)) {
          r = !0;
          const _ = this.renderRoot.querySelector(".dss-timepicker-dropdown__items--minute");
          if (_) {
            const f = c.offsetTop - _.clientHeight / 2;
            setTimeout(() => {
              _.scrollTo({
                top: f,
                behavior: "smooth"
              });
            }, 0);
          }
          l === n && c.click();
        }
      });
    }
  }
};
L.formAssociated = !0;
let s = L;
o([
  I("input.dss-input")
], s.prototype, "_input");
o([
  I("label.dss-label")
], s.prototype, "_label");
o([
  a({ type: String })
], s.prototype, "label");
o([
  a(k)
], s.prototype, "hideLabel");
o([
  a({ type: String })
], s.prototype, "name");
o([
  a({ type: String })
], s.prototype, "id");
o([
  a({ type: String })
], s.prototype, "type");
o([
  a({ type: String })
], s.prototype, "placeholder");
o([
  a({ type: String })
], s.prototype, "value");
o([
  a({ converter: g, reflect: !0 })
], s.prototype, "disabled");
o([
  a({ converter: g, reflect: !0 })
], s.prototype, "readonly");
o([
  a({ converter: g, reflect: !0 })
], s.prototype, "required");
o([
  a({ converter: g, reflect: !0 })
], s.prototype, "invalid");
o([
  a({ type: Number })
], s.prototype, "step");
o([
  a({ type: Number })
], s.prototype, "min");
o([
  a({ type: Number })
], s.prototype, "max");
o([
  a({ type: Number })
], s.prototype, "minLength");
o([
  a({ type: Number })
], s.prototype, "maxLength");
o([
  a({ type: String })
], s.prototype, "pattern");
o([
  a({ type: String })
], s.prototype, "inputmode");
o([
  a({ type: String })
], s.prototype, "autocapitalize");
o([
  a({ type: String })
], s.prototype, "autocomplete");
o([
  a(k)
], s.prototype, "autocorrect");
o([
  a(k)
], s.prototype, "autofocus");
o([
  a(k)
], s.prototype, "spellcheck");
o([
  a({ type: String })
], s.prototype, "size");
o([
  a({ type: String })
], s.prototype, "icon");
o([
  a({ type: String })
], s.prototype, "helpText");
o([
  a(k)
], s.prototype, "showDropdown");
o([
  a({ type: String })
], s.prototype, "dropdown");
o([
  a({ type: String })
], s.prototype, "dropdownPlacement");
o([
  a(k)
], s.prototype, "dropdownFixed");
o([
  a({ type: Array })
], s.prototype, "customTimeListOptions");
o([
  a({ type: String })
], s.prototype, "errorTimeFormatText");
o([
  a({ type: String })
], s.prototype, "errorTimeOptionText");
o([
  a({ type: Number })
], s.prototype, "minHour");
o([
  a({ type: Number })
], s.prototype, "maxHour");
o([
  a({ type: Number })
], s.prototype, "minutesRange");
o([
  M()
], s.prototype, "_isFocused");
o([
  M()
], s.prototype, "_isTruncated");
o([
  M()
], s.prototype, "_labelClicked");
export {
  s as FormTimepicker
};
//# sourceMappingURL=form-timepicker.js.map
