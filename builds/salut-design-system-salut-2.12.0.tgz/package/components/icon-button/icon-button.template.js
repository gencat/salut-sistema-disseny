import { classMap as d } from "lit/directives/class-map.js";
import { when as $ } from "lit/directives/when.js";
import { unsafeStatic as e, literal as b, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as r } from "../../api/custom-element-scope.js";
const s = b`dss-icon${e(r())}`, l = b`dss-tooltip${e(r())}`, t = (i) => a`
  ${$(
  i.label && !i.hideTooltip,
  () => a`
      <${l} 
        position="top" 
        ?tooltipFixed=${i.tooltipFixed}
        aria-hidden="true">
        ${i.label}
      </${l}>
    `
)}
`, f = (i) => a`
  ${$(
  i.ariaExpanded !== void 0,
  () => a`
    <button
      type=${i.type}
      class=${d({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
      ?disabled=${i.disabled}
      ?hidden=${i.hidden}
      aria-expanded=${i.ariaExpanded}
      aria-label="${i.ariaLabel ?? i.label}"
      tabindex="${i.disableTabindex ? "-1" : "0"}"
      @click=${i._handleClick}
    >
      <${s} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}"></${s}>
      ${t(i)}
    </button>
  `,
  () => a`
      <button
        type=${i.type}
        class=${d({
    "dss-icon-button": !0,
    [`dss-icon-button--${i.variant}`]: !!i.variant,
    [`dss-icon-button--${i.size}`]: !!i.size
  })}
        ?disabled=${i.disabled}
        ?hidden=${i.hidden}
        aria-label="${i.label}"
        tabindex="${i.disableTabindex ? "-1" : "0"}"
        @click=${i._handleClick}
      >
        <${s} class="dss-icon-button__icon" icon="${i.icon}" size="${i.size}"></${s}>
        ${t(i)}
      </button>
    `
)}
`;
export {
  f as template
};
//# sourceMappingURL=icon-button.template.js.map
