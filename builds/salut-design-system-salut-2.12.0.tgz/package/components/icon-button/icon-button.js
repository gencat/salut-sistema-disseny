import { LitElement as y, unsafeCSS as d } from "lit";
import { property as t } from "lit/decorators.js";
import h from "../../shared/reset.style.css.js";
import { booleanType as r } from "../../utils/property-types.js";
import m from "./icon-button.style.css.js";
import { template as f } from "./icon-button.template.js";
var b = Object.defineProperty, e = (p, a, n, u) => {
  for (var o = void 0, s = p.length - 1, l; s >= 0; s--)
    (l = p[s]) && (o = l(a, n, o) || o);
  return o && b(a, n, o), o;
};
class i extends y {
  constructor() {
    super(...arguments), this.type = "button", this.variant = "primary", this.size = "md", this.label = "", this.icon = void 0, this.disabled = !1, this.hidden = !1, this.disableTabindex = !1, this.ariaLabel = null, this.ariaExpanded = void 0, this.tooltipFixed = !1, this.hideTooltip = !1;
  }
  static get styles() {
    return [d(h), d(m)];
  }
  _handleClick() {
    this.dispatchEvent(new CustomEvent("onClick", { bubbles: !0, composed: !0 }));
  }
  render() {
    return f(this);
  }
}
e([
  t({ type: String })
], i.prototype, "type");
e([
  t({ type: String })
], i.prototype, "variant");
e([
  t({ type: String })
], i.prototype, "size");
e([
  t({ type: String })
], i.prototype, "label");
e([
  t({ type: String })
], i.prototype, "icon");
e([
  t(r)
], i.prototype, "disabled");
e([
  t(r)
], i.prototype, "hidden");
e([
  t(r)
], i.prototype, "disableTabindex");
e([
  t({ type: String })
], i.prototype, "ariaLabel");
e([
  t(r)
], i.prototype, "ariaExpanded");
e([
  t(r)
], i.prototype, "tooltipFixed");
e([
  t(r)
], i.prototype, "hideTooltip");
export {
  i as IconButton
};
//# sourceMappingURL=icon-button.js.map
