import { nothing as e } from "lit";
import { classMap as u } from "lit/directives/class-map.js";
import { unsafeStatic as t, literal as n, html as d } from "lit/static-html.js";
import { getCustomElementSuffix as l } from "../../api/custom-element-scope.js";
import { checkTextTruncate as r, checkWebkitTruncate as o } from "../../utils/helpers.js";
const p = n`dss-icon-button${t(l())}`, $ = n`dss-button${t(l())}`, a = n`dss-icon${t(l())}`, _ = n`dss-badge${t(l())}`, i = n`dss-tooltip${t(l())}`, m = (s) => d`
  <div
    class=${u({
  "dss-header-menu-patient": !0,
  "dss-header-menu-patient--jcef": s.jcef,
  [`dss-header-menu-patient--${s.variant}`]: !!s.variant
})}
  >
    <div class="dss-header-menu-patient-avatar">
      <slot name="avatar"></slot>
    </div>
    <div class="dss-header-menu-patient-details">
      <div class="dss-header-menu-patient-details__name">
        ${s.name}
      </div>
      <div class="dss-header-menu-patient-details__info">
        ${s.cip ? d`
            <span class="dss-header-menu-patient-details__info-label dss-header-menu-patient-details__info-label--cip">
              ${s.cip}
            </span>
            <span class="divider-v divider-v--cip"></span>
          ` : null}
        ${s.age ? d`
            <span class="dss-header-menu-patient-details__info-label">
              ${s.age}
            </span>
            <span class="divider-v"></span>
          ` : null}
        ${s.gender ? d`
            <span class="dss-header-menu-patient-details__info-label">
              ${s.gender}
            </span>
          ` : null}
      </div>
    </div>
    <${p}
      class="dss-header-menu-patient__toggle-action"
      icon="${s._toggleIcon}"
      label="${s._toggleLabel}"
      variant="primary"
      @onClick="${s._toggleDropdown}"
      ?disabled=${s.disabled}
      ariaLabel="${s._toggleLabel} menú pacient"
      ariaExpanded="${s._showDropdown ? "true" : "false"}"
    ></${p}>
    ${s._showDropdown ? d`
          <div
            id="menu-patient"
            class=${u({
  "dss-header-menu-patient-dropdown": !0,
  "dss-header-menu-patient-dropdown--expanded": !!s._showDropdown
})}
          >
            <div class="dss-header-menu-patient-dropdown__info">
              <div class="dss-header-menu-patient-dropdown__title">
                ${s.infoLabel}
              </div>

              <div class="dss-header-menu-patient-dropdown__content">
                <div class="dss-header-menu-patient-dropdown__subtitle">
                  ${s.name}
                </div>

                ${s.cip ? d`
                  <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--cip">
                    <span class="dss-header-menu-patient-dropdown__description__cip">
                      ${s.cip}
                    </span>
                    ${s.hideCopyCip ? e : d`
                        <${p}
                          icon="content_copy"
                          size="sm"
                          label="Copiar CIP"
                          variant="primary"
                          @onClick="${s._handleCIPClick}"
                          ?disabled=${s.disabled}
                        ></${p}>
                      `}
                   
                  </div>
                  ` : e}

                ${s.age ? d`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="person" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.age}
                      </div>
                    </div>
                  ` : e}

                ${s.gender ? d`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="${s._getGenderIcon()}" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.gender}
                      </div>
                    </div>
                  ` : e}

                ${s.phoneMain ? d`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.phoneMain}
                      </div>
                    </div>
                  ` : e}

                ${s.phoneAlt ? d`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="phone" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description">
                        ${s.phoneAlt}
                      </div>
                    </div>
                  ` : e}

                ${s.mail ? d`
                    <div class="dss-header-menu-patient-dropdown__group">
                      <${a} icon="mail" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                        
                        ${s.mail}
                        <${i} class="description-tooltip" aria-hidden="true">
                          ${s.mail}
                        </${i}>
                      </div>
                    </div>
                 
                  ` : e}

                ${s.address ? d`
                    <div class="dss-header-menu-patient-dropdown__group dss-header-menu-patient-dropdown__group--address">
                      <${a} class="address-icon" icon="home_work" size="sm"></${a}>
                      <div class="dss-header-menu-patient-dropdown__description dss-header-menu-patient-dropdown__description--address" @mouseenter=${o}>
                        <a class="dss-header-menu-patient-dropdown__link" href="${s.addressURL}" target="_blank" rel="noopener">
                          ${s.address}
                        </a>
                        <${i} class="description-tooltip" aria-hidden="true">
                          ${s.address}
                        </${i}>
                      </div>
                    </div>
                  ` : e}

                ${s.assignments ? d`
                  <div class="dss-header-menu-patient-dropdown__assignments">
                    <div class="dss-header-menu-patient-dropdown__title dss-header-menu-patient-dropdown__title--assigned">
                      ${s.assignedLabel}
                    </div>

                    ${s.assignments.uab ? d`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAB</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${s.assignments.uab}
                          <${i} class="description-tooltip" aria-hidden="true">
                            ${s.assignments.uab}
                          </${i}>
                        </div>
                      </div>
                      ` : e} 

                    ${s.assignments.ui ? d`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UI</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${s.assignments.ui}
                          <${i} class="description-tooltip" aria-hidden="true">
                            ${s.assignments.ui}
                          </${i}>
                        </div>
                      </div>
                      ` : e} 

                    ${s.assignments.uas ? d`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__area">UAS</div>
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${s.assignments.uas}
                          <${i} class="description-tooltip" aria-hidden="true">
                            ${s.assignments.uas}
                          </${i}>
                        </div>
                      </div>
                      ` : e} 

                    ${s.assignments.center ? d`
                      <div class="dss-header-menu-patient-dropdown__group">
                        <div class="dss-header-menu-patient-dropdown__description" @mouseenter=${r}>
                          ${s.assignments.center}
                          <${i} class="description-tooltip" aria-hidden="true">
                            ${s.assignments.center}
                          </${i}>
                        </div>
                        ${s.assignments.up ? d`
                          <${_} size="sm" state="info" outlined text="${s.upLabel}">
                            <${i} slot="tooltip"> 
                              ${s.upMessage} 
                            </${i}>
                          </${_}>
                        ` : e}
                      </div>
                      ` : e} 



                    
                  </div>
                ` : e}
              </div>
            </div>

            

            ${!s.hideViewDetails || s.edit ? d`
                <div class="dss-header-menu-patient-dropdown__actions">
                  ${s.hideViewDetails ? e : d`
                      <${$}
                        variant="link"
                        size="md"
                        label="${s.detailsLabel}"
                        fullWidth
                        @click="${s._handleViewDetails}"
                      </${$}>
                    `}
                  ${s.edit ? d`
                      <${$}
                        variant="link"
                        size="md"
                        label="${s.editLabel}"
                        icon="open_in_new" 
                        iconPosition="right"
                        fullWidth
                        @click="${s._handleEdit}"
                      </${$}>
                    ` : e}
                </div>` : e}

          </div>
        ` : null}
  </div>
`;
export {
  m as headerMenuPatientTemplate
};
//# sourceMappingURL=header-menu-patient.template.js.map
