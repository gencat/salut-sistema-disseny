import { nothing as e } from "lit";
import { classMap as r } from "lit/directives/class-map.js";
import { ifDefined as l } from "lit/directives/if-defined.js";
import { unsafeStatic as i, literal as h, html as a } from "lit/static-html.js";
import { getCustomElementSuffix as t } from "../../api/custom-element-scope.js";
const d = h`dss-icon${i(t())}`, _ = h`dss-spinner${i(t())}`, g = h`dss-tooltip${i(t())}`, b = h`dss-icon-button${i(t())}`, T = (s) => {
  var $, u, v;
  const f = {
    "dss-search-bar--invalid": s.invalid || !s._inputValidity,
    "dss-search-bar--disabled": s.disabled,
    "dss-search-bar--required": s.required,
    "dss-search-bar--read-only": s.readonly,
    "dss-search-bar--focused": s._isFocused,
    "dss-search-bar--default": !s.multiple,
    "dss-search-bar--multiple": s.multiple,
    "dss-search-bar--show-chips": s._showAllChips,
    "dss-search-bar--md": s.size === "md",
    "dss-search-bar--inner-focus": s.innerFocus,
    "dss-search-bar--has-value": s._showClearButton || (($ = s._input) == null ? void 0 : $.value) || s.searchTerms.length > 0
  }, y = {}, c = {};
  return a`
    <div class="dss-search">
        <div
          class="dss-search-bar ${r(f)}"
          role="combobox"
          aria-controls="search-catalog"
          aria-expanded=${l(s._showDropdown)}
        >
          <div class="dss-search-bar__icon">
            <${d} size="md" icon="${s.icon}"  @click=${s._focusInput}></${d}>
          </div>

          <div class="dss-search-bar__container">
            ${s.multiple ? a`
                  <div class="dss-search-bar__chips">
                    ${a`${s._generateSearchChips()}`}
                    ${!s._showAllChips && s.searchTerms.length > 5 ? a`
                          <div class="dss-chip__counter">
                            +${s.searchTerms.length - 5}
                            <${g}
                              class="dss-chip__tooltip"
                              position="bottom"
                              align="left"
                              noHeightLimit
                            >
                              ${s.searchTerms.slice(5, s.searchTerms.length).map(
    (w) => a`<span class="dss-chip__tooltip-item">
                                        ${w}
                                      </span>`
  )}
                            </${g}>
                          </div>
                        ` : null}
                  </div>
                ` : null}

            <div class="dss-search-bar__input">
              <label 
                class="dss-label" 
                for="${s._getEffectiveId()}" 
              >
                ${s.label}
              </label>
              <input
                class="dss-input"
                id=${s._getEffectiveId()}
                .type="text"
                .name="${s.name ?? e}"
                .placeholder=${s.placeholder}
                ?disabled=${s.disabled}
                ?readonly=${s.readonly}
                ?required=${s.required}
                ?autofocus=${s.autofocus}
                spellcheck=${s.spellcheck ? "true" : "false"}
                autocorrect=${s.autocorrect ? "on" : "off"}
                autocomplete=${s.autocomplete}
                autocapitalize=${s.autocapitalize}
                pattern=${s.pattern ?? e}
                inputmode=${s.inputmode ?? e}
                @input=${s._handleInput}
                @change=${s._handleChange}
                @keydown=${s._handleKeyDown}
                @focusin=${s._handleFocusIn}
                @focusout=${s._handleFocusOut}
              />
            </div>
          </div>

          <div class="dss-search-bar__clear">
            <${b} 
              icon="cancel"
              variant="primary"
              size="md"
              @click=${s._clearSearch}
              label="Esborra la cerca"
            >
            </${b}>
          </div>
        </div>

        ${s.helpText ? a`
              <div class="dss-search-help ${r(y)}">
                <span>${s.helpText}</span>
              </div>
            ` : null}

        ${s._showDropdown && s.isCatalogLoading && ((u = s.catalog) == null ? void 0 : u.length) === 0 && s._input.value.length >= s.threshold ? a`
              <div
                id="search-catalog"
                class="dss-search-dropdown ${r(c)}"
                style=${l(s._dropdownStyle)}
              >
                <div class="dss-search-catalog--empty">
                  <${_} size="md"/>
                </div>
              </div>
            ` : e}

        ${s._showDropdown && ((v = s.catalog) == null ? void 0 : v.length) > 0 && s._input.value.length >= s.threshold ? a`
              <div
                id="search-catalog"
                class="dss-search-dropdown ${r(c)}"
                style=${l(s._dropdownStyle)}
              >
                ${s.isCatalogLoading ? a`
                      <div class="dss-search-catalog--empty">
											  <${_} size="md"/>
                      </div>
                    ` : a`
                      ${s._filteredCatalog.length > 0 ? a`
                            ${s.recentSearches ? a`
                                  <div class="dss-search-title">
                                    ${s.recentSearchesLabel}
                                  </div>
                                ` : null}
                            <div 
                              class="dss-search-catalog" 
                              role="listbox" 
                              aria-label="Search Catalog"
                              style=${l(s.catalogStyle)}
                            >
                              ${a`${s._generateFilterCatalog()}`}
                            </div>
                          ` : a`
                            <div
                              class="dss-search-catalog dss-search-catalog--empty"
                              style=${l(s.catalogStyle)}
                            >
                              <${d} size="sm" icon="info"></${d}>
                              <span class="text">
                                ${s.emptyDropdownText}: ${s._input.value}
                              </span>
                            </div>
                          `}
                    `}
              </div>
            ` : null}
      </div>
  `;
};
export {
  T as template
};
//# sourceMappingURL=searchbar.template.js.map
