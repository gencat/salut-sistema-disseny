import { classMap as d } from "lit/directives/class-map.js";
import { unsafeHTML as u } from "lit/directives/unsafe-html.js";
import { unsafeStatic as t, literal as i, html as l } from "lit/static-html.js";
import { getCustomElementSuffix as e } from "../../api/custom-element-scope.js";
const r = i`dss-icon${t(e())}`, $ = i`dss-icon-button${t(e())}`, a = i`dss-button${t(e())}`, c = (s) => l`
  <div
    class=${d({
  "dss-alert": !0,
  [`dss-alert--${s.size}`]: !!s.size,
  [`dss-alert--${s.state}`]: !!s.state,
  "dss-alert--full-width": s.fullWidth,
  "dss-alert--button-bottom": s.buttonBottom
})}
  >
    <div class="dss-alert-body">
      ${s.size !== "sm" ? l`
            <div class="dss-alert__icon">
              <${r} size="${s._getIconSize()}" icon="${s._stateIcon}"></${r}>
            </div>
          ` : null}
      <div class="dss-alert-content">
        <div
          class=${d({
  "dss-alert__text": !0,
  "dss-alert__text--expanded": s.expanded
})}>
          ${u(s.message)}
        </div>
        ${s.isOverflowing ? l`
          <${a}
            class="dss-alert__show-more"
            size="sm"
            variant="subtle"
            label="${s.expanded ? s.showLessLabel : s.showMoreLabel}"
            @onClick="${s.toggleExpand}"
          ></${a}>
          ` : null}
      </div>
    </div>
    ${s.hasCloseIcon ? l`
          <div class="dss-alert-action">
            <${$}
              class="dss-alert__icon-button"
              icon="close"
              label="Tancar"
              size="${s._getIconSize()}"
              variant="${s.state}"
              @onClick="${s._handleClose}"
            ></${$}>
          </div>
        ` : null}
    ${s.size === "lg" && s.hasButton ? l`
          <div class="dss-alert-action">
            <${a}
              size="sm"
              variant="${s.state}"
              label="${s.buttonLabel}"
              @onClick="${s._handleButtonClick}"
            ></${a}>
          </div>
        ` : null}
  </div>
`;
export {
  c as alertTemplate
};
//# sourceMappingURL=alert.template.js.map
